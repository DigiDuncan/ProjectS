import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import java.util.Random;













public class sq
  extends nn
{
  private boolean a;
  private double b;
  private int c;
  private double d;
  private double e;
  private double f;
  private double g;
  private double h;
  @SideOnly(Side.CLIENT)
  private double i;
  @SideOnly(Side.CLIENT)
  private double j;
  @SideOnly(Side.CLIENT)
  private double au;
  private nn throwingEntity;
  
  public sq(abw par1World)
  {
    super(par1World);
    a = true;
    b = 0.07D;
    m = true;
    a(1.5F, 0.6F);
    N = (P / 2.0F);
    throwingEntity = null;
  }
  




  protected boolean e_()
  {
    return false;
  }
  
  protected void a()
  {
    ah.a(17, new Integer(0));
    ah.a(18, new Integer(1));
    ah.a(19, new Float(0.0F));
  }
  




  public asx g(nn par1Entity)
  {
    return E;
  }
  



  public asx E()
  {
    return E;
  }
  



  public boolean M()
  {
    return true;
  }
  
  public sq(abw par1World, double par2, double par4, double par6)
  {
    this(par1World);
    b(par2, par4 + N, par6);
    x = 0.0D;
    y = 0.0D;
    z = 0.0D;
    r = par2;
    s = par4;
    t = par6;
  }
  



  public double Y()
  {
    return P * 0.0D - 0.30000001192092896D;
  }
  



  public boolean a(nb par1DamageSource, float par2)
  {
    if (ar())
    {
      return false;
    }
    if ((!q.I) && (!M))
    {
      c(-h());
      a(10);
      a(d() + par2 * 10.0F);
      K();
      boolean flag = ((par1DamageSource.i() instanceof uf)) && (ibG.d);
      
      if ((flag) || (d() > 40.0F))
      {
        if (n != null)
        {
          n.a((n instanceof uf) ? this : null);
        }
        
        if (!flag)
        {
          a(aGcv, 1, 0.0F);
        }
        
        x();
      }
      
      return true;
    }
    

    return true;
  }
  





  @SideOnly(Side.CLIENT)
  public void ad()
  {
    c(-h());
    a(10);
    a(d() * 11.0F);
  }
  



  public boolean L()
  {
    return !M;
  }
  





  @SideOnly(Side.CLIENT)
  public void a(double par1, double par3, double par5, float par7, float par8, int par9)
  {
    if ((a) && (holdingEntity == null) && (throwingEntity == null))
    {
      c = (par9 + 5);
    }
    else if ((holdingEntity == null) && (throwingEntity == null))
    {
      double d3 = par1 - u;
      double d4 = par3 - v;
      double d5 = par5 - w;
      double d6 = d3 * d3 + d4 * d4 + d5 * d5;
      
      if (d6 <= 1.0D)
      {
        return;
      }
      
      c = 3;
    }
    
    d = par1;
    e = par3;
    f = par5;
    g = par7;
    h = par8;
    x = i;
    y = j;
    z = au;
  }
  




  @SideOnly(Side.CLIENT)
  public void h(double par1, double par3, double par5)
  {
    i = (this.x = par1);
    j = (this.y = par3);
    au = (this.z = par5);
  }
  
  public void getDroppedByEntity(nn par1Entity)
  {
    nn holder = holdingEntity;
    super.getDroppedByEntity(par1Entity);
    if ((holder != null) && (holdingEntity == null))
    {
      throwingEntity = holder;
    }
  }
  



  public void l_()
  {
    super.l_();
    
    if (e() > 0)
    {
      a(e() - 1);
    }
    
    if (d() > 0.0F)
    {
      a(d() - 1.0F);
    }
    
    if ((holdingEntity != null) || (F) || (ae))
    {
      throwingEntity = null;
    }
    
    r = u;
    s = v;
    t = w;
    byte b0 = 5;
    double d0 = 0.0D;
    boolean actuallyInWater = false;
    
    for (int i = 0; i < b0; i++)
    {
      double d1 = E.b + (E.e - E.b) * (i + 0) / b0 - 0.125D;
      double d2 = E.b + (E.e - E.b) * (i + 1) / b0 - 0.125D;
      asx axisalignedbb = asx.a().a(E.a, d1, E.c, E.d, d2, E.f);
      
      if (q.b(axisalignedbb, akc.h))
      {
        actuallyInWater = true;
        d0 += 1.0D / b0;
      }
    }
    
    double d3 = Math.sqrt(x * x + z * z);
    


    if ((d3 > 0.26249999999999996D) && (actuallyInWater))
    {
      double d4 = Math.cos(A * 3.141592653589793D / 180.0D);
      double d5 = Math.sin(A * 3.141592653589793D / 180.0D);
      
      for (int j = 0; j < 1.0D + d3 * 60.0D; j++)
      {
        double d6 = ab.nextFloat() * 2.0F - 1.0F;
        double d7 = (ab.nextInt(2) * 2 - 1) * 0.7D;
        


        if (ab.nextBoolean())
        {
          double d8 = u - d4 * d6 * 0.8D + d5 * d7;
          double d9 = w - d5 * d6 * 0.8D - d4 * d7;
          q.a("splash", d8, v - 0.125D, d9, x, y, z);
        }
        else
        {
          double d8 = u + d4 + d5 * d6 * 0.7D;
          double d9 = w + d5 - d4 * d6 * 0.7D;
          q.a("splash", d8, v - 0.125D, d9, x, y, z);
        }
      }
    }
    



    if ((q.I) && (a) && (holdingEntity == null) && (throwingEntity == null))
    {
      if (c > 0)
      {
        double d4 = u + (d - u) / c;
        double d5 = v + (e - v) / c;
        double d11 = w + (f - w) / c;
        double d10 = ls.g(g - A);
        A = ((float)(A + d10 / c));
        B = ((float)(B + (h - B) / c));
        c -= 1;
        b(d4, d5, d11);
        b(A, B);
      }
      else
      {
        double d4 = u + x;
        double d5 = v + y;
        double d11 = w + z;
        b(d4, d5, d11);
        
        if (F)
        {
          x *= 0.5D;
          y *= 0.5D;
          z *= 0.5D;
        }
        
        x *= 0.9900000095367432D;
        y *= 0.949999988079071D;
        z *= 0.9900000095367432D;
      }
    }
    else
    {
      if ((holdingEntity == null) && (throwingEntity == null))
      {
        if (d0 < 1.0D)
        {
          double d4 = d0 * 2.0D - 1.0D;
          y += 0.03999999910593033D * d4;
        }
        else
        {
          if (y < 0.0D)
          {
            y /= 2.0D;
          }
          
          y += 0.007000000216066837D;
        }
        
        if ((n != null) && ((n instanceof of)) && ((!n.isTiny()) || ((((of)n).aZ() != null) && ((((of)n).aZ().b() instanceof yy)))))
        {
          double d4 = n).bf;
          
          if (d4 > 0.0D)
          {
            double d5 = -Math.sin(n.A * 3.1415927F / 180.0F);
            double d11 = Math.cos(n.A * 3.1415927F / 180.0F);
            x += d5 * b * 0.05000000074505806D;
            z += d11 * b * 0.05000000074505806D;
          }
        }
        
        double d4 = Math.sqrt(x * x + z * z);
        
        if (d4 > 0.35D)
        {
          double d5 = 0.35D / d4;
          x *= d5;
          z *= d5;
          d4 = 0.35D;
        }
        
        if ((d4 > d3) && (b < 0.35D))
        {
          b += (0.35D - b) / 35.0D;
          
          if (b > 0.35D)
          {
            b = 0.35D;
          }
        }
        else
        {
          b -= (b - 0.07D) / 35.0D;
          
          if (b < 0.07D)
          {
            b = 0.07D;
          }
        }
      }
      
      if (F)
      {
        x *= 0.5D;
        y *= 0.5D;
        z *= 0.5D;
      }
      
      d(x, y, z);
      
      if ((G) && (d3 > 0.2D))
      {
        if ((!q.I) && (!M))
        {
          x();
          

          for (int k = 0; k < 3; k++)
          {
            a(CcF, 1, 0.0F);
          }
          
          for (k = 0; k < 2; k++)
          {
            a(Fcv, 1, 0.0F);
          }
        }
      }
      else
      {
        x *= 0.9900000095367432D;
        y *= 0.949999988079071D;
        z *= 0.9900000095367432D;
      }
      
      if ((holdingEntity == null) && (throwingEntity == null))
      {
        B = 0.0F;
        double d5 = A;
        double d11 = r - u;
        double d10 = t - w;
        
        if (d11 * d11 + d10 * d10 > 0.001D)
        {
          d5 = (float)(Math.atan2(d10, d11) * 180.0D / 3.141592653589793D);
        }
        
        double d12 = ls.g(d5 - A);
        
        if (d12 > 20.0D)
        {
          d12 = 20.0D;
        }
        
        if (d12 < -20.0D)
        {
          d12 = -20.0D;
        }
        
        A = ((float)(A + d12));
        b(A, B);
      }
      
      if (!q.I)
      {
        List list = q.b(this, E.b(0.20000000298023224D, 0.0D, 0.20000000298023224D));
        

        if ((list != null) && (!list.isEmpty()))
        {
          for (int l = 0; l < list.size(); l++)
          {
            nn entity = (nn)list.get(l);
            
            if ((entity != n) && (entity.M()) && ((entity instanceof sq)))
            {
              entity.f(this);
            }
          }
        }
        
        for (int l = 0; l < 4; l++)
        {
          int i1 = ls.c(u + (l % 2 - 0.5D) * 0.8D);
          int j1 = ls.c(w + (l / 2 - 0.5D) * 0.8D);
          
          for (int k1 = 0; k1 < 2; k1++)
          {
            int l1 = ls.c(v) + k1;
            int i2 = q.a(i1, l1, j1);
            
            if (i2 == aXcF)
            {
              q.i(i1, l1, j1);
            }
            else if (i2 == bEcF)
            {
              q.a(i1, l1, j1, true);
            }
          }
        }
        
        if ((n != null) && (n.M))
        {
          n = null;
        }
      }
    }
  }
  
  public float maxRiderWidth(nn par1Entity)
  {
    return O * 0.5F;
  }
  
  protected void throwRider(float par1)
  {
    if ((n != null) && (n.O > maxRiderWidth(n)))
    {
      n.a((n instanceof uf) ? this : null);
      

      for (int k = 0; k < 3; k++)
      {
        a(CcF, 1, 0.0F);
      }
      
      for (int l = 0; l < 2; l++)
      {
        a(Fcv, 1, 0.0F);
      }
      
      x();
    }
  }
  
  public void W()
  {
    if (n != null)
    {
      double d0 = Math.cos(A * 3.141592653589793D / 180.0D) * 0.4D;
      double d1 = Math.sin(A * 3.141592653589793D / 180.0D) * 0.4D;
      n.b(u + d0, v + Y() + n.X(), w + d1);
    }
  }
  


  protected void b(by par1NBTTagCompound) {}
  


  protected void a(by par1NBTTagCompound) {}
  


  @SideOnly(Side.CLIENT)
  public float S()
  {
    return 0.0F;
  }
  



  public boolean c(uf par1EntityPlayer)
  {
    if ((n != null) && ((n instanceof uf)) && (n != par1EntityPlayer))
    {
      return true;
    }
    

    if ((!q.I) && (O <= maxRiderWidth(par1EntityPlayer)))
    {
      par1EntityPlayer.a(this);
    }
    
    return true;
  }
  




  public void a(float par1)
  {
    ah.b(19, Float.valueOf(par1));
  }
  



  public float d()
  {
    return ah.d(19);
  }
  



  public void a(int par1)
  {
    ah.b(17, Integer.valueOf(par1));
  }
  



  public int e()
  {
    return ah.c(17);
  }
  



  public void c(int par1)
  {
    ah.b(18, Integer.valueOf(par1));
  }
  



  public int h()
  {
    return ah.c(18);
  }
  
  @SideOnly(Side.CLIENT)
  public void a(boolean par1)
  {
    a = par1;
  }
}
