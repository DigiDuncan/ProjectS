import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import org.lwjgl.opengl.GL11;












@SideOnly(Side.CLIENT)
public class bht
  extends bhe
{
  private static final bjo a = new bjo("textures/entity/iron_golem.png");
  
  private final bcg f;
  

  public bht()
  {
    super(new bcg(), 0.5F);
    f = ((bcg)i);
  }
  



  public void a(sd par1EntityIronGolem, double par2, double par4, double par6, float par8, float par9)
  {
    super.a(par1EntityIronGolem, par2, par4, par6, par8, par9);
  }
  
  protected bjo a(sd par1EntityIronGolem)
  {
    return a;
  }
  



  protected void a(sd par1EntityIronGolem, float par2, float par3, float par4)
  {
    super.a(par1EntityIronGolem, par2, par3, par4);
    
    if (aG >= 0.01D)
    {
      float f3 = 13.0F;
      float f4 = aH - aG * (1.0F - par4) + 6.0F;
      float f5 = (Math.abs(f4 % f3 - f3 * 0.5F) - f3 * 0.25F) / (f3 * 0.25F);
      GL11.glRotatef(6.5F * f5, 0.0F, 0.0F, 1.0F);
    }
  }
  



  protected void a(sd par1EntityIronGolem, float par2)
  {
    super.c(par1EntityIronGolem, par2);
    
    if (par1EntityIronGolem.bV() != 0)
    {
      float sizeroot = par1EntityIronGolem.getSizeMultiplierRoot();
      
      GL11.glEnable(32826);
      GL11.glPushMatrix();
      GL11.glRotatef(5.0F + 180.0F * f.c.f / 3.1415927F, 1.0F, 0.0F, 0.0F);
      GL11.glTranslatef(-0.6875F, 1.25F, -1.2375F + 0.3F * sizeroot);
      GL11.glRotatef(90.0F, 1.0F, 0.0F, 0.0F);
      float f1 = 0.8F / sizeroot;
      GL11.glScalef(f1, -f1, f1);
      int i = par1EntityIronGolem.c(par2);
      int j = i % 65536;
      int k = i / 65536;
      bma.a(bma.b, j / 1.0F, k / 1.0F);
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
      a(bik.b);
      c.a(aqz.aj, 0, 1.0F);
      GL11.glPopMatrix();
      GL11.glDisable(32826);
    }
  }
  
  public void a(og par1EntityLiving, double par2, double par4, double par6, float par8, float par9)
  {
    a((sd)par1EntityLiving, par2, par4, par6, par8, par9);
  }
  
  protected void c(of par1EntityLivingBase, float par2)
  {
    a((sd)par1EntityLivingBase, par2);
  }
  
  protected void a(of par1EntityLivingBase, float par2, float par3, float par4)
  {
    a((sd)par1EntityLivingBase, par2, par3, par4);
  }
  
  public void a(of par1EntityLivingBase, double par2, double par4, double par6, float par8, float par9)
  {
    a((sd)par1EntityLivingBase, par2, par4, par6, par8, par9);
  }
  



  protected bjo a(nn par1Entity)
  {
    return a((sd)par1Entity);
  }
  






  public void a(nn par1Entity, double par2, double par4, double par6, float par8, float par9)
  {
    a((sd)par1Entity, par2, par4, par6, par8, par9);
  }
}
