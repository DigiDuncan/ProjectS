import java.util.Iterator;
import java.util.List;




public class pr
  extends ps
{
  rp a;
  rp b;
  double c;
  private int d;
  
  public pr(rp par1EntityAnimal, double par2)
  {
    a = par1EntityAnimal;
    c = par2;
  }
  



  public boolean a()
  {
    if (a.b() >= 0)
    {
      return false;
    }
    

    double range = a.getRangeMultiplier() * 4.0D;
    List list = a.q.a(a.getClass(), a.E.b(range * 2.0D, range, range * 2.0D));
    rp entityanimal = null;
    double d0 = Double.MAX_VALUE;
    Iterator iterator = list.iterator();
    
    while (iterator.hasNext())
    {
      rp entityanimal1 = (rp)iterator.next();
      
      if ((entityanimal1.b() >= 0) && (a.isEntityInRelativeSizeRange(entityanimal1, 0.4F, 2.5F)))
      {
        double d1 = a.e(entityanimal1);
        
        if (d1 <= d0)
        {
          d0 = d1;
          entityanimal = entityanimal1;
        }
      }
    }
    
    if (entityanimal == null)
    {
      return false;
    }
    if (d0 < 9.0D * (a.getRangeMultiplier() * a.getRangeMultiplier()))
    {
      return false;
    }
    

    b = entityanimal;
    return true;
  }
  





  public boolean b()
  {
    if (!b.T())
    {
      return false;
    }
    

    double d0 = a.e(b);
    return (d0 >= 9.0D * (a.getRangeMultiplier() * a.getRangeMultiplier())) && (d0 <= 256.0D * (a.getRangeMultiplier() * a.getRangeMultiplier()));
  }
  




  public void c()
  {
    d = 0;
  }
  



  public void d()
  {
    b = null;
  }
  



  public void e()
  {
    if (--d <= 0)
    {
      d = 10;
      a.k().a(b, c);
    }
  }
}
