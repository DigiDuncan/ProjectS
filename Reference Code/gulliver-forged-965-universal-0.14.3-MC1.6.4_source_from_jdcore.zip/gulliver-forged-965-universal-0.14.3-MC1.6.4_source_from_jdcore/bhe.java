import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import org.lwjgl.opengl.GL11;








@SideOnly(Side.CLIENT)
public abstract class bhe
  extends bhb
{
  public bhe(bbo par1ModelBase, float par2)
  {
    super(par1ModelBase, par2);
  }
  
  protected boolean b(og par1EntityLiving)
  {
    return (super.b(par1EntityLiving)) && ((par1EntityLiving.bd()) || ((par1EntityLiving.bB()) && (par1EntityLiving == b.i)));
  }
  
  public void a(og par1EntityLiving, double par2, double par4, double par6, float par8, float par9)
  {
    super.a(par1EntityLiving, par2, par4, par6, par8, par9);
    b(par1EntityLiving, par2, par4, par6, par8, par9);
  }
  
  private double a(double par1, double par3, double par5)
  {
    return par1 + (par3 - par1) * par5;
  }
  
  protected void b(og par1EntityLiving, double par2, double par4, double par6, float par8, float par9)
  {
    nn entity = par1EntityLiving.bI();
    
    if (entity != null)
    {
      double dsizemult = entity.getSizeMultiplier();
      
      double adj = 1.6D * dsizemult - P;
      if ((entity instanceof oc)) {}
      


      par4 += P / 1.2F;
      bfq tessellator = bfq.a;
      double d3 = a(C, A, par9 * 0.5F) * 0.01745329238474369D;
      double d4 = a(D, B, par9 * 0.5F) * 0.01745329238474369D;
      double d5 = Math.cos(d3);
      double d6 = Math.sin(d3);
      double d7 = Math.sin(d4);
      
      if ((entity instanceof oc))
      {
        d5 = 0.0D;
        d6 = 0.0D;
        d7 = -1.0D;
      }
      
      double d8 = Math.cos(d4);
      double d9 = a(r, u, par9) - d5 * 0.7D * dsizemult - d6 * 0.5D * d8 * dsizemult;
      double d10 = a(s + entity.f() * 0.7D, v + entity.f() * 0.7D, par9) - d7 * 0.5D * dsizemult - 0.25D * dsizemult;
      double d11 = a(t, w, par9) - d6 * 0.7D * dsizemult + d5 * 0.5D * d8 * dsizemult;
      double d12 = a(aO, aN, par9) * 0.01745329238474369D + 1.5707963267948966D;
      d5 = Math.cos(d12) * O * 0.4D;
      d6 = Math.sin(d12) * O * 0.4D;
      double d13 = a(r, u, par9) + d5;
      double d14 = a(s + P / 1.2F, v + P / 1.2F, par9);
      double d15 = a(t, w, par9) + d6;
      par2 += d5;
      par6 += d6;
      double d16 = (float)(d9 - d13);
      double d17 = (float)(d10 - d14);
      double d18 = (float)(d11 - d15);
      GL11.glDisable(3553);
      GL11.glDisable(2896);
      GL11.glDisable(2884);
      boolean flag = true;
      double d19 = 0.025D;
      tessellator.b(5);
      


      for (int i = 0; i <= 24; i++)
      {
        if (i % 2 == 0)
        {
          tessellator.a(0.5F, 0.4F, 0.3F, 1.0F);
        }
        else
        {
          tessellator.a(0.35F, 0.28F, 0.21000001F, 1.0F);
        }
        
        float f2 = i / 24.0F;
        tessellator.a(par2 + d16 * f2 + 0.0D, par4 + d17 * (f2 * f2 + f2) * 0.5D + 0.125F * (entity.getSizeMultiplier() * f2 + par1EntityLiving.getSizeMultiplier() * (1.0F - f2)), par6 + d18 * f2);
        tessellator.a(par2 + d16 * f2 + 0.025D * entity.getSizeMultiplierRoot(), par4 + d17 * (f2 * f2 + f2) * 0.5D + 0.125F * (entity.getSizeMultiplier() * f2 + par1EntityLiving.getSizeMultiplier() * (1.0F - f2)) + 0.025D * entity.getSizeMultiplierRoot(), par6 + d18 * f2);
      }
      
      tessellator.a();
      tessellator.b(5);
      
      for (i = 0; i <= 24; i++)
      {
        if (i % 2 == 0)
        {
          tessellator.a(0.5F, 0.4F, 0.3F, 1.0F);
        }
        else
        {
          tessellator.a(0.35F, 0.28F, 0.21000001F, 1.0F);
        }
        
        float f2 = i / 24.0F;
        tessellator.a(par2 + d16 * f2 + 0.0D, par4 + d17 * (f2 * f2 + f2) * 0.5D + 0.125F * (entity.getSizeMultiplier() * f2 + par1EntityLiving.getSizeMultiplier() * (1.0F - f2)) + 0.025D * entity.getSizeMultiplierRoot(), par6 + d18 * f2);
        tessellator.a(par2 + d16 * f2 + 0.025D * entity.getSizeMultiplierRoot(), par4 + d17 * (f2 * f2 + f2) * 0.5D + 0.125F * (entity.getSizeMultiplier() * f2 + par1EntityLiving.getSizeMultiplier() * (1.0F - f2)), par6 + d18 * f2 + 0.025D * entity.getSizeMultiplierRoot());
      }
      
      tessellator.a();
      GL11.glEnable(2896);
      GL11.glEnable(3553);
      GL11.glEnable(2884);
    }
  }
  
  protected boolean b(of par1EntityLivingBase)
  {
    return b((og)par1EntityLivingBase);
  }
  
  public void a(of par1EntityLivingBase, double par2, double par4, double par6, float par8, float par9)
  {
    a((og)par1EntityLivingBase, par2, par4, par6, par8, par9);
  }
  






  public void a(nn par1Entity, double par2, double par4, double par6, float par8, float par9)
  {
    a((og)par1Entity, par2, par4, par6, par8, par9);
  }
}
