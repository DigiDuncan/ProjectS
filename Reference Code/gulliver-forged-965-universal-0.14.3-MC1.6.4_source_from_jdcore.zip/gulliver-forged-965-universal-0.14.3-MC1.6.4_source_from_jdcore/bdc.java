import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import gulliver.client.EntityResizeableClientPlayerMP;
import java.util.Random;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.EventBus;
import net.minecraftforge.event.entity.player.PlayerDestroyItemEvent;

























@SideOnly(Side.CLIENT)
public class bdc
{
  private final atv a;
  private final bcw b;
  private int c = -1;
  

  private int d = -1;
  

  private int e = -1;
  

  private ye f;
  

  private float g;
  

  private float h;
  

  private int i;
  

  private boolean j;
  

  private ace k;
  

  private int l;
  


  public bdc(atv par1Minecraft, bcw par2NetClientHandler)
  {
    k = ace.b;
    a = par1Minecraft;
    b = par2NetClientHandler;
  }
  



  public static void a(atv par0Minecraft, bdc par1PlayerControllerMP, int par2, int par3, int par4, int par5)
  {
    if (!f.a(h, par2, par3, par4, par5))
    {
      par1PlayerControllerMP.a(par2, par3, par4, par5);
    }
  }
  



  public void a(uf par1EntityPlayer)
  {
    k.a(bG);
  }
  






  public boolean a()
  {
    return false;
  }
  



  public void a(ace par1EnumGameType)
  {
    k = par1EnumGameType;
    k.a(a.h.bG);
  }
  



  public void b(uf par1EntityPlayer)
  {
    A = -180.0F;
  }
  
  public boolean b()
  {
    return k.e();
  }
  



  public boolean a(int par1, int par2, int par3, int par4)
  {
    ye stack = a.h.by();
    if ((stack != null) && (stack.b() != null) && (stack.b().onBlockStartBreak(stack, par1, par2, par3, a.h)))
    {
      return false;
    }
    
    if ((this.k.c()) && (!a.h.d(par1, par2, par3)))
    {
      return false;
    }
    if ((this.k.d()) && (a.h.aZ() != null) && ((a.h.aZ().b() instanceof zl)))
    {
      return false;
    }
    

    bdd worldclient = a.f;
    aqz block = aqz.s[worldclient.a(par1, par2, par3)];
    
    if (block == null)
    {
      return false;
    }
    

    worldclient.e(2001, par1, par2, par3, cF + (worldclient.h(par1, par2, par3) << 12));
    int i1 = worldclient.h(par1, par2, par3);
    boolean flag = block.removeBlockByPlayer(worldclient, a.h, par1, par2, par3);
    
    if (flag)
    {
      block.g(worldclient, par1, par2, par3, i1);
    }
    
    d = -1;
    
    if (!this.k.d())
    {
      ye itemstack = a.h.by();
      
      if (itemstack != null)
      {
        itemstack.a(worldclient, cF, par1, par2, par3, a.h);
        
        if (b == 0)
        {
          a.h.bz();
        }
      }
      else if (a.h.isHuge())
      {

        for (int k = 0; k < 6; k++)
        {
          int p = k % 3 == 0 ? 1 : 0;
          int q = k % 3 == 1 ? 1 : 0;
          int r = k % 3 == 2 ? 1 : 0;
          int f = k % 2 * 2 - 1;
          if ((a.f.s.nextInt(3) != 0) && (cF == a.f.a(par1 + f * p, par2 + f * q, par3 + f * r)))
          {
            b.c(new fb(0, par1 + f * p, par2 + f * q, par3 + f * r, par4));
            b.c(new fb(2, par1 + f * p, par2 + f * q, par3 + f * r, par4));
            int mdata = worldclient.h(par1 + f * p, par2 + f * q, par3 + f * r);
            worldclient.e(2001, par1 + f * p, par2 + f * q, par3 + f * r, cF + (mdata << 12));
            boolean flag2 = worldclient.i(par1 + f * p, par2 + f * q, par3 + f * r);
            if (flag2)
            {
              block.g(worldclient, par1 + f * p, par2 + f * q, par3 + f * r, mdata);
            }
          }
        }
      }
    }
    
    return flag;
  }
  





  public void b(int par1, int par2, int par3, int par4)
  {
    if ((!k.c()) || (a.h.d(par1, par2, par3)))
    {
      if (k.d())
      {
        b.c(new fb(0, par1, par2, par3, par4));
        a(a, this, par1, par2, par3, par4);
        i = 5;
      }
      else if ((!j) || (!a(par1, par2, par3)))
      {
        if (j)
        {
          b.c(new fb(1, c, d, e, par4));
        }
        
        b.c(new fb(0, par1, par2, par3, par4));
        int i1 = a.f.a(par1, par2, par3);
        
        if ((i1 > 0) && (g == 0.0F))
        {
          aqz.s[i1].a(a.f, par1, par2, par3, a.h);
        }
        
        if ((i1 > 0) && (aqz.s[i1].a(a.h, a.h.q, par1, par2, par3) >= 1.0F))
        {
          a(par1, par2, par3, par4);
        }
        else
        {
          j = true;
          c = par1;
          d = par2;
          e = par3;
          f = a.h.aZ();
          g = 0.0F;
          h = 0.0F;
          a.f.f(a.h.k, c, d, e, (int)(g * 10.0F) - 1);
        }
      }
    }
  }
  



  public void c()
  {
    if (j)
    {
      b.c(new fb(1, c, d, e, -1));
    }
    
    j = false;
    g = 0.0F;
    a.f.f(a.h.k, c, d, e, -1);
  }
  



  public void c(int par1, int par2, int par3, int par4)
  {
    k();
    
    if (i > 0)
    {
      i -= 1;
    }
    else if (k.d())
    {
      i = 5;
      b.c(new fb(0, par1, par2, par3, par4));
      a(a, this, par1, par2, par3, par4);


    }
    else if (a(par1, par2, par3))
    {
      int i1 = a.f.a(par1, par2, par3);
      
      if (i1 == 0)
      {
        j = false;
        return;
      }
      
      aqz block = aqz.s[i1];
      g += block.a(a.h, a.h.q, par1, par2, par3);
      
      if ((h % 4.0F == 0.0F) && (block != null))
      {
        a.v.a(cS.e(), par1 + 0.5F, par2 + 0.5F, par3 + 0.5F, (cS.c() + 1.0F) / 8.0F, cS.d() * 0.5F);
      }
      
      h += 1.0F;
      
      if (g >= 1.0F)
      {
        j = false;
        b.c(new fb(2, par1, par2, par3, par4));
        a(par1, par2, par3, par4);
        g = 0.0F;
        h = 0.0F;
        i = 5;
      }
      
      a.f.f(a.h.k, c, d, e, (int)(g * 10.0F) - 1);
    }
    else
    {
      b(par1, par2, par3, par4);
    }
  }
  




  public float d()
  {
    return k.d() ? 5.0F : 4.5F;
  }
  
  public void e()
  {
    k();
    a.v.c();
  }
  
  private boolean a(int par1, int par2, int par3)
  {
    ye itemstack = a.h.aZ();
    boolean flag = (f == null) && (itemstack == null);
    
    if ((f != null) && (itemstack != null))
    {
      flag = (d == f.d) && (ye.a(itemstack, f)) && ((itemstack.g()) || (itemstack.k() == f.k()));
    }
    
    return (par1 == c) && (par2 == d) && (par3 == e) && (flag);
  }
  



  private void k()
  {
    int i = a.h.bn.c;
    
    if (i != l)
    {
      l = i;
      b.c(new fk(l));
    }
  }
  



  public boolean a(uf par1EntityPlayer, abw par2World, ye par3ItemStack, int par4, int par5, int par6, int par7, atc par8Vec3)
  {
    k();
    float f = (float)c - par4;
    float f1 = (float)d - par5;
    float f2 = (float)e - par6;
    boolean flag = false;
    
    if ((par3ItemStack != null) && (par3ItemStack.b() != null) && (par3ItemStack.b().onItemUseFirst(par3ItemStack, par1EntityPlayer, par2World, par4, par5, par6, par7, f, f1, f2)))
    {


      return true;
    }
    
    if ((!par1EntityPlayer.ah()) || (par1EntityPlayer.aZ() == null) || (par1EntityPlayer.aZ().b().shouldPassSneakingClickToBlock(par2World, par4, par5, par6)))
    {
      int i1 = par2World.a(par4, par5, par6);
      
      if ((i1 > 0) && (aqz.s[i1].a(par2World, par4, par5, par6, par1EntityPlayer, par7, f, f1, f2)))
      {
        flag = true;
      }
    }
    
    if ((!flag) && (par3ItemStack != null) && ((par3ItemStack.b() instanceof zh)))
    {
      zh itemblock = (zh)par3ItemStack.b();
      
      if (!itemblock.a(par2World, par4, par5, par6, par7, par1EntityPlayer, par3ItemStack))
      {
        return false;
      }
    }
    
    if (heldEntity != null)
    {
      par1EntityPlayer.dropHeldEntity(heldEntity);
    }
    
    b.c(new gk(par4, par5, par6, par7, bn.h(), f, f1, f2));
    
    if (flag)
    {
      return true;
    }
    if (par3ItemStack == null)
    {
      return false;
    }
    if (k.d())
    {
      int i1 = par3ItemStack.k();
      int j1 = b;
      boolean flag1 = par3ItemStack.a(par1EntityPlayer, par2World, par4, par5, par6, par7, f, f1, f2);
      par3ItemStack.b(i1);
      b = j1;
      return flag1;
    }
    

    if (!par3ItemStack.a(par1EntityPlayer, par2World, par4, par5, par6, par7, f, f1, f2))
    {
      return false;
    }
    if (b <= 0)
    {
      MinecraftForge.EVENT_BUS.post(new PlayerDestroyItemEvent(par1EntityPlayer, par3ItemStack));
    }
    return true;
  }
  




  public boolean a(uf par1EntityPlayer, abw par2World, ye par3ItemStack)
  {
    k();
    b.c(new gk(-1, -1, -1, 255, bn.h(), 0.0F, 0.0F, 0.0F));
    int i = b;
    ye itemstack1 = par3ItemStack.a(par2World, par1EntityPlayer);
    
    if ((itemstack1 == par3ItemStack) && ((itemstack1 == null) || (b == i)))
    {
      return false;
    }
    

    bn.a[bn.c] = itemstack1;
    
    if (b <= 0)
    {
      bn.a[bn.c] = null;
      MinecraftForge.EVENT_BUS.post(new PlayerDestroyItemEvent(par1EntityPlayer, itemstack1));
    }
    
    return true;
  }
  

  public bdi a(abw par1World)
  {
    return new EntityResizeableClientPlayerMP(a, par1World, a.H(), b);
  }
  



  public void a(uf par1EntityPlayer, nn par2Entity)
  {
    k();
    b.c(new eh(k, k, 1));
    par1EntityPlayer.q(par2Entity);
  }
  
  public boolean b(uf par1EntityPlayer, nn par2Entity)
  {
    k();
    b.c(new eh(k, k, 0));
    return par1EntityPlayer.p(par2Entity);
  }
  
  public ye a(int par1, int par2, int par3, int par4, uf par5EntityPlayer)
  {
    short short1 = bp.a(bn);
    ye itemstack = bp.a(par2, par3, par4, par5EntityPlayer);
    b.c(new du(par1, par2, par3, par4, itemstack, short1));
    return itemstack;
  }
  




  public void a(int par1, int par2)
  {
    b.c(new dt(par1, par2));
  }
  



  public void a(ye par1ItemStack, int par2)
  {
    if (k.d())
    {
      b.c(new fl(par2, par1ItemStack));
    }
  }
  
  public void a(ye par1ItemStack)
  {
    if ((k.d()) && (par1ItemStack != null))
    {
      b.c(new fl(-1, par1ItemStack));
    }
  }
  
  public void c(uf par1EntityPlayer)
  {
    k();
    b.c(new fb(5, 0, 0, 0, 255));
    par1EntityPlayer.bt();
  }
  
  public boolean f()
  {
    return k.e();
  }
  



  public boolean g()
  {
    return !k.d();
  }
  



  public boolean h()
  {
    return k.d();
  }
  



  public boolean i()
  {
    return k.d();
  }
  
  public boolean j()
  {
    return (a.h.ag()) && ((a.h.o instanceof rs)) && (!a.h.isTinierThan(a.h.o));
  }
}
