import java.util.Iterator;
import java.util.List;
import java.util.Random;












public class pk
  extends ps
{
  private rp d;
  abw a;
  private rp e;
  int b;
  double c;
  
  public pk(rp par1EntityAnimal, double par2)
  {
    d = par1EntityAnimal;
    a = q;
    c = par2;
    a(3);
    
    minTargetSize = 0.5F;
    maxTargetSize = 2.0F;
  }
  



  public boolean a()
  {
    if (!d.bY())
    {
      return false;
    }
    

    e = f();
    return e != null;
  }
  




  public boolean b()
  {
    return (e.T()) && (e.bY()) && (b < 60);
  }
  



  public void d()
  {
    e = null;
    b = 0;
  }
  



  public void e()
  {
    d.h().a(e, 10.0F, d.bp());
    d.k().a(e, c);
    b += 1;
    
    if ((b >= 60) && (d.isEntityInRelativeSizeRange(e, minTargetSize, maxTargetSize)) && (d.e(e) < 9.0D * d.getRangeMultiplier() * d.getRangeMultiplier()))
    {
      g();
    }
  }
  




  private rp f()
  {
    float f = 8.0F * d.getRangeMultiplier();
    List list = a.a(d.getClass(), d.E.b(f, f, f));
    double d0 = Double.MAX_VALUE;
    rp entityanimal = null;
    Iterator iterator = list.iterator();
    
    while (iterator.hasNext())
    {
      rp entityanimal1 = (rp)iterator.next();
      
      if ((d.a(entityanimal1)) && (d.isEntityInRelativeSizeRange(entityanimal1, minTargetSize, maxTargetSize)) && (d.e(entityanimal1) < d0))
      {
        entityanimal = entityanimal1;
        d0 = d.e(entityanimal1);
      }
    }
    
    return entityanimal;
  }
  



  private void g()
  {
    nk entityageable = d.a(e);
    
    if (entityageable != null)
    {
      d.c(6000);
      e.c(6000);
      d.bZ();
      e.bZ();
      entityageable.c(41536);
      
      float newsize = (d.getSizeMultiplier() + e.getSizeMultiplier()) * 0.5F;
      entityageable.setSizeBaseMultiplier(newsize);
      entityageable.doResize(newsize, false);
      entityageable.b(d.u, d.v, d.w, 0.0F, 0.0F);
      a.d(entityageable);
      Random random = d.aD();
      
      for (int i = 0; i < 7; i++)
      {
        double d0 = random.nextGaussian() * 0.02D;
        double d1 = random.nextGaussian() * 0.02D;
        double d2 = random.nextGaussian() * 0.02D;
        a.a("heart", d.u + random.nextFloat() * d.O * 2.0F - d.O, d.v + 0.5D + random.nextFloat() * d.P, d.w + random.nextFloat() * d.O * 2.0F - d.O, d0, d1, d2);
      }
      
      a.d(new oa(a, d.u, d.v, d.w, random.nextInt(7) + 1));
    }
  }
}
