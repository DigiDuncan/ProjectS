import com.google.common.collect.HashMultimap;
import com.google.common.collect.Multimap;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Random;
import java.util.UUID;
import net.minecraftforge.event.ForgeEventFactory;





















public final class ye
{
  public static final DecimalFormat a = new DecimalFormat("#.###");
  


  public int b;
  


  public int c;
  

  public int d;
  

  public by e;
  

  int f;
  

  private od g;
  


  public ye(aqz par1Block)
  {
    this(par1Block, 1);
  }
  
  public ye(aqz par1Block, int par2)
  {
    this(cF, par2, 0);
  }
  
  public ye(aqz par1Block, int par2, int par3)
  {
    this(cF, par2, par3);
  }
  
  public ye(yc par1Item)
  {
    this(cv, 1, 0);
  }
  
  public ye(yc par1Item, int par2)
  {
    this(cv, par2, 0);
  }
  
  public ye(yc par1Item, int par2, int par3)
  {
    this(cv, par2, par3);
  }
  
  public ye(int par1, int par2, int par3)
  {
    d = par1;
    b = par2;
    f = par3;
    
    if (f < 0)
    {
      f = 0;
    }
  }
  
  public static ye a(by par0NBTTagCompound)
  {
    ye itemstack = new ye();
    itemstack.c(par0NBTTagCompound);
    return itemstack.b() != null ? itemstack : null;
  }
  


  private ye() {}
  

  public ye a(int par1)
  {
    ye itemstack = new ye(d, par1, f);
    
    if (e != null)
    {
      e = ((by)e.b());
    }
    
    b -= par1;
    return itemstack;
  }
  



  public yc b()
  {
    return yc.g[d];
  }
  




  @SideOnly(Side.CLIENT)
  public ms c()
  {
    return b().h(this);
  }
  
  @SideOnly(Side.CLIENT)
  public int d()
  {
    return b().l();
  }
  
  public boolean a(uf par1EntityPlayer, abw par2World, int par3, int par4, int par5, int par6, float par7, float par8, float par9)
  {
    boolean flag = b().a(this, par1EntityPlayer, par2World, par3, par4, par5, par6, par7, par8, par9);
    
    if (flag)
    {
      par1EntityPlayer.a(la.E[d], 1);
    }
    
    return flag;
  }
  



  public float a(aqz par1Block)
  {
    return b().a(this, par1Block);
  }
  




  public ye a(abw par1World, uf par2EntityPlayer)
  {
    return b().a(this, par1World, par2EntityPlayer);
  }
  
  public ye b(abw par1World, uf par2EntityPlayer)
  {
    return b().b(this, par1World, par2EntityPlayer);
  }
  



  public by b(by par1NBTTagCompound)
  {
    par1NBTTagCompound.a("id", (short)d);
    par1NBTTagCompound.a("Count", (byte)b);
    par1NBTTagCompound.a("Damage", (short)f);
    
    if (e != null)
    {
      par1NBTTagCompound.a("tag", e);
    }
    
    return par1NBTTagCompound;
  }
  



  public void c(by par1NBTTagCompound)
  {
    d = par1NBTTagCompound.d("id");
    b = par1NBTTagCompound.c("Count");
    f = par1NBTTagCompound.d("Damage");
    
    if (f < 0)
    {
      f = 0;
    }
    
    if (par1NBTTagCompound.b("tag"))
    {
      e = par1NBTTagCompound.l("tag");
    }
  }
  



  public int e()
  {
    return b().getItemStackLimit(this);
  }
  



  public boolean f()
  {
    return (e() > 1) && ((!g()) || (!i()));
  }
  



  public boolean g()
  {
    return yc.g[d].getMaxDamage(this) > 0;
  }
  
  public boolean h()
  {
    return yc.g[d].n();
  }
  



  public boolean i()
  {
    boolean damaged = f > 0;
    if (b() != null) damaged = b().isDamaged(this);
    return (g()) && (damaged);
  }
  



  public int j()
  {
    if (b() != null)
    {
      return b().getDisplayDamage(this);
    }
    return f;
  }
  



  public int k()
  {
    if (b() != null)
    {
      return b().getDamage(this);
    }
    return f;
  }
  



  public void b(int par1)
  {
    if (b() != null)
    {
      b().setDamage(this, par1);
      return;
    }
    
    f = par1;
    
    if (f < 0)
    {
      f = 0;
    }
  }
  



  public int l()
  {
    return b().getMaxDamage(this);
  }
  






  public boolean a(int par1, Random par2Random)
  {
    if (!g())
    {
      return false;
    }
    

    if (par1 > 0)
    {
      int j = aaw.a(tz, this);
      int k = 0;
      
      for (int l = 0; (j > 0) && (l < par1); l++)
      {
        if (aas.a(this, j, par2Random))
        {
          k++;
        }
      }
      
      par1 -= k;
      
      if (par1 <= 0)
      {
        return false;
      }
    }
    
    b(k() + par1);
    return k() > l();
  }
  




  public void a(int par1, of par2EntityLivingBase)
  {
    if ((!(par2EntityLivingBase instanceof uf)) || (!bG.d))
    {
      if (g())
      {

        if (par1 > 0)
        {
          of damager = par2EntityLivingBase;
          
          if (((par2EntityLivingBase instanceof uf)) && (d == bTcv) && ((o instanceof ry)))
          {
            damager = (of)o;
          }
          
          float psize = damager.getSizeMultiplier();
          
          if (par1 * psize < 1.0F)
          {

            par1 = q.s.nextFloat() < par1 * damager.getSizeMultiplierRoot() ? 1 : 0;

          }
          else
          {
            par1 = (int)(par1 * psize);
          }
        }
        
        if (a(par1, par2EntityLivingBase.aD()))
        {
          par2EntityLivingBase.a(this);
          b -= 1;
          
          if ((par2EntityLivingBase instanceof uf))
          {
            uf entityplayer = (uf)par2EntityLivingBase;
            entityplayer.a(la.F[d], 1);
            
            if ((b == 0) && ((b() instanceof wp)))
            {
              entityplayer.bz();
            }
          }
          
          if (b < 0)
          {
            b = 0;
          }
          
          f = 0;
        }
      }
    }
  }
  



  public void a(of par1EntityLivingBase, uf par2EntityPlayer)
  {
    boolean flag = yc.g[d].a(this, par1EntityLivingBase, par2EntityPlayer);
    
    if (flag)
    {
      par2EntityPlayer.a(la.E[d], 1);
    }
  }
  
  public void a(abw par1World, int par2, int par3, int par4, int par5, uf par6EntityPlayer)
  {
    boolean flag = yc.g[d].a(this, par1World, par2, par3, par4, par5, par6EntityPlayer);
    
    if (flag)
    {
      par6EntityPlayer.a(la.E[d], 1);
    }
  }
  



  public boolean b(aqz par1Block)
  {
    return yc.g[d].canHarvestBlock(par1Block, this);
  }
  

  public boolean a(uf par1EntityPlayer, of par2EntityLivingBase)
  {
    if ((!(yc.g[d] instanceof yt)) || (!par1EntityPlayer.isTinierThan(par2EntityLivingBase)))
    {
      return yc.g[d].a(this, par1EntityPlayer, par2EntityLivingBase);
    }
    

    return false;
  }
  




  public ye m()
  {
    ye itemstack = new ye(d, b, f);
    
    if (e != null)
    {
      e = ((by)e.b());
    }
    
    return itemstack;
  }
  
  public static boolean a(ye par0ItemStack, ye par1ItemStack)
  {
    return (par0ItemStack == null) && (par1ItemStack == null);
  }
  



  public static boolean b(ye par0ItemStack, ye par1ItemStack)
  {
    return (par0ItemStack == null) && (par1ItemStack == null);
  }
  



  private boolean d(ye par1ItemStack)
  {
    return b == b;
  }
  




  public boolean a(ye par1ItemStack)
  {
    return (d == d) && (f == f);
  }
  
  public String a()
  {
    return yc.g[d].d(this);
  }
  



  public static ye b(ye par0ItemStack)
  {
    return par0ItemStack == null ? null : par0ItemStack.m();
  }
  
  public String toString()
  {
    return b + "x" + yc.g[d].a() + "@" + f;
  }
  




  public void a(abw par1World, nn par2Entity, int par3, boolean par4)
  {
    if (c > 0)
    {
      c -= 1;
    }
    
    yc.g[d].a(this, par1World, par2Entity, par3, par4);
  }
  
  public void a(abw par1World, uf par2EntityPlayer, int par3)
  {
    par2EntityPlayer.a(la.D[d], par3);
    yc.g[d].d(this, par1World, par2EntityPlayer);
  }
  
  public int n()
  {
    return b().d_(this);
  }
  
  public zj o()
  {
    return b().c_(this);
  }
  



  public void b(abw par1World, uf par2EntityPlayer, int par3)
  {
    b().a(this, par1World, par2EntityPlayer, par3);
  }
  



  public boolean p()
  {
    return e != null;
  }
  



  public by q()
  {
    return e;
  }
  
  public cg r()
  {
    return e == null ? null : (cg)e.a("ench");
  }
  



  public void d(by par1NBTTagCompound)
  {
    e = par1NBTTagCompound;
  }
  



  public String s()
  {
    String s = b().l(this);
    
    if ((e != null) && (e.b("display")))
    {
      by nbttagcompound = e.l("display");
      
      if (nbttagcompound.b("Name"))
      {
        s = nbttagcompound.i("Name");
      }
    }
    
    return s;
  }
  



  public void c(String par1Str)
  {
    if (e == null)
    {
      e = new by("tag");
    }
    
    if (!e.b("display"))
    {
      e.a("display", new by());
    }
    
    e.l("display").a("Name", par1Str);
  }
  
  public void t()
  {
    if (e != null)
    {
      if (e.b("display"))
      {
        by nbttagcompound = e.l("display");
        nbttagcompound.o("Name");
        
        if (nbttagcompound.d())
        {
          e.o("display");
          
          if (e.d())
          {
            d((by)null);
          }
        }
      }
    }
  }
  



  public boolean u()
  {
    return !e.b("display") ? false : e == null ? false : e.l("display").b("Name");
  }
  




  @SideOnly(Side.CLIENT)
  public List a(uf par1EntityPlayer, boolean par2)
  {
    ArrayList arraylist = new ArrayList();
    yc item = yc.g[d];
    String s = s();
    
    if (u())
    {
      s = a.u + s + a.v;
    }
    
    if (par2)
    {
      String s1 = "";
      
      if (s.length() > 0)
      {
        s = s + " (";
        s1 = ")";
      }
      
      if (h())
      {
        s = s + String.format("#%04d/%d%s", new Object[] { Integer.valueOf(d), Integer.valueOf(f), s1 });
      }
      else
      {
        s = s + String.format("#%04d%s", new Object[] { Integer.valueOf(d), s1 });
      }
    }
    else if ((!u()) && (d == bfcv))
    {
      s = s + " #" + f;
    }
    
    arraylist.add(s);
    item.a(this, par1EntityPlayer, arraylist, par2);
    
    if (p())
    {
      cg nbttaglist = r();
      
      if (nbttaglist != null)
      {
        for (int i = 0; i < nbttaglist.c(); i++)
        {
          short short1 = ((by)nbttaglist.b(i)).d("id");
          short short2 = ((by)nbttaglist.b(i)).d("lvl");
          
          if (aau.b[short1] != null)
          {
            arraylist.add(aau.b[short1].c(short2));
          }
        }
      }
      
      if (e.b("display"))
      {
        by nbttagcompound = e.l("display");
        
        if (nbttagcompound.b("color"))
        {
          if (par2)
          {
            arraylist.add("Color: #" + Integer.toHexString(nbttagcompound.e("color")).toUpperCase());
          }
          else
          {
            arraylist.add(a.u + bu.a("item.dyed"));
          }
        }
        
        if (nbttagcompound.b("Lore"))
        {
          cg nbttaglist1 = nbttagcompound.m("Lore");
          
          if (nbttaglist1.c() > 0)
          {
            for (int j = 0; j < nbttaglist1.c(); j++)
            {
              arraylist.add(a.f + "" + a.u + ba);
            }
          }
        }
      }
    }
    
    Multimap multimap = D();
    
    if (!multimap.isEmpty())
    {
      arraylist.add("");
      Iterator iterator = multimap.entries().iterator();
      
      while (iterator.hasNext())
      {
        Map.Entry entry = (Map.Entry)iterator.next();
        ot attributemodifier = (ot)entry.getValue();
        double d0 = attributemodifier.d();
        double d1;
        double d1;
        if ((attributemodifier.c() != 1) && (attributemodifier.c() != 2))
        {
          d1 = attributemodifier.d();
        }
        else
        {
          d1 = attributemodifier.d() * 100.0D;
        }
        
        if (d0 > 0.0D)
        {
          arraylist.add(a.j + bu.a(new StringBuilder().append("attribute.modifier.plus.").append(attributemodifier.c()).toString(), new Object[] { a.format(d1), bu.a("attribute.name." + (String)entry.getKey()) }));
        }
        else if (d0 < 0.0D)
        {
          d1 *= -1.0D;
          arraylist.add(a.m + bu.a(new StringBuilder().append("attribute.modifier.take.").append(attributemodifier.c()).toString(), new Object[] { a.format(d1), bu.a("attribute.name." + (String)entry.getKey()) }));
        }
      }
    }
    
    if ((par2) && (i()))
    {
      arraylist.add("Durability: " + (l() - j()) + " / " + l());
    }
    ForgeEventFactory.onItemTooltip(this, par1EntityPlayer, arraylist, par2);
    
    return arraylist;
  }
  
  @Deprecated
  @SideOnly(Side.CLIENT)
  public boolean v()
  {
    return hasEffect(0);
  }
  
  @SideOnly(Side.CLIENT)
  public boolean hasEffect(int pass) {
    return b().hasEffect(this, pass);
  }
  
  @SideOnly(Side.CLIENT)
  public yq w()
  {
    return b().f(this);
  }
  



  public boolean x()
  {
    return b().e_(this);
  }
  



  public void a(aau par1Enchantment, int par2)
  {
    if (e == null)
    {
      d(new by());
    }
    
    if (!e.b("ench"))
    {
      e.a("ench", new cg("ench"));
    }
    
    cg nbttaglist = (cg)e.a("ench");
    by nbttagcompound = new by();
    nbttagcompound.a("id", (short)z);
    nbttagcompound.a("lvl", (short)(byte)par2);
    nbttaglist.a(nbttagcompound);
  }
  



  public boolean y()
  {
    return (e != null) && (e.b("ench"));
  }
  
  public void a(String par1Str, cl par2NBTBase)
  {
    if (e == null)
    {
      d(new by());
    }
    
    e.a(par1Str, par2NBTBase);
  }
  
  public boolean z()
  {
    return b().z();
  }
  



  public boolean A()
  {
    return g != null;
  }
  



  public void a(od par1EntityItemFrame)
  {
    g = par1EntityItemFrame;
  }
  



  public od B()
  {
    return g;
  }
  



  public int C()
  {
    return (p()) && (e.b("RepairCost")) ? e.e("RepairCost") : 0;
  }
  



  public void c(int par1)
  {
    if (!p())
    {
      e = new by("tag");
    }
    
    e.a("RepairCost", par1);
  }
  



  public Multimap D()
  {
    Object object;
    

    if ((p()) && (e.b("AttributeModifiers")))
    {
      Object object = HashMultimap.create();
      cg nbttaglist = e.m("AttributeModifiers");
      
      for (int i = 0; i < nbttaglist.c(); i++)
      {
        by nbttagcompound = (by)nbttaglist.b(i);
        ot attributemodifier = tp.a(nbttagcompound);
        
        if ((attributemodifier.a().getLeastSignificantBits() != 0L) && (attributemodifier.a().getMostSignificantBits() != 0L))
        {
          ((Multimap)object).put(nbttagcompound.i("AttributeName"), attributemodifier);
        }
      }
    }
    else
    {
      object = b().h();
    }
    
    return (Multimap)object;
  }
}
