import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.Random;



























public class tf
  extends tm
{
  private int bp;
  private int bq;
  private int br = 30;
  

  private int bs = 3;
  
  public tf(abw par1World)
  {
    super(par1World);
    c.a(1, new pp(this));
    c.a(2, new qs(this));
    c.a(3, new pg(this, rx.class, 6.0F, 1.0D, 1.2D));
    c.a(4, new qa(this, 1.0D, false));
    c.a(5, new qm(this, 0.8D));
    c.a(6, new px(this, uf.class, 8.0F));
    c.a(6, new ql(this));
    d.a(1, new qy(this, uf.class, 0, true));
    d.a(2, new qx(this, false));
  }
  
  protected void az()
  {
    super.az();
    a(tp.d).a(0.25D);
  }
  



  public boolean bf()
  {
    return true;
  }
  



  public int as()
  {
    return m() == null ? 3 : 3 + (int)(aN() - 1.0F);
  }
  



  protected void b(float par1)
  {
    super.b(par1);
    bq = ((int)(bq + par1 * 1.5F));
    
    if (bq > br - 5)
    {
      bq = (br - 5);
    }
  }
  
  protected void a()
  {
    super.a();
    ah.a(16, Byte.valueOf((byte)-1));
    ah.a(17, Byte.valueOf((byte)0));
  }
  



  public void b(by par1NBTTagCompound)
  {
    super.b(par1NBTTagCompound);
    
    if (ah.a(17) == 1)
    {
      par1NBTTagCompound.a("powered", true);
    }
    
    par1NBTTagCompound.a("Fuse", (short)br);
    par1NBTTagCompound.a("ExplosionRadius", (byte)bs);
  }
  



  public void a(by par1NBTTagCompound)
  {
    super.a(par1NBTTagCompound);
    ah.b(17, Byte.valueOf((byte)(par1NBTTagCompound.n("powered") ? 1 : 0)));
    
    if (par1NBTTagCompound.b("Fuse"))
    {
      br = par1NBTTagCompound.d("Fuse");
    }
    
    if (par1NBTTagCompound.b("ExplosionRadius"))
    {
      bs = par1NBTTagCompound.c("ExplosionRadius");
    }
  }
  
  public void W()
  {
    if (n.O < O * 0.5F)
    {
      n.b(u, v + Y() * 1.45D + n.X(), w);
    }
    else
    {
      double d = Math.cos((aN - 90.0F) * 3.141592653589793D / 180.0D) * O * 0.45D;
      double d1 = Math.sin((aN - 90.0F) * 3.141592653589793D / 180.0D) * O * 0.45D;
      
      n.b(u + d, v + Y() + n.X(), w + d1);
    }
  }
  



  public double Y()
  {
    return P * 0.6D;
  }
  



  public void l_()
  {
    if (T())
    {
      bp = bq;
      int i = bV();
      
      if ((i > 0) && (bq == 0))
      {
        a("random.fuse", 1.0F, 0.5F);
      }
      
      bq += i;
      
      if (bq < 0)
      {
        bq = 0;
      }
      
      if (bq >= br)
      {
        bq = br;
        
        if (!q.I)
        {
          boolean flag = q.O().b("mobGriefing");
          
          float sizefactor = getSizeMultiplierRoot();
          if (sizefactor < 1.0F)
          {
            sizefactor = getSizeMultiplier();
          }
          
          if (bT())
          {
            q.a(this, u, v + P / 3.0D, w, bs * 2 * sizefactor, flag);
          }
          else
          {
            q.a(this, u, v + P / 3.0D, w, bs * sizefactor, flag);
          }
          
          x();
        }
      }
    }
    
    super.l_();
  }
  



  protected String aO()
  {
    return "mob.creeper.say";
  }
  



  protected String aP()
  {
    return "mob.creeper.death";
  }
  



  public void a(nb par1DamageSource)
  {
    super.a(par1DamageSource);
    
    if ((par1DamageSource.i() instanceof tr))
    {
      int i = cjcv + ab.nextInt(cucv - cjcv + 1);
      b(i, 1);
    }
  }
  
  public boolean m(nn par1Entity)
  {
    return true;
  }
  



  public boolean bT()
  {
    return ah.a(17) == 1;
  }
  




  @SideOnly(Side.CLIENT)
  public float a(float par1)
  {
    return (bp + (bq - bp) * par1) / (br - 2);
  }
  



  protected int s()
  {
    return Ocv;
  }
  



  public int bV()
  {
    return ah.a(16);
  }
  



  public void a(int par1)
  {
    ah.b(16, Byte.valueOf((byte)par1));
  }
  



  public void a(sp par1EntityLightningBolt)
  {
    super.a(par1EntityLightningBolt);
    ah.b(17, Byte.valueOf((byte)1));
  }
}
