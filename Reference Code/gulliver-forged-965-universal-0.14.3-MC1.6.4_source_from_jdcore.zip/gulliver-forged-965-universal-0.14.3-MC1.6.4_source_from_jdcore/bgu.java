import com.google.common.collect.Maps;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.Map;
import net.minecraftforge.client.ForgeHooksClient;
import net.minecraftforge.client.IItemRenderer;
import net.minecraftforge.client.IItemRenderer.ItemRenderType;
import net.minecraftforge.client.IItemRenderer.ItemRendererHelper;
import net.minecraftforge.client.MinecraftForgeClient;
import org.lwjgl.opengl.GL11;















@SideOnly(Side.CLIENT)
public class bgu
  extends bhe
{
  protected bbj a;
  protected float f;
  protected bbj g;
  protected bbj h;
  private static final Map k = ;
  

  public static String[] l = { "leather", "chainmail", "iron", "diamond", "gold" };
  
  public bgu(bbj par1ModelBiped, float par2)
  {
    this(par1ModelBiped, par2, 1.0F);
  }
  
  public bgu(bbj par1ModelBiped, float par2, float par3)
  {
    super(par1ModelBiped, par2);
    a = par1ModelBiped;
    f = par3;
    b();
  }
  
  protected void b()
  {
    g = new bbj(1.0F);
    h = new bbj(0.5F);
  }
  
  @Deprecated
  public static bjo a(wh par0ItemArmor, int par1)
  {
    return a(par0ItemArmor, par1, (String)null);
  }
  
  @Deprecated
  public static bjo a(wh par0ItemArmor, int par1, String par2Str)
  {
    String s1 = String.format("textures/models/armor/%s_layer_%d%s.png", new Object[] { l[d], Integer.valueOf(par1 == 2 ? 2 : 1), par2Str == null ? "" : String.format("_%s", new Object[] { par2Str }) });
    bjo resourcelocation = (bjo)k.get(s1);
    
    if (resourcelocation == null)
    {
      resourcelocation = new bjo(s1);
      k.put(s1, resourcelocation);
    }
    
    return resourcelocation;
  }
  









  public static bjo getArmorResource(nn entity, ye stack, int slot, String type)
  {
    wh item = (wh)stack.b();
    String s1 = String.format("textures/models/armor/%s_layer_%d%s.png", new Object[] { l[d], Integer.valueOf(slot == 2 ? 2 : 1), type == null ? "" : String.format("_%s", new Object[] { type }) });
    

    s1 = ForgeHooksClient.getArmorTexture(entity, stack, s1, slot, type);
    bjo resourcelocation = (bjo)k.get(s1);
    
    if (resourcelocation == null)
    {
      resourcelocation = new bjo(s1);
      k.put(s1, resourcelocation);
    }
    
    return resourcelocation;
  }
  
  protected int a(og par1EntityLiving, int par2, float par3)
  {
    ye itemstack = par1EntityLiving.o(3 - par2);
    
    if (itemstack != null)
    {
      yc item = itemstack.b();
      
      if ((item instanceof wh))
      {
        wh itemarmor = (wh)item;
        a(getArmorResource(par1EntityLiving, itemstack, par2, null));
        bbj modelbiped = par2 == 2 ? h : g;
        c.j = (par2 == 0);
        d.j = (par2 == 0);
        e.j = ((par2 == 1) || (par2 == 2));
        f.j = (par2 == 1);
        g.j = (par2 == 1);
        h.j = ((par2 == 2) || (par2 == 3));
        i.j = ((par2 == 2) || (par2 == 3));
        modelbiped = ForgeHooksClient.getArmorModel(par1EntityLiving, itemstack, par2, modelbiped);
        a(modelbiped);
        p = i.p;
        q = i.q;
        s = i.s;
        float f1 = 1.0F;
        

        int j = itemarmor.b(itemstack);
        if (j != -1)
        {
          float f2 = (j >> 16 & 0xFF) / 255.0F;
          float f3 = (j >> 8 & 0xFF) / 255.0F;
          float f4 = (j & 0xFF) / 255.0F;
          GL11.glColor3f(f1 * f2, f1 * f3, f1 * f4);
          
          if (itemstack.y())
          {
            return 31;
          }
          
          return 16;
        }
        
        GL11.glColor3f(f1, f1, f1);
        
        if (itemstack.y())
        {
          return 15;
        }
        
        return 1;
      }
    }
    
    return -1;
  }
  
  protected void b(og par1EntityLiving, int par2, float par3)
  {
    ye itemstack = par1EntityLiving.o(3 - par2);
    
    if (itemstack != null)
    {
      yc item = itemstack.b();
      
      if ((item instanceof wh))
      {
        a(getArmorResource(par1EntityLiving, itemstack, par2, "overlay"));
        float f1 = 1.0F;
        GL11.glColor3f(f1, f1, f1);
      }
    }
  }
  
  public void a(og par1EntityLiving, double par2, double par4, double par6, float par8, float par9)
  {
    float f2 = 1.0F;
    GL11.glColor3f(f2, f2, f2);
    ye itemstack = par1EntityLiving.aZ();
    a(par1EntityLiving, itemstack);
    double d3 = par4 - N;
    
    if (par1EntityLiving.ah())
    {
      d3 -= 0.125D;
    }
    
    super.a(par1EntityLiving, par2, d3, par6, par8, par9);
    g.o = (h.o = a.o = 0);
    g.n = (h.n = a.n = 0);
    g.m = (h.m = a.m = 0);
  }
  
  protected bjo a(og par1EntityLiving)
  {
    return null;
  }
  
  protected void a(og par1EntityLiving, ye par2ItemStack)
  {
    g.m = (h.m = a.m = heldEntity != null ? 4 : par2ItemStack != null ? 1 : 0);
    g.n = (h.n = a.n = par1EntityLiving.ah());
  }
  
  protected void a(og par1EntityLiving, float par2)
  {
    float f1 = 1.0F;
    GL11.glColor3f(f1, f1, f1);
    super.c(par1EntityLiving, par2);
    ye itemstack = par1EntityLiving.aZ();
    ye itemstack1 = par1EntityLiving.o(3);
    

    if (itemstack1 != null)
    {
      GL11.glPushMatrix();
      a.c.c(0.0625F);
      
      IItemRenderer customRenderer = MinecraftForgeClient.getItemRenderer(itemstack1, IItemRenderer.ItemRenderType.EQUIPPED);
      boolean is3D = (customRenderer != null) && (customRenderer.shouldUseRenderHelper(IItemRenderer.ItemRenderType.EQUIPPED, itemstack1, IItemRenderer.ItemRendererHelper.BLOCK_3D));
      
      if ((itemstack1.b() instanceof zh))
      {
        if ((is3D) || (bfr.a(aqz.s[d].d())))
        {
          float f2 = 0.625F;
          GL11.glTranslatef(0.0F, -0.25F, 0.0F);
          GL11.glRotatef(90.0F, 0.0F, 1.0F, 0.0F);
          GL11.glScalef(f2, -f2, -f2);
        }
        
        b.f.a(par1EntityLiving, itemstack1, 0);
      }
      else if (bcv == bScv)
      {
        float f2 = 1.0625F;
        GL11.glScalef(f2, -f2, -f2);
        String s = "";
        
        if ((itemstack1.p()) && (itemstack1.q().b("SkullOwner")))
        {
          s = itemstack1.q().i("SkullOwner");
        }
        
        bjb.a.a(-0.5F, 0.0F, -0.5F, 1, 180.0F, itemstack1.k(), s);
      }
      
      GL11.glPopMatrix();
    }
    
    if (itemstack != null)
    {
      GL11.glPushMatrix();
      
      if (i.s)
      {
        float f2 = 0.5F;
        GL11.glTranslatef(0.0F, 0.625F, 0.0F);
        GL11.glRotatef(-20.0F, -1.0F, 0.0F, 0.0F);
        GL11.glScalef(f2, f2, f2);
      }
      
      a.f.c(0.0625F);
      GL11.glTranslatef(-0.0625F, 0.4375F, 0.0625F);
      
      IItemRenderer customRenderer = MinecraftForgeClient.getItemRenderer(itemstack, IItemRenderer.ItemRenderType.EQUIPPED);
      boolean is3D = (customRenderer != null) && (customRenderer.shouldUseRenderHelper(IItemRenderer.ItemRenderType.EQUIPPED, itemstack, IItemRenderer.ItemRendererHelper.BLOCK_3D));
      
      if (((itemstack.b() instanceof zh)) && ((is3D) || (bfr.a(aqz.s[d].d()))))
      {
        float f2 = 0.5F;
        GL11.glTranslatef(0.0F, 0.1875F, -0.3125F);
        f2 *= 0.75F;
        GL11.glRotatef(20.0F, 1.0F, 0.0F, 0.0F);
        GL11.glRotatef(45.0F, 0.0F, 1.0F, 0.0F);
        GL11.glScalef(-f2, -f2, f2);
      }
      else if (d == mcv)
      {
        float f2 = 0.625F;
        GL11.glTranslatef(0.0F, 0.125F, 0.3125F);
        GL11.glRotatef(-20.0F, 0.0F, 1.0F, 0.0F);
        GL11.glScalef(f2, -f2, f2);
        GL11.glRotatef(-100.0F, 1.0F, 0.0F, 0.0F);
        GL11.glRotatef(45.0F, 0.0F, 1.0F, 0.0F);
      }
      else if (yc.g[d].n_())
      {
        float f2 = 0.625F;
        
        if (yc.g[d].o_())
        {
          GL11.glRotatef(180.0F, 0.0F, 0.0F, 1.0F);
          GL11.glTranslatef(0.0F, -0.125F, 0.0F);
        }
        
        c();
        GL11.glScalef(f2, -f2, f2);
        GL11.glRotatef(-100.0F, 1.0F, 0.0F, 0.0F);
        GL11.glRotatef(45.0F, 0.0F, 1.0F, 0.0F);
      }
      else
      {
        float f2 = 0.375F;
        GL11.glTranslatef(0.25F, 0.1875F, -0.1875F);
        GL11.glScalef(f2, f2, f2);
        GL11.glRotatef(60.0F, 0.0F, 0.0F, 1.0F);
        GL11.glRotatef(-90.0F, 1.0F, 0.0F, 0.0F);
        GL11.glRotatef(20.0F, 0.0F, 0.0F, 1.0F);
      }
      


      float mult = 1.0F / par1EntityLiving.getSizeMultiplierRoot();
      GL11.glScalef(mult, mult, mult);
      b.f.a(par1EntityLiving, itemstack, 0);
      
      if (itemstack.b().b())
      {
        for (int x = 1; x < itemstack.b().getRenderPasses(itemstack.k()); x++)
        {
          b.f.a(par1EntityLiving, itemstack, x);
        }
      }
      
      GL11.glPopMatrix();
    }
  }
  
  protected void c()
  {
    GL11.glTranslatef(0.0F, 0.1875F, 0.0F);
  }
  
  protected void c(of par1EntityLivingBase, int par2, float par3)
  {
    b((og)par1EntityLivingBase, par2, par3);
  }
  



  protected int a(of par1EntityLivingBase, int par2, float par3)
  {
    return a((og)par1EntityLivingBase, par2, par3);
  }
  
  protected void c(of par1EntityLivingBase, float par2)
  {
    a((og)par1EntityLivingBase, par2);
  }
  
  public void a(of par1EntityLivingBase, double par2, double par4, double par6, float par8, float par9)
  {
    a((og)par1EntityLivingBase, par2, par4, par6, par8, par9);
  }
  



  protected bjo a(nn par1Entity)
  {
    return a((og)par1Entity);
  }
  






  public void a(nn par1Entity, double par2, double par4, double par6, float par8, float par9)
  {
    a((og)par1Entity, par2, par4, par6, par8, par9);
  }
}
