import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import gulliver.network.packet.Packet172AttachEntitySpecial;
import java.util.List;
import java.util.Random;




















public class uh
  extends nn
  implements un
{
  private int d = -1;
  private int e = -1;
  private int f = -1;
  
  private int g;
  
  private int h;
  
  private boolean i;
  
  public int a;
  
  public int b;
  
  public nn c;
  private int j;
  private int au;
  private double av = 2.0D;
  
  private int aw;
  

  public uh(abw par1World)
  {
    super(par1World);
    l = 10.0D;
    a(0.5F, 0.5F);
  }
  
  public uh(abw par1World, double par2, double par4, double par6)
  {
    super(par1World);
    
    l = 10.0D;
    a(0.5F, 0.5F);
    b(par2, par4, par6);
    N = 0.0F;
  }
  
  public uh(abw par1World, of par2EntityLivingBase, of par3EntityLivingBase, float par4, float par5)
  {
    super(par1World);
    
    setSizeMultiplier(par2EntityLivingBase.getSizeMultiplierRoot());
    l = 10.0D;
    c = par2EntityLivingBase;
    
    if ((par2EntityLivingBase instanceof uf))
    {
      a = 1;
    }
    
    a(0.5F, 0.5F);
    v = (v + par2EntityLivingBase.f() - 0.10000000149011612D);
    double d0 = u - u;
    double d1 = E.b + P / 3.0F - v;
    double d2 = w - w;
    double d3 = ls.a(d0 * d0 + d2 * d2);
    
    if (d3 >= 1.0E-7D)
    {
      float f2 = (float)(Math.atan2(d2, d0) * 180.0D / 3.141592653589793D) - 90.0F;
      float f3 = (float)-(Math.atan2(d1, d3) * 180.0D / 3.141592653589793D);
      double d4 = d0 / d3;
      double d5 = d2 / d3;
      b(u + d4, v, w + d5, f2, f3);
      N = 0.0F;
      float f4 = (float)d3 * 0.2F;
      c(d0, d1 + f4, d2, par4, par5);
    }
  }
  

  public uh(abw par1World, of par2EntityLivingBase, float par3)
  {
    super(par1World);
    
    setSizeMultiplier(par2EntityLivingBase.getSizeMultiplierRoot());
    l = 10.0D;
    c = par2EntityLivingBase;
    
    if ((par2EntityLivingBase instanceof uf))
    {
      a = 1;
    }
    
    a(0.5F, 0.5F);
    b(u, v + par2EntityLivingBase.f(), w, A, B);
    u -= ls.b(A / 180.0F * 3.1415927F) * 0.16F;
    v -= 0.10000000149011612D * par2EntityLivingBase.getSizeMultiplier();
    w -= ls.a(A / 180.0F * 3.1415927F) * 0.16F;
    b(u, v, w);
    N = 0.0F;
    x = (-ls.a(A / 180.0F * 3.1415927F) * ls.b(B / 180.0F * 3.1415927F));
    z = (ls.b(A / 180.0F * 3.1415927F) * ls.b(B / 180.0F * 3.1415927F));
    y = (-ls.a(B / 180.0F * 3.1415927F));
    c(x, y, z, par3 * 1.5F * getSizeMultiplierRoot(), 1.0F * getSizeMultiplierRoot());
  }
  
  protected void a()
  {
    ah.a(16, Byte.valueOf((byte)0));
  }
  
  public boolean isResizable()
  {
    return true;
  }
  



  public void a(float par1, float par2)
  {
    super.a(par1 * getSizeMultiplier(), par2 * getSizeMultiplier());
  }
  



  public void c(double par1, double par3, double par5, float par7, float par8)
  {
    float f2 = ls.a(par1 * par1 + par3 * par3 + par5 * par5);
    par1 /= f2;
    par3 /= f2;
    par5 /= f2;
    par1 += ab.nextGaussian() * (ab.nextBoolean() ? -1 : 1) * 0.007499999832361937D * par8;
    par3 += ab.nextGaussian() * (ab.nextBoolean() ? -1 : 1) * 0.007499999832361937D * par8;
    par5 += ab.nextGaussian() * (ab.nextBoolean() ? -1 : 1) * 0.007499999832361937D * par8;
    par1 *= par7;
    par3 *= par7;
    par5 *= par7;
    x = par1;
    y = par3;
    z = par5;
    float f3 = ls.a(par1 * par1 + par5 * par5);
    C = (this.A = (float)(Math.atan2(par1, par5) * 180.0D / 3.141592653589793D));
    D = (this.B = (float)(Math.atan2(par3, f3) * 180.0D / 3.141592653589793D));
    j = 0;
  }
  





  @SideOnly(Side.CLIENT)
  public void a(double par1, double par3, double par5, float par7, float par8, int par9)
  {
    b(par1, par3, par5);
    b(par7, par8);
  }
  




  @SideOnly(Side.CLIENT)
  public void h(double par1, double par3, double par5)
  {
    x = par1;
    y = par3;
    z = par5;
    
    if ((D == 0.0F) && (C == 0.0F))
    {
      float f = ls.a(par1 * par1 + par5 * par5);
      C = (this.A = (float)(Math.atan2(par1, par5) * 180.0D / 3.141592653589793D));
      D = (this.B = (float)(Math.atan2(par3, f) * 180.0D / 3.141592653589793D));
      D = B;
      C = A;
      b(u, v, w, A, B);
      j = 0;
    }
  }
  
  public void pickUpEntity(nn par1Entity)
  {
    super.pickUpEntity(par1Entity);
    
    if ((q instanceof js))
    {
      Packet172AttachEntitySpecial var5 = new Packet172AttachEntitySpecial(heldEntity, this, (byte)3);
      ((js)q).q().a(this, var5);
    }
  }
  
  public void dropHeldEntity(nn par1Entity)
  {
    nn held = heldEntity;
    super.dropHeldEntity(par1Entity);
    
    if ((q instanceof js))
    {
      Packet172AttachEntitySpecial var5 = new Packet172AttachEntitySpecial(held, this, (byte)0);
      ((js)q).q().a(this, var5);
    }
  }
  
  public float maxHeldWidth(nn par1Entity)
  {
    return O;
  }
  
  public void updateHeldPosition()
  {
    if (heldEntity != null)
    {
      double pitch = Math.cos(B * 3.141592653589793D / 180.0D);
      double pitch1 = Math.sin(B * 3.141592653589793D / 180.0D);
      double d = Math.sin(A * 3.141592653589793D / 180.0D) * pitch * O * -0.5D;
      double d1 = Math.cos(A * 3.141592653589793D / 180.0D) * pitch * O * -0.5D;
      double dy = pitch1 * P * -0.5D + heldEntity.N;
      
      if ((!i) || ((heldEntity instanceof uf)))
      {
        dy -= heldEntity.P * 0.25D;
      }
      
      if (i)
      {
        double dx = d;
        double dz = d1;
        
        while (q.t(ls.c(u + d), ls.c(v + dy), ls.c(w + d1)))
        {
          d += dx;
          d1 += dz;
          dy += pitch1 * P * -0.5D;
        }
      }
      
      heldEntity.b(u + d, v + dy, w + d1);
    }
  }
  



  public void l_()
  {
    super.l_();
    
    if ((D == 0.0F) && (C == 0.0F))
    {
      float f = ls.a(x * x + z * z);
      C = (this.A = (float)(Math.atan2(x, z) * 180.0D / 3.141592653589793D));
      D = (this.B = (float)(Math.atan2(y, f) * 180.0D / 3.141592653589793D));
    }
    
    int i = q.a(d, e, this.f);
    
    if (i > 0)
    {
      aqz.s[i].a(q, d, e, this.f);
      asx axisalignedbb = aqz.s[i].b(q, d, e, this.f);
      
      if ((axisalignedbb != null) && (axisalignedbb.a(q.V().a(u, v, w))))
      {
        this.i = true;
      }
    }
    
    if (b > 0)
    {
      b -= 1;
    }
    
    if ((heldEntity != null) && (heldEntity.holdingEntity != this))
    {
      dropHeldEntity(null);
    }
    
    if (this.i)
    {
      int j = q.a(d, e, this.f);
      int k = q.h(d, e, this.f);
      
      if ((j == g) && (k == h))
      {
        this.j += 1;
        
        if (this.j == 1200)
        {
          x();
        }
      }
      else if ((heldEntity != null) && (heldEntity.holdingEntity == this))
      {
        nn held = heldEntity;
        dropHeldEntity(held);
        x();
        
        if ((held instanceof of))
        {
          ((of)held).m(((of)held).aU() + 1);
        }
      }
      else
      {
        this.i = false;
        x *= ab.nextFloat() * 0.2F;
        y *= ab.nextFloat() * 0.2F;
        z *= ab.nextFloat() * 0.2F;
        this.j = 0;
        au = 0;
      }
    }
    else
    {
      au += 1;
      atc vec3 = q.V().a(u, v, w);
      atc vec31 = q.V().a(u + x, v + y, w + z);
      ata movingobjectposition = q.a(vec3, vec31, false, true);
      vec3 = q.V().a(u, v, w);
      vec31 = q.V().a(u + x, v + y, w + z);
      
      if (movingobjectposition != null)
      {
        vec31 = q.V().a(f.c, f.d, f.e);
      }
      
      nn entity = null;
      List list = q.b(this, E.a(x, y, z).b(1.0D, 1.0D, 1.0D));
      double d0 = 0.0D;
      


      for (int l = 0; l < list.size(); l++)
      {
        nn entity1 = (nn)list.get(l);
        
        if ((entity1.L()) && (heldEntity == null)) { if (((entity1 == c) || ((c != null) && (entity1 == c.o))) && ((au < 5) || (entity1 == c))) { if (au < (c.getSizeMultiplier() <= 1.0F ? 5 : (int)(5.0F * c.getSizeMultiplierRoot()))) {}
          } else {
            float f1 = 0.3F;
            asx axisalignedbb1 = E.b(f1, f1, f1);
            ata movingobjectposition1 = axisalignedbb1.a(vec3, vec31);
            
            if (movingobjectposition1 != null)
            {
              double d1 = vec3.d(f);
              
              if ((d1 < d0) || (d0 == 0.0D))
              {
                entity = entity1;
                d0 = d1;
              }
            }
          }
        }
      }
      if (entity != null)
      {
        movingobjectposition = new ata(entity);
      }
      
      if ((movingobjectposition != null) && (g != null) && ((g instanceof uf)))
      {
        uf entityplayer = (uf)g;
        
        if ((bG.a) || (((c instanceof uf)) && (!((uf)c).a(entityplayer))))
        {
          movingobjectposition = null;
        }
      }
      



      if (movingobjectposition != null)
      {
        if (g != null)
        {
          float f2 = ls.a(x * x + y * y + z * z);
          int i1 = ls.f(f2 * av);
          
          if (d())
          {
            i1 += ab.nextInt(i1 / 2 + 2);
          }
          
          nb damagesource = null;
          
          if (c == null)
          {
            damagesource = nb.a(this, this);
          }
          else
          {
            damagesource = nb.a(this, c);
          }
          
          if ((af()) && (!(g instanceof tg)))
          {
            g.d(5);
          }
          


          ye willtell = null;
          
          if (((g instanceof uf)) && (g.isTiny()))
          {
            willtell = ((uf)g).aZ();
            
            if ((willtell != null) && (willtell.b() != yc.l) && (willtell.b() != yc.av))
            {
              willtell = null;
            }
          }
          
          if (willtell != null)
          {
            uf hit = (uf)g;
            bn.a(bn.c, 1);
            
            if (willtell.b() == yc.l)
            {

              g.a(damagesource, i1 / 3);
              a("random.bowhit", 0.75F, 1.2F / (ab.nextFloat() * 0.2F + 0.9F));
              x();
              
              if (ab.nextInt(3) == 0)
              {
                hit.a(new ye(yc.l, 1), true);
              }
            }
            else if (willtell.b() == yc.av)
            {

              hit.a(new ye(yc.l, 1), true);
              x *= -0.10000000149011612D;
              y *= -0.10000000149011612D;
              z *= -0.10000000149011612D;
              A += 180.0F;
              C += 180.0F;
              au = 0;
            }
          }
          else if (g.a(damagesource, i1))
          {
            if ((g instanceof of))
            {
              of entitylivingbase = (of)g;
              
              if (!q.I)
              {
                if ((getSizeMultiplier() <= entitylivingbase.getSizeMultiplierRoot() * 1.85F) && (getSizeMultiplier() > entitylivingbase.getSizeMultiplierRoot() / 1.85F))
                {

                  entitylivingbase.m(entitylivingbase.aU() + 1);
                }
              }
              
              if (getSizeMultiplier() > entitylivingbase.getSizeMultiplierRoot() * 1.85F)
              {
                if (maxHeldWidth(entitylivingbase) >= O)
                {
                  if (heldEntity != null)
                  {
                    dropHeldEntity(heldEntity);
                  }
                  
                  if (holdingEntity != null)
                  {
                    entitylivingbase.getDroppedByEntity(null);
                  }
                  
                  pickUpEntity(entitylivingbase);
                }
              }
              else if (aw > 0)
              {
                float f3 = ls.a(x * x + z * z);
                
                if (f3 > 0.0F)
                {
                  g.g(x * aw * 0.6000000238418579D / f3, 0.1D, z * aw * 0.6000000238418579D / f3);
                }
              }
              
              if (c != null)
              {
                abh.a(c, entitylivingbase, ab);
              }
              
              if ((c != null) && (g != c) && ((g instanceof uf)) && ((c instanceof jv)))
              {
                c).a.b(new ef(6, 0));
              }
            }
            
            a("random.bowhit", 1.0F, 1.2F / (ab.nextFloat() * 0.2F + 0.9F));
            
            if ((!(g instanceof tg)) && ((!(g instanceof of)) || (getSizeMultiplier() <= g.getSizeMultiplierRoot() * 1.85F)))
            {
              x();
            }
          }
          else if (((g instanceof of)) && (getSizeMultiplier() > g.getSizeMultiplierRoot() * 1.85F))
          {
            if (maxHeldWidth(g) >= g.O)
            {
              if (heldEntity != null)
              {
                dropHeldEntity(heldEntity);
              }
              
              if (g.holdingEntity != null)
              {
                g.getDroppedByEntity(null);
              }
              
              pickUpEntity(g);
            }
          }
          else
          {
            x *= -0.10000000149011612D;
            y *= -0.10000000149011612D;
            z *= -0.10000000149011612D;
            A += 180.0F;
            C += 180.0F;
            au = 0;
          }
        }
        else
        {
          d = b;
          e = c;
          this.f = d;
          g = q.a(d, e, this.f);
          h = q.h(d, e, this.f);
          x = ((float)(f.c - u));
          y = ((float)(f.d - v));
          z = ((float)(f.e - w));
          float f2 = ls.a(x * x + y * y + z * z);
          u -= x / f2 * 0.05000000074505806D;
          v -= y / f2 * 0.05000000074505806D;
          w -= z / f2 * 0.05000000074505806D;
          a("random.bowhit", 1.0F, 1.2F / (ab.nextFloat() * 0.2F + 0.9F));
          this.i = true;
          b = 7;
          a(false);
          
          if (g != 0)
          {
            aqz.s[g].a(q, d, e, this.f, this);
          }
        }
      }
      
      if (d())
      {
        for (l = 0; l < 4; l++)
        {
          q.a("crit", u + x * l / 4.0D, v + y * l / 4.0D, w + z * l / 4.0D, -x, -y + 0.2D, -z);
        }
      }
      
      u += x;
      v += y;
      w += z;
      float f2 = ls.a(x * x + z * z);
      A = ((float)(Math.atan2(x, z) * 180.0D / 3.141592653589793D));
      
      for (B = ((float)(Math.atan2(y, f2) * 180.0D / 3.141592653589793D)); B - D < -180.0F; D -= 360.0F) {}
      



      while (B - D >= 180.0F)
      {
        D += 360.0F;
      }
      
      while (A - C < -180.0F)
      {
        C -= 360.0F;
      }
      
      while (A - C >= 180.0F)
      {
        C += 360.0F;
      }
      
      B = (D + (B - D) * 0.2F);
      A = (C + (A - C) * 0.2F);
      float f4 = 0.99F;
      float f1 = 0.05F;
      
      if (H())
      {
        for (int j1 = 0; j1 < 4; j1++)
        {
          float f3 = 0.25F;
          q.a("bubble", u - x * f3, v - y * f3, w - z * f3, x, y, z);
        }
        
        f4 = 0.8F;
      }
      
      x *= f4;
      y *= f4;
      z *= f4;
      y -= f1;
      b(u, v, w);
      D();
    }
  }
  



  public void b(by par1NBTTagCompound)
  {
    par1NBTTagCompound.a("xTile", (short)d);
    par1NBTTagCompound.a("yTile", (short)e);
    par1NBTTagCompound.a("zTile", (short)f);
    par1NBTTagCompound.a("inTile", (byte)g);
    par1NBTTagCompound.a("inData", (byte)h);
    par1NBTTagCompound.a("shake", (byte)b);
    par1NBTTagCompound.a("inGround", (byte)(i ? 1 : 0));
    par1NBTTagCompound.a("pickup", (byte)a);
    par1NBTTagCompound.a("damage", av);
  }
  



  public void a(by par1NBTTagCompound)
  {
    d = par1NBTTagCompound.d("xTile");
    e = par1NBTTagCompound.d("yTile");
    f = par1NBTTagCompound.d("zTile");
    g = (par1NBTTagCompound.c("inTile") & 0xFF);
    h = (par1NBTTagCompound.c("inData") & 0xFF);
    b = (par1NBTTagCompound.c("shake") & 0xFF);
    i = (par1NBTTagCompound.c("inGround") == 1);
    
    if (par1NBTTagCompound.b("damage"))
    {
      av = par1NBTTagCompound.h("damage");
    }
    
    if (par1NBTTagCompound.b("pickup"))
    {
      a = par1NBTTagCompound.c("pickup");
    }
    else if (par1NBTTagCompound.b("player"))
    {
      a = (par1NBTTagCompound.n("player") ? 1 : 0);
    }
  }
  



  public void b_(uf par1EntityPlayer)
  {
    if ((!q.I) && (i) && (b <= 0))
    {
      boolean flag = (a == 1) || ((a == 2) && (bG.d));
      
      if ((getSizeMultiplier() > par1EntityPlayer.getSizeMultiplierRoot() * 1.85F) || (getSizeMultiplier() <= par1EntityPlayer.getSizeMultiplierRoot() / 1.85F) || ((heldEntity != null) && (!heldEntity.M)))
      {

        return;
      }
      
      if ((a == 1) && (!bn.a(new ye(yc.n, 1))))
      {
        flag = false;
      }
      
      if (flag)
      {
        a("random.pop", 0.2F, ((ab.nextFloat() - ab.nextFloat()) * 0.7F + 1.0F) * 2.0F);
        par1EntityPlayer.a(this, 1);
        x();
      }
    }
  }
  




  protected boolean e_()
  {
    return false;
  }
  
  @SideOnly(Side.CLIENT)
  public float S()
  {
    return 0.0F;
  }
  
  public void b(double par1)
  {
    av = par1;
  }
  
  public double c()
  {
    return av;
  }
  



  public void a(int par1)
  {
    aw = par1;
  }
  



  public boolean aq()
  {
    return false;
  }
  



  public void a(boolean par1)
  {
    byte b0 = ah.a(16);
    
    if (par1)
    {
      ah.b(16, Byte.valueOf((byte)(b0 | 0x1)));
    }
    else
    {
      ah.b(16, Byte.valueOf((byte)(b0 & 0xFFFFFFFE)));
    }
  }
  



  public boolean d()
  {
    byte b0 = ah.a(16);
    return (b0 & 0x1) != 0;
  }
}
