import java.util.Random;


















public class sb
  extends rv
  implements to
{
  public sb(abw par1World)
  {
    super(par1World);
    a(0.4F, 1.8F);
    minLookSize = (this.minTargetSize = 0.1F);
    maxLookSize = (this.maxTargetSize = 10.0F);
    k().a(true);
    c.a(1, new qn(this, 1.25D, 20, 10.0F));
    c.a(2, new qm(this, 1.0D));
    c.a(3, new px(this, uf.class, 6.0F));
    c.a(4, new ql(this));
    d.a(1, new qy(this, og.class, 0, true, false, th.a));
  }
  



  public boolean bf()
  {
    return true;
  }
  
  protected void az()
  {
    super.az();
    a(tp.a).a(4.0D);
    a(tp.d).a(0.20000000298023224D);
  }
  
  public void W()
  {
    n.b(u, v + Y() + n.X(), w);
  }
  



  public double Y()
  {
    return P * 0.95D;
  }
  




  public void c()
  {
    super.c();
    
    if (G())
    {
      a(nb.e, 1.0F);
    }
    
    int i = ls.c(u);
    int j = ls.c(w);
    
    if (q.a(i, j).j() > 1.0F)
    {
      a(nb.b, 1.0F);
    }
    
    if (isTiny())
    {
      return;
    }
    
    int snowheight = (int)(getSizeMultiplier() * 0.7F);
    if (snowheight <= 0)
    {
      snowheight = 1;
    }
    else if (snowheight > 8)
    {
      snowheight = 8;
    }
    
    int twidth = (int)(O * 2.0F) + 2;
    float tfwidth = twidth - 1;
    for (int var1 = 0; var1 < twidth * twidth; var1++)
    {
      int var2 = ls.c(u + (var1 % twidth - tfwidth * 0.5F) * 0.5F);
      int var3 = ls.c(v);
      int var4 = ls.c(w + (var1 / twidth % twidth - tfwidth * 0.5F) * 0.5F);
      boolean canplace = aqz.aX.c(q, var2, var3, var4);
      aqz b = aqz.s[q.a(var2, var3, var4)];
      boolean snowable = (b == null) || ((snowheight > 1) && (cU == akc.k)) || ((snowheight > 2) && ((b instanceof aqv))) || ((cF == aXcF) && ((q.h(var2, var3, var4) & 0x7) < snowheight - 1));
      boolean isstable = ((q.a(var2 - 1, var3, var4) == aXcF) && (q.w(var2 - 1, var3 - 1, var4)) && (q.a(var2 + 1, var3, var4) == aXcF) && (q.w(var2 + 1, var3 - 1, var4))) || ((q.a(var2, var3, var4 - 1) == aXcF) && (q.w(var2, var3 - 1, var4 - 1)) && (q.a(var2, var3, var4 + 1) == aXcF) && (q.w(var2, var3 - 1, var4 + 1)));
      
      if ((snowable) && (q.a(var2, var4).j() < 0.8F) && ((isHuge()) || (canplace)))
      {
        if ((canplace) || ((snowheight >= 2) && (isstable)))
        {
          if ((b != null) && (cU == akc.k))
          {
            b.c(q, var2, var3, var4, q.h(var2, var3, var4), 0);
          }
          
          q.f(var2, var3, var4, aXcF, canplace ? snowheight : 0, (getSizeMultiplier() > 1.5F) && (!canplace) && (isstable) ? 2 : 3);
          
          if ((snowheight > 2) && (q.a(var2, var3 - 1, var4) == GcF))
          {
            q.c(var2, var3 - 1, var4, aYcF);
          }
        }
      }
    }
  }
  



  protected int s()
  {
    return aFcv;
  }
  




  protected void b(boolean par1, int par2)
  {
    dropItemSizedAmount(0, aFcv, 0, 16);
  }
  



  public void a(of par1EntityLivingBase, float par2)
  {
    up entitysnowball = new up(q, this);
    double d0 = u - u;
    double d1 = v + par1EntityLivingBase.f() - 1.100000023841858D - v;
    double d2 = w - w;
    float f1 = ls.a(d0 * d0 + d2 * d2) * 0.2F;
    entitysnowball.c(d0, d1 + f1, d2, 1.6F, 12.0F);
    a("random.bow", 1.0F, 1.0F / (aD().nextFloat() * 0.4F + 0.8F));
    q.d(entitysnowball);
  }
}
