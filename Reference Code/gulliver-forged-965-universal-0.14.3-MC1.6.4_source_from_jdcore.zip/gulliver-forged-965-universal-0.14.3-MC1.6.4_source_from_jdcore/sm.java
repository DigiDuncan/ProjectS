import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import java.util.Random;

























public class sm
  extends tm
  implements sg, to
{
  private float[] bp = new float[2];
  private float[] bq = new float[2];
  private float[] br = new float[2];
  private float[] bs = new float[2];
  private int[] bt = new int[2];
  private int[] bu = new int[2];
  
  private int bv;
  
  private static final nw bw = new sn();
  
  public sm(abw par1World)
  {
    super(par1World);
    g(aT());
    a(0.9F, 4.0F);
    ag = true;
    k().e(true);
    c.a(0, new pp(this));
    c.a(2, new qn(this, 1.0D, 40, 20.0F));
    c.a(5, new qm(this, 1.0D));
    c.a(6, new px(this, uf.class, 8.0F));
    c.a(7, new ql(this));
    d.a(1, new qx(this, false));
    d.a(2, new qy(this, og.class, 0, false, false, bw));
    b = 50;
  }
  
  protected void a()
  {
    super.a();
    ah.a(17, new Integer(0));
    ah.a(18, new Integer(0));
    ah.a(19, new Integer(0));
    ah.a(20, new Integer(0));
  }
  



  public void b(by par1NBTTagCompound)
  {
    super.b(par1NBTTagCompound);
    par1NBTTagCompound.a("Invul", bU());
  }
  



  public void a(by par1NBTTagCompound)
  {
    super.a(par1NBTTagCompound);
    p(par1NBTTagCompound.e("Invul"));
  }
  
  @SideOnly(Side.CLIENT)
  public float S()
  {
    return P / 8.0F;
  }
  



  protected String r()
  {
    return "mob.wither.idle";
  }
  



  protected String aO()
  {
    return "mob.wither.hurt";
  }
  



  protected String aP()
  {
    return "mob.wither.death";
  }
  




  public void c()
  {
    y *= 0.6000000238418579D;
    



    if ((!q.I) && (q(0) > 0))
    {
      nn entity = q.a(q(0));
      
      if (entity != null)
      {
        if ((v < v) || ((!bV()) && (v < v + 5.0D)))
        {
          if (y < 0.0D)
          {
            y = 0.0D;
          }
          
          y += (0.5D - y) * 0.6000000238418579D;
        }
        
        double d3 = u - u;
        double d0 = w - w;
        double d1 = d3 * d3 + d0 * d0;
        
        if (d1 > 9.0D)
        {
          double d2 = ls.a(d1);
          x += (d3 / d2 * 0.5D - x) * 0.6000000238418579D;
          z += (d0 / d2 * 0.5D - z) * 0.6000000238418579D;
        }
      }
    }
    
    if (x * x + z * z > 0.05000000074505806D)
    {
      A = ((float)Math.atan2(z, x) * 57.295776F - 90.0F);
    }
    
    super.c();
    

    for (int i = 0; i < 2; i++)
    {
      bs[i] = bq[i];
      br[i] = bp[i];
    }
    


    for (i = 0; i < 2; i++)
    {
      int j = q(i + 1);
      nn entity1 = null;
      
      if (j > 0)
      {
        entity1 = q.a(j);
      }
      
      if (entity1 != null)
      {
        double d0 = r(i + 1);
        double d1 = s(i + 1);
        double d2 = t(i + 1);
        double d4 = u - d0;
        double d5 = v + entity1.f() - d1;
        double d6 = w - d2;
        double d7 = ls.a(d4 * d4 + d6 * d6);
        float f = (float)(Math.atan2(d6, d4) * 180.0D / 3.141592653589793D) - 90.0F;
        float f1 = (float)-(Math.atan2(d5, d7) * 180.0D / 3.141592653589793D);
        bp[i] = b(bp[i], f1, 40.0F);
        bq[i] = b(bq[i], f, 10.0F);
      }
      else
      {
        bq[i] = b(bq[i], aN, 10.0F);
      }
    }
    
    boolean flag = bV();
    
    for (int j = 0; j < 3; j++)
    {
      double d8 = r(j);
      double d9 = s(j);
      double d10 = t(j);
      q.a(!isHuge() ? "smoke" : "largesmoke", d8 + ab.nextGaussian() * 0.30000001192092896D * getSizeMultiplier(), d9 + ab.nextGaussian() * 0.30000001192092896D * getSizeMultiplier(), d10 + ab.nextGaussian() * 0.30000001192092896D * getSizeMultiplier(), 0.0D, 0.0D, 0.0D);
      
      if ((flag) && (q.s.nextInt(4) == 0))
      {
        q.a("mobSpell", d8 + ab.nextGaussian() * 0.30000001192092896D * getSizeMultiplier(), d9 + ab.nextGaussian() * 0.30000001192092896D * getSizeMultiplier(), d10 + ab.nextGaussian() * 0.30000001192092896D * getSizeMultiplier(), 0.699999988079071D * getRangeMultiplier(), 0.699999988079071D * getRangeMultiplier(), 0.5D * getRangeMultiplier());
      }
    }
    
    if (bU() > 0)
    {
      for (j = 0; j < 3; j++)
      {
        q.a("mobSpell", u + ab.nextGaussian() * 1.0D * getSizeMultiplier(), v + ab.nextFloat() * 3.3F * getSizeMultiplier(), w + ab.nextGaussian() * 1.0D * getSizeMultiplier(), 0.699999988079071D * getRangeMultiplier(), 0.699999988079071D * getRangeMultiplier(), 0.8999999761581421D * getRangeMultiplier());
      }
    }
  }
  


  protected void bi()
  {
    if (bU() > 0)
    {
      int i = bU() - 1;
      
      if (i <= 0)
      {
        q.a(this, u, v + f(), w, 7.0F * getSizeMultiplierRoot(), false, q.O().b("mobGriefing"));
        q.d(1013, (int)u, (int)v, (int)w, 0);
      }
      
      p(i);
      
      if (ac % 10 == 0)
      {
        f(10.0F);
      }
    }
    else
    {
      super.bi();
      

      for (int i = 1; i < 3; i++)
      {
        if (ac >= bt[(i - 1)])
        {
          bt[(i - 1)] = (ac + 10 + ab.nextInt(10));
          
          if (q.r >= 2)
          {
            int k = i - 1;
            int l = bu[(i - 1)];
            bu[k] = (bu[(i - 1)] + 1);
            
            if (l > 15)
            {
              float f = 10.0F * getRangeMultiplier();
              float f1 = 5.0F * getRangeMultiplier();
              double d0 = ls.a(ab, u - f, u + f);
              double d1 = ls.a(ab, v - f1, v + f1);
              double d2 = ls.a(ab, w - f, w + f);
              a(i + 1, d0, d1, d2, true);
              bu[(i - 1)] = 0;
            }
          }
          
          int j = q(i);
          
          if (j > 0)
          {
            nn entity = q.a(j);
            
            if ((entity != null) && (entity.T()) && (e(entity) <= 900.0D) && (o(entity)))
            {
              a(i + 1, (of)entity);
              bt[(i - 1)] = (ac + 40 + ab.nextInt(20));
              bu[(i - 1)] = 0;
            }
            else
            {
              c(i, 0);
            }
          }
          else
          {
            List list = q.a(of.class, E.b(20.0D, 8.0D, 20.0D), bw);
            
            for (int i1 = 0; (i1 < 10) && (!list.isEmpty()); i1++)
            {
              of entitylivingbase = (of)list.get(ab.nextInt(list.size()));
              
              if ((entitylivingbase != this) && (entitylivingbase.T()) && (o(entitylivingbase)))
              {
                if ((entitylivingbase instanceof uf))
                {
                  if (bG.a)
                    break;
                  c(i, k); break;
                }
                


                c(i, k);
                

                break;
              }
              
              list.remove(entitylivingbase);
            }
          }
        }
      }
      
      if (m() != null)
      {
        c(0, mk);
      }
      else
      {
        c(0, 0);
      }
      
      if (bv > 0)
      {
        bv -= 1;
        
        if ((bv == 0) && (q.O().b("mobGriefing")))
        {
          i = ls.c(v);
          int j = ls.c(u);
          int j1 = ls.c(w);
          boolean flag = false;
          
          for (int k1 = -1; k1 <= 1; k1++)
          {
            for (int l1 = -1; l1 <= 1; l1++)
            {
              for (int i2 = 0; i2 <= 3; i2++)
              {
                int j2 = j + k1;
                int k2 = i + i2;
                int l2 = j1 + l1;
                int i3 = q.a(j2, k2, l2);
                
                aqz block = aqz.s[i3];
                if ((block != null) && (block.canEntityDestroy(q, j2, k2, l2, this)))
                {
                  flag = (q.a(j2, k2, l2, true)) || (flag);
                }
              }
            }
          }
          
          if (flag)
          {
            q.a((uf)null, 1012, (int)u, (int)v, (int)w, 0);
          }
        }
      }
      
      if (ac % 20 == 0)
      {
        f(1.0F);
      }
    }
  }
  
  public void bT()
  {
    p(220);
    g(aT() / 3.0F);
  }
  



  public void am() {}
  



  public int aQ()
  {
    return 4;
  }
  
  private double r(int par1)
  {
    if (par1 <= 0)
    {
      return u;
    }
    

    float f = (aN + 180 * (par1 - 1)) / 180.0F * 3.1415927F;
    float f1 = ls.b(f);
    return u + f1 * 1.3D * getSizeMultiplier();
  }
  

  private double s(int par1)
  {
    return par1 <= 0 ? v + 3.0D * getSizeMultiplier() : v + 2.2D * getSizeMultiplier();
  }
  
  private double t(int par1)
  {
    if (par1 <= 0)
    {
      return w;
    }
    

    float f = (aN + 180 * (par1 - 1)) / 180.0F * 3.1415927F;
    float f1 = ls.a(f);
    return w + f1 * 1.3D * getSizeMultiplier();
  }
  

  private float b(float par1, float par2, float par3)
  {
    float f3 = ls.g(par2 - par1);
    
    if (f3 > par3)
    {
      f3 = par3;
    }
    
    if (f3 < -par3)
    {
      f3 = -par3;
    }
    
    return par1 + f3;
  }
  
  private void a(int par1, of par2EntityLivingBase)
  {
    a(par1, u, v + par2EntityLivingBase.f() * 0.5D, w, (par1 == 0) && (ab.nextFloat() < 0.001F));
  }
  
  private void a(int par1, double par2, double par4, double par6, boolean par8)
  {
    q.a((uf)null, 1014, (int)u, (int)v, (int)w, 0);
    double d3 = r(par1);
    double d4 = s(par1);
    double d5 = t(par1);
    double d6 = par2 - d3;
    double d7 = par4 - d4;
    double d8 = par6 - d5;
    uv entitywitherskull = new uv(q, this, d6, d7, d8);
    
    if (par8)
    {
      entitywitherskull.a(true);
    }
    
    v = d4;
    u = d3;
    w = d5;
    q.d(entitywitherskull);
  }
  



  public void a(of par1EntityLivingBase, float par2)
  {
    a(0, par1EntityLivingBase);
  }
  



  public boolean a(nb par1DamageSource, float par2)
  {
    if (ar())
    {
      return false;
    }
    if (par1DamageSource == nb.e)
    {
      return false;
    }
    if (bU() > 0)
    {
      return false;
    }
    



    if (bV())
    {
      nn entity = par1DamageSource.h();
      
      if ((entity instanceof uh))
      {
        return false;
      }
    }
    
    nn entity = par1DamageSource.i();
    
    if ((entity != null) && (!(entity instanceof uf)) && ((entity instanceof of)) && (((of)entity).aY() == aY()))
    {
      return false;
    }
    

    if (bv <= 0)
    {
      bv = 20;
    }
    
    for (int i = 0; i < bu.length; i++)
    {
      bu[i] += 3;
    }
    
    return super.a(par1DamageSource, par2);
  }
  






  protected void b(boolean par1, int par2)
  {
    dropItemSizedAmount(0, bUcv, 1, 0);
  }
  



  protected void u()
  {
    aV = 0;
  }
  
  @SideOnly(Side.CLIENT)
  public int c(float par1)
  {
    return 15728880;
  }
  



  public boolean L()
  {
    return !M;
  }
  



  protected void b(float par1) {}
  



  public void c(nj par1PotionEffect) {}
  



  protected boolean bf()
  {
    return true;
  }
  
  protected void az()
  {
    super.az();
    a(tp.a).a(300.0D);
    a(tp.d).a(0.6000000238418579D);
    a(tp.b).a(40.0D);
  }
  
  @SideOnly(Side.CLIENT)
  public float a(int par1)
  {
    return bq[par1];
  }
  
  @SideOnly(Side.CLIENT)
  public float c(int par1)
  {
    return bp[par1];
  }
  
  public int bU()
  {
    return ah.c(20);
  }
  
  public void p(int par1)
  {
    ah.b(20, Integer.valueOf(par1));
  }
  



  public int q(int par1)
  {
    return ah.c(17 + par1);
  }
  
  public void c(int par1, int par2)
  {
    ah.b(17 + par1, Integer.valueOf(par2));
  }
  




  public boolean bV()
  {
    return aN() <= aT() / 2.0F;
  }
  



  public oj aY()
  {
    return oj.b;
  }
  



  public void a(nn par1Entity)
  {
    o = null;
  }
}
