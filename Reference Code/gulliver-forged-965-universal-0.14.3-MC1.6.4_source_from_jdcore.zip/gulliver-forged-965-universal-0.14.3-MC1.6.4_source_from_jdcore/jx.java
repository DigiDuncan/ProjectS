import cpw.mods.fml.common.network.FMLNetworkHandler;
import gulliver.network.packet.Packet171EntitySize;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;




































































public class jx
{
  public nn a;
  public int b;
  public int c;
  public int lastScaledSizeMultiplier;
  public int d;
  public int e;
  public int f;
  public int g;
  public int h;
  public int i;
  public double j;
  public double k;
  public double l;
  public int m;
  private double p;
  private double q;
  private double r;
  private boolean s;
  private boolean t;
  private int u;
  private nn v;
  private boolean w;
  public boolean n;
  public Set o = new HashSet();
  
  public jx(nn par1Entity, int par2, int par3, boolean par4)
  {
    a = par1Entity;
    b = par2;
    c = par3;
    t = par4;
    d = ls.c(u * 32.0D);
    e = ls.c(v * 32.0D);
    f = ls.c(w * 32.0D);
    g = ls.d(A * 256.0F / 360.0F);
    h = ls.d(B * 256.0F / 360.0F);
    i = ls.d(par1Entity.ap() * 256.0F / 360.0F);
    lastScaledSizeMultiplier = ls.d(par1Entity.getSizeMultiplier() * 256.0F);
  }
  
  public boolean equals(Object par1Obj)
  {
    return a.k == a.k;
  }
  
  public int hashCode()
  {
    return a.k;
  }
  



  public void a(List par1List)
  {
    n = false;
    
    if ((!s) || (a.e(p, q, r) > 16.0D))
    {
      p = a.u;
      q = a.v;
      r = a.w;
      s = true;
      n = true;
      b(par1List);
    }
    
    if ((v != a.o) || ((!(a instanceof uf)) && (a.o != null) && (m % 60 == 0)))
    {
      v = a.o;
      a(new fo(0, a, a.o));
    }
    
    if (((a instanceof od)) && (m % 10 == 0))
    {
      od entityitemframe = (od)a;
      ye itemstack = entityitemframe.h();
      
      if ((itemstack != null) && ((itemstack.b() instanceof yh)))
      {
        ali mapdata = yc.bf.a(itemstack, a.q);
        Iterator iterator = par1List.iterator();
        
        while (iterator.hasNext())
        {
          uf entityplayer = (uf)iterator.next();
          jv entityplayermp = (jv)entityplayer;
          mapdata.a(entityplayermp, itemstack);
          
          if (a.f() <= 5)
          {
            ey packet = yc.bf.c(itemstack, a.q, entityplayermp);
            
            if (packet != null)
            {
              a.b(packet);
            }
          }
        }
      }
      
      b();
    }
    else if ((m % c == 0) || (a.an) || (a.v().a()))
    {



      if ((a.o == null) && (a.holdingEntity == null))
      {
        u += 1;
        int i = a.at.a(a.u);
        int j = ls.c(a.v * 32.0D);
        int k = a.at.a(a.w);
        int l = ls.d(a.A * 256.0F / 360.0F);
        int i1 = ls.d(a.B * 256.0F / 360.0F);
        int s1 = ls.d(a.getSizeMultiplier() * 256.0F);
        int j1 = i - d;
        int k1 = j - e;
        int l1 = k - f;
        Object object = null;
        boolean sb = s1 != lastScaledSizeMultiplier;
        boolean flag = (sb) || (m % 60 == 0) || (!a.isTiny() ? (Math.abs(j1) < 4) || (Math.abs(k1) < 2) || (Math.abs(l1) < 4) : (Math.abs(j1) >= 1) || (Math.abs(k1) >= 1) || (Math.abs(l1) >= 1));
        boolean flag1 = (Math.abs(l - g) >= 4) || (Math.abs(i1 - h) >= 4);
        
        if ((m > 0) || ((a instanceof uh)))
        {
          if (sb)
          {
            a(new Packet171EntitySize(a, a.getSizeMultiplier()));
            lastScaledSizeMultiplier = s1;
          }
          
          if ((j1 >= -128) && (j1 < 128) && (k1 >= -128) && (k1 < 128) && (l1 >= -128) && (l1 < 128) && (u <= 400) && (!w))
          {
            if ((flag) && (flag1))
            {
              object = new es(a.k, (byte)j1, (byte)k1, (byte)l1, (byte)l, (byte)i1);
            }
            else if (flag)
            {
              object = new er(a.k, (byte)j1, (byte)k1, (byte)l1);
            }
            else if (flag1)
            {
              object = new et(a.k, (byte)l, (byte)i1);
            }
          }
          else
          {
            u = 0;
            object = new gb(a.k, i, j, k, (byte)l, (byte)i1);
          }
        }
        
        if ((t) && (a.holdingEntity == null))
        {
          double d0 = a.x - this.j;
          double d1 = a.y - this.k;
          double d2 = a.z - this.l;
          double d3 = 0.02D;
          double d4 = d0 * d0 + d1 * d1 + d2 * d2;
          
          if ((d4 > d3 * d3) || ((d4 > 0.0D) && (a.x == 0.0D) && (a.y == 0.0D) && (a.z == 0.0D)))
          {
            this.j = a.x;
            this.k = a.y;
            this.l = a.z;
            a(new fp(a.k, this.j, this.k, this.l));
          }
        }
        
        if (object != null)
        {
          a((ey)object);
        }
        
        b();
        
        if (flag)
        {
          d = i;
          e = j;
          f = k;
        }
        
        if (flag1)
        {
          g = l;
          h = i1;
        }
        
        w = false;
      }
      else
      {
        i = ls.d(a.A * 256.0F / 360.0F);
        int j = ls.d(a.B * 256.0F / 360.0F);
        int s1 = ls.d(a.getSizeMultiplier() * 256.0F);
        boolean flag2 = (Math.abs(i - g) >= 4) || (Math.abs(j - h) >= 4);
        boolean sb = s1 != lastScaledSizeMultiplier;
        
        if (sb)
        {
          a(new Packet171EntitySize(a, a.getSizeMultiplier()));
          lastScaledSizeMultiplier = s1;
        }
        
        if (flag2)
        {
          a(new et(a.k, (byte)i, (byte)j));
          g = i;
          h = j;
        }
        
        d = a.at.a(a.u);
        e = ls.c(a.v * 32.0D);
        f = a.at.a(a.w);
        b();
        w = true;
      }
      
      int i = ls.d(a.ap() * 256.0F / 360.0F);
      
      if (Math.abs(i - this.i) >= 4)
      {
        a(new fi(a.k, (byte)i));
        this.i = i;
      }
      
      a.an = false;
    }
    
    m += 1;
    
    if (a.J)
    {
      b(new fp(a));
      a.J = false;
    }
  }
  
  private void b()
  {
    oo datawatcher = a.v();
    
    if (datawatcher.a())
    {
      b(new fn(a.k, datawatcher, false));
    }
    
    if ((a instanceof of))
    {
      pa serversideattributemap = (pa)((of)a).aX();
      Set set = serversideattributemap.b();
      
      if (!set.isEmpty())
      {
        b(new gh(a.k, set));
      }
      
      set.clear();
    }
  }
  



  public void a(ey par1Packet)
  {
    Iterator iterator = o.iterator();
    
    while (iterator.hasNext())
    {
      jv entityplayermp = (jv)iterator.next();
      a.b(par1Packet);
    }
  }
  



  public void b(ey par1Packet)
  {
    a(par1Packet);
    
    if ((a instanceof jv))
    {
      a).a.b(par1Packet);
    }
  }
  
  public void a()
  {
    Iterator iterator = o.iterator();
    
    while (iterator.hasNext())
    {
      jv entityplayermp = (jv)iterator.next();
      g.add(Integer.valueOf(a.k));
    }
  }
  
  public void a(jv par1EntityPlayerMP)
  {
    if (o.contains(par1EntityPlayerMP))
    {
      g.add(Integer.valueOf(a.k));
      o.remove(par1EntityPlayerMP);
    }
  }
  



  public void b(jv par1EntityPlayerMP)
  {
    if (par1EntityPlayerMP != a)
    {
      double d0 = u - d / 32;
      double d1 = w - f / 32;
      
      if ((d0 >= -b) && (d0 <= b) && (d1 >= -b) && (d1 <= b))
      {
        if ((!o.contains(par1EntityPlayerMP)) && ((d(par1EntityPlayerMP)) || (a.p)))
        {
          o.add(par1EntityPlayerMP);
          ey packet = c();
          a.b(packet);
          
          if (!a.v().d())
          {
            a.b(new fn(a.k, a.v(), true));
          }
          
          if ((a instanceof of))
          {
            pa serversideattributemap = (pa)((of)a).aX();
            Collection collection = serversideattributemap.c();
            
            if (!collection.isEmpty())
            {
              a.b(new gh(a.k, collection));
            }
          }
          
          j = a.x;
          k = a.y;
          l = a.z;
          
          if ((a.getSizeMultiplier() != 1.0F) || ((a instanceof of)))
          {
            a.b(new Packet171EntitySize(a, a.getSizeMultiplier()));
          }
          
          int posX = ls.c(a.u * 32.0D);
          int posY = ls.c(a.v * 32.0D);
          int posZ = ls.c(a.w * 32.0D);
          if ((posX != d) || (posY != e) || (posZ != f))
          {
            FMLNetworkHandler.makeEntitySpawnAdjustment(a.k, par1EntityPlayerMP, d, e, f);
          }
          
          if ((t) && (!(packet instanceof dg)))
          {
            a.b(new fp(a.k, a.x, a.y, a.z));
          }
          
          if (a.o != null)
          {
            a.b(new fo(0, a, a.o));
          }
          
          if (((a instanceof og)) && (((og)a).bI() != null))
          {
            a.b(new fo(1, a, ((og)a).bI()));
          }
          
          if ((a instanceof of))
          {
            for (int i = 0; i < 5; i++)
            {
              ye itemstack = ((of)a).n(i);
              
              if (itemstack != null)
              {
                a.b(new fq(a.k, i, itemstack));
              }
            }
          }
          
          if ((a instanceof uf))
          {
            uf entityplayer = (uf)a;
            
            if (entityplayer.bh())
            {
              a.b(new ec(a, 0, ls.c(a.u), ls.c(a.v), ls.c(a.w)));
            }
          }
          
          if ((a instanceof of))
          {
            of entitylivingbase = (of)a;
            Iterator iterator = entitylivingbase.aL().iterator();
            
            while (iterator.hasNext())
            {
              nj potioneffect = (nj)iterator.next();
              a.b(new gj(a.k, potioneffect));
            }
          }
        }
      }
      else if (o.contains(par1EntityPlayerMP))
      {
        o.remove(par1EntityPlayerMP);
        g.add(Integer.valueOf(a.k));
      }
    }
  }
  
  private boolean d(jv par1EntityPlayerMP)
  {
    return par1EntityPlayerMP.p().s().a(par1EntityPlayerMP, a.aj, a.al);
  }
  
  public void b(List par1List)
  {
    for (int i = 0; i < par1List.size(); i++)
    {
      b((jv)par1List.get(i));
    }
  }
  
  private ey c()
  {
    if (a.M)
    {
      a.q.Y().b("Fetching addPacket for removed entity");
    }
    
    ey pkt = FMLNetworkHandler.getEntitySpawningPacket(a);
    
    if (pkt != null)
    {
      return pkt;
    }
    
    if ((a instanceof ss))
    {
      return new dd(a, 2, 1);
    }
    if ((a instanceof jv))
    {
      return new di((uf)a);
    }
    if ((a instanceof st))
    {
      st entityminecart = (st)a;
      return new dd(a, 10, entityminecart.l());
    }
    if ((a instanceof sq))
    {
      return new dd(a, 1);
    }
    if ((!(a instanceof nl)) && (!(a instanceof sk)))
    {
      if ((a instanceof ul))
      {
        uf entityplayer = a).b;
        return new dd(a, 90, entityplayer != null ? k : a.k);
      }
      if ((a instanceof uh))
      {
        nn entity = a).c;
        return new dd(a, 60, entity != null ? k : a.k);
      }
      if ((a instanceof up))
      {
        return new dd(a, 61);
      }
      if ((a instanceof uu))
      {
        return new dd(a, 73, ((uu)a).i());
      }
      if ((a instanceof ut))
      {
        return new dd(a, 75);
      }
      if ((a instanceof us))
      {
        return new dd(a, 65);
      }
      if ((a instanceof ui))
      {
        return new dd(a, 72);
      }
      if ((a instanceof uk))
      {
        return new dd(a, 76);
      }
      



      if ((a instanceof uj))
      {
        uj entityfireball = (uj)a;
        dd packet23vehiclespawn = null;
        byte b0 = 63;
        
        if ((a instanceof uo))
        {
          b0 = 64;
        }
        else if ((a instanceof uv))
        {
          b0 = 66;
        }
        
        if (a != null)
        {
          packet23vehiclespawn = new dd(a, b0, a).a.k);
        }
        else
        {
          packet23vehiclespawn = new dd(a, b0, 0);
        }
        
        e = ((int)(b * 8000.0D));
        f = ((int)(c * 8000.0D));
        g = ((int)(d * 8000.0D));
        return packet23vehiclespawn;
      }
      if ((a instanceof ur))
      {
        return new dd(a, 62);
      }
      if ((a instanceof tc))
      {
        return new dd(a, 50);
      }
      if ((a instanceof sj))
      {
        return new dd(a, 51);
      }
      if ((a instanceof sr))
      {
        sr entityfallingsand = (sr)a;
        return new dd(a, 70, a | b << 16);
      }
      if ((a instanceof ol))
      {
        return new dh((ol)a);
      }
      if ((a instanceof od))
      {
        od entityitemframe = (od)a;
        dd packet23vehiclespawn = new dd(a, 71, a);
        b = ls.d(b * 32);
        c = ls.d(c * 32);
        d = ls.d(d * 32);
        return packet23vehiclespawn;
      }
      if ((a instanceof oe))
      {
        oe entityleashknot = (oe)a;
        dd packet23vehiclespawn = new dd(a, 77);
        b = ls.d(b * 32);
        c = ls.d(c * 32);
        d = ls.d(d * 32);
        return packet23vehiclespawn;
      }
      if ((a instanceof oa))
      {
        return new de((oa)a);
      }
      

      throw new IllegalArgumentException("Don't know how to add " + a.getClass() + "!");
    }
    



    i = ls.d(a.ap() * 256.0F / 360.0F);
    return new dg((of)a);
  }
  

  public void c(jv par1EntityPlayerMP)
  {
    if (o.contains(par1EntityPlayerMP))
    {
      o.remove(par1EntityPlayerMP);
      g.add(Integer.valueOf(a.k));
    }
  }
}
