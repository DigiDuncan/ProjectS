import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;





















public class nj
{
  private int a;
  public int b;
  private int c;
  private boolean d;
  private boolean e;
  @SideOnly(Side.CLIENT)
  private boolean f;
  private List<ye> curativeItems;
  
  public nj(int par1, int par2)
  {
    this(par1, par2, 0);
  }
  
  public nj(int par1, int par2, int par3)
  {
    this(par1, par2, par3, false);
  }
  
  public nj(int par1, int par2, int par3, boolean par4)
  {
    a = par1;
    b = par2;
    c = par3;
    e = par4;
    curativeItems = new ArrayList();
    curativeItems.add(new ye(yc.aI));
  }
  
  public nj(nj par1PotionEffect)
  {
    a = a;
    b = b;
    c = c;
    curativeItems = par1PotionEffect.getCurativeItems();
  }
  
  public boolean isValidPotionEffect()
  {
    return ni.a[a] != null;
  }
  




  public void a(nj par1PotionEffect)
  {
    if (a != a)
    {
      System.err.println("This method should only be called for matching effects!");
    }
    
    if (c > c)
    {
      c = c;
      b = b;
    }
    else if ((c == c) && (b < b))
    {
      b = b;
    }
    else if ((!e) && (e))
    {
      e = e;
    }
  }
  



  public int a()
  {
    return a;
  }
  
  public int b()
  {
    return b;
  }
  
  public int c()
  {
    return c;
  }
  




  public List<ye> getCurativeItems()
  {
    return curativeItems;
  }
  





  public boolean isCurativeItem(ye stack)
  {
    boolean found = false;
    for (ye curativeItem : curativeItems)
    {
      if (curativeItem.a(stack))
      {
        found = true;
      }
    }
    
    return found;
  }
  




  public void setCurativeItems(List<ye> curativeItems)
  {
    this.curativeItems = curativeItems;
  }
  




  public void addCurativeItem(ye stack)
  {
    boolean found = false;
    for (ye curativeItem : curativeItems)
    {
      if (curativeItem.a(stack))
      {
        found = true;
      }
    }
    if (!found)
    {
      curativeItems.add(stack);
    }
  }
  



  public void a(boolean par1)
  {
    d = par1;
  }
  



  public boolean e()
  {
    return e;
  }
  
  public boolean a(of par1EntityLivingBase)
  {
    if (b > 0)
    {


      int sized_amp = c;
      float slog2 = (float)(Math.log(par1EntityLivingBase.getSizeMultiplier()) / Math.log(2.0D));
      
      if (par1EntityLivingBase.getSizeMultiplier() > 1.0F)
      {
        sized_amp -= ls.d(slog2 * 0.75F);
      }
      else if (par1EntityLivingBase.getSizeMultiplier() < 1.0F)
      {
        sized_amp += ls.d(slog2 * -0.75F);
      }
      if ((isValidPotionEffect()) && (ni.a[a].a(b, sized_amp)))
      {
        b(par1EntityLivingBase);
      }
      
      h();
    }
    
    return b > 0;
  }
  
  private int h()
  {
    return --b;
  }
  
  public void b(of par1EntityLivingBase)
  {
    if ((b > 0) && (isValidPotionEffect()))
    {
      ni.a[a].a(par1EntityLivingBase, c);
    }
  }
  
  public void finishEffect(of par1EntityLivingBase)
  {
    if (isValidPotionEffect())
    {
      ni.a[a].finishEffect(par1EntityLivingBase);
    }
    b = 0;
  }
  
  public String f()
  {
    return isValidPotionEffect() ? ni.a[a].a() : "UNKNOWN EFFECT";
  }
  
  public int hashCode()
  {
    return a;
  }
  
  public String toString()
  {
    String s = "";
    
    if (c() > 0)
    {
      s = f() + " x " + (c() + 1) + ", Duration: " + b();
    }
    else
    {
      s = f() + ", Duration: " + b();
    }
    
    if (d)
    {
      s = s + ", Splash: true";
    }
    
    return (isValidPotionEffect()) && (ni.a[a].i()) ? "(" + s + ")" : s;
  }
  
  public boolean equals(Object par1Obj)
  {
    if (!(par1Obj instanceof nj))
    {
      return false;
    }
    

    nj potioneffect = (nj)par1Obj;
    return (a == a) && (c == c) && (b == b) && (d == d) && (e == e);
  }
  




  public by a(by par1NBTTagCompound)
  {
    par1NBTTagCompound.a("Id", (byte)a());
    par1NBTTagCompound.a("Amplifier", (byte)c());
    par1NBTTagCompound.a("Duration", b());
    par1NBTTagCompound.a("Ambient", e());
    return par1NBTTagCompound;
  }
  



  public static nj b(by par0NBTTagCompound)
  {
    byte b0 = par0NBTTagCompound.c("Id");
    byte b1 = par0NBTTagCompound.c("Amplifier");
    int i = par0NBTTagCompound.e("Duration");
    boolean flag = par0NBTTagCompound.n("Ambient");
    return new nj(b0, i, b1, flag);
  }
  




  @SideOnly(Side.CLIENT)
  public void b(boolean par1)
  {
    f = par1;
  }
  
  @SideOnly(Side.CLIENT)
  public boolean g()
  {
    return f;
  }
}
