import java.util.Random;
import org.apache.commons.lang3.StringUtils;



























public abstract class re
  extends ps
{
  protected on c;
  protected boolean canTargetOwner;
  protected boolean d;
  private boolean a;
  private int b;
  private int e;
  private int f;
  
  public re(on par1EntityCreature, boolean par2)
  {
    this(par1EntityCreature, par2, false);
  }
  
  public re(on par1EntityCreature, boolean par2, boolean par3)
  {
    c = par1EntityCreature;
    d = par2;
    a = par3;
  }
  
  public re setCanTargetOwner(boolean canTarget)
  {
    canTargetOwner = canTarget;
    
    return this;
  }
  



  public boolean b()
  {
    of entitylivingbase = c.m();
    
    if (entitylivingbase == null)
    {
      return false;
    }
    if (!entitylivingbase.T())
    {
      return false;
    }
    

    double d0 = f();
    
    double dist = d0 > 2.0D ? 2.0D + (d0 - 2.0D) * c.getRangeMultiplier() : d0;
    
    if (c.e(entitylivingbase) > dist * dist)
    {
      return false;
    }
    

    if (d)
    {
      if (c.l().a(entitylivingbase))
      {
        f = 0;
      }
      else if (++f > 60)
      {
        return false;
      }
    }
    
    return true;
  }
  


  protected double f()
  {
    os attributeinstance = c.a(tp.b);
    return attributeinstance == null ? 16.0D : attributeinstance.e();
  }
  



  public void c()
  {
    b = 0;
    e = 0;
    f = 0;
  }
  



  public void d()
  {
    c.d((of)null);
  }
  



  protected boolean a(of par1EntityLivingBase, boolean par2)
  {
    if (par1EntityLivingBase == null)
    {
      return false;
    }
    if (par1EntityLivingBase == c)
    {
      return false;
    }
    if (!par1EntityLivingBase.T())
    {
      return false;
    }
    if ((!c.isEntityInRelativeSizeRange(par1EntityLivingBase, minTargetSize, maxTargetSize)) && (par1EntityLivingBase != c.aE()))
    {

      return false;
    }
    if (!c.a(par1EntityLivingBase.getClass()))
    {
      return false;
    }
    

    if (((c instanceof ok)) && (StringUtils.isNotEmpty(((ok)c).h_())))
    {
      if (((par1EntityLivingBase instanceof ok)) && (((ok)c).h_().equals(((ok)par1EntityLivingBase).h_())) && (!canTargetOwner))
      {
        return false;
      }
      
      if ((par1EntityLivingBase == ((ok)c).d()) && (!canTargetOwner))
      {
        return false;
      }
    }
    else if (((par1EntityLivingBase instanceof uf)) && (!par2) && (bG.a))
    {
      return false;
    }
    
    if (!c.b(ls.c(u), ls.c(v), ls.c(w)))
    {
      return false;
    }
    if ((d) && (!c.l().a(par1EntityLivingBase)))
    {
      return false;
    }
    

    if (a)
    {
      if (--e <= 0)
      {
        b = 0;
      }
      
      if (b == 0)
      {
        b = (a(par1EntityLivingBase) ? 1 : 2);
      }
      
      if (b == 2)
      {
        return false;
      }
    }
    
    return true;
  }
  





  private boolean a(of par1EntityLivingBase)
  {
    e = (10 + c.aD().nextInt(5));
    alf pathentity = c.k().a(par1EntityLivingBase);
    
    if (pathentity == null)
    {
      return false;
    }
    

    ale pathpoint = pathentity.c();
    
    if (pathpoint == null)
    {
      return false;
    }
    

    int i = a - ls.c(u);
    int j = c - ls.c(w);
    return i * i + j * j <= 2.25D;
  }
}
