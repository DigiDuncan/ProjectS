








public class pf
{
  private og a;
  private double b;
  private double c;
  private double d;
  private double e;
  private boolean f;
  
  public pf(og par1EntityLiving)
  {
    a = par1EntityLiving;
    b = u;
    c = v;
    d = w;
  }
  
  public boolean a()
  {
    return f;
  }
  
  public double b()
  {
    return e;
  }
  



  public void a(double par1, double par3, double par5, double par7)
  {
    b = par1;
    c = par3;
    d = par5;
    e = par7;
    f = true;
  }
  
  public void c()
  {
    a.n(0.0F);
    
    if (this.f)
    {
      this.f = false;
      int i = ls.c(a.E.b + 0.5D);
      double d0 = b - a.u;
      double d1 = d - a.w;
      double d2 = c - i;
      double d3 = d0 * d0 + d2 * d2 + d1 * d1;
      
      if (d3 >= 2.500000277905201E-7D * (a.getSizeMultiplier() * a.getSizeMultiplier()))
      {
        float f = (float)(Math.atan2(d1, d0) * 180.0D / 3.141592653589793D) - 90.0F;
        a.A = a(a.A, f, 30.0F);
        a.i((float)(e * a.a(tp.d).e()));
        


        if (d2 > a.getStepHeight()) { if (d0 * d0 + d1 * d1 < (a.getSizeMultiplier() >= 1.0F ? 1.0D : a.getSizeMultiplierRoot()))
          {
            a.j().a();
          }
        }
      }
    }
  }
  


  private float a(float par1, float par2, float par3)
  {
    float f3 = ls.g(par2 - par1);
    
    if (f3 > par3)
    {
      f3 = par3;
    }
    
    if (f3 < -par3)
    {
      f3 = -par3;
    }
    
    return par1 + f3;
  }
}
