import com.google.common.collect.ImmutableSetMultimap;
import cpw.mods.fml.common.FMLLog;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import gulliver.common.GulliverEnvoy;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Set;
import net.minecraft.server.MinecraftServer;
import net.minecraftforge.client.ForgeHooksClient;
import net.minecraftforge.common.ForgeChunkManager;
import net.minecraftforge.common.ForgeChunkManager.Ticket;
import net.minecraftforge.common.ForgeDirection;
import net.minecraftforge.common.ForgeDummyContainer;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.WorldSpecificSaveHandler;
import net.minecraftforge.event.EventBus;
import net.minecraftforge.event.entity.EntityEvent.CanUpdate;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraftforge.event.entity.PlaySoundAtEntityEvent;























































public abstract class abw
  implements acf
{
  public static double MAX_ENTITY_RADIUS = 2.0D;
  


  public final amr perWorldStorage;
  

  public boolean d;
  

  public List e = new ArrayList();
  protected List f = new ArrayList();
  

  public List g = new ArrayList();
  private List a = new ArrayList();
  

  private List b = new ArrayList();
  

  public List h = new ArrayList();
  

  public List i = new ArrayList();
  private long c = 16777215L;
  



  public int j;
  



  protected int k = new Random().nextInt();
  



  protected final int l = 1013904223;
  

  public float m;
  

  public float n;
  
  public float o;
  
  public float p;
  
  public int q;
  
  public int r;
  
  public Random s = new Random();
  
  public final aei t;
  
  protected List u = new ArrayList();
  

  protected ado v;
  
  protected final amc w;
  
  protected als x;
  
  public boolean y;
  
  public amr z;
  
  public rm A;
  
  protected final rl B = new rl(this);
  
  public final lv C;
  
  private final atd J = new atd(300, 2000);
  private final Calendar K = Calendar.getInstance();
  protected atj D = new atj();
  
  private final lp L;
  
  private ArrayList M = new ArrayList();
  
  private boolean N;
  
  protected boolean E = true;
  

  protected boolean F = true;
  

  public Set G = new HashSet();
  

  private int O;
  

  int[] H;
  

  public boolean I;
  

  public float lastSizeBase;
  

  private static amr s_mapStorage;
  

  private static amc s_savehandler;
  


  public acq a(int par1, int par2)
  {
    return t.getBiomeGenForCoords(par1, par2);
  }
  
  public acq getBiomeGenForCoordsBody(int par1, int par2)
  {
    if (f(par1, 0, par2))
    {
      adr chunk = d(par1, par2);
      
      if (chunk != null)
      {
        return chunk.a(par1 & 0xF, par2 & 0xF, t.e);
      }
    }
    
    return t.e.a(par1, par2);
  }
  
  public acv u()
  {
    return t.e;
  }
  
  @SideOnly(Side.CLIENT)
  public abw(amc par1ISaveHandler, String par2Str, aei par3WorldProvider, acd par4WorldSettings, lv par5Profiler, lp par6ILogAgent)
  {
    O = s.nextInt(12000);
    H = new int[32768];
    w = par1ISaveHandler;
    C = par5Profiler;
    x = new als(par4WorldSettings, par2Str);
    t = par3WorldProvider;
    perWorldStorage = new amr((amc)null);
    lastSizeBase = GulliverEnvoy.getNewBasePlayerSize();
    L = par6ILogAgent;
  }
  


  @SideOnly(Side.CLIENT)
  protected void finishSetup()
  {
    rm villagecollection = (rm)z.a(rm.class, "villages");
    
    if (villagecollection == null)
    {
      A = new rm(this);
      z.a("villages", A);
    }
    else
    {
      A = villagecollection;
      A.a(this);
    }
    
    int providerDim = t.i;
    t.a(this);
    t.i = providerDim;
    v = j();
    A();
    a();
  }
  
  public abw(amc par1ISaveHandler, String par2Str, acd par3WorldSettings, aei par4WorldProvider, lv par5Profiler, lp par6ILogAgent)
  {
    O = s.nextInt(12000);
    H = new int[32768];
    w = par1ISaveHandler;
    C = par5Profiler;
    z = getMapStorage(par1ISaveHandler);
    L = par6ILogAgent;
    x = par1ISaveHandler.d();
    lastSizeBase = GulliverEnvoy.getNewBasePlayerSize();
    
    if (par4WorldProvider != null)
    {
      t = par4WorldProvider;
    }
    else if ((x != null) && (x.j() != 0))
    {
      t = aei.a(x.j());
    }
    else
    {
      t = aei.a(0);
    }
    
    if (x == null)
    {
      x = new als(par3WorldSettings, par2Str);
    }
    else
    {
      x.a(par2Str);
    }
    
    t.a(this);
    v = j();
    if ((this instanceof js))
    {
      perWorldStorage = new amr(new WorldSpecificSaveHandler((js)this, par1ISaveHandler));
    }
    else
    {
      perWorldStorage = new amr((amc)null);
    }
    
    if (!x.w())
    {
      try
      {
        a(par3WorldSettings);
      }
      catch (Throwable throwable)
      {
        b crashreport = b.a(throwable, "Exception initializing level");
        
        try
        {
          a(crashreport);
        }
        catch (Throwable throwable1) {}
        



        throw new u(crashreport);
      }
      
      x.d(true);
    }
    
    rm villagecollection = (rm)perWorldStorage.a(rm.class, "villages");
    
    if (villagecollection == null)
    {
      A = new rm(this);
      perWorldStorage.a("villages", A);
    }
    else
    {
      A = villagecollection;
      A.a(this);
    }
    
    A();
    a();
  }
  




  private amr getMapStorage(amc savehandler)
  {
    if ((s_savehandler != savehandler) || (s_mapStorage == null))
    {
      s_mapStorage = new amr(savehandler);
      s_savehandler = savehandler;
    }
    return s_mapStorage;
  }
  


  protected abstract ado j();
  

  protected void a(acd par1WorldSettings)
  {
    x.d(true);
  }
  




  @SideOnly(Side.CLIENT)
  public void f()
  {
    E(8, 64, 8);
  }
  






  public int b(int par1, int par2)
  {
    for (int k = 63; !c(par1, k + 1, par2); k++) {}
    



    return a(par1, k, par2);
  }
  



  public int a(int par1, int par2, int par3)
  {
    if ((par1 >= -30000000) && (par3 >= -30000000) && (par1 < 30000000) && (par3 < 30000000))
    {
      if (par2 < 0)
      {
        return 0;
      }
      if (par2 >= 256)
      {
        return 0;
      }
      

      adr chunk = null;
      
      try
      {
        chunk = e(par1 >> 4, par3 >> 4);
        return chunk.a(par1 & 0xF, par2, par3 & 0xF);
      }
      catch (Throwable throwable)
      {
        b crashreport = b.a(throwable, "Exception getting block type in world");
        m crashreportcategory = crashreport.a("Requested block coordinates");
        crashreportcategory.a("Found chunk", Boolean.valueOf(chunk == null));
        crashreportcategory.a("Location", m.a(par1, par2, par3));
        throw new u(crashreport);
      }
    }
    


    return 0;
  }
  




  public boolean c(int par1, int par2, int par3)
  {
    int id = a(par1, par2, par3);
    return (id == 0) || (aqz.s[id] == null) || (aqz.s[id].isAirBlock(this, par1, par2, par3));
  }
  



  public boolean d(int par1, int par2, int par3)
  {
    int l = a(par1, par2, par3);
    int meta = h(par1, par2, par3);
    return (aqz.s[l] != null) && (aqz.s[l].hasTileEntity(meta));
  }
  



  public int e(int par1, int par2, int par3)
  {
    int l = a(par1, par2, par3);
    return aqz.s[l] != null ? aqz.s[l].d() : -1;
  }
  



  public boolean f(int par1, int par2, int par3)
  {
    return (par2 >= 0) && (par2 < R()) ? c(par1 >> 4, par3 >> 4) : false;
  }
  



  public boolean b(int par1, int par2, int par3, int par4)
  {
    return e(par1 - par4, par2 - par4, par3 - par4, par1 + par4, par2 + par4, par3 + par4);
  }
  



  public boolean e(int par1, int par2, int par3, int par4, int par5, int par6)
  {
    if ((par5 >= 0) && (par2 < 256))
    {
      par1 >>= 4;
      par3 >>= 4;
      par4 >>= 4;
      par6 >>= 4;
      
      for (int k1 = par1; k1 <= par4; k1++)
      {
        for (int l1 = par3; l1 <= par6; l1++)
        {
          if (!c(k1, l1))
          {
            return false;
          }
        }
      }
      
      return true;
    }
    

    return false;
  }
  




  protected boolean c(int par1, int par2)
  {
    return v.a(par1, par2);
  }
  



  public adr d(int par1, int par2)
  {
    return e(par1 >> 4, par2 >> 4);
  }
  



  public adr e(int par1, int par2)
  {
    return v.d(par1, par2);
  }
  





  public boolean f(int par1, int par2, int par3, int par4, int par5, int par6)
  {
    if ((par1 >= -30000000) && (par3 >= -30000000) && (par1 < 30000000) && (par3 < 30000000))
    {
      if (par2 < 0)
      {
        return false;
      }
      if (par2 >= 256)
      {
        return false;
      }
      

      adr chunk = e(par1 >> 4, par3 >> 4);
      int k1 = 0;
      
      if ((par6 & 0x1) != 0)
      {
        k1 = chunk.a(par1 & 0xF, par2, par3 & 0xF);
      }
      
      boolean flag = chunk.a(par1 & 0xF, par2, par3 & 0xF, par4, par5);
      C.a("checkLight");
      A(par1, par2, par3);
      C.b();
      
      if (flag)
      {
        if (((par6 & 0x2) != 0) && ((!I) || ((par6 & 0x4) == 0)))
        {
          j(par1, par2, par3);
        }
        
        if ((!I) && ((par6 & 0x1) != 0))
        {
          d(par1, par2, par3, k1);
          aqz block = aqz.s[par4];
          
          if ((block != null) && (block.q_()))
          {
            m(par1, par2, par3, par4);
          }
        }
      }
      
      return flag;
    }
    


    return false;
  }
  




  public akc g(int par1, int par2, int par3)
  {
    int l = a(par1, par2, par3);
    return l == 0 ? akc.a : scU;
  }
  



  public int h(int par1, int par2, int par3)
  {
    if ((par1 >= -30000000) && (par3 >= -30000000) && (par1 < 30000000) && (par3 < 30000000))
    {
      if (par2 < 0)
      {
        return 0;
      }
      if (par2 >= 256)
      {
        return 0;
      }
      

      adr chunk = e(par1 >> 4, par3 >> 4);
      par1 &= 0xF;
      par3 &= 0xF;
      return chunk.c(par1, par2, par3);
    }
    


    return 0;
  }
  





  public boolean b(int par1, int par2, int par3, int par4, int par5)
  {
    if ((par1 >= -30000000) && (par3 >= -30000000) && (par1 < 30000000) && (par3 < 30000000))
    {
      if (par2 < 0)
      {
        return false;
      }
      if (par2 >= 256)
      {
        return false;
      }
      

      adr chunk = e(par1 >> 4, par3 >> 4);
      int j1 = par1 & 0xF;
      int k1 = par3 & 0xF;
      boolean flag = chunk.b(j1, par2, k1, par4);
      
      if (flag)
      {
        int l1 = chunk.a(j1, par2, k1);
        
        if (((par5 & 0x2) != 0) && ((!I) || ((par5 & 0x4) == 0)))
        {
          j(par1, par2, par3);
        }
        
        if ((!I) && ((par5 & 0x1) != 0))
        {
          d(par1, par2, par3, l1);
          aqz block = aqz.s[l1];
          
          if ((block != null) && (block.q_()))
          {
            m(par1, par2, par3, l1);
          }
        }
      }
      
      return flag;
    }
    


    return false;
  }
  




  public boolean i(int par1, int par2, int par3)
  {
    return f(par1, par2, par3, 0, 0, 3);
  }
  



  public boolean a(int par1, int par2, int par3, boolean par4)
  {
    int l = a(par1, par2, par3);
    
    if (l > 0)
    {
      int i1 = h(par1, par2, par3);
      e(2001, par1, par2, par3, l + (i1 << 12));
      
      if (par4)
      {
        aqz.s[l].c(this, par1, par2, par3, i1, 0);
      }
      
      return f(par1, par2, par3, 0, 0, 3);
    }
    

    return false;
  }
  




  public boolean c(int par1, int par2, int par3, int par4)
  {
    return f(par1, par2, par3, par4, 0, 3);
  }
  




  public void j(int par1, int par2, int par3)
  {
    for (int l = 0; l < u.size(); l++)
    {
      ((acb)u.get(l)).a(par1, par2, par3);
    }
  }
  



  public void d(int par1, int par2, int par3, int par4)
  {
    f(par1, par2, par3, par4);
  }
  





  public void e(int par1, int par2, int par3, int par4)
  {
    if (par3 > par4)
    {
      int i1 = par4;
      par4 = par3;
      par3 = i1;
    }
    
    if (!t.g)
    {
      for (int i1 = par3; i1 <= par4; i1++)
      {
        c(ach.a, par1, i1, par2);
      }
    }
    
    g(par1, par3, par2, par1, par4, par2);
  }
  




  public void g(int par1, int par2, int par3, int par4, int par5, int par6)
  {
    for (int k1 = 0; k1 < u.size(); k1++)
    {
      ((acb)u.get(k1)).a(par1, par2, par3, par4, par5, par6);
    }
  }
  



  public void f(int par1, int par2, int par3, int par4)
  {
    g(par1 - 1, par2, par3, par4);
    g(par1 + 1, par2, par3, par4);
    g(par1, par2 - 1, par3, par4);
    g(par1, par2 + 1, par3, par4);
    g(par1, par2, par3 - 1, par4);
    g(par1, par2, par3 + 1, par4);
  }
  




  public void c(int par1, int par2, int par3, int par4, int par5)
  {
    if (par5 != 4)
    {
      g(par1 - 1, par2, par3, par4);
    }
    
    if (par5 != 5)
    {
      g(par1 + 1, par2, par3, par4);
    }
    
    if (par5 != 0)
    {
      g(par1, par2 - 1, par3, par4);
    }
    
    if (par5 != 1)
    {
      g(par1, par2 + 1, par3, par4);
    }
    
    if (par5 != 2)
    {
      g(par1, par2, par3 - 1, par4);
    }
    
    if (par5 != 3)
    {
      g(par1, par2, par3 + 1, par4);
    }
  }
  



  public void g(int par1, int par2, int par3, int par4)
  {
    if (!I)
    {
      int i1 = a(par1, par2, par3);
      aqz block = aqz.s[i1];
      
      if (block != null)
      {
        try
        {
          block.a(this, par1, par2, par3, par4);
        }
        catch (Throwable throwable)
        {
          b crashreport = b.a(throwable, "Exception while updating neighbours");
          m crashreportcategory = crashreport.a("Block being updated");
          
          int j1;
          try
          {
            j1 = h(par1, par2, par3);
          }
          catch (Throwable throwable1)
          {
            j1 = -1;
          }
          
          crashreportcategory.a("Source block type", new abx(this, par4));
          m.a(crashreportcategory, par1, par2, par3, i1, j1);
          throw new u(crashreport);
        }
      }
    }
  }
  



  public boolean a(int par1, int par2, int par3, int par4)
  {
    return false;
  }
  



  public boolean l(int par1, int par2, int par3)
  {
    return e(par1 >> 4, par3 >> 4).d(par1 & 0xF, par2, par3 & 0xF);
  }
  



  public int m(int par1, int par2, int par3)
  {
    if (par2 < 0)
    {
      return 0;
    }
    

    if (par2 >= 256)
    {
      par2 = 255;
    }
    
    return e(par1 >> 4, par3 >> 4).c(par1 & 0xF, par2, par3 & 0xF, 0);
  }
  




  public int n(int par1, int par2, int par3)
  {
    return b(par1, par2, par3, true);
  }
  





  public int b(int par1, int par2, int par3, boolean par4)
  {
    if ((par1 >= -30000000) && (par3 >= -30000000) && (par1 < 30000000) && (par3 < 30000000))
    {
      if (par4)
      {
        int l = a(par1, par2, par3);
        
        if (aqz.x[l] != 0)
        {
          int i1 = b(par1, par2 + 1, par3, false);
          int j1 = b(par1 + 1, par2, par3, false);
          int k1 = b(par1 - 1, par2, par3, false);
          int l1 = b(par1, par2, par3 + 1, false);
          int i2 = b(par1, par2, par3 - 1, false);
          
          if (j1 > i1)
          {
            i1 = j1;
          }
          
          if (k1 > i1)
          {
            i1 = k1;
          }
          
          if (l1 > i1)
          {
            i1 = l1;
          }
          
          if (i2 > i1)
          {
            i1 = i2;
          }
          
          return i1;
        }
      }
      
      if (par2 < 0)
      {
        return 0;
      }
      

      if (par2 >= 256)
      {
        par2 = 255;
      }
      
      adr chunk = e(par1 >> 4, par3 >> 4);
      par1 &= 0xF;
      par3 &= 0xF;
      return chunk.c(par1, par2, par3, j);
    }
    


    return 15;
  }
  




  public int f(int par1, int par2)
  {
    if ((par1 >= -30000000) && (par2 >= -30000000) && (par1 < 30000000) && (par2 < 30000000))
    {
      if (!c(par1 >> 4, par2 >> 4))
      {
        return 0;
      }
      

      adr chunk = e(par1 >> 4, par2 >> 4);
      return chunk.b(par1 & 0xF, par2 & 0xF);
    }
    


    return 0;
  }
  





  public int g(int par1, int par2)
  {
    if ((par1 >= -30000000) && (par2 >= -30000000) && (par1 < 30000000) && (par2 < 30000000))
    {
      if (!c(par1 >> 4, par2 >> 4))
      {
        return 0;
      }
      

      adr chunk = e(par1 >> 4, par2 >> 4);
      return p;
    }
    


    return 0;
  }
  






  @SideOnly(Side.CLIENT)
  public int a(ach par1EnumSkyBlock, int par2, int par3, int par4)
  {
    if ((t.g) && (par1EnumSkyBlock == ach.a))
    {
      return 0;
    }
    

    if (par3 < 0)
    {
      par3 = 0;
    }
    
    if (par3 >= 256)
    {
      return c;
    }
    if ((par2 >= -30000000) && (par4 >= -30000000) && (par2 < 30000000) && (par4 < 30000000))
    {
      int l = par2 >> 4;
      int i1 = par4 >> 4;
      
      if (!c(l, i1))
      {
        return c;
      }
      if (aqz.x[a(par2, par3, par4)] != 0)
      {
        int j1 = b(par1EnumSkyBlock, par2, par3 + 1, par4);
        int k1 = b(par1EnumSkyBlock, par2 + 1, par3, par4);
        int l1 = b(par1EnumSkyBlock, par2 - 1, par3, par4);
        int i2 = b(par1EnumSkyBlock, par2, par3, par4 + 1);
        int j2 = b(par1EnumSkyBlock, par2, par3, par4 - 1);
        
        if (k1 > j1)
        {
          j1 = k1;
        }
        
        if (l1 > j1)
        {
          j1 = l1;
        }
        
        if (i2 > j1)
        {
          j1 = i2;
        }
        
        if (j2 > j1)
        {
          j1 = j2;
        }
        
        return j1;
      }
      

      adr chunk = e(l, i1);
      return chunk.a(par1EnumSkyBlock, par2 & 0xF, par3, par4 & 0xF);
    }
    


    return c;
  }
  






  public int b(ach par1EnumSkyBlock, int par2, int par3, int par4)
  {
    if (par3 < 0)
    {
      par3 = 0;
    }
    
    if (par3 >= 256)
    {
      par3 = 255;
    }
    
    if ((par2 >= -30000000) && (par4 >= -30000000) && (par2 < 30000000) && (par4 < 30000000))
    {
      int l = par2 >> 4;
      int i1 = par4 >> 4;
      
      if (!c(l, i1))
      {
        return c;
      }
      

      adr chunk = e(l, i1);
      return chunk.a(par1EnumSkyBlock, par2 & 0xF, par3, par4 & 0xF);
    }
    


    return c;
  }
  





  public void b(ach par1EnumSkyBlock, int par2, int par3, int par4, int par5)
  {
    if ((par2 >= -30000000) && (par4 >= -30000000) && (par2 < 30000000) && (par4 < 30000000))
    {
      if (par3 >= 0)
      {
        if (par3 < 256)
        {
          if (c(par2 >> 4, par4 >> 4))
          {
            adr chunk = e(par2 >> 4, par4 >> 4);
            chunk.a(par1EnumSkyBlock, par2 & 0xF, par3, par4 & 0xF, par5);
            
            for (int i1 = 0; i1 < u.size(); i1++)
            {
              ((acb)u.get(i1)).b(par2, par3, par4);
            }
          }
        }
      }
    }
  }
  



  public void p(int par1, int par2, int par3)
  {
    for (int l = 0; l < u.size(); l++)
    {
      ((acb)u.get(l)).b(par1, par2, par3);
    }
  }
  




  @SideOnly(Side.CLIENT)
  public int h(int par1, int par2, int par3, int par4)
  {
    int i1 = a(ach.a, par1, par2, par3);
    int j1 = a(ach.b, par1, par2, par3);
    
    if (j1 < par4)
    {
      j1 = par4;
    }
    
    return i1 << 20 | j1 << 4;
  }
  
  @SideOnly(Side.CLIENT)
  public float i(int par1, int par2, int par3, int par4)
  {
    int i1 = n(par1, par2, par3);
    
    if (i1 < par4)
    {
      i1 = par4;
    }
    
    return t.h[i1];
  }
  




  public float q(int par1, int par2, int par3)
  {
    return t.h[n(par1, par2, par3)];
  }
  



  public boolean v()
  {
    return t.isDaytime();
  }
  



  public ata a(atc par1Vec3, atc par2Vec3)
  {
    return a(par1Vec3, par2Vec3, false, false);
  }
  



  public ata a(atc par1Vec3, atc par2Vec3, boolean par3)
  {
    return a(par1Vec3, par2Vec3, par3, false);
  }
  
  public ata a(atc par1Vec3, atc par2Vec3, boolean par3, boolean par4)
  {
    return rayTraceBlocks_do_do_limit(par1Vec3, par2Vec3, par3, par4, false);
  }
  
  public ata rayTraceBlocks_do_do_limit(atc par1Vec3, atc par2Vec3, boolean par3, boolean par4, boolean par5)
  {
    return rayTraceBlocks_do_do_limit_leaves(par1Vec3, par2Vec3, par3, par4, par5, false);
  }
  
  public ata rayTraceBlocks_do_do_leaves(atc par1Vec3, atc par2Vec3, boolean par3, boolean par4, boolean par5)
  {
    return rayTraceBlocks_do_do_limit_leaves(par1Vec3, par2Vec3, par3, par4, false, par5);
  }
  
  public ata rayTraceBlocks_do_do_limit_leaves(atc par1Vec3, atc par2Vec3, boolean par3, boolean par4, boolean par5, boolean par6)
  {
    if ((!Double.isNaN(c)) && (!Double.isNaN(d)) && (!Double.isNaN(e)))
    {
      if ((!Double.isNaN(c)) && (!Double.isNaN(d)) && (!Double.isNaN(e)))
      {
        int i = ls.c(c);
        int j = ls.c(d);
        int k = ls.c(e);
        int l = ls.c(c);
        int i1 = ls.c(d);
        int j1 = ls.c(e);
        int k1 = a(l, i1, j1);
        int l1 = h(l, i1, j1);
        aqz block = aqz.s[k1];
        
        if ((block != null) && ((!par4) || (block == null) || (block.b(this, l, i1, j1) != null)) && (k1 > 0) && (block.a(l1, par3)) && ((!par6) || ((!(block instanceof arh)) && (cU != akc.x))))
        {
          ata movingobjectposition = block.a(this, l, i1, j1, par1Vec3, par2Vec3);
          
          if (movingobjectposition != null)
          {
            return movingobjectposition;
          }
        }
        
        k1 = 200;
        
        while (k1-- >= 0)
        {
          if ((Double.isNaN(c)) || (Double.isNaN(d)) || (Double.isNaN(e)))
          {
            return null;
          }
          
          if ((l == i) && (i1 == j) && (j1 == k))
          {
            return null;
          }
          
          boolean flag2 = true;
          boolean flag3 = true;
          boolean flag4 = true;
          double d0 = 999.0D;
          double d1 = 999.0D;
          double d2 = 999.0D;
          
          if (i > l)
          {
            d0 = l + 1.0D;
          }
          else if (i < l)
          {
            d0 = l + 0.0D;
          }
          else
          {
            flag2 = false;
          }
          
          if (j > i1)
          {
            d1 = i1 + 1.0D;
          }
          else if (j < i1)
          {
            d1 = i1 + 0.0D;
          }
          else
          {
            flag3 = false;
          }
          
          if (k > j1)
          {
            d2 = j1 + 1.0D;
          }
          else if (k < j1)
          {
            d2 = j1 + 0.0D;
          }
          else
          {
            flag4 = false;
          }
          
          double d3 = 999.0D;
          double d4 = 999.0D;
          double d5 = 999.0D;
          double d6 = c - c;
          double d7 = d - d;
          double d8 = e - e;
          
          if (flag2)
          {
            d3 = (d0 - c) / d6;
          }
          
          if (flag3)
          {
            d4 = (d1 - d) / d7;
          }
          
          if (flag4)
          {
            d5 = (d2 - e) / d8;
          }
          
          boolean flag5 = false;
          
          byte b0;
          if ((d3 < d4) && (d3 < d5)) { byte b0;
            byte b0;
            if (i > l)
            {
              b0 = 4;
            }
            else
            {
              b0 = 5;
            }
            
            c = d0;
            d += d7 * d3;
            e += d8 * d3;
          }
          else if (d4 < d5) { byte b0;
            byte b0;
            if (j > i1)
            {
              b0 = 0;
            }
            else
            {
              b0 = 1;
            }
            
            c += d6 * d4;
            d = d1;
            e += d8 * d4;
          }
          else {
            byte b0;
            if (k > j1)
            {
              b0 = 2;
            }
            else
            {
              b0 = 3;
            }
            
            c += d6 * d5;
            d += d7 * d5;
            e = d2;
          }
          
          atc vec32 = V().a(c, d, e);
          l = (int)(vec32.c = ls.c(c));
          
          if (b0 == 5)
          {
            l--;
            c += 1.0D;
          }
          
          i1 = (int)(vec32.d = ls.c(d));
          
          if (b0 == 1)
          {
            i1--;
            d += 1.0D;
          }
          
          j1 = (int)(vec32.e = ls.c(e));
          
          if (b0 == 3)
          {
            j1--;
            e += 1.0D;
          }
          
          boolean narrow = false;
          
          int i2 = a(l, i1, j1);
          int j2 = h(l, i1, j1);
          aqz block1 = aqz.s[i2];
          ata binner = (block1 != null) && (i2 > 0) ? block1.a(this, l, i1, j1, par1Vec3, par2Vec3) : null;
          
          if (par5)
          {
            ata bface = blockRayTrace(this, l, i1, j1, par1Vec3, par2Vec3);
            
            if (bface != null)
            {


              asx bb0 = (block1 != null) && (i2 > 0) ? block1.b(this, l, i1, j1) : null;
              int id1 = a(l - 1, i1, j1);
              aqz b1 = aqz.s[id1];
              int id2 = a(l + 1, i1, j1);
              aqz b2 = aqz.s[id2];
              





              if ((e != 4) && (e != 5))
              {
                asx bb1 = couldHugeCollideWithBlock(l - 1, i1, j1) ? b1.b(this, l - 1, i1, j1) : null;
                asx bb2 = couldHugeCollideWithBlock(l + 1, i1, j1) ? b2.b(this, l + 1, i1, j1) : null;
                

                if ((bb0 != null) || (bb1 != null) || (bb2 != null))
                {
                  if ((e == 0) || (e == 1))
                  {

                    double zbase = j1;
                    boolean bb0z = (bb0 != null) && (f - zbase > 0.25D) && (c - zbase < 0.75D);
                    boolean bb1z = (bb1 != null) && (f - zbase > 0.25D) && (c - zbase < 0.75D);
                    boolean bb2z = (bb2 != null) && (f - zbase > 0.25D) && (c - zbase < 0.75D);
                    boolean bb0zl = (bb0 != null) && (f.e <= c);
                    boolean bb0zg = (bb0 != null) && (f.e >= f);
                    boolean bb1zl = (bb1 != null) && (f.e <= c);
                    boolean bb1zg = (bb1 != null) && (f.e >= f);
                    boolean bb2zl = (bb2 != null) && (f.e <= c);
                    boolean bb2zg = (bb2 != null) && (f.e >= f);
                    
                    if ((bb0z) || ((bb1z) && (bb2z)))
                    {
                      if ((!bb0z) || (!bb1z) || (((!bb0zl) || (!bb1zl)) && ((!bb0zg) || (!bb1zg)) && ((f.c > d) || (a - d < 1.5D))))
                      {
                        if ((!bb0z) || (!bb2z) || (((!bb0zl) || (!bb2zl)) && ((!bb0zg) || (!bb2zg)) && ((f.c < a) || (a - d < 1.5D))))
                        {
                          if ((bb1z) || (!bb0z) || ((!bb0zl) && (!bb0zg) && ((f.c > d) || (a - l < 0.25D))))
                          {
                            if ((bb2z) || (!bb0z) || ((!bb0zl) && (!bb0zg) && ((f.c < a) || (d - l > 0.75D))))
                            {
                              if ((bb0z) || (!bb1z) || (!bb2z) || (a - d < 1.5D))
                              {


                                narrow = true; } }
                          }
                        }
                      }
                    }
                  } else {
                    double ybase = i1;
                    boolean bb0y = (bb0 != null) && (e - ybase > 0.25D) && (b - ybase < 0.75D);
                    boolean bb1y = (bb1 != null) && (e - ybase > 0.25D) && (b - ybase < 0.75D);
                    boolean bb2y = (bb2 != null) && (e - ybase > 0.25D) && (b - ybase < 0.75D);
                    boolean bb0yl = (bb0 != null) && (f.d <= b);
                    boolean bb0yg = (bb0 != null) && (f.d >= e);
                    boolean bb1yl = (bb1 != null) && (f.d <= b);
                    boolean bb1yg = (bb1 != null) && (f.d >= e);
                    boolean bb2yl = (bb2 != null) && (f.d <= b);
                    boolean bb2yg = (bb2 != null) && (f.d >= e);
                    
                    if ((bb0y) || ((bb1y) && (bb2y)))
                    {
                      if ((!bb0y) || (!bb1y) || (((!bb0yl) || (!bb1yl)) && ((!bb0yg) || (!bb1yg)) && ((f.c > d) || (a - d < 1.5D))))
                      {
                        if ((!bb0y) || (!bb2y) || (((!bb0yl) || (!bb2yl)) && ((!bb0yg) || (!bb2yg)) && ((f.c < a) || (a - d < 1.5D))))
                        {
                          if ((bb1y) || (!bb0y) || ((!bb0yl) && (!bb0yg) && ((f.c > d) || (a - l < 0.25D))))
                          {
                            if ((bb2y) || (!bb0y) || ((!bb0yl) && (!bb0yg) && ((f.c < a) || (d - l > 0.75D))))
                            {
                              if ((bb0y) || (!bb1y) || (!bb2y) || (a - d < 1.5D))
                              {




                                narrow = true; } } } }
                      }
                    }
                  }
                }
              }
              if (!narrow)
              {
                id1 = a(l, i1 - 1, j1);
                b1 = aqz.s[id1];
                id2 = a(l, i1 + 1, j1);
                b2 = aqz.s[id2];
                
                if ((e != 0) && (e != 1))
                {
                  asx bb1 = couldHugeCollideWithBlock(l, i1 - 1, j1) ? b1.b(this, l, i1 - 1, j1) : null;
                  asx bb2 = couldHugeCollideWithBlock(l, i1 + 1, j1) ? b2.b(this, l, i1 + 1, j1) : null;
                  

                  if ((bb0 != null) || (bb1 != null) || (bb2 != null))
                  {
                    if ((e == 4) || (e == 5))
                    {

                      double zbase = j1;
                      boolean bb0z = (bb0 != null) && (f - zbase > 0.25D) && (c - zbase < 0.75D);
                      boolean bb1z = (bb1 != null) && (f - zbase > 0.25D) && (c - zbase < 0.75D);
                      boolean bb2z = (bb2 != null) && (f - zbase > 0.25D) && (c - zbase < 0.75D);
                      boolean bb0zl = (bb0 != null) && (f.e <= c);
                      boolean bb0zg = (bb0 != null) && (f.e >= f);
                      boolean bb1zl = (bb1 != null) && (f.e <= c);
                      boolean bb1zg = (bb1 != null) && (f.e >= f);
                      boolean bb2zl = (bb2 != null) && (f.e <= c);
                      boolean bb2zg = (bb2 != null) && (f.e >= f);
                      
                      if ((bb0z) || ((bb1z) && (bb2z)))
                      {
                        if ((!bb0z) || (!bb1z) || (((!bb0zl) || (!bb1zl)) && ((!bb0zg) || (!bb1zg)) && ((f.d > e) || (b - e < 1.5D))))
                        {
                          if ((!bb0z) || (!bb2z) || (((!bb0zl) || (!bb2zl)) && ((!bb0zg) || (!bb2zg)) && ((f.d < b) || (b - e < 1.5D))))
                          {
                            if ((bb1z) || (!bb0z) || ((!bb0zl) && (!bb0zg) && ((f.d > e) || (b - i1 < 0.25D))))
                            {
                              if ((bb2z) || (!bb0z) || ((!bb0zl) && (!bb0zg) && ((f.d < b) || (e - i1 > 0.75D))))
                              {
                                if ((bb0z) || (!bb1z) || (!bb2z) || (b - e < 1.5D))
                                {



                                  narrow = true; } }
                            }
                          }
                        }
                      }
                    } else {
                      double xbase = l;
                      boolean bb0x = (bb0 != null) && (d - xbase > 0.25D) && (a - xbase < 0.75D);
                      boolean bb1x = (bb1 != null) && (d - xbase > 0.25D) && (a - xbase < 0.75D);
                      boolean bb2x = (bb2 != null) && (d - xbase > 0.25D) && (a - xbase < 0.75D);
                      boolean bb0xl = (bb0 != null) && (f.c <= a);
                      boolean bb0xg = (bb0 != null) && (f.c >= d);
                      boolean bb1xl = (bb1 != null) && (f.c <= a);
                      boolean bb1xg = (bb1 != null) && (f.c >= d);
                      boolean bb2xl = (bb2 != null) && (f.c <= a);
                      boolean bb2xg = (bb2 != null) && (f.c >= d);
                      
                      if ((bb0x) || ((bb1x) && (bb2x)))
                      {
                        if ((!bb0x) || (!bb1x) || (((!bb0xl) || (!bb1xl)) && ((!bb0xg) || (!bb1xg)) && ((f.d > e) || (b - e < 1.5D))))
                        {
                          if ((!bb0x) || (!bb2x) || (((!bb0xl) || (!bb2xl)) && ((!bb0xg) || (!bb2xg)) && ((f.d < b) || (b - e < 1.5D))))
                          {
                            if ((bb1x) || (!bb0x) || ((!bb0xl) && (!bb0xg) && ((f.d > e) || (b - i1 < 0.25D))))
                            {
                              if ((bb2x) || (!bb0x) || ((!bb0xl) && (!bb0xg) && ((f.d < b) || (e - i1 > 0.75D))))
                              {
                                if ((bb0x) || (!bb1x) || (!bb2x) || (b - e < 1.5D))
                                {



                                  narrow = true; } } } }
                        }
                      }
                    }
                  }
                }
              }
              if (!narrow)
              {
                id1 = a(l, i1, j1 - 1);
                b1 = aqz.s[id1];
                id2 = a(l, i1, j1 + 1);
                b2 = aqz.s[id2];
                
                if ((e != 2) && (e != 3))
                {
                  asx bb1 = couldHugeCollideWithBlock(l, i1, j1 - 1) ? b1.b(this, l, i1, j1 - 1) : null;
                  asx bb2 = couldHugeCollideWithBlock(l, i1, j1 + 1) ? b2.b(this, l, i1, j1 + 1) : null;
                  

                  if ((bb0 != null) || (bb1 != null) || (bb2 != null))
                  {
                    if ((e == 4) || (e == 5))
                    {

                      double ybase = i1;
                      boolean bb0y = (bb0 != null) && (e - ybase > 0.25D) && (b - ybase < 0.75D);
                      boolean bb1y = (bb1 != null) && (e - ybase > 0.25D) && (b - ybase < 0.75D);
                      boolean bb2y = (bb2 != null) && (e - ybase > 0.25D) && (b - ybase < 0.75D);
                      boolean bb0yl = (bb0 != null) && (f.d <= b);
                      boolean bb0yg = (bb0 != null) && (f.d >= e);
                      boolean bb1yl = (bb1 != null) && (f.d <= b);
                      boolean bb1yg = (bb1 != null) && (f.d >= e);
                      boolean bb2yl = (bb2 != null) && (f.d <= b);
                      boolean bb2yg = (bb2 != null) && (f.d >= e);
                      
                      if ((bb0y) || ((bb1y) && (bb2y)))
                      {
                        if ((!bb0y) || (!bb1y) || (((!bb0yl) || (!bb1yl)) && ((!bb0yg) || (!bb1yg)) && ((f.e > f) || (c - f < 1.5D))))
                        {
                          if ((!bb0y) || (!bb2y) || (((!bb0yl) || (!bb2yl)) && ((!bb0yg) || (!bb2yg)) && ((f.e < c) || (c - f < 1.5D))))
                          {
                            if ((bb1y) || (!bb0y) || ((!bb0yl) && (!bb0yg) && ((f.e > f) || (c - j1 < 0.25D))))
                            {
                              if ((bb2y) || (!bb0y) || ((!bb0yl) && (!bb0yg) && ((f.e < c) || (f - j1 > 0.75D))))
                              {
                                if ((bb0y) || (!bb1y) || (!bb2y) || (c - f < 1.5D))
                                {



                                  narrow = true; } }
                            }
                          }
                        }
                      }
                    } else {
                      double xbase = l;
                      boolean bb0x = (bb0 != null) && (d - xbase > 0.25D) && (a - xbase < 0.75D);
                      boolean bb1x = (bb1 != null) && (d - xbase > 0.25D) && (a - xbase < 0.75D);
                      boolean bb2x = (bb2 != null) && (d - xbase > 0.25D) && (a - xbase < 0.75D);
                      boolean bb0xl = (bb0 != null) && (f.c <= a);
                      boolean bb0xg = (bb0 != null) && (f.c >= d);
                      boolean bb1xl = (bb1 != null) && (f.c <= a);
                      boolean bb1xg = (bb1 != null) && (f.c >= d);
                      boolean bb2xl = (bb2 != null) && (f.c <= a);
                      boolean bb2xg = (bb2 != null) && (f.c >= d);
                      
                      if ((bb0x) || ((bb1x) && (bb2x)))
                      {
                        if ((!bb0x) || (!bb1x) || (((!bb0xl) || (!bb1xl)) && ((!bb0xg) || (!bb1xg)) && ((f.e > f) || (c - f < 1.5D))))
                        {
                          if ((!bb0x) || (!bb2x) || (((!bb0xl) || (!bb2xl)) && ((!bb0xg) || (!bb2xg)) && ((f.e < c) || (c - f < 1.5D))))
                          {
                            if ((bb1x) || (!bb0x) || ((!bb0xl) && (!bb0xg) && ((f.e > f) || (c - j1 < 0.25D))))
                            {
                              if ((bb2x) || (!bb0x) || ((!bb0xl) && (!bb0xg) && ((f.e < c) || (f - j1 > 0.75D))))
                              {
                                if ((bb0x) || (!bb1x) || (!bb2x) || (c - f < 1.5D))
                                {



                                  narrow = true; } } } }
                        }
                      }
                    }
                  }
                }
              }
            }
            if (narrow)
            {



              return bface;
            }
          }
          
          if (((!par4) || (block1 == null) || (block1.b(this, l, i1, j1) != null)) && (i2 > 0) && (block1.a(j2, par3)) && ((!par6) || ((!(block1 instanceof arh)) && (cU != akc.x))))
          {
            ata movingobjectposition1 = binner;
            
            if (movingobjectposition1 != null)
            {
              return movingobjectposition1;
            }
          }
        }
        
        return null;
      }
      

      return null;
    }
    


    return null;
  }
  


  private boolean couldHugeCollideWithBlock(int par1, int par2, int par3)
  {
    int id = a(par1, par2, par3);
    aqz b = aqz.s[id];
    
    return (b != null) && (id > 0) && (cU != akc.k) && (cU != akc.j) && (cU != akc.F);
  }
  

  public ata blockRayTrace(abw par1World, int par2, int par3, int par4, atc par5Vec3, atc par6Vec3)
  {
    par5Vec3 = par5Vec3.c(-par2, -par3, -par4);
    par6Vec3 = par6Vec3.c(-par2, -par3, -par4);
    atc var7 = par5Vec3.b(par6Vec3, 0.0D);
    atc var8 = par5Vec3.b(par6Vec3, 1.0D);
    atc var9 = par5Vec3.c(par6Vec3, 0.0D);
    atc var10 = par5Vec3.c(par6Vec3, 1.0D);
    atc var11 = par5Vec3.d(par6Vec3, 0.0D);
    atc var12 = par5Vec3.d(par6Vec3, 1.0D);
    
    if ((var7 == null) || (d < 0.0D) || (d > 1.0D) || (e < 0.0D) || (e > 1.0D))
    {
      var7 = null;
    }
    
    if ((var8 == null) || (d < 0.0D) || (d > 1.0D) || (e < 0.0D) || (e > 1.0D))
    {
      var8 = null;
    }
    
    if ((var9 == null) || (c < 0.0D) || (c > 1.0D) || (e < 0.0D) || (e > 1.0D))
    {
      var9 = null;
    }
    
    if ((var10 == null) || (c < 0.0D) || (c > 1.0D) || (e < 0.0D) || (e > 1.0D))
    {
      var10 = null;
    }
    
    if ((var11 == null) || (c < 0.0D) || (c > 1.0D) || (d < 0.0D) || (d > 1.0D))
    {
      var11 = null;
    }
    
    if ((var12 == null) || (c < 0.0D) || (c > 1.0D) || (d < 0.0D) || (d > 1.0D))
    {
      var12 = null;
    }
    
    atc var13 = null;
    
    if ((var7 != null) && ((var13 == null) || (par5Vec3.e(var7) < par5Vec3.e(var13))))
    {
      var13 = var7;
    }
    
    if ((var8 != null) && ((var13 == null) || (par5Vec3.e(var8) < par5Vec3.e(var13))))
    {
      var13 = var8;
    }
    
    if ((var9 != null) && ((var13 == null) || (par5Vec3.e(var9) < par5Vec3.e(var13))))
    {
      var13 = var9;
    }
    
    if ((var10 != null) && ((var13 == null) || (par5Vec3.e(var10) < par5Vec3.e(var13))))
    {
      var13 = var10;
    }
    
    if ((var11 != null) && ((var13 == null) || (par5Vec3.e(var11) < par5Vec3.e(var13))))
    {
      var13 = var11;
    }
    
    if ((var12 != null) && ((var13 == null) || (par5Vec3.e(var12) < par5Vec3.e(var13))))
    {
      var13 = var12;
    }
    
    if (var13 == null)
    {
      return null;
    }
    

    byte var14 = -1;
    
    if (var13 == var7)
    {
      var14 = 4;
    }
    
    if (var13 == var8)
    {
      var14 = 5;
    }
    
    if (var13 == var9)
    {
      var14 = 0;
    }
    
    if (var13 == var10)
    {
      var14 = 1;
    }
    
    if (var13 == var11)
    {
      var14 = 2;
    }
    
    if (var13 == var12)
    {
      var14 = 3;
    }
    
    return new ata(par2, par3, par4, var14, var13.c(par2, par3, par4));
  }
  





  public void a(nn par1Entity, String par2Str, float par3, float par4)
  {
    PlaySoundAtEntityEvent event = new PlaySoundAtEntityEvent(par1Entity, par2Str, par3, par4);
    if (MinecraftForge.EVENT_BUS.post(event))
    {
      return;
    }
    par2Str = name;
    if ((par1Entity != null) && (par2Str != null))
    {
      for (int i = 0; i < u.size(); i++)
      {
        ((acb)u.get(i)).a(par2Str, u, v - N, w, par3, par4);
      }
    }
  }
  



  public void a(uf par1EntityPlayer, String par2Str, float par3, float par4)
  {
    PlaySoundAtEntityEvent event = new PlaySoundAtEntityEvent(par1EntityPlayer, par2Str, par3, par4);
    if (MinecraftForge.EVENT_BUS.post(event))
    {
      return;
    }
    par2Str = name;
    if ((par1EntityPlayer != null) && (par2Str != null))
    {
      for (int i = 0; i < u.size(); i++)
      {
        ((acb)u.get(i)).a(par1EntityPlayer, par2Str, u, v - N, w, par3, par4);
      }
    }
  }
  





  public void a(double par1, double par3, double par5, String par7Str, float par8, float par9)
  {
    if (par7Str != null)
    {
      for (int i = 0; i < u.size(); i++)
      {
        ((acb)u.get(i)).a(par7Str, par1, par3, par5, par8, par9);
      }
    }
  }
  



  public void a(double par1, double par3, double par5, String par7Str, float par8, float par9, boolean par10) {}
  



  public void a(String par1Str, int par2, int par3, int par4)
  {
    for (int l = 0; l < u.size(); l++)
    {
      ((acb)u.get(l)).a(par1Str, par2, par3, par4);
    }
  }
  



  public void a(String par1Str, double par2, double par4, double par6, double par8, double par10, double par12)
  {
    for (int i = 0; i < u.size(); i++)
    {
      ((acb)u.get(i)).a(par1Str, par2, par4, par6, par8, par10, par12);
    }
  }
  



  public boolean c(nn par1Entity)
  {
    i.add(par1Entity);
    return true;
  }
  



  public boolean d(nn par1Entity)
  {
    int i = ls.c(u / 16.0D);
    int j = ls.c(w / 16.0D);
    boolean flag = p;
    
    if ((par1Entity instanceof uf))
    {
      flag = true;
    }
    
    if ((!flag) && (!c(i, j)))
    {
      return false;
    }
    

    if ((par1Entity instanceof uf))
    {
      uf entityplayer = (uf)par1Entity;
      h.add(entityplayer);
      c();
    }
    
    if ((MinecraftForge.EVENT_BUS.post(new EntityJoinWorldEvent(par1Entity, this))) && (!flag))
    {
      return false;
    }
    
    e(i, j).a(par1Entity);
    e.add(par1Entity);
    a(par1Entity);
    return true;
  }
  

  protected void a(nn par1Entity)
  {
    for (int i = 0; i < u.size(); i++)
    {
      ((acb)u.get(i)).a(par1Entity);
    }
  }
  
  public void b(nn par1Entity)
  {
    for (int i = 0; i < u.size(); i++)
    {
      ((acb)u.get(i)).b(par1Entity);
    }
  }
  



  public void e(nn par1Entity)
  {
    if (n != null)
    {
      n.a((nn)null);
    }
    
    if (heldEntity != null)
    {
      par1Entity.dropHeldEntity(heldEntity);
    }
    
    if (o != null)
    {
      par1Entity.a((nn)null);
    }
    
    if (holdingEntity != null)
    {
      par1Entity.getDroppedByEntity(holdingEntity);
    }
    
    par1Entity.x();
    
    if ((par1Entity instanceof uf))
    {
      lastSizeBase = sizeBaseMultiplier;
      h.remove(par1Entity);
      c();
    }
  }
  



  public void f(nn par1Entity)
  {
    par1Entity.x();
    
    if ((par1Entity instanceof uf))
    {
      h.remove(par1Entity);
      c();
    }
    
    int i = aj;
    int j = al;
    
    if ((ai) && (c(i, j)))
    {
      e(i, j).b(par1Entity);
    }
    
    e.remove(par1Entity);
    b(par1Entity);
  }
  



  public void a(acb par1IWorldAccess)
  {
    u.add(par1IWorldAccess);
  }
  




  public List a(nn par1Entity, asx par2AxisAlignedBB)
  {
    M.clear();
    int i = ls.c(a);
    int j = ls.c(d + 1.0D);
    int k = ls.c(b);
    int l = ls.c(e + 1.0D);
    int i1 = ls.c(c);
    int j1 = ls.c(f + 1.0D);
    
    for (int k1 = i; k1 < j; k1++)
    {
      for (int l1 = i1; l1 < j1; l1++)
      {
        if (f(k1, 64, l1))
        {
          for (int i2 = k - 1; i2 < l; i2++)
          {
            aqz block = aqz.s[a(k1, i2, l1)];
            
            if (block != null)
            {
              block.a(this, k1, i2, l1, par2AxisAlignedBB, M, par1Entity);
            }
          }
        }
      }
    }
    
    double d0 = 0.25D;
    List list = b(par1Entity, par2AxisAlignedBB.b(d0, d0, d0));
    
    for (int j2 = 0; j2 < list.size(); j2++)
    {
      asx axisalignedbb1 = ((nn)list.get(j2)).E();
      
      if ((axisalignedbb1 != null) && (axisalignedbb1.b(par2AxisAlignedBB)))
      {
        M.add(axisalignedbb1);
      }
      
      axisalignedbb1 = par1Entity.g((nn)list.get(j2));
      
      if ((axisalignedbb1 != null) && (axisalignedbb1.b(par2AxisAlignedBB)))
      {
        M.add(axisalignedbb1);
      }
    }
    
    return M;
  }
  



  public List a(asx par1AxisAlignedBB)
  {
    return getAllCollidingBoundingBoxes((nn)null, par1AxisAlignedBB);
  }
  
  public List getAllCollidingBoundingBoxes(nn par1Entity, asx par1AxisAlignedBB)
  {
    M.clear();
    int i = ls.c(a);
    int j = ls.c(d + 1.0D);
    int k = ls.c(b);
    int l = ls.c(e + 1.0D);
    int i1 = ls.c(c);
    int j1 = ls.c(f + 1.0D);
    
    for (int k1 = i; k1 < j; k1++)
    {
      for (int l1 = i1; l1 < j1; l1++)
      {
        if (f(k1, 64, l1))
        {
          for (int i2 = k - 1; i2 < l; i2++)
          {
            aqz block = aqz.s[a(k1, i2, l1)];
            
            if (block != null)
            {
              block.a(this, k1, i2, l1, par1AxisAlignedBB, M, par1Entity);
            }
          }
        }
      }
    }
    
    return M;
  }
  



  public int a(float par1)
  {
    float f1 = c(par1);
    float f2 = 1.0F - (ls.b(f1 * 3.1415927F * 2.0F) * 2.0F + 0.5F);
    
    if (f2 < 0.0F)
    {
      f2 = 0.0F;
    }
    
    if (f2 > 1.0F)
    {
      f2 = 1.0F;
    }
    
    f2 = 1.0F - f2;
    f2 = (float)(f2 * (1.0D - i(par1) * 5.0F / 16.0D));
    f2 = (float)(f2 * (1.0D - h(par1) * 5.0F / 16.0D));
    f2 = 1.0F - f2;
    return (int)(f2 * 11.0F);
  }
  




  @SideOnly(Side.CLIENT)
  public void b(acb par1IWorldAccess)
  {
    u.remove(par1IWorldAccess);
  }
  




  @SideOnly(Side.CLIENT)
  public float b(float par1)
  {
    float f1 = c(par1);
    float f2 = 1.0F - (ls.b(f1 * 3.1415927F * 2.0F) * 2.0F + 0.2F);
    
    if (f2 < 0.0F)
    {
      f2 = 0.0F;
    }
    
    if (f2 > 1.0F)
    {
      f2 = 1.0F;
    }
    
    f2 = 1.0F - f2;
    f2 = (float)(f2 * (1.0D - i(par1) * 5.0F / 16.0D));
    f2 = (float)(f2 * (1.0D - h(par1) * 5.0F / 16.0D));
    return f2 * 0.8F + 0.2F;
  }
  




  @SideOnly(Side.CLIENT)
  public atc a(nn par1Entity, float par2)
  {
    return t.getSkyColor(par1Entity, par2);
  }
  
  @SideOnly(Side.CLIENT)
  public atc getSkyColorBody(nn par1Entity, float par2)
  {
    float f1 = c(par2);
    float f2 = ls.b(f1 * 3.1415927F * 2.0F) * 2.0F + 0.5F;
    
    if (f2 < 0.0F)
    {
      f2 = 0.0F;
    }
    
    if (f2 > 1.0F)
    {
      f2 = 1.0F;
    }
    
    int i = ls.c(u);
    int j = ls.c(w);
    
    int multiplier = ForgeHooksClient.getSkyBlendColour(this, i, j);
    
    float f4 = (multiplier >> 16 & 0xFF) / 255.0F;
    float f5 = (multiplier >> 8 & 0xFF) / 255.0F;
    float f6 = (multiplier & 0xFF) / 255.0F;
    f4 *= f2;
    f5 *= f2;
    f6 *= f2;
    float f7 = i(par2);
    


    if (f7 > 0.0F)
    {
      float f8 = (f4 * 0.3F + f5 * 0.59F + f6 * 0.11F) * 0.6F;
      float f9 = 1.0F - f7 * 0.75F;
      f4 = f4 * f9 + f8 * (1.0F - f9);
      f5 = f5 * f9 + f8 * (1.0F - f9);
      f6 = f6 * f9 + f8 * (1.0F - f9);
    }
    
    float f8 = h(par2);
    
    if (f8 > 0.0F)
    {
      float f9 = (f4 * 0.3F + f5 * 0.59F + f6 * 0.11F) * 0.2F;
      float f10 = 1.0F - f8 * 0.75F;
      f4 = f4 * f10 + f9 * (1.0F - f10);
      f5 = f5 * f10 + f9 * (1.0F - f10);
      f6 = f6 * f10 + f9 * (1.0F - f10);
    }
    
    if (q > 0)
    {
      float f9 = q - par2;
      
      if (f9 > 1.0F)
      {
        f9 = 1.0F;
      }
      
      f9 *= 0.45F;
      f4 = f4 * (1.0F - f9) + 0.8F * f9;
      f5 = f5 * (1.0F - f9) + 0.8F * f9;
      f6 = f6 * (1.0F - f9) + 1.0F * f9;
    }
    
    return V().a(f4, f5, f6);
  }
  



  public float c(float par1)
  {
    return t.a(x.g(), par1);
  }
  
  @SideOnly(Side.CLIENT)
  public int w()
  {
    return t.a(x.g());
  }
  



  public float x()
  {
    return aei.a[t.a(x.g())];
  }
  



  public float d(float par1)
  {
    float f1 = c(par1);
    return f1 * 3.1415927F * 2.0F;
  }
  
  @SideOnly(Side.CLIENT)
  public atc e(float par1)
  {
    return t.drawClouds(par1);
  }
  
  @SideOnly(Side.CLIENT)
  public atc drawCloudsBody(float par1)
  {
    float f1 = c(par1);
    float f2 = ls.b(f1 * 3.1415927F * 2.0F) * 2.0F + 0.5F;
    
    if (f2 < 0.0F)
    {
      f2 = 0.0F;
    }
    
    if (f2 > 1.0F)
    {
      f2 = 1.0F;
    }
    
    float f3 = (float)(c >> 16 & 0xFF) / 255.0F;
    float f4 = (float)(c >> 8 & 0xFF) / 255.0F;
    float f5 = (float)(c & 0xFF) / 255.0F;
    float f6 = i(par1);
    


    if (f6 > 0.0F)
    {
      float f7 = (f3 * 0.3F + f4 * 0.59F + f5 * 0.11F) * 0.6F;
      float f8 = 1.0F - f6 * 0.95F;
      f3 = f3 * f8 + f7 * (1.0F - f8);
      f4 = f4 * f8 + f7 * (1.0F - f8);
      f5 = f5 * f8 + f7 * (1.0F - f8);
    }
    
    f3 *= (f2 * 0.9F + 0.1F);
    f4 *= (f2 * 0.9F + 0.1F);
    f5 *= (f2 * 0.85F + 0.15F);
    float f7 = h(par1);
    
    if (f7 > 0.0F)
    {
      float f8 = (f3 * 0.3F + f4 * 0.59F + f5 * 0.11F) * 0.2F;
      float f9 = 1.0F - f7 * 0.95F;
      f3 = f3 * f9 + f8 * (1.0F - f9);
      f4 = f4 * f9 + f8 * (1.0F - f9);
      f5 = f5 * f9 + f8 * (1.0F - f9);
    }
    
    return V().a(f3, f4, f5);
  }
  




  @SideOnly(Side.CLIENT)
  public atc f(float par1)
  {
    float f1 = c(par1);
    return t.b(f1, par1);
  }
  



  public int h(int par1, int par2)
  {
    return d(par1, par2).d(par1 & 0xF, par2 & 0xF);
  }
  



  public int i(int par1, int par2)
  {
    adr chunk = d(par1, par2);
    int x = par1;
    int z = par2;
    int k = chunk.h() + 15;
    par1 &= 0xF;
    
    for (par2 &= 0xF; k > 0; k--)
    {
      int l = chunk.a(par1, k, par2);
      
      if ((l != 0) && (scU.c()) && (scU != akc.j) && (!aqz.s[l].isBlockFoliage(this, x, k, z)))
      {
        return k + 1;
      }
    }
    
    return -1;
  }
  




  @SideOnly(Side.CLIENT)
  public float g(float par1)
  {
    return t.getStarBrightness(par1);
  }
  
  @SideOnly(Side.CLIENT)
  public float getStarBrightnessBody(float par1)
  {
    float f1 = c(par1);
    float f2 = 1.0F - (ls.b(f1 * 3.1415927F * 2.0F) * 2.0F + 0.25F);
    
    if (f2 < 0.0F)
    {
      f2 = 0.0F;
    }
    
    if (f2 > 1.0F)
    {
      f2 = 1.0F;
    }
    
    return f2 * f2 * 0.5F;
  }
  



  public void a(int par1, int par2, int par3, int par4, int par5) {}
  


  public void a(int par1, int par2, int par3, int par4, int par5, int par6) {}
  


  public void b(int par1, int par2, int par3, int par4, int par5, int par6) {}
  


  public void h()
  {
    C.a("entities");
    C.a("global");
    




    for (int i = 0; i < this.i.size(); i++)
    {
      nn entity = (nn)this.i.get(i);
      
      try
      {
        ac += 1;
        entity.l_();
      }
      catch (Throwable throwable)
      {
        b crashreport = b.a(throwable, "Ticking entity");
        m crashreportcategory = crashreport.a("Entity being ticked");
        
        if (entity == null)
        {
          crashreportcategory.a("Entity", "~~NULL~~");
        }
        else
        {
          entity.a(crashreportcategory);
        }
        
        if (ForgeDummyContainer.removeErroringEntities)
        {
          FMLLog.severe(crashreport.e(), new Object[0]);
          e(entity);
        }
        else
        {
          throw new u(crashreport);
        }
      }
      
      if (M)
      {
        this.i.remove(i--);
      }
    }
    
    C.c("remove");
    e.removeAll(f);
    


    for (i = 0; i < f.size(); i++)
    {
      nn entity = (nn)f.get(i);
      int j = aj;
      int k = al;
      
      if ((ai) && (c(j, k)))
      {
        e(j, k).b(entity);
      }
    }
    
    for (i = 0; i < f.size(); i++)
    {
      b((nn)f.get(i));
    }
    
    f.clear();
    C.c("regular");
    
    for (i = 0; i < e.size(); i++)
    {
      nn entity = (nn)e.get(i);
      
      if (o != null)
      {
        if ((o.M) || (o.n != entity))
        {



          o.n = null;
          o = null;
        }
      } else {
        C.a("tick");
        
        if (!M)
        {
          try
          {
            g(entity);
          }
          catch (Throwable throwable1)
          {
            b crashreport = b.a(throwable1, "Ticking entity");
            m crashreportcategory = crashreport.a("Entity being ticked");
            entity.a(crashreportcategory);
            
            if (ForgeDummyContainer.removeErroringEntities)
            {
              FMLLog.severe(crashreport.e(), new Object[0]);
              e(entity);
            }
            else
            {
              throw new u(crashreport);
            }
          }
        }
        
        C.b();
        C.a("remove");
        
        if (M)
        {
          int j = aj;
          int k = al;
          
          if ((ai) && (c(j, k)))
          {
            e(j, k).b(entity);
          }
          
          e.remove(i--);
          b(entity);
        }
        
        C.b();
      }
    }
    C.c("tileEntities");
    N = true;
    Iterator iterator = g.iterator();
    
    while (iterator.hasNext())
    {
      asp tileentity = (asp)iterator.next();
      
      if ((!tileentity.r()) && (tileentity.o()) && (f(l, m, n)))
      {
        try
        {
          tileentity.h();
        }
        catch (Throwable throwable2)
        {
          b crashreport = b.a(throwable2, "Ticking tile entity");
          m crashreportcategory = crashreport.a("Tile entity being ticked");
          tileentity.a(crashreportcategory);
          if (ForgeDummyContainer.removeErroringTileEntities)
          {
            FMLLog.severe(crashreport.e(), new Object[0]);
            tileentity.w_();
            i(l, m, n);
          }
          else
          {
            throw new u(crashreport);
          }
        }
      }
      
      if (tileentity.r())
      {
        iterator.remove();
        
        if (c(l >> 4, n >> 4))
        {
          adr chunk = e(l >> 4, n >> 4);
          
          if (chunk != null)
          {
            chunk.cleanChunkBlockTileEntity(l & 0xF, m, n & 0xF);
          }
        }
      }
    }
    

    if (!b.isEmpty())
    {
      for (Object tile : b)
      {
        ((asp)tile).onChunkUnload();
      }
      g.removeAll(b);
      b.clear();
    }
    
    N = false;
    
    C.c("pendingTileEntities");
    
    if (!a.isEmpty())
    {
      for (int l = 0; l < a.size(); l++)
      {
        asp tileentity1 = (asp)a.get(l);
        
        if (!tileentity1.r())
        {
          if (!g.contains(tileentity1))
          {
            g.add(tileentity1);
          }
          

        }
        else if (c(l >> 4, n >> 4))
        {
          adr chunk1 = e(l >> 4, n >> 4);
          
          if (chunk1 != null)
          {
            chunk1.cleanChunkBlockTileEntity(l & 0xF, m, n & 0xF);
          }
        }
      }
      

      a.clear();
    }
    
    C.b();
    C.b();
  }
  
  public void a(Collection par1Collection)
  {
    List dest = N ? a : g;
    for (Object entity : par1Collection)
    {
      if (((asp)entity).canUpdate())
      {
        dest.add(entity);
      }
    }
  }
  



  public void g(nn par1Entity)
  {
    a(par1Entity, true);
  }
  




  public void a(nn par1Entity, boolean par2)
  {
    int i = ls.c(u);
    int j = ls.c(w);
    
    boolean isForced = getPersistentChunks().containsKey(new abp(i >> 4, j >> 4));
    byte b0 = isForced ? 0 : 32;
    boolean canUpdate = (!par2) || (e(i - b0, 0, j - b0, i + b0, 0, j + b0));
    if (!canUpdate)
    {
      EntityEvent.CanUpdate event = new EntityEvent.CanUpdate(par1Entity);
      MinecraftForge.EVENT_BUS.post(event);
      canUpdate = canUpdate;
    }
    if (canUpdate)
    {
      U = u;
      V = v;
      W = w;
      C = A;
      D = B;
      
      if ((par2) && (ai))
      {
        ac += 1;
        
        if ((o != null) || (holdingEntity != null))
        {
          par1Entity.V();
        }
        else
        {
          par1Entity.l_();
        }
      }
      
      C.a("chunkCheck");
      
      if ((Double.isNaN(u)) || (Double.isInfinite(u)))
      {
        u = U;
      }
      
      if ((Double.isNaN(v)) || (Double.isInfinite(v)))
      {
        v = V;
      }
      
      if ((Double.isNaN(w)) || (Double.isInfinite(w)))
      {
        w = W;
      }
      
      if ((Double.isNaN(B)) || (Double.isInfinite(B)))
      {
        B = D;
      }
      
      if ((Double.isNaN(A)) || (Double.isInfinite(A)))
      {
        A = C;
      }
      
      int k = ls.c(u / 16.0D);
      int l = ls.c(v / 16.0D);
      int i1 = ls.c(w / 16.0D);
      
      if ((!ai) || (aj != k) || (ak != l) || (al != i1))
      {
        if ((ai) && (c(aj, al)))
        {
          e(aj, al).a(par1Entity, ak);
        }
        
        if (c(k, i1))
        {
          ai = true;
          e(k, i1).a(par1Entity);
        }
        else
        {
          ai = false;
        }
      }
      
      C.b();
      
      if ((par2) && (ai) && (n != null))
      {

        if ((!n.M) && (n.o == par1Entity) && (o != n))
        {
          g(n);
        }
        else
        {
          n.o = null;
          n = null;
        }
      }
    }
  }
  



  public boolean b(asx par1AxisAlignedBB)
  {
    return a(par1AxisAlignedBB, (nn)null);
  }
  



  public boolean a(asx par1AxisAlignedBB, nn par2Entity)
  {
    List list = b((nn)null, par1AxisAlignedBB);
    
    for (int i = 0; i < list.size(); i++)
    {
      nn entity1 = (nn)list.get(i);
      
      if ((!M) && (m) && (entity1 != par2Entity))
      {
        return false;
      }
    }
    
    return true;
  }
  



  public boolean c(asx par1AxisAlignedBB)
  {
    int i = ls.c(a);
    int j = ls.c(d + 1.0D);
    int k = ls.c(b);
    int l = ls.c(e + 1.0D);
    int i1 = ls.c(c);
    int j1 = ls.c(f + 1.0D);
    
    if (a < 0.0D)
    {
      i--;
    }
    
    if (b < 0.0D)
    {
      k--;
    }
    
    if (c < 0.0D)
    {
      i1--;
    }
    
    for (int k1 = i; k1 < j; k1++)
    {
      for (int l1 = k; l1 < l; l1++)
      {
        for (int i2 = i1; i2 < j1; i2++)
        {
          aqz block = aqz.s[a(k1, l1, i2)];
          
          if (block != null)
          {
            return true;
          }
        }
      }
    }
    
    return false;
  }
  



  public boolean d(asx par1AxisAlignedBB)
  {
    int i = ls.c(a);
    int j = ls.c(d + 1.0D);
    int k = ls.c(b);
    int l = ls.c(e + 1.0D);
    int i1 = ls.c(c);
    int j1 = ls.c(f + 1.0D);
    
    if (a < 0.0D)
    {
      i--;
    }
    
    if (b < 0.0D)
    {
      k--;
    }
    
    if (c < 0.0D)
    {
      i1--;
    }
    
    for (int k1 = i; k1 < j; k1++)
    {
      for (int l1 = k; l1 < l; l1++)
      {
        for (int i2 = i1; i2 < j1; i2++)
        {
          aqz block = aqz.s[a(k1, l1, i2)];
          
          if ((block != null) && ((cU.d()) || ((cF == bLcF) && (h(k1, l1, i2) > 0))))
          {
            return true;
          }
        }
      }
    }
    
    return false;
  }
  



  public boolean e(asx par1AxisAlignedBB)
  {
    int i = ls.c(a);
    int j = ls.c(d + 1.0D);
    int k = ls.c(b);
    int l = ls.c(e + 1.0D);
    int i1 = ls.c(c);
    int j1 = ls.c(f + 1.0D);
    
    if (e(i, k, i1, j, l, j1))
    {
      for (int k1 = i; k1 < j; k1++)
      {
        for (int l1 = k; l1 < l; l1++)
        {
          for (int i2 = i1; i2 < j1; i2++)
          {
            int j2 = a(k1, l1, i2);
            
            if ((j2 == awcF) || (j2 == HcF) || (j2 == IcF))
            {
              return true;
            }
            

            aqz block = aqz.s[j2];
            if ((block != null) && (block.isBlockBurning(this, k1, l1, i2)))
            {
              return true;
            }
          }
        }
      }
    }
    

    return false;
  }
  



  public boolean a(asx par1AxisAlignedBB, akc par2Material, nn par3Entity)
  {
    int i = ls.c(a);
    int j = ls.c(d + 1.0D);
    int k = ls.c(b);
    int l = ls.c(e + 1.0D);
    int i1 = ls.c(c);
    int j1 = ls.c(f + 1.0D);
    
    if (!e(i, k, i1, j, l, j1))
    {
      return false;
    }
    

    boolean flag = false;
    atc vec3 = V().a(0.0D, 0.0D, 0.0D);
    
    for (int k1 = i; k1 < j; k1++)
    {
      for (int l1 = k; l1 < l; l1++)
      {
        for (int i2 = i1; i2 < j1; i2++)
        {
          aqz block = aqz.s[a(k1, l1, i2)];
          
          if ((block != null) && (cU == par2Material))
          {
            double d0 = l1 + 1 - apc.d(h(k1, l1, i2));
            
            if (l >= d0)
            {
              flag = true;
              block.a(this, k1, l1, i2, par3Entity, vec3);
            }
          }
          else if ((block != null) && (par2Material == akc.h) && (cF == bLcF) && (h(k1, l1, i2) > 0))
          {

            double var16 = l1 + (h(k1, l1, i2) * 0.1875F + 0.3125F + 0.15625F);
            
            if (E.b < var16)
            {
              flag = true;
            }
          }
        }
      }
    }
    
    if ((vec3.b() > 0.0D) && (par3Entity.ax()))
    {
      vec3 = vec3.a();
      double d1 = 0.014D;
      x += c * d1;
      y += d * d1 * par3Entity.getSizeMultiplierRoot();
      z += e * d1;
      
      if ((par3Entity.isTiny()) && ((par3Entity instanceof of)))
      {
        of ent = (of)par3Entity;
        if (ent.getTinyLadderRate() > 0.0F)
        {
          x += c * d1 * ((ent.isSticky() ? 0.0D : ent.getSizeMultiplier()) - 1.0D);
          z += e * d1 * ((ent.isSticky() ? 0.0D : ent.getSizeMultiplier()) - 1.0D);
        }
      }
    }
    
    return flag;
  }
  




  public boolean a(asx par1AxisAlignedBB, akc par2Material)
  {
    int i = ls.c(a);
    int j = ls.c(d + 1.0D);
    int k = ls.c(b);
    int l = ls.c(e + 1.0D);
    int i1 = ls.c(c);
    int j1 = ls.c(f + 1.0D);
    
    for (int k1 = i; k1 < j; k1++)
    {
      for (int l1 = k; l1 < l; l1++)
      {
        for (int i2 = i1; i2 < j1; i2++)
        {
          aqz block = aqz.s[a(k1, l1, i2)];
          
          if ((block != null) && (cU == par2Material))
          {
            return true;
          }
        }
      }
    }
    
    return false;
  }
  



  public boolean b(asx par1AxisAlignedBB, akc par2Material)
  {
    int i = ls.c(a);
    int j = ls.c(d + 1.0D);
    int k = ls.c(b);
    int l = ls.c(e + 1.0D);
    int i1 = ls.c(c);
    int j1 = ls.c(f + 1.0D);
    
    for (int k1 = i; k1 < j; k1++)
    {
      for (int l1 = k; l1 < l; l1++)
      {
        for (int i2 = i1; i2 < j1; i2++)
        {
          aqz block = aqz.s[a(k1, l1, i2)];
          
          if ((block != null) && (cU == par2Material))
          {
            int j2 = h(k1, l1, i2);
            double d0 = l1 + 1;
            
            if (j2 < 8)
            {
              d0 = l1 + 1 - j2 / 8.0D;
            }
            
            if (d0 >= b)
            {
              return true;
            }
          }
          else if ((block != null) && (par2Material == akc.h) && (cF == bLcF) && (h(k1, l1, i2) > 0))
          {

            float wl = h(k1, l1, i2) * 0.1875F + 0.3125F + 0.15625F;
            if (wl + l1 >= b)
            {
              return true;
            }
          }
        }
      }
    }
    
    return false;
  }
  



  public abr a(nn par1Entity, double par2, double par4, double par6, float par8, boolean par9)
  {
    return a(par1Entity, par2, par4, par6, par8, false, par9);
  }
  



  public abr a(nn par1Entity, double par2, double par4, double par6, float par8, boolean par9, boolean par10)
  {
    abr explosion = new abr(this, par1Entity, par2, par4, par6, par8);
    a = par9;
    b = par10;
    explosion.a();
    explosion.a(true);
    return explosion;
  }
  



  public float a(atc par1Vec3, asx par2AxisAlignedBB)
  {
    double d0 = 1.0D / ((d - a) * 2.0D + 1.0D);
    double d1 = 1.0D / ((e - b) * 2.0D + 1.0D);
    double d2 = 1.0D / ((f - c) * 2.0D + 1.0D);
    int i = 0;
    int j = 0;
    
    for (float f = 0.0F; f <= 1.0F; f = (float)(f + d0))
    {
      for (float f1 = 0.0F; f1 <= 1.0F; f1 = (float)(f1 + d1))
      {
        for (float f2 = 0.0F; f2 <= 1.0F; f2 = (float)(f2 + d2))
        {
          double d3 = a + (d - a) * f;
          double d4 = b + (e - b) * f1;
          double d5 = c + (f - c) * f2;
          
          if (a(V().a(d3, d4, d5), par1Vec3) == null)
          {
            i++;
          }
          
          j++;
        }
      }
    }
    
    return i / j;
  }
  




  public boolean a(uf par1EntityPlayer, int par2, int par3, int par4, int par5)
  {
    if (par5 == 0)
    {
      par3--;
    }
    
    if (par5 == 1)
    {
      par3++;
    }
    
    if (par5 == 2)
    {
      par4--;
    }
    
    if (par5 == 3)
    {
      par4++;
    }
    
    if (par5 == 4)
    {
      par2--;
    }
    
    if (par5 == 5)
    {
      par2++;
    }
    
    if (a(par2, par3, par4) == awcF)
    {
      a(par1EntityPlayer, 1004, par2, par3, par4, 0);
      i(par2, par3, par4);
      return true;
    }
    

    return false;
  }
  





  @SideOnly(Side.CLIENT)
  public String y()
  {
    return "All: " + e.size();
  }
  




  @SideOnly(Side.CLIENT)
  public String z()
  {
    return v.e();
  }
  



  public asp r(int par1, int par2, int par3)
  {
    if ((par2 >= 0) && (par2 < 256))
    {
      asp tileentity = null;
      


      if (N)
      {
        for (int l = 0; l < a.size(); l++)
        {
          asp tileentity1 = (asp)a.get(l);
          
          if ((!tileentity1.r()) && (l == par1) && (m == par2) && (n == par3))
          {
            tileentity = tileentity1;
            break;
          }
        }
      }
      
      if (tileentity == null)
      {
        adr chunk = e(par1 >> 4, par3 >> 4);
        
        if (chunk != null)
        {
          tileentity = chunk.e(par1 & 0xF, par2, par3 & 0xF);
        }
      }
      
      if (tileentity == null)
      {
        for (int l = 0; l < a.size(); l++)
        {
          asp tileentity1 = (asp)a.get(l);
          
          if ((!tileentity1.r()) && (l == par1) && (m == par2) && (n == par3))
          {
            tileentity = tileentity1;
            break;
          }
        }
      }
      
      return tileentity;
    }
    

    return null;
  }
  




  public void a(int par1, int par2, int par3, asp par4TileEntity)
  {
    if ((par4TileEntity == null) || (par4TileEntity.r()))
    {
      return;
    }
    
    if (par4TileEntity.canUpdate())
    {
      if (N)
      {
        Iterator iterator = a.iterator();
        while (iterator.hasNext())
        {
          asp tileentity1 = (asp)iterator.next();
          
          if ((l == par1) && (m == par2) && (n == par3))
          {
            tileentity1.w_();
            iterator.remove();
          }
        }
        a.add(par4TileEntity);
      }
      else
      {
        g.add(par4TileEntity);
      }
    }
    
    adr chunk = e(par1 >> 4, par3 >> 4);
    if (chunk != null)
    {
      chunk.a(par1 & 0xF, par2, par3 & 0xF, par4TileEntity);
    }
    
    m(par1, par2, par3, 0);
  }
  



  public void s(int par1, int par2, int par3)
  {
    adr chunk = e(par1 >> 4, par3 >> 4);
    if (chunk != null)
    {
      chunk.f(par1 & 0xF, par2, par3 & 0xF);
    }
    
    m(par1, par2, par3, 0);
  }
  



  public void a(asp par1TileEntity)
  {
    b.add(par1TileEntity);
  }
  



  public boolean t(int par1, int par2, int par3)
  {
    aqz block = aqz.s[a(par1, par2, par3)];
    return block == null ? false : block.c();
  }
  



  public boolean u(int par1, int par2, int par3)
  {
    aqz block = aqz.s[a(par1, par2, par3)];
    return (block != null) && (block.isBlockNormalCube(this, par1, par2, par3));
  }
  
  public boolean v(int par1, int par2, int par3)
  {
    int l = a(par1, par2, par3);
    
    if ((l != 0) && (aqz.s[l] != null))
    {
      asx axisalignedbb = aqz.s[l].b(this, par1, par2, par3);
      return (axisalignedbb != null) && (axisalignedbb.b() >= 1.0D);
    }
    

    return false;
  }
  




  public boolean w(int par1, int par2, int par3)
  {
    return isBlockSolidOnSide(par1, par2, par3, ForgeDirection.UP);
  }
  





  @Deprecated
  public boolean a(aqz par1Block, int par2)
  {
    return par1Block != null;
  }
  




  public boolean c(int par1, int par2, int par3, boolean par4)
  {
    if ((par1 >= -30000000) && (par3 >= -30000000) && (par1 < 30000000) && (par3 < 30000000))
    {
      adr chunk = v.d(par1 >> 4, par3 >> 4);
      
      if ((chunk != null) && (!chunk.g()))
      {
        aqz block = aqz.s[a(par1, par2, par3)];
        return block == null ? false : u(par1, par2, par3);
      }
      

      return par4;
    }
    


    return par4;
  }
  




  public void A()
  {
    int i = a(1.0F);
    
    if (i != j)
    {
      j = i;
    }
  }
  



  public void a(boolean par1, boolean par2)
  {
    t.setAllowedSpawnTypes(par1, par2);
  }
  



  public void b()
  {
    o();
  }
  



  private void a()
  {
    t.calculateInitialWeather();
  }
  
  public void calculateInitialWeatherBody()
  {
    if (x.p())
    {
      n = 1.0F;
      
      if (x.n())
      {
        p = 1.0F;
      }
    }
  }
  



  protected void o()
  {
    t.updateWeather();
  }
  
  public void updateWeatherBody()
  {
    if (!t.g)
    {
      int i = x.o();
      
      if (i <= 0)
      {
        if (x.n())
        {
          x.f(s.nextInt(12000) + 3600);
        }
        else
        {
          x.f(s.nextInt(168000) + 12000);
        }
      }
      else
      {
        i--;
        x.f(i);
        
        if (i <= 0)
        {
          x.a(!x.n());
        }
      }
      
      int j = x.q();
      
      if (j <= 0)
      {
        if (x.p())
        {
          x.g(s.nextInt(12000) + 12000);
        }
        else
        {
          x.g(s.nextInt(168000) + 12000);
        }
      }
      else
      {
        j--;
        x.g(j);
        
        if (j <= 0)
        {
          x.b(!x.p());
        }
      }
      
      m = n;
      
      if (x.p())
      {
        n = ((float)(n + 0.01D));
      }
      else
      {
        n = ((float)(n - 0.01D));
      }
      
      if (n < 0.0F)
      {
        n = 0.0F;
      }
      
      if (n > 1.0F)
      {
        n = 1.0F;
      }
      
      o = p;
      
      if (x.n())
      {
        p = ((float)(p + 0.01D));
      }
      else
      {
        p = ((float)(p - 0.01D));
      }
      
      if (p < 0.0F)
      {
        p = 0.0F;
      }
      
      if (p > 1.0F)
      {
        p = 1.0F;
      }
    }
  }
  
  public void B()
  {
    t.toggleRain();
  }
  
  protected void C()
  {
    G.clear();
    G.addAll(getPersistentChunks().keySet());
    
    C.a("buildList");
    




    for (int i = 0; i < h.size(); i++)
    {
      uf entityplayer = (uf)h.get(i);
      int j = ls.c(u / 16.0D);
      int k = ls.c(w / 16.0D);
      byte b0 = 7;
      
      for (int l = -b0; l <= b0; l++)
      {
        for (int i1 = -b0; i1 <= b0; i1++)
        {
          G.add(new abp(l + j, i1 + k));
        }
      }
    }
    
    C.b();
    
    if (O > 0)
    {
      O -= 1;
    }
    
    C.a("playerCheckLight");
    
    if (!h.isEmpty())
    {
      i = s.nextInt(h.size());
      uf entityplayer = (uf)h.get(i);
      int j = ls.c(u) + s.nextInt(11) - 5;
      int k = ls.c(v) + s.nextInt(11) - 5;
      int j1 = ls.c(w) + s.nextInt(11) - 5;
      A(j, k, j1);
    }
    
    C.b();
  }
  
  protected void a(int par1, int par2, adr par3Chunk)
  {
    C.c("moodSound");
    
    if ((O == 0) && (!I))
    {
      this.k = (this.k * 3 + 1013904223);
      int k = this.k >> 2;
      int l = k & 0xF;
      int i1 = k >> 8 & 0xF;
      int j1 = k >> 16 & 0x7F;
      int k1 = par3Chunk.a(l, j1, i1);
      l += par1;
      i1 += par2;
      
      if ((k1 == 0) && (m(l, j1, i1) <= s.nextInt(8)) && (b(ach.a, l, j1, i1) <= 0))
      {
        uf entityplayer = a(l + 0.5D, j1 + 0.5D, i1 + 0.5D, 8.0D);
        
        if ((entityplayer != null) && (entityplayer.e(l + 0.5D, j1 + 0.5D, i1 + 0.5D) > 4.0D))
        {
          a(l + 0.5D, j1 + 0.5D, i1 + 0.5D, "ambient.cave.cave", 0.7F, 0.8F + s.nextFloat() * 0.2F);
          O = (s.nextInt(12000) + 6000);
        }
      }
    }
    
    C.c("checkLight");
    par3Chunk.o();
  }
  




  protected void g()
  {
    C();
  }
  



  public boolean x(int par1, int par2, int par3)
  {
    return d(par1, par2, par3, false);
  }
  



  public boolean y(int par1, int par2, int par3)
  {
    return d(par1, par2, par3, true);
  }
  




  public boolean d(int par1, int par2, int par3, boolean par4)
  {
    return t.canBlockFreeze(par1, par2, par3, par4);
  }
  
  public boolean canBlockFreezeBody(int par1, int par2, int par3, boolean par4)
  {
    acq biomegenbase = a(par1, par3);
    float f = biomegenbase.j();
    
    if (f > 0.15F)
    {
      return false;
    }
    

    if ((par2 >= 0) && (par2 < 256) && (b(ach.b, par1, par2, par3) < 10))
    {
      int l = a(par1, par2, par3);
      
      if (((l == GcF) || (l == FcF)) && (h(par1, par2, par3) == 0))
      {
        if (!par4)
        {
          return true;
        }
        
        boolean flag1 = true;
        
        if ((flag1) && (g(par1 - 1, par2, par3) != akc.h))
        {
          flag1 = false;
        }
        
        if ((flag1) && (g(par1 + 1, par2, par3) != akc.h))
        {
          flag1 = false;
        }
        
        if ((flag1) && (g(par1, par2, par3 - 1) != akc.h))
        {
          flag1 = false;
        }
        
        if ((flag1) && (g(par1, par2, par3 + 1) != akc.h))
        {
          flag1 = false;
        }
        
        if (!flag1)
        {
          return true;
        }
      }
    }
    
    return false;
  }
  




  public boolean z(int par1, int par2, int par3)
  {
    return t.canSnowAt(par1, par2, par3);
  }
  
  public boolean canSnowAtBody(int par1, int par2, int par3)
  {
    acq biomegenbase = a(par1, par3);
    float f = biomegenbase.j();
    
    if (f > 0.15F)
    {
      return false;
    }
    

    if ((par2 >= 0) && (par2 < 256) && (b(ach.b, par1, par2, par3) < 10))
    {
      int l = a(par1, par2 - 1, par3);
      int i1 = a(par1, par2, par3);
      
      if ((i1 == 0) && (aqz.aX.c(this, par1, par2, par3)) && (l != 0) && (l != aYcF) && (scU.c()))
      {
        return true;
      }
    }
    
    return false;
  }
  

  public void A(int par1, int par2, int par3)
  {
    if (!t.g)
    {
      c(ach.a, par1, par2, par3);
    }
    
    c(ach.b, par1, par2, par3);
  }
  
  private int a(int par1, int par2, int par3, ach par4EnumSkyBlock)
  {
    if ((par4EnumSkyBlock == ach.a) && (l(par1, par2, par3)))
    {
      return 15;
    }
    

    int l = a(par1, par2, par3);
    aqz block = aqz.s[l];
    int blockLight = block == null ? 0 : block.getLightValue(this, par1, par2, par3);
    int i1 = par4EnumSkyBlock == ach.a ? 0 : blockLight;
    int j1 = block == null ? 0 : block.getLightOpacity(this, par1, par2, par3);
    
    if ((j1 >= 15) && (blockLight > 0))
    {
      j1 = 1;
    }
    
    if (j1 < 1)
    {
      j1 = 1;
    }
    
    if (j1 >= 15)
    {
      return 0;
    }
    if (i1 >= 14)
    {
      return i1;
    }
    

    for (int k1 = 0; k1 < 6; k1++)
    {
      int l1 = par1 + s.b[k1];
      int i2 = par2 + s.c[k1];
      int j2 = par3 + s.d[k1];
      int k2 = b(par4EnumSkyBlock, l1, i2, j2) - j1;
      
      if (k2 > i1)
      {
        i1 = k2;
      }
      
      if (i1 >= 14)
      {
        return i1;
      }
    }
    
    return i1;
  }
  


  public void c(ach par1EnumSkyBlock, int par2, int par3, int par4)
  {
    if (b(par2, par3, par4, 17))
    {
      int l = 0;
      int i1 = 0;
      C.a("getBrightness");
      int j1 = b(par1EnumSkyBlock, par2, par3, par4);
      int k1 = a(par2, par3, par4, par1EnumSkyBlock);
      









      if (k1 > j1)
      {
        H[(i1++)] = 133152;
      }
      else if (k1 < j1)
      {
        H[(i1++)] = (0x20820 | j1 << 18);
        
        while (l < i1)
        {
          int l1 = H[(l++)];
          int i2 = (l1 & 0x3F) - 32 + par2;
          int j2 = (l1 >> 6 & 0x3F) - 32 + par3;
          int k2 = (l1 >> 12 & 0x3F) - 32 + par4;
          int l2 = l1 >> 18 & 0xF;
          int i3 = b(par1EnumSkyBlock, i2, j2, k2);
          
          if (i3 == l2)
          {
            b(par1EnumSkyBlock, i2, j2, k2, 0);
            
            if (l2 > 0)
            {
              int j3 = ls.a(i2 - par2);
              int l3 = ls.a(j2 - par3);
              int k3 = ls.a(k2 - par4);
              
              if (j3 + l3 + k3 < 17)
              {
                for (int i4 = 0; i4 < 6; i4++)
                {
                  int j4 = i2 + s.b[i4];
                  int k4 = j2 + s.c[i4];
                  int l4 = k2 + s.d[i4];
                  aqz block = aqz.s[a(j4, k4, l4)];
                  int blockOpacity = block == null ? 0 : block.getLightOpacity(this, j4, k4, l4);
                  int i5 = Math.max(1, blockOpacity);
                  i3 = b(par1EnumSkyBlock, j4, k4, l4);
                  
                  if ((i3 == l2 - i5) && (i1 < H.length))
                  {
                    H[(i1++)] = (j4 - par2 + 32 | k4 - par3 + 32 << 6 | l4 - par4 + 32 << 12 | l2 - i5 << 18);
                  }
                }
              }
            }
          }
        }
        
        l = 0;
      }
      
      C.b();
      C.a("checkedPosition < toCheckCount");
      
      while (l < i1)
      {
        int l1 = H[(l++)];
        int i2 = (l1 & 0x3F) - 32 + par2;
        int j2 = (l1 >> 6 & 0x3F) - 32 + par3;
        int k2 = (l1 >> 12 & 0x3F) - 32 + par4;
        int l2 = b(par1EnumSkyBlock, i2, j2, k2);
        int i3 = a(i2, j2, k2, par1EnumSkyBlock);
        
        if (i3 != l2)
        {
          b(par1EnumSkyBlock, i2, j2, k2, i3);
          
          if (i3 > l2)
          {
            int j3 = Math.abs(i2 - par2);
            int l3 = Math.abs(j2 - par3);
            int k3 = Math.abs(k2 - par4);
            boolean flag = i1 < H.length - 6;
            
            if ((j3 + l3 + k3 < 17) && (flag))
            {
              if (b(par1EnumSkyBlock, i2 - 1, j2, k2) < i3)
              {
                H[(i1++)] = (i2 - 1 - par2 + 32 + (j2 - par3 + 32 << 6) + (k2 - par4 + 32 << 12));
              }
              
              if (b(par1EnumSkyBlock, i2 + 1, j2, k2) < i3)
              {
                H[(i1++)] = (i2 + 1 - par2 + 32 + (j2 - par3 + 32 << 6) + (k2 - par4 + 32 << 12));
              }
              
              if (b(par1EnumSkyBlock, i2, j2 - 1, k2) < i3)
              {
                H[(i1++)] = (i2 - par2 + 32 + (j2 - 1 - par3 + 32 << 6) + (k2 - par4 + 32 << 12));
              }
              
              if (b(par1EnumSkyBlock, i2, j2 + 1, k2) < i3)
              {
                H[(i1++)] = (i2 - par2 + 32 + (j2 + 1 - par3 + 32 << 6) + (k2 - par4 + 32 << 12));
              }
              
              if (b(par1EnumSkyBlock, i2, j2, k2 - 1) < i3)
              {
                H[(i1++)] = (i2 - par2 + 32 + (j2 - par3 + 32 << 6) + (k2 - 1 - par4 + 32 << 12));
              }
              
              if (b(par1EnumSkyBlock, i2, j2, k2 + 1) < i3)
              {
                H[(i1++)] = (i2 - par2 + 32 + (j2 - par3 + 32 << 6) + (k2 + 1 - par4 + 32 << 12));
              }
            }
          }
        }
      }
      
      C.b();
    }
  }
  



  public boolean a(boolean par1)
  {
    return false;
  }
  
  public List a(adr par1Chunk, boolean par2)
  {
    return null;
  }
  



  public List b(nn par1Entity, asx par2AxisAlignedBB)
  {
    return a(par1Entity, par2AxisAlignedBB, (nw)null);
  }
  
  public List a(nn par1Entity, asx par2AxisAlignedBB, nw par3IEntitySelector)
  {
    ArrayList arraylist = new ArrayList();
    
    if (par2AxisAlignedBB != null)
    {
      int i = ls.c((a - MAX_ENTITY_RADIUS) / 16.0D);
      int j = ls.c((d + MAX_ENTITY_RADIUS) / 16.0D);
      int k = ls.c((c - MAX_ENTITY_RADIUS) / 16.0D);
      int l = ls.c((f + MAX_ENTITY_RADIUS) / 16.0D);
      
      for (int i1 = i; i1 <= j; i1++)
      {
        for (int j1 = k; j1 <= l; j1++)
        {
          if (c(i1, j1))
          {
            e(i1, j1).a(par1Entity, par2AxisAlignedBB, arraylist, par3IEntitySelector);
          }
        }
      }
    }
    
    return arraylist;
  }
  



  public List a(Class par1Class, asx par2AxisAlignedBB)
  {
    return a(par1Class, par2AxisAlignedBB, (nw)null);
  }
  
  public List a(Class par1Class, asx par2AxisAlignedBB, nw par3IEntitySelector)
  {
    int i = ls.c((a - MAX_ENTITY_RADIUS) / 16.0D);
    int j = ls.c((d + MAX_ENTITY_RADIUS) / 16.0D);
    int k = ls.c((c - MAX_ENTITY_RADIUS) / 16.0D);
    int l = ls.c((f + MAX_ENTITY_RADIUS) / 16.0D);
    ArrayList arraylist = new ArrayList();
    
    for (int i1 = i; i1 <= j; i1++)
    {
      for (int j1 = k; j1 <= l; j1++)
      {
        if (c(i1, j1))
        {
          e(i1, j1).a(par1Class, par2AxisAlignedBB, arraylist, par3IEntitySelector);
        }
      }
    }
    
    return arraylist;
  }
  
  public nn a(Class par1Class, asx par2AxisAlignedBB, nn par3Entity)
  {
    List list = a(par1Class, par2AxisAlignedBB);
    nn entity1 = null;
    double d0 = Double.MAX_VALUE;
    
    for (int i = 0; i < list.size(); i++)
    {
      nn entity2 = (nn)list.get(i);
      
      if (entity2 != par3Entity)
      {
        double d1 = par3Entity.e(entity2);
        
        if (d1 <= d0)
        {
          entity1 = entity2;
          d0 = d1;
        }
      }
    }
    
    return entity1;
  }
  
  public nn findNearestSizedEntityWithinAABB(Class par1Class, asx par2AxisAlignedBB, nn par3Entity, float min, float max)
  {
    List list = a(par1Class, par2AxisAlignedBB);
    GulliverEnvoy.pruneSmallerEntities(min * par3Entity.getSizeMultiplier(), list);
    GulliverEnvoy.pruneLargerEntities(max * par3Entity.getSizeMultiplier(), list);
    
    nn entity = null;
    double d = Double.MAX_VALUE;
    Iterator iterator = list.iterator();
    


    while (iterator.hasNext())
    {



      nn entity1 = (nn)iterator.next();
      
      if (entity1 != par3Entity)
      {
        double d1 = par3Entity.e(entity1);
        
        if (d1 <= d)
        {
          entity = entity1;
          d = d1;
        }
      }
    }
    

    return entity;
  }
  
  public nn findNearestVisibleSizedEntityWithinAABB(Class par1Class, asx par2AxisAlignedBB, nn par3Entity, float min, float max)
  {
    List list = a(par1Class, par2AxisAlignedBB);
    GulliverEnvoy.pruneSmallerEntities(min * par3Entity.getSizeMultiplier(), list);
    GulliverEnvoy.pruneLargerEntities(max * par3Entity.getSizeMultiplier(), list);
    
    nn entity = null;
    double d = Double.MAX_VALUE;
    Iterator iterator = list.iterator();
    


    while (iterator.hasNext())
    {



      nn entity1 = (nn)iterator.next();
      
      if (entity1 != par3Entity)
      {
        if ((!(par3Entity instanceof of)) || (!entity1.isTiny()) || (entity1.getSizeMultiplier() / par3Entity.getSizeMultiplier() >= 0.3F) || (!((of)par3Entity).o(entity1)))
        {


          double d1 = par3Entity.e(entity1);
          
          if (d1 <= d)
          {
            entity = entity1;
            d = d1;
          }
        }
      }
    }
    
    return entity;
  }
  




  public abstract nn a(int paramInt);
  



  @SideOnly(Side.CLIENT)
  public List D()
  {
    return e;
  }
  




  public void b(int par1, int par2, int par3, asp par4TileEntity)
  {
    if (f(par1, par2, par3))
    {
      d(par1, par3).e();
    }
  }
  



  public int a(Class par1Class)
  {
    int i = 0;
    
    for (int j = 0; j < e.size(); j++)
    {
      nn entity = (nn)e.get(j);
      
      if (((!(entity instanceof og)) || (!((og)entity).bE())) && (par1Class.isAssignableFrom(entity.getClass())))
      {
        i++;
      }
    }
    
    return i;
  }
  



  public void a(List par1List)
  {
    for (int i = 0; i < par1List.size(); i++)
    {
      nn entity = (nn)par1List.get(i);
      if (!MinecraftForge.EVENT_BUS.post(new EntityJoinWorldEvent(entity, this)))
      {
        e.add(entity);
        a(entity);
      }
    }
  }
  



  public void b(List par1List)
  {
    f.addAll(par1List);
  }
  



  public boolean a(int par1, int par2, int par3, int par4, boolean par5, int par6, nn par7Entity, ye par8ItemStack)
  {
    int j1 = a(par2, par3, par4);
    aqz block = aqz.s[j1];
    aqz block1 = aqz.s[par1];
    asx axisalignedbb = block1.b(this, par2, par3, par4);
    
    if (par5)
    {
      axisalignedbb = null;
    }
    
    if ((axisalignedbb != null) && (!a(axisalignedbb, par7Entity)))
    {
      return false;
    }
    

    if ((block != null) && ((block == aqz.F) || (block == aqz.G) || (block == aqz.H) || (block == aqz.I) || (block == aqz.aw) || (cU.j())))
    {
      block = null;
    }
    
    if ((block != null) && (block.isBlockReplaceable(this, par2, par3, par4)))
    {
      block = null;
    }
    
    return (block != null) && (cU == akc.q) && (block1 == aqz.cm);
  }
  

  public alf a(nn par1Entity, nn par2Entity, float par3, boolean par4, boolean par5, boolean par6, boolean par7)
  {
    C.a("pathfind");
    int i = ls.c(u);
    int j = ls.c(v + 1.0D);
    int k = ls.c(w);
    int l = (int)(par3 + 16.0F);
    int i1 = i - l;
    int j1 = j - l;
    int k1 = k - l;
    int l1 = i + l;
    int i2 = j + l;
    int j2 = k + l;
    acl chunkcache = new acl(this, i1, j1, k1, l1, i2, j2, 0);
    alf pathentity = new alg(chunkcache, par4, par5, par6, par7).a(par1Entity, par2Entity, par3);
    C.b();
    return pathentity;
  }
  
  public alf a(nn par1Entity, int par2, int par3, int par4, float par5, boolean par6, boolean par7, boolean par8, boolean par9)
  {
    C.a("pathfind");
    int l = ls.c(u);
    int i1 = ls.c(v);
    int j1 = ls.c(w);
    int k1 = (int)(par5 + 8.0F);
    int l1 = l - k1;
    int i2 = i1 - k1;
    int j2 = j1 - k1;
    int k2 = l + k1;
    int l2 = i1 + k1;
    int i3 = j1 + k1;
    acl chunkcache = new acl(this, l1, i2, j2, k2, l2, i3, 0);
    alf pathentity = new alg(chunkcache, par6, par7, par8, par9).a(par1Entity, par2, par3, par4, par5);
    C.b();
    return pathentity;
  }
  



  public int j(int par1, int par2, int par3, int par4)
  {
    int i1 = a(par1, par2, par3);
    return i1 == 0 ? 0 : aqz.s[i1].c(this, par1, par2, par3, par4);
  }
  



  public int B(int par1, int par2, int par3)
  {
    byte b0 = 0;
    int l = Math.max(b0, j(par1, par2 - 1, par3, 0));
    
    if (l >= 15)
    {
      return l;
    }
    

    l = Math.max(l, j(par1, par2 + 1, par3, 1));
    
    if (l >= 15)
    {
      return l;
    }
    

    l = Math.max(l, j(par1, par2, par3 - 1, 2));
    
    if (l >= 15)
    {
      return l;
    }
    

    l = Math.max(l, j(par1, par2, par3 + 1, 3));
    
    if (l >= 15)
    {
      return l;
    }
    

    l = Math.max(l, j(par1 - 1, par2, par3, 4));
    
    if (l >= 15)
    {
      return l;
    }
    

    l = Math.max(l, j(par1 + 1, par2, par3, 5));
    return l >= 15 ? l : l;
  }
  









  public boolean k(int par1, int par2, int par3, int par4)
  {
    return l(par1, par2, par3, par4) > 0;
  }
  



  public int l(int par1, int par2, int par3, int par4)
  {
    aqz block = aqz.s[a(par1, par2, par3)];
    
    if (block == null)
    {
      return 0;
    }
    
    if (!block.shouldCheckWeakPower(this, par1, par2, par3, par4))
    {
      return B(par1, par2, par3);
    }
    

    return block.b(this, par1, par2, par3, par4);
  }
  





  public boolean C(int par1, int par2, int par3)
  {
    return l(par1, par2 - 1, par3, 0) > 0;
  }
  
  public int D(int par1, int par2, int par3)
  {
    int l = 0;
    
    for (int i1 = 0; i1 < 6; i1++)
    {
      int j1 = l(par1 + s.b[i1], par2 + s.c[i1], par3 + s.d[i1], i1);
      
      if (j1 >= 15)
      {
        return 15;
      }
      
      if (j1 > l)
      {
        l = j1;
      }
    }
    
    return l;
  }
  




  public uf a(nn par1Entity, double par2)
  {
    return a(u, v, w, par2);
  }
  




  public uf a(double par1, double par3, double par5, double par7)
  {
    double d4 = -1.0D;
    uf entityplayer = null;
    
    for (int i = 0; i < h.size(); i++)
    {
      uf entityplayer1 = (uf)h.get(i);
      double d5 = entityplayer1.e(par1, par3, par5);
      
      if (((par7 < 0.0D) || (d5 < par7 * par7)) && ((d4 == -1.0D) || (d5 < d4)))
      {
        d4 = d5;
        entityplayer = entityplayer1;
      }
    }
    
    return entityplayer;
  }
  
  public uf getClosestSizedPlayerToEntity(of entity, double d, float min, float max)
  {
    double px = u;
    double py = v;
    double pz = w;
    double dtmp = -1.0D;
    uf entityplayer = null;
    for (int i = 0; i < h.size(); i++)
    {
      uf entityplayer1 = (uf)h.get(i);
      if (entity.isEntityInRelativeSizeRange(entityplayer1, min, max))
      {


        double d1 = entityplayer1.e(px, py, pz);
        if (((d < 0.0D) || (d1 < d * d)) && ((dtmp == -1.0D) || (d1 < dtmp)))
        {
          dtmp = d1;
          entityplayer = entityplayer1;
        }
      }
    }
    return entityplayer;
  }
  
  public uf getClosestVisibleSizedPlayerToEntity(of entity, double d, float min, float max)
  {
    double px = u;
    double py = v;
    double pz = w;
    double dtmp = -1.0D;
    uf entityplayer = null;
    for (int i = 0; i < h.size(); i++)
    {
      uf entityplayer1 = (uf)h.get(i);
      if (n != entityplayer1)
      {



        if (entity.isEntityInRelativeSizeRange(entityplayer1, min, max))
        {



          if ((!entityplayer1.isTiny()) || (!entityplayer1.isTinierThan(entity)) || (entity.o(entityplayer1)))
          {



            double d1 = entityplayer1.e(px, py, pz);
            double d2 = d;
            
            if (entityplayer1.ah())
            {
              d2 = d * 0.800000011920929D;
            }
            
            if (entityplayer1.aj())
            {
              float var18 = entityplayer1.bx();
              
              if (var18 < 0.1F)
              {
                var18 = 0.1F;
              }
              
              d2 *= 0.7F * var18;
            }
            
            if (((d < 0.0D) || (d1 < d2 * d2)) && ((dtmp == -1.0D) || (d1 < dtmp)))
            {
              dtmp = d1;
              entityplayer = entityplayer1;
            }
          } } }
    }
    return entityplayer;
  }
  




  public uf b(nn par1Entity, double par2)
  {
    return getClosestSizedVulnerablePlayerToEntity(par1Entity, par2 * par1Entity.getRangeMultiplier(), par1Entity.getMinTargetSize(), par1Entity.getMaxTargetSize());
  }
  




  public uf b(double par1, double par3, double par5, double par7)
  {
    double d4 = -1.0D;
    uf entityplayer = null;
    
    for (int i = 0; i < h.size(); i++)
    {
      uf entityplayer1 = (uf)h.get(i);
      
      if ((!bG.a) && (entityplayer1.T()))
      {
        double d5 = entityplayer1.e(par1, par3, par5);
        double d6 = par7;
        
        if (entityplayer1.ah())
        {
          d6 = par7 * 0.800000011920929D;
        }
        
        if (entityplayer1.aj())
        {
          float f = entityplayer1.bx();
          
          if (f < 0.1F)
          {
            f = 0.1F;
          }
          
          d6 *= 0.7F * f;
        }
        
        if (((par7 < 0.0D) || (d5 < d6 * d6)) && ((d4 == -1.0D) || (d5 < d4)))
        {
          d4 = d5;
          entityplayer = entityplayer1;
        }
      }
    }
    
    return entityplayer;
  }
  
  public uf getClosestSizedVulnerablePlayerToEntity(nn entity, double d, float min, float max)
  {
    double px = u;
    double py = v;
    double pz = w;
    double dtmp = -1.0D;
    uf entityplayer = null;
    for (int i = 0; i < h.size(); i++)
    {
      uf entityplayer1 = (uf)h.get(i);
      if ((!bG.a) && (entityplayer1.T()))
      {


        if (entity.isEntityInRelativeSizeRange(entityplayer1, min, max))
        {



          if ((!entityplayer1.isTiny()) || (!entityplayer1.isTinierThan(entity)) || (!(entity instanceof og)) || (((og)entity).o(entityplayer1)))
          {



            double d1 = entityplayer1.e(px, py, pz);
            double d2 = d;
            
            if (entityplayer1.ah())
            {
              d2 = d * 0.800000011920929D;
            }
            
            if (entityplayer1.aj())
            {
              float var18 = entityplayer1.bx();
              
              if (var18 < 0.1F)
              {
                var18 = 0.1F;
              }
              
              d2 *= 0.7F * var18;
            }
            
            if (((d < 0.0D) || (d1 < d2 * d2)) && ((dtmp == -1.0D) || (d1 < dtmp)))
            {
              dtmp = d1;
              entityplayer = entityplayer1;
            }
          } } }
    }
    return entityplayer;
  }
  



  public uf a(String par1Str)
  {
    for (int i = 0; i < h.size(); i++)
    {
      if (par1Str.equals(((uf)h.get(i)).c_()))
      {
        return (uf)h.get(i);
      }
    }
    
    return null;
  }
  



  @SideOnly(Side.CLIENT)
  public void F() {}
  



  public void G()
    throws aca
  {
    w.c();
  }
  
  @SideOnly(Side.CLIENT)
  public void a(long par1)
  {
    x.b(par1);
  }
  



  public long H()
  {
    return t.getSeed();
  }
  
  public long I()
  {
    return x.f();
  }
  
  public long J()
  {
    return t.getWorldTime();
  }
  



  public void b(long par1)
  {
    t.setWorldTime(par1);
  }
  



  public t K()
  {
    return t.getSpawnPoint();
  }
  
  @SideOnly(Side.CLIENT)
  public void E(int par1, int par2, int par3)
  {
    t.setSpawnPoint(par1, par2, par3);
  }
  




  @SideOnly(Side.CLIENT)
  public void h(nn par1Entity)
  {
    int i = ls.c(u / 16.0D);
    int j = ls.c(w / 16.0D);
    byte b0 = 2;
    
    for (int k = i - b0; k <= i + b0; k++)
    {
      for (int l = j - b0; l <= j + b0; l++)
      {
        e(k, l);
      }
    }
    
    if (!e.contains(par1Entity))
    {
      if (!MinecraftForge.EVENT_BUS.post(new EntityJoinWorldEvent(par1Entity, this)))
      {
        e.add(par1Entity);
      }
    }
  }
  



  public boolean a(uf par1EntityPlayer, int par2, int par3, int par4)
  {
    return t.canMineBlock(par1EntityPlayer, par2, par3, par4);
  }
  
  public boolean canMineBlockBody(uf par1EntityPlayer, int par2, int par3, int par4)
  {
    return true;
  }
  



  public void a(nn par1Entity, byte par2) {}
  



  public void setEntitySize(nn entity, float par2) {}
  



  public ado L()
  {
    return v;
  }
  




  public void d(int par1, int par2, int par3, int par4, int par5, int par6)
  {
    if (par4 > 0)
    {
      aqz.s[par4].b(this, par1, par2, par3, par5, par6);
    }
  }
  



  public amc M()
  {
    return w;
  }
  



  public als N()
  {
    return x;
  }
  



  public abt O()
  {
    return x.x();
  }
  


  public void c() {}
  

  public float h(float par1)
  {
    return (o + (p - o) * par1) * i(par1);
  }
  



  public float i(float par1)
  {
    return m + (n - m) * par1;
  }
  
  @SideOnly(Side.CLIENT)
  public void j(float par1)
  {
    m = par1;
    n = par1;
  }
  



  public boolean P()
  {
    return h(1.0F) > 0.9D;
  }
  



  public boolean Q()
  {
    return i(1.0F) > 0.2D;
  }
  
  public boolean F(int par1, int par2, int par3)
  {
    if (!Q())
    {
      return false;
    }
    if (!l(par1, par2, par3))
    {
      return false;
    }
    if (h(par1, par3) > par2)
    {
      return false;
    }
    

    acq biomegenbase = a(par1, par3);
    return biomegenbase.c() ? false : biomegenbase.d();
  }
  




  public boolean G(int par1, int par2, int par3)
  {
    return t.isBlockHighHumidity(par1, par2, par3);
  }
  




  public void a(String par1Str, all par2WorldSavedData)
  {
    z.a(par1Str, par2WorldSavedData);
  }
  




  public all a(Class par1Class, String par2Str)
  {
    return z.a(par1Class, par2Str);
  }
  




  public int b(String par1Str)
  {
    return z.a(par1Str);
  }
  
  public void d(int par1, int par2, int par3, int par4, int par5)
  {
    for (int j1 = 0; j1 < u.size(); j1++)
    {
      ((acb)u.get(j1)).a(par1, par2, par3, par4, par5);
    }
  }
  



  public void e(int par1, int par2, int par3, int par4, int par5)
  {
    a((uf)null, par1, par2, par3, par4, par5);
  }
  



  public void a(uf par1EntityPlayer, int par2, int par3, int par4, int par5, int par6)
  {
    try
    {
      for (int j1 = 0; j1 < u.size(); j1++)
      {
        ((acb)u.get(j1)).a(par1EntityPlayer, par2, par3, par4, par5, par6);
      }
    }
    catch (Throwable throwable)
    {
      b crashreport = b.a(throwable, "Playing level event");
      m crashreportcategory = crashreport.a("Level event being played");
      crashreportcategory.a("Block coordinates", m.a(par3, par4, par5));
      crashreportcategory.a("Event source", par1EntityPlayer);
      crashreportcategory.a("Event type", Integer.valueOf(par2));
      crashreportcategory.a("Event data", Integer.valueOf(par6));
      throw new u(crashreport);
    }
  }
  



  public int R()
  {
    return t.getHeight();
  }
  



  public int S()
  {
    return t.getActualHeight();
  }
  
  public hr a(st par1EntityMinecart)
  {
    return null;
  }
  



  public Random H(int par1, int par2, int par3)
  {
    long l = par1 * 341873128712L + par2 * 132897987541L + N().b() + par3;
    s.setSeed(l);
    return s;
  }
  



  public aco b(String par1Str, int par2, int par3, int par4)
  {
    return L().a(this, par1Str, par2, par3, par4);
  }
  




  @SideOnly(Side.CLIENT)
  public boolean T()
  {
    return false;
  }
  




  @SideOnly(Side.CLIENT)
  public double U()
  {
    return t.getHorizon();
  }
  



  public m a(b par1CrashReport)
  {
    m crashreportcategory = par1CrashReport.a("Affected level", 1);
    crashreportcategory.a("Level name", x == null ? "????" : x.k());
    crashreportcategory.a("All players", new aby(this));
    crashreportcategory.a("Chunk stats", new abz(this));
    
    try
    {
      x.a(crashreportcategory);
    }
    catch (Throwable throwable)
    {
      crashreportcategory.a("Level Data Unobtainable", throwable);
    }
    
    return crashreportcategory;
  }
  




  public void f(int par1, int par2, int par3, int par4, int par5)
  {
    for (int j1 = 0; j1 < u.size(); j1++)
    {
      acb iworldaccess = (acb)u.get(j1);
      iworldaccess.b(par1, par2, par3, par4, par5);
    }
  }
  



  public atd V()
  {
    return J;
  }
  



  public Calendar W()
  {
    if (I() % 600L == 0L)
    {
      K.setTimeInMillis(MinecraftServer.aq());
    }
    
    return K;
  }
  
  @SideOnly(Side.CLIENT)
  public void a(double par1, double par3, double par5, double par7, double par9, double par11, by par13NBTTagCompound) {}
  
  public atj X()
  {
    return D;
  }
  
  public void m(int par1, int par2, int par3, int par4)
  {
    for (ForgeDirection dir : ForgeDirection.VALID_DIRECTIONS)
    {
      int j1 = par1 + offsetX;
      int y = par2 + offsetY;
      int k1 = par3 + offsetZ;
      int l1 = a(j1, y, k1);
      aqz block = aqz.s[l1];
      
      if (block != null)
      {
        block.onNeighborTileChange(this, j1, y, k1, par1, par2, par3);
        
        if (aqz.l(l1))
        {
          j1 += offsetX;
          y += offsetY;
          k1 += offsetZ;
          l1 = a(j1, y, k1);
          block = aqz.s[l1];
          if ((block != null) && (block.weakTileChanges()))
          {
            block.onNeighborTileChange(this, j1, y, k1, par1, par2, par3);
          }
        }
      }
    }
  }
  
  public lp Y()
  {
    return L;
  }
  





  public float b(double par1, double par3, double par5)
  {
    return I(ls.c(par1), ls.c(par3), ls.c(par5));
  }
  





  public float I(int par1, int par2, int par3)
  {
    float f = 0.0F;
    boolean flag = r == 3;
    
    if (f(par1, par2, par3))
    {
      float f1 = x();
      f += ls.a((float)dq / 3600000.0F, 0.0F, 1.0F) * (flag ? 1.0F : 0.75F);
      f += f1 * 0.25F;
    }
    
    if (r < 2)
    {
      f *= r / 2.0F;
    }
    
    return ls.a(f, 0.0F, flag ? 1.5F : 1.0F);
  }
  




  public void addTileEntity(asp entity)
  {
    List dest = N ? a : g;
    if (entity.canUpdate())
    {
      dest.add(entity);
    }
  }
  










  public boolean isBlockSolidOnSide(int x, int y, int z, ForgeDirection side)
  {
    return isBlockSolidOnSide(x, y, z, side, false);
  }
  












  public boolean isBlockSolidOnSide(int x, int y, int z, ForgeDirection side, boolean _default)
  {
    if ((x < -30000000) || (z < -30000000) || (x >= 30000000) || (z >= 30000000))
    {
      return _default;
    }
    
    adr chunk = v.d(x >> 4, z >> 4);
    if ((chunk == null) || (chunk.g()))
    {
      return _default;
    }
    
    aqz block = aqz.s[a(x, y, z)];
    if (block == null)
    {
      return false;
    }
    
    return block.isBlockSolidOnSide(this, x, y, z, side);
  }
  





  public ImmutableSetMultimap<abp, ForgeChunkManager.Ticket> getPersistentChunks()
  {
    return ForgeChunkManager.getPersistentChunksFor(this);
  }
  








  public int getBlockLightOpacity(int x, int y, int z)
  {
    if ((x < -30000000) || (z < -30000000) || (x >= 30000000) || (z >= 30000000))
    {
      return 0;
    }
    
    if ((y < 0) || (y >= 256))
    {
      return 0;
    }
    
    return e(x >> 4, z >> 4).b(x & 0xF, y, z & 0xF);
  }
  



  public int countEntities(oh type, boolean forSpawnCount)
  {
    int count = 0;
    for (int x = 0; x < e.size(); x++)
    {
      if (((nn)e.get(x)).isCreatureType(type, forSpawnCount))
      {
        count++;
      }
    }
    return count;
  }
}
