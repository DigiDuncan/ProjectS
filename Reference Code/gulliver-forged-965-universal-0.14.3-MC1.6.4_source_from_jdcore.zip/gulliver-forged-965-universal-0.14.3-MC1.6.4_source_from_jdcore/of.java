import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import gulliver.EntityDamageSourcePassive;
import gulliver.api.IResizeableLiving;
import gulliver.common.GulliverEnvoy;
import gulliver.potion.PotionResizing;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import net.minecraftforge.common.ForgeHooks;


















































public abstract class of
  extends nn
  implements IResizeableLiving
{
  private static final UUID b = UUID.fromString("662A6B8D-DA3E-4C1C-8813-96EA6097278D");
  private static final ot c = new ot(b, "Sprinting speed boost", 0.30000001192092896D, 2).a(false);
  private ov d;
  private final na e = new na(this);
  private final HashMap f = new HashMap();
  

  private final ye[] g = new ye[5];
  

  public boolean au;
  

  public int av;
  

  public int aw;
  

  public float ax;
  
  public int ay;
  
  public int az;
  
  public float aA;
  
  public int aB;
  
  public int aC;
  
  public float aD;
  
  public float aE;
  
  public float aF;
  
  public float aG;
  
  public float aH;
  
  public int aI = 20;
  
  public float aJ;
  
  public float aK;
  
  public float aL;
  
  public float aM;
  
  public float aN;
  
  public float aO;
  
  public float aP;
  
  public float aQ;
  public float aR = 0.02F;
  

  protected uf aS;
  

  protected int aT;
  

  protected boolean aU;
  

  protected int aV;
  

  protected float aW;
  

  protected float aX;
  

  protected float aY;
  

  protected float aZ;
  

  protected float ba;
  

  protected int bb;
  

  protected float bc;
  

  protected boolean bd;
  

  public float be;
  
  public float bf;
  
  protected float bg;
  
  protected int bh;
  
  protected double bi;
  
  protected double bj;
  
  protected double bk;
  
  protected double bl;
  
  protected double bm;
  
  private boolean h = true;
  
  private of i;
  
  private int j;
  
  private of bn;
  
  private int bo;
  
  private float bp;
  
  private int bq;
  
  private float br;
  
  protected float ladderRate;
  
  protected int ladderBlockId;
  
  public boolean readSizeBaseFromFile;
  
  public float sizeBaseMultiplier;
  
  protected float sizeBaseAdjustMultiplier;
  
  public float sizePotionMultiplier;
  
  public float sizeDestMultiplier;
  
  public float sizeRate;
  public float sizeWitheringMultiplier;
  public int unwitheringCountdown;
  protected float normalWidth;
  protected float normalHeight;
  public boolean isGlidingFlag = false;
  public boolean isRaftingFlag = false;
  public boolean couldUseUmbrella = false;
  public boolean isStruggling = false;
  
  public void doResize(float f, boolean reposition)
  {
    float oldw = O;
    super.doResize(f, reposition);
    
    super.a(normalWidth * getSizeMultiplier(), normalHeight * getSizeMultiplier());
    
    if (reposition)
    {
      float neww = O;
      b(u, v, w);
      GulliverEnvoy.resizeCollision(this, oldw, neww);
    }
  }
  
  public void doWalkingResize(float f, boolean reposition)
  {
    asx bb2 = E.c();
    float oldsm = getSizeMultiplier();
    float oldh = P;
    float oldw = O;
    setSizeMultiplier(f);
    float sizemult = getSizeMultiplier();
    super.a(normalWidth * sizemult, normalHeight * sizemult);
    
    if (reposition)
    {
      b(u, v, w);
    }
    
    if ((!Z) && (T()) && ((reposition) || ((this instanceof uf))) && (GulliverEnvoy.canSizeGrief(this)))
    {
      if ((!q.I) && (oldsm < sizemult) && (sizemult > 0.5F))
      {
        GulliverEnvoy.breakBlocksViaGrowth(this, bb2, (P - oldh) / 4.0D, (O - oldw) / 4.0D, ab);
      }
      
      GulliverEnvoy.resizeCollision(this, oldw, O);
    }
  }
  
  public float getSizePotionMultiplier()
  {
    return sizePotionMultiplier * sizeWitheringMultiplier;
  }
  
  public float getSizeItemMultiplier()
  {
    float osize = 1.0F;
    
    if ((GulliverEnvoy.isDyeResizingEnabled()) && (aZ() != null) && ((aZ().b() instanceof xl)))
    {
      if (aZ().k() == 6)
      {

        osize *= 0.5F;
      }
      else if (aZ().k() == 5)
      {

        osize *= 2.0F;
      }
    }
    
    return osize;
  }
  


  public void setSizeBaseMultiplier(float f)
  {
    if (GulliverEnvoy.isInvalidSize(f))
    {
      f = 1.0F;
    }
    
    sizeBaseAdjustMultiplier = 1.0F;
    


    if (GulliverEnvoy.getMinEntityBaseSize() > 0.0D)
    {
      while ((sizeBaseAdjustMultiplier * f <= (float)GulliverEnvoy.getMinEntityBaseSize()) && (sizeBaseAdjustMultiplier * f * 2.0F <= (float)GulliverEnvoy.getMinEntityBaseSize()))
      {
        sizeBaseAdjustMultiplier *= 2.0F;
      }
    }
    
    if (GulliverEnvoy.getMaxEntityBaseSize() > 0.0D)
    {
      while ((sizeBaseAdjustMultiplier * f >= (float)GulliverEnvoy.getMaxEntityBaseSize()) && (sizeBaseAdjustMultiplier * f / 2.0F >= (float)GulliverEnvoy.getMaxEntityBaseSize()))
      {
        sizeBaseAdjustMultiplier /= 2.0F;
      }
    }
    
    sizeBaseMultiplier = f;
  }
  

  public float getNewSizeDestMultiplier()
  {
    float dest = sizeBaseMultiplier * sizeBaseAdjustMultiplier;
    
    if (dest > (float)GulliverEnvoy.getMaxEntityBaseSize())
    {
      dest = (float)GulliverEnvoy.getMaxEntityBaseSize();
    }
    if (dest < (float)GulliverEnvoy.getMinEntityBaseSize())
    {
      dest = (float)GulliverEnvoy.getMinEntityBaseSize();
    }
    

    if (GulliverEnvoy.isInvalidSize(dest))
    {
      dest = 1.0F;
    }
    
    float mult = getSizePotionMultiplier();
    if (!GulliverEnvoy.isInvalidSize(mult))
    {
      dest *= mult;
    }
    
    mult = getSizeItemMultiplier();
    if (!GulliverEnvoy.isInvalidSize(mult))
    {
      dest *= mult;
    }
    
    float max = (float)GulliverEnvoy.getMaxSizeForEntity(this);
    float min = (float)GulliverEnvoy.getMinSizeForEntity(this);
    if (dest > max)
    {
      dest = max;
    }
    if (dest < min)
    {
      dest = min;
    }
    
    max = (float)GulliverEnvoy.getMaxEntitySize();
    min = (float)GulliverEnvoy.getMinEntitySize();
    if (dest > max)
    {
      dest = max;
    }
    if (dest < min)
    {
      dest = min;
    }
    
    if (dest > 8.0F)
    {
      dest = 8.0F;
    }
    if (dest < 0.125F)
    {
      dest = 0.125F;
    }
    
    return dest;
  }
  
  public void refreshSizeDestMultiplier()
  {
    if (q.I)
    {
      return;
    }
    
    float tmp = sizeDestMultiplier;
    sizeDestMultiplier = getNewSizeDestMultiplier();
    
    if (getSizeMultiplier() == sizeDestMultiplier)
    {
      sizeRate = 0.0F;
    }
    else if ((sizeRate == 0.0F) || (tmp != sizeDestMultiplier) || (sizeRate * (sizeDestMultiplier - getSizeMultiplier()) < 0.0F))
    {
      int amp = 2;
      

      if (a(PotionResizing.huge))
      {
        amp = b(PotionResizing.huge).c();
        amp = amp >= 255 ? 1 : 2 * (amp + 1);
      }
      else if (a(PotionResizing.tiny))
      {
        amp = b(PotionResizing.tiny).c();
        amp = amp >= 255 ? 1 : 2 * (amp + 1);
      }
      
      sizeRate = ((sizeDestMultiplier - getSizeMultiplier()) / (20 * amp));
    }
  }
  

  public void setBaseSize(float f)
  {
    if (q.I)
    {
      return;
    }
    

    if (f > 0.0F)
    {
      setSizeBaseMultiplier(f);
      refreshSizeDestMultiplier();
    }
  }
  

  public void adjustBaseSize(float f)
  {
    if (q.I)
    {
      return;
    }
    

    if (f > 0.0F)
    {
      setSizeBaseMultiplier(sizeBaseMultiplier * f);
      refreshSizeDestMultiplier();
    }
  }
  

  public void halveSize()
  {
    if (q.I)
    {
      return;
    }
    
    if (sizeBaseMultiplier > (float)GulliverEnvoy.getMinEntityBaseSize())
    {
      setSizeBaseMultiplier(sizeBaseMultiplier * 0.5F);
      refreshSizeDestMultiplier();
    }
  }
  

  public void doubleSize()
  {
    if (q.I)
    {
      return;
    }
    
    if (sizeBaseMultiplier < (float)GulliverEnvoy.getMaxEntityBaseSize())
    {
      setSizeBaseMultiplier(sizeBaseMultiplier * 2.0F);
      refreshSizeDestMultiplier();
    }
  }
  
  public float getStepHeight()
  {
    float f = Y;
    float sizemult = getSizeMultiplier();
    float norm = 1.0F;
    
    while (norm * sizemult < 0.5F)
    {
      norm *= 2.0F;
      f /= 2.0F;
    }
    
    while (norm * sizemult > 1.0F)
    {
      norm /= 2.0F;
      f *= 2.0F;
    }
    


    if (norm * sizemult < 0.65F)
    {
      f *= norm * sizemult;
    }
    
    return f;
  }
  
  public float getAdjStepHeight()
  {
    return getStepHeight();
  }
  


  public int getStepSide()
  {
    return 1;
  }
  
  public boolean isResizable()
  {
    return true;
  }
  
  public of(abw par1World)
  {
    super(par1World);
    az();
    g(aT());
    sizeBaseMultiplier = 1.0F;
    sizeBaseAdjustMultiplier = 1.0F;
    
    if (!(this instanceof uf))
    {
      setSizeBaseMultiplier(GulliverEnvoy.getNewBaseEntitySize(this));
    }
    
    sizePotionMultiplier = (this.sizeWitheringMultiplier = 1.0F);
    normalWidth = O;
    normalHeight = P;
    setSizeMultiplier(sizeBaseMultiplier * sizeBaseAdjustMultiplier);
    sizeDestMultiplier = getSizeMultiplier();
    super.a(O * getSizeMultiplier(), P * getSizeMultiplier());
    m = true;
    aM = ((float)(Math.random() + 1.0D) * 0.01F);
    b(u, v, w);
    aL = ((float)Math.random() * 12398.0F);
    A = ((float)(Math.random() * 3.141592653589793D * 2.0D));
    aP = A;
    Y = 0.5F;
  }
  
  protected void a()
  {
    ah.a(7, Integer.valueOf(0));
    ah.a(8, Byte.valueOf((byte)0));
    ah.a(9, Byte.valueOf((byte)0));
    ah.a(6, Float.valueOf(1.0F));
  }
  
  protected void az()
  {
    aX().b(tp.a);
    aX().b(tp.c);
    aX().b(tp.d);
    
    if (!bf())
    {
      a(tp.d).a(0.10000000149011612D);
    }
  }
  




  protected void a(double par1, boolean par3)
  {
    if (!H())
    {
      I();
    }
    
    if ((par3) && (T > 0.0F))
    {
      int i = ls.c(u);
      int j = ls.c(v - 0.20000000298023224D - N);
      int k = ls.c(w);
      int l = q.a(i, j, k);
      
      if (l == 0)
      {
        int i1 = q.e(i, j - 1, k);
        
        if ((i1 == 11) || (i1 == 32) || (i1 == 21))
        {
          l = q.a(i, j - 1, k);
        }
      }
      
      if (l > 0)
      {
        aqz.s[l].a(q, i, j, k, this, T);
      }
      
      if ((isHuge()) && (T > 0.8F))
      {
        int i1 = (ls.c(E.a + 0.001D) + i) / 2;
        int k1 = (ls.c(E.c + 0.001D) + k) / 2;
        int i2 = (ls.c(E.d - 0.001D) + i) / 2;
        int k2 = (ls.c(E.f - 0.001D) + k) / 2;
        
        l = q.a(i1, j, k1);
        
        if (l > 0)
        {
          aqz.s[l].a(q, i1, j, k1, this, T);
        }
        
        l = q.a(i2, j, k2);
        
        if (l > 0)
        {
          aqz.s[l].a(q, i2, j, k2, this, T);
        }
        
        l = q.a(i1, j, k2);
        
        if (l > 0)
        {
          aqz.s[l].a(q, i1, j, k2, this, T);
        }
        
        l = q.a(i2, j, k1);
        
        if (l > 0)
        {
          aqz.s[l].a(q, i2, j, k1, this, T);
        }
      }
      
      if ((!q.I) && (isSticky()))
      {
        q.a(this, "mob.slime.small", 0.5F * getSizeMultiplierRoot(), 0.7F);
      }
    }
    
    super.a(par1, par3);
  }
  
  public boolean aA()
  {
    return false;
  }
  



  public boolean G()
  {
    return (super.G()) || (GulliverEnvoy.couldBeRainedOn(this));
  }
  
  public boolean holdingPointyItem()
  {
    ye var2 = aZ();
    
    if (var2 == null)
    {
      return false;
    }
    

    return GulliverEnvoy.isItemPointy(var2);
  }
  




  public void y()
  {
    aD = aE;
    super.y();
    q.C.a("livingEntityBaseTick");
    
    if ((T()) && (U()))
    {
      a(nb.d, 1.0F);
    }
    
    if ((F()) || (q.I))
    {
      B();
    }
    
    boolean flag = ((this instanceof uf)) && (bG.a);
    
    if ((T()) && ((a(akc.h)) || (GulliverEnvoy.tinyCaughtInRain(this))))
    {
      if ((!aA()) && (!i(oH)) && (!flag))
      {
        if ((a(akc.h)) || (ac % 4 == 0))
        {
          g(h(al()));
        }
        
        if (al() == -20)
        {
          g(0);
          
          for (int i = 0; i < 8; i++)
          {
            float f = ab.nextFloat() - ab.nextFloat();
            float f1 = ab.nextFloat() - ab.nextFloat();
            float f2 = ab.nextFloat() - ab.nextFloat();
            q.a("bubble", u + f, v + f1, w + f2, x, y, z);
          }
          
          a(nb.e, 2.0F);
        }
      }
      
      B();
      
      if ((!q.I) && (ag()) && (o != null) && (o.shouldDismountInWater(this)) && (!isEntityHoldingOn()))
      {
        a((nn)null);
      }
    }
    else
    {
      g(300);
    }
    
    aJ = aK;
    
    if (aC > 0)
    {
      aC -= 1;
    }
    
    if (ay > 0)
    {
      ay -= 1;
    }
    
    if (af > 0)
    {
      af -= 1;
    }
    
    if (aN() <= 0.0F)
    {
      aB();
    }
    
    if (aT > 0)
    {
      aT -= 1;
    }
    else
    {
      aS = null;
    }
    
    if ((bn != null) && (!bn.T()))
    {
      bn = null;
    }
    
    if ((this.i != null) && (!this.i.T()))
    {
      b((of)null);
    }
    
    aJ();
    aZ = aY;
    aO = aN;
    aQ = aP;
    C = A;
    D = B;
    q.C.b();
  }
  



  public boolean g_()
  {
    return false;
  }
  



  protected void aB()
  {
    aB += 1;
    
    if (aB == 20)
    {


      if ((!q.I) && ((aT > 0) || (aC())) && (!g_()) && (q.O().b("doMobLoot")))
      {
        int i = e(aS);
        
        while (i > 0)
        {
          int j = oa.a(i);
          i -= j;
          q.d(new oa(q, u, v, w, j));
        }
      }
      
      x();
      
      for (int i = 0; i < 20; i++)
      {
        double d0 = ab.nextGaussian() * 0.02D;
        double d1 = ab.nextGaussian() * 0.02D;
        double d2 = ab.nextGaussian() * 0.02D;
        q.a("explode", u + ab.nextFloat() * O * 2.0F - O, v + ab.nextFloat() * P, w + ab.nextFloat() * O * 2.0F - O, d0, d1, d2);
      }
    }
  }
  



  protected int h(int par1)
  {
    int j = aaw.b(this);
    return (j > 0) && (ab.nextInt(j + 1) > 0) ? par1 : par1 - 1;
  }
  



  protected int e(uf par1EntityPlayer)
  {
    return 0;
  }
  



  protected boolean aC()
  {
    return false;
  }
  
  public Random aD()
  {
    return ab;
  }
  

  public of aE()
  {
    return i;
  }
  
  public int aF()
  {
    return j;
  }
  
  public void b(of par1EntityLivingBase)
  {
    i = par1EntityLivingBase;
    j = ac;
    ForgeHooks.onLivingSetAttackTarget(this, par1EntityLivingBase);
  }
  

  public of aG()
  {
    return bn;
  }
  
  public int aH()
  {
    return bo;
  }
  
  public void k(nn par1Entity)
  {
    if ((par1Entity instanceof of))
    {
      bn = ((of)par1Entity);
    }
    else
    {
      bn = null;
    }
    
    bo = ac;
  }
  
  public int aI()
  {
    return aV;
  }
  



  public void b(by par1NBTTagCompound)
  {
    par1NBTTagCompound.a("HealF", aN());
    par1NBTTagCompound.a("Health", (short)(int)Math.ceil(aN()));
    par1NBTTagCompound.a("HurtTime", (short)ay);
    par1NBTTagCompound.a("DeathTime", (short)aB);
    par1NBTTagCompound.a("AttackTime", (short)aC);
    par1NBTTagCompound.a("SizeBase", sizeBaseMultiplier);
    par1NBTTagCompound.a("SizeWithered", sizeWitheringMultiplier);
    par1NBTTagCompound.a("AbsorptionAmount", bn());
    ye[] aitemstack = ae();
    int i = aitemstack.length;
    


    for (int j = 0; j < i; j++)
    {
      ye itemstack = aitemstack[j];
      
      if (itemstack != null)
      {
        d.a(itemstack.D());
      }
    }
    
    par1NBTTagCompound.a("Attributes", tp.a(aX()));
    aitemstack = ae();
    i = aitemstack.length;
    
    for (j = 0; j < i; j++)
    {
      ye itemstack = aitemstack[j];
      
      if (itemstack != null)
      {
        d.b(itemstack.D());
      }
    }
    
    if (!f.isEmpty())
    {
      cg nbttaglist = new cg();
      Iterator iterator = f.values().iterator();
      
      while (iterator.hasNext())
      {
        nj potioneffect = (nj)iterator.next();
        nbttaglist.a(potioneffect.a(new by()));
      }
      
      par1NBTTagCompound.a("ActiveEffects", nbttaglist);
    }
  }
  



  public void a(by par1NBTTagCompound)
  {
    m(par1NBTTagCompound.g("AbsorptionAmount"));
    
    if ((par1NBTTagCompound.b("Attributes")) && (q != null) && (!q.I))
    {
      tp.a(aX(), par1NBTTagCompound.m("Attributes"), q == null ? null : q.Y());
    }
    

    sizeRate = 0.0F;
    sizeDestMultiplier = getSizeMultiplier();
    
    if (par1NBTTagCompound.b("SpawnSizeBase"))
    {
      setSizeBaseMultiplier(GulliverEnvoy.getSizeFromRangeString(par1NBTTagCompound.i("SpawnSizeBase"), false));
    }
    else if (!par1NBTTagCompound.b("SizeBase"))
    {
      setSizeBaseMultiplier(getSizeMultiplier());
    }
    else
    {
      setSizeBaseMultiplier(par1NBTTagCompound.g("SizeBase"));
      readSizeBaseFromFile = true;
    }
    
    if (par1NBTTagCompound.b("SizeWithered"))
    {
      sizeWitheringMultiplier = par1NBTTagCompound.g("SizeWithered");
      if ((sizeWitheringMultiplier < 0.1F) || (sizeWitheringMultiplier > 1.0F))
      {
        sizeWitheringMultiplier = 1.0F;
      }
    }
    else
    {
      sizeWitheringMultiplier = 1.0F;
    }
    
    if (par1NBTTagCompound.b("ActiveEffects"))
    {
      cg nbttaglist = par1NBTTagCompound.m("ActiveEffects");
      
      for (int i = 0; i < nbttaglist.c(); i++)
      {
        by nbttagcompound1 = (by)nbttaglist.b(i);
        nj potioneffect = nj.b(nbttagcompound1);
        if (potioneffect.isValidPotionEffect())
        {
          f.put(Integer.valueOf(potioneffect.a()), potioneffect);
        }
      }
    }
    
    if (par1NBTTagCompound.b("HealF"))
    {
      g(par1NBTTagCompound.g("HealF"));
    }
    else
    {
      cl nbtbase = par1NBTTagCompound.a("Health");
      
      if (nbtbase == null)
      {
        g(aT());
      }
      else if (nbtbase.a() == 5)
      {
        g(a);
      }
      else if (nbtbase.a() == 2)
      {
        g(a);
      }
    }
    
    ay = par1NBTTagCompound.d("HurtTime");
    aB = par1NBTTagCompound.d("DeathTime");
    aC = par1NBTTagCompound.d("AttackTime");
  }
  
  protected void aJ()
  {
    if (!q.I)
    {
      if ((a(PotionResizing.huge)) && (a(PotionResizing.tiny)))
      {

        b(b(PotionResizing.huge));
        f.remove(Integer.valueOf(PotionResizing.huge.c()));
        b(b(PotionResizing.tiny));
        f.remove(Integer.valueOf(PotionResizing.tiny.c()));
      }
      
      if (a(ni.v))
      {
        unwitheringCountdown = 0;
      }
      else if ((!(this instanceof uf)) || (!q.N().t()))
      {
        if (sizeWitheringMultiplier < 1.0F)
        {
          if (unwitheringCountdown <= 0)
          {
            sizeWitheringMultiplier *= (1.0F + 0.1F * aN() / aT());
            

            if ((sizeWitheringMultiplier < 1.0F) && (sizeWitheringMultiplier > 0.0F))
            {
              unwitheringCountdown = 100;
            }
            else
            {
              unwitheringCountdown = 0;
              sizeWitheringMultiplier = 1.0F;
            }
          }
          else
          {
            unwitheringCountdown -= 1;
          }
        }
        else
        {
          unwitheringCountdown = 0;
          sizeWitheringMultiplier = 1.0F;
        }
      }
    }
    
    Iterator iterator = f.keySet().iterator();
    
    while (iterator.hasNext())
    {
      Integer integer = (Integer)iterator.next();
      nj potioneffect = (nj)f.get(integer);
      
      if (!potioneffect.a(this))
      {
        if (!q.I)
        {
          iterator.remove();
          b(potioneffect);
        }
      }
      else if (potioneffect.b() % 600 == 0)
      {
        a(potioneffect, false);
      }
    }
    


    if (h)
    {
      if (!q.I)
      {
        if (f.isEmpty())
        {
          ah.b(8, Byte.valueOf((byte)0));
          ah.b(7, Integer.valueOf(0));
          d(false);
        }
        else
        {
          int i = zp.a(f.values());
          ah.b(8, Byte.valueOf((byte)(zp.b(f.values()) ? 1 : 0)));
          ah.b(7, Integer.valueOf(i));
          d(i(pH));
        }
      }
      
      h = false;
    }
    
    int i = ah.c(7);
    boolean flag = ah.a(8) > 0;
    
    if (i > 0)
    {
      boolean flag1 = false;
      
      if (!aj())
      {
        flag1 = ab.nextBoolean();
      }
      else
      {
        flag1 = ab.nextInt(15) == 0;
      }
      if (isTiny())
      {
        flag1 &= ab.nextInt(4) == 0;
      }
      
      if (flag)
      {
        flag1 &= ab.nextInt(5) == 0;
      }
      
      if ((flag1) && (i > 0))
      {
        double d0 = (i >> 16 & 0xFF) / 255.0D;
        double d1 = (i >> 8 & 0xFF) / 255.0D;
        double d2 = (i >> 0 & 0xFF) / 255.0D;
        q.a((flag) || (isTiny()) ? "mobSpellAmbient" : "mobSpell", u + (ab.nextDouble() - 0.5D) * O, v + ab.nextDouble() * P - N, w + (ab.nextDouble() - 0.5D) * O, d0, d1, d2);
      }
    }
  }
  
  public void aK()
  {
    Iterator iterator = f.keySet().iterator();
    
    while (iterator.hasNext())
    {
      Integer integer = (Integer)iterator.next();
      nj potioneffect = (nj)f.get(integer);
      
      if (!q.I)
      {
        iterator.remove();
        b(potioneffect);
      }
    }
  }
  
  public Collection aL()
  {
    return f.values();
  }
  
  public boolean i(int par1)
  {
    return f.containsKey(Integer.valueOf(par1));
  }
  
  public boolean a(ni par1Potion)
  {
    return f.containsKey(Integer.valueOf(H));
  }
  



  public nj b(ni par1Potion)
  {
    return (nj)f.get(Integer.valueOf(H));
  }
  



  public void c(nj par1PotionEffect)
  {
    if (d(par1PotionEffect))
    {
      if (f.containsKey(Integer.valueOf(par1PotionEffect.a())))
      {
        ((nj)f.get(Integer.valueOf(par1PotionEffect.a()))).a(par1PotionEffect);
        a((nj)f.get(Integer.valueOf(par1PotionEffect.a())), true);
      }
      else
      {
        f.put(Integer.valueOf(par1PotionEffect.a()), par1PotionEffect);
        a(par1PotionEffect);
      }
    }
  }
  
  public boolean d(nj par1PotionEffect)
  {
    if (aY() == oj.b)
    {
      int i = par1PotionEffect.a();
      
      if ((i == lH) || (i == uH))
      {
        return false;
      }
    }
    
    return true;
  }
  



  public boolean aM()
  {
    return aY() == oj.b;
  }
  



  public void j(int par1)
  {
    f.remove(Integer.valueOf(par1));
  }
  



  public void k(int par1)
  {
    nj potioneffect = (nj)f.remove(Integer.valueOf(par1));
    
    if (potioneffect != null)
    {
      b(potioneffect);
    }
  }
  
  protected void a(nj par1PotionEffect)
  {
    h = true;
    
    if (!q.I)
    {
      ni.a[par1PotionEffect.a()].b(this, aX(), par1PotionEffect.c());
    }
  }
  
  protected void a(nj par1PotionEffect, boolean par2)
  {
    h = true;
    
    if ((par2) && (!q.I))
    {
      ni.a[par1PotionEffect.a()].a(this, aX(), par1PotionEffect.c());
      ni.a[par1PotionEffect.a()].b(this, aX(), par1PotionEffect.c());
    }
  }
  
  protected void b(nj par1PotionEffect)
  {
    h = true;
    
    if (!q.I)
    {
      ni.a[par1PotionEffect.a()].a(this, aX(), par1PotionEffect.c());
      par1PotionEffect.finishEffect(this);
    }
  }
  



  public void f(float par1)
  {
    float f1 = aN();
    
    if (f1 > 0.0F)
    {
      g(f1 + par1);
    }
  }
  
  public final float aN()
  {
    return ah.d(6);
  }
  
  public void g(float par1)
  {
    ah.b(6, Float.valueOf(ls.a(par1, 0.0F, aT())));
  }
  



  public boolean a(nb par1DamageSource, float par2)
  {
    if (ForgeHooks.onLivingAttack(this, par1DamageSource, par2)) return false;
    if (ar())
    {
      return false;
    }
    if (q.I)
    {
      return false;
    }
    

    aV = 0;
    
    if (aN() <= 0.0F)
    {
      return false;
    }
    if ((par1DamageSource.m()) && (a(ni.n)))
    {
      return false;
    }
    if ((par1DamageSource.n().equals(nb.g.n())) && (getSizeMultiplier() > 3.5F))
    {
      return false;
    }
    

    if (par1DamageSource == nb.l)
    {
      if ((sizeWitheringMultiplier > 0.1F) && (aT() > 0.0F))
      {
        sizeWitheringMultiplier *= (0.97F + 0.02F * aN() / aT());

      }
      else
      {
        sizeWitheringMultiplier = 0.1F;
      }
    }
    
    if ((par1DamageSource == nb.m) || (par1DamageSource == nb.n))
    {
      par2 /= getSizeMultiplierRoot();
      
      if (n(4) != null)
      {
        n(4).a((int)(par2 * 4.0F + ab.nextFloat() * par2 * 2.0F), this);
        par2 *= 0.75F;
      }
    }
    
    aG = 1.5F;
    boolean flag = true;
    nn entity = par1DamageSource.i();
    nn cause = par1DamageSource.h();
    
    if ((cause != null) && (!par1DamageSource.n().equals("squish")) && (!par1DamageSource.n().equals("step")))
    {

      if ((par1DamageSource.n().equals("thrown")) && (par2 == 0.0F) && (P >= P * 0.5F))
      {
        par2 = 0.5F;
      }
      
      boolean squish = (par1DamageSource.n().equals("mob")) && ((entity instanceof og)) && (((og)cause).shouldSquish(this));
      float sizemult = cause.getSizeMultiplier();
      par2 /= (squish ? getSizeMultiplierRoot() : getSizeMultiplier());
      
      if ((squish) || (((cause instanceof of)) && (((of)cause).aZ() != null)))
      {
        ye stack = ((of)cause).aZ();
        
        if ((sizemult < 1.0F) && (((of)cause).holdingPointyItem()) && (stack.b() != null) && (!stack.b().e_(stack)))
        {

          par2 *= (float)Math.cbrt(sizemult);
        }
        else
        {
          par2 *= cause.getSizeMultiplierRoot();
        }
      }
      else
      {
        par2 *= sizemult;
      }
    }
    else if (par1DamageSource.n().equals(nb.g.n()))
    {

      par2 *= (isTiny() ? 0.5F : 1.0F) / getRangeMultiplier();
    }
    
    if (af > aI / 2.0F)
    {
      if (par2 <= bc)
      {
        return false;
      }
      
      d(par1DamageSource, par2 - bc);
      bc = par2;
      flag = false;
    }
    else
    {
      bc = par2;
      ax = aN();
      af = aI;
      d(par1DamageSource, par2);
      ay = (this.az = 10);
    }
    
    if (par2 > 1.0F)
    {
      if ((n != null) && ((n instanceof uf)))
      {
        ((uf)n).maybeKnockoff();
      }
    }
    
    aA = 0.0F;
    
    if (entity != null)
    {
      if ((entity instanceof of))
      {
        b((of)entity);
      }
      
      if ((entity instanceof uf))
      {
        aT = 100;
        aS = ((uf)entity);
      }
      else if ((entity instanceof sf))
      {
        sf entitywolf = (sf)entity;
        
        if (entitywolf.bT())
        {
          aT = 100;
          aS = null;
        }
      }
    }
    
    if (flag)
    {
      q.a(this, (byte)2);
      
      if (par1DamageSource != nb.e)
      {
        K();
      }
      
      if (entity != null)
      {
        double d0 = u - u;
        

        for (double d1 = w - w; d0 * d0 + d1 * d1 < 1.0E-4D; d1 = (Math.random() - Math.random()) * 0.01D)
        {
          d0 = (Math.random() - Math.random()) * 0.01D;
        }
        
        aA = ((float)(Math.atan2(d1, d0) * 180.0D / 3.141592653589793D) - A);
        
        if ((par2 > 0.0F) || ((par1DamageSource.n().equals("thrown")) && (P >= P * 0.03125F)))
        {

          if (!par1DamageSource.n().equals("squish"))
          {
            a(entity, par2, d0, d1);
          }
          
          if (heldEntity != null)
          {
            heldEntity.getDroppedByEntity(this);
          }
        }
      }
      else if ((isTiny()) && (par1DamageSource.n().equals(nb.g.n())))
      {

        double d0 = ls.c(u) + 0.5D - u;
        

        for (double d1 = ls.c(w) + 0.5D - w; d0 * d0 + d1 * d1 < 1.0E-4D; d1 = (Math.random() - Math.random()) * 0.01D)
        {
          d0 = (Math.random() - Math.random()) * 0.01D;
        }
        
        aA = ((float)(Math.atan2(d1, d0) * 180.0D / 3.141592653589793D) - A);
        a(entity, par2, d0, d1);
      }
      else
      {
        aA = ((int)(Math.random() * 2.0D) * 180);
      }
    }
    
    if (aN() <= 0.0F)
    {
      if (flag)
      {
        a(aP(), ba(), bb());
      }
      
      a(par1DamageSource);
    }
    else if (flag)
    {
      a(aO(), ba(), bb());
    }
    
    return true;
  }
  


  public boolean shouldSquish(nn par1Entity)
  {
    return false;
  }
  



  public void a(ye par1ItemStack)
  {
    a("random.break", 0.8F, 0.8F + q.s.nextFloat() * 0.4F);
    
    for (int i = 0; i < 5; i++)
    {
      atc vec3 = q.V().a((ab.nextFloat() - 0.5D) * 0.1D, Math.random() * 0.1D + 0.1D, 0.0D);
      vec3.a(-B * 3.1415927F / 180.0F);
      vec3.b(-A * 3.1415927F / 180.0F);
      atc vec31 = q.V().a((ab.nextFloat() - 0.5D) * 0.3D, -ab.nextFloat() * 0.6D - 0.3D, 0.6D);
      vec31.a(-B * 3.1415927F / 180.0F);
      vec31.b(-A * 3.1415927F / 180.0F);
      vec31 = vec31.c(u, v + f(), w);
      q.a("iconcrack_" + bcv, c, d, e, c, d + 0.05D, e);
    }
  }
  



  public void a(nb par1DamageSource)
  {
    if (ForgeHooks.onLivingDeath(this, par1DamageSource)) return;
    nn entity = par1DamageSource.i();
    of entitylivingbase = aS();
    
    if ((bb >= 0) && (entitylivingbase != null))
    {
      entitylivingbase.b(this, bb);
    }
    
    if (entity != null)
    {
      entity.a(this);
    }
    
    aU = true;
    
    if (!q.I)
    {
      int i = 0;
      
      if ((entity instanceof uf))
      {
        i = aaw.g((of)entity);
      }
      
      captureDrops = true;
      capturedDrops.clear();
      int j = 0;
      
      if ((!g_()) && (q.O().b("doMobLoot")))
      {
        b(aT > 0, i);
        a(aT > 0, i);
        
        if (aT > 0)
        {
          j = ab.nextInt(200) - i;
          
          if (j < 5)
          {
            l(j <= 0 ? 1 : 0);
          }
        }
      }
      
      captureDrops = false;
      
      if (!ForgeHooks.onLivingDrops(this, par1DamageSource, capturedDrops, i, aT > 0, j))
      {
        for (ss item : capturedDrops)
        {
          q.d(item);
        }
      }
    }
    
    q.a(this, (byte)3);
  }
  




  protected void a(boolean par1, int par2) {}
  



  public void a(nn par1Entity, float par2, double par3, double par5)
  {
    if (ab.nextDouble() >= a(tp.c).e() * (getSizeMultiplierRoot() / (par1Entity == null ? 1.0F : par1Entity.getSizeMultiplierRoot())))
    {
      an = true;
      float f1 = ls.a(par3 * par3 + par5 * par5);
      float f2 = 0.4F;
      
      if (par1Entity != null)
      {
        if (((par1Entity instanceof of)) && (par1Entity.ah()) && (getSizeMultiplier() < par1Entity.getSizeMultiplier()))
        {

          f2 *= getSizeMultiplier();
        }
        else if ((((par1Entity instanceof uf)) && (((uf)par1Entity).by() != null)) || (((par1Entity instanceof of)) && (((of)par1Entity).aZ() != null)))
        {
          if ((par1Entity.getSizeMultiplier() < 1.0F) && (((of)par1Entity).holdingPointyItem()))
          {
            f2 = (float)(f2 * Math.cbrt(par1Entity.getSizeMultiplier()));
          }
          else
          {
            f2 *= par1Entity.getSizeMultiplierRoot();
          }
          
        }
        else {
          f2 *= par1Entity.getSizeMultiplier();
        }
        
      }
      else {
        f2 /= 4.0F;
      }
      
      if (isSticky())
      {
        f2 *= 0.25F;
      }
      
      x /= 2.0D;
      y /= 2.0D;
      z /= 2.0D;
      x -= par3 / f1 * f2;
      y += f2;
      z -= par5 / f1 * f2;
      
      if (y > 0.4000000059604645D)
      {
        y = 0.4000000059604645D;
      }
    }
  }
  



  protected String aO()
  {
    return "damage.hit";
  }
  



  protected String aP()
  {
    return "damage.hit";
  }
  



  protected void l(int par1) {}
  


  protected void b(boolean par1, int par2) {}
  


  public boolean e()
  {
    ladderRate = 0.0F;
    ladderBlockId = 0;
    
    if (o != null)
    {
      return false;
    }
    

    int i = ls.c(u);
    int j = ls.c(E.b);
    int k = ls.c(w);
    int r = (int)(O / 2.0F + 0.25F);
    
    for (int p = i - r; p <= i + r; p++)
    {
      for (int q = k - r; q <= k + r; q++)
      {
        ladderBlockId = this.q.a(p, j, q);
        aqz b1 = aqz.s[ladderBlockId];
        boolean isLadderBlock = ForgeHooks.isLivingOnLadder(b1, this.q, p, j, q, this);
        
        if ((isLadderBlock) && (b1 != null))
        {
          asx entityBB = E.b(O, 0.0D, O);
          ArrayList<asx> bblist = new ArrayList();
          aqz.s[ladderBlockId].a(this.q, p, j, q, entityBB, bblist, this);
          

          if ((!isHuge()) || (!bblist.isEmpty()))
          {



            if (!isTiny())
            {
              ladderRate = 1.0F;
              return true;
            }
            

            if (bblist.isEmpty())
            {
              aqz b = aqz.s[ladderBlockId];
              b.a(this.q, p, j, q);
              bblist.add(asx.a().a(p + b.u(), j + b.w(), q + b.y(), p + b.v(), j + b.x(), q + b.z()));
            }
            
            for (int n = 0; n < bblist.size(); n++)
            {
              if (entityBB.b((asx)bblist.get(n)))
              {
                ladderRate = getSizeMultiplierRoot();
                return true;
              }
            }
          }
        }
      }
    }
    if (isTiny())
    {


      double ex = O * (((this instanceof uf)) && (GulliverEnvoy.isGlideableItem(aZ())) ? 0.25D : 1.0D);
      List lst = this.q.getAllCollidingBoundingBoxes(this, E.b(ex, 0.0D, ex).d(0.0D, F ? 0.0D : -0.03125D, 0.0D));
      
      if ((lst != null) && (!lst.isEmpty()))
      {
        if (this.q.a(i, j, k) == bLcF)
        {

          ladderBlockId = bLcF;
          ladderRate = 0.3F;
          return G;
        }
        
        for (int n = 0; n < lst.size(); n++)
        {
          asx bb = (asx)lst.get(n);
          
          int i2 = ls.c((a + d) / 2.0D);
          int j2 = ls.c((b + e) / 2.0D);
          int k2 = ls.c((c + f) / 2.0D);
          
          float rate = GulliverEnvoy.blockClimbingRateForTiny(this.q, i2, j2, k2);
          
          if ((rate > 0.0F) && (((i == i2) && (k == k2)) || ((i != i2) && (k == k2)) || ((i == i2) && (k != k2) && ((u <= a) || (u >= d) || (w <= c) || (w >= f)))))
          {
            ladderBlockId = this.q.a(i2, j2, k2);
            ladderRate = rate;
            return G;
          }
        }
        if (isSticky())
        {
          ladderRate = 1.0F;
          return G;
        }
      }
    }
    
    return false;
  }
  
  public float getTinyLadderRate()
  {
    return ladderRate;
  }
  



  public boolean T()
  {
    return (!M) && (aN() > 0.0F);
  }
  



  protected void b(float par1)
  {
    par1 = ForgeHooks.onLivingFall(this, par1);
    if (par1 <= 0.0F) return;
    doLivingFall(par1);
  }
  
  protected void doLivingFall(float par1)
  {
    float sh = getAdjStepHeight();
    
    if ((this.n != null) && ((this.n instanceof uf)) && (!ah()) && (par1 > nP * 3.0F) && (par1 > sh * 1.1F))
    {
      ((uf)this.n).maybeKnockoff();
    }
    
    float sizeroot = getSizeMultiplierRoot();
    float min = sh * 1.5F;
    float threshold = sizeroot >= 1.0F ? 3.0F : 0.125F + 2.875F * sizeroot;
    
    if (min < threshold)
    {
      min = threshold;
    }
    
    nj potioneffect = b(ni.j);
    float f1 = potioneffect != null ? potioneffect.c() + 1 : 0.0F;
    float damage = (par1 - min - f1) * sizeroot;
    
    if (damage > 0.0F)
    {
      super.b(par1);
    }
    
    if ((!qI) && (damage > 0.0F))
    {
      int l = ls.c(u);
      int m = ls.c(v - 0.20000000298023224D - N);
      int n = ls.c(w);
      int j = this.q.a(l, m, n);
      
      if ((j > 0) && (!isSticky()))
      {
        ard stepsound = scS;
        a(stepsound.e(), stepsound.c() * 0.5F, stepsound.d() * 0.75F);
      }
      
      if ((isHuge()) && (o == null) && (GulliverEnvoy.canSizeGrief(this)))
      {

        int r = (int)Math.ceil(O * 0.5F);
        int lev = ls.c(Math.log(getSizeMultiplier()) / Math.log(2.0D));
        
        if (par1 - min <= 3.0F)
        {

          lev--;
        }
        
        for (int s = m; (s > m - lev + 1) && (s > 0); s--)
        {
          for (int p = l - r; p <= l + r; p++)
          {
            for (int q = n - r; q <= n + r; q++)
            {
              if ((!(this instanceof uf)) || (this.q.a((uf)this, p, s, q)))
              {

                aqz block = aqz.s[this.q.a(p, s, q)];
                float h = block != null ? block.l(this.q, p, s, q) : 0.0F;
                
                if ((block != null) && (h <= 1.0F) && (h >= 0.0F))
                {
                  if (h > 0.0F)
                  {
                    damage = (float)(damage - (0.1D + h) / getSizeMultiplierRoot() / 2.0D);
                  }
                  
                  int md = this.q.h(p, s, q);
                  
                  if ((cU.d()) || (block == aqz.aY))
                  {
                    if (block == aqz.aY)
                    {
                      akc var8 = this.q.g(p, s - 1, q);
                      
                      if ((var8.c()) || (var8.d()))
                      {
                        this.q.c(p, s, q, FcF);
                      }
                      else
                      {
                        this.q.i(p, s, q);
                      }
                    }
                    else if (cU == akc.h)
                    {
                      this.q.c(p, s, q, FcF);
                    }
                    
                  }
                  else
                  {
                    block.c(this.q, p, s, q, md, 0);
                    this.q.i(p, s, q);
                  }
                  
                  if (ab.nextInt(2) == 0)
                  {
                    this.q.e(2001, p, s, q, cF + (md << 12));
                  }
                }
              }
            }
          }
        }
      }
      int var2 = ls.f(damage);
      
      if (var2 > 0)
      {
        if (var2 > 4)
        {
          a("damage.fallbig", 1.0F, 1.0F);
        }
        else
        {
          a("damage.fallsmall", 1.0F, 1.0F);
        }
        
        a(nb.h, var2);
      }
    }
  }
  




  @SideOnly(Side.CLIENT)
  public void ad()
  {
    ay = (this.az = 10);
    aA = 0.0F;
  }
  



  public int aQ()
  {
    int i = 0;
    ye[] aitemstack = ae();
    int j = aitemstack.length;
    
    for (int k = 0; k < j; k++)
    {
      ye itemstack = aitemstack[k];
      
      if ((itemstack != null) && ((itemstack.b() instanceof wh)))
      {
        int l = bc;
        i += l;
      }
    }
    
    return i;
  }
  


  protected void h(float par1) {}
  

  protected float b(nb par1DamageSource, float par2)
  {
    if (!par1DamageSource.e())
    {
      int i = 25 - aQ();
      float f1 = par2 * i;
      h(par2);
      par2 = f1 / 25.0F;
    }
    
    return par2;
  }
  



  protected float c(nb par1DamageSource, float par2)
  {
    if ((this instanceof tw))
    {
      par2 = par2;
    }
    




    if ((a(ni.m)) && (par1DamageSource != nb.i))
    {
      int i = (b(ni.m).c() + 1) * 5;
      int j = 25 - i;
      float f1 = par2 * j;
      par2 = f1 / 25.0F;
    }
    
    if (par2 <= 0.0F)
    {
      return 0.0F;
    }
    

    int i = aaw.a(ae(), par1DamageSource);
    
    if (i > 20)
    {
      i = 20;
    }
    
    if ((i > 0) && (i <= 20))
    {
      int j = 25 - i;
      float f1 = par2 * j;
      par2 = f1 / 25.0F;
    }
    
    return par2;
  }
  





  protected void d(nb par1DamageSource, float par2)
  {
    if (!ar())
    {
      par2 = ForgeHooks.onLivingHurt(this, par1DamageSource, par2);
      if (par2 <= 0.0F) return;
      par2 = b(par1DamageSource, par2);
      par2 = c(par1DamageSource, par2);
      float f1 = par2;
      par2 = Math.max(par2 - bn(), 0.0F);
      m(bn() - (f1 - par2));
      
      if (par2 != 0.0F)
      {
        float f2 = aN();
        g(f2 - par2);
        aR().a(par1DamageSource, f2, par2);
        m(bn() - par2);
      }
    }
  }
  
  public na aR()
  {
    return e;
  }
  
  public of aS()
  {
    return i != null ? i : aS != null ? aS : e.c() != null ? e.c() : null;
  }
  
  public final float aT()
  {
    return (float)a(tp.a).e();
  }
  



  public final int aU()
  {
    return ah.a(9);
  }
  



  public final void m(int par1)
  {
    ah.b(9, Byte.valueOf((byte)par1));
  }
  




  private int h()
  {
    return a(ni.f) ? 6 + (1 + b(ni.f).c()) * 2 : a(ni.e) ? 6 - (1 + b(ni.e).c()) * 1 : 6;
  }
  



  public void aV()
  {
    ye stack = aZ();
    
    if ((stack != null) && (stack.b() != null))
    {
      yc item = stack.b();
      if (item.onEntitySwing(this, stack))
      {
        return;
      }
    }
    
    if ((!au) || (av >= h() / 2) || (av < 0))
    {
      av = -1;
      au = true;
      
      if ((q instanceof js))
      {
        ((js)q).q().a(this, new dj(this, 1));
      }
    }
  }
  
  @SideOnly(Side.CLIENT)
  public void a(byte par1)
  {
    if (par1 == 2)
    {
      aG = 1.5F;
      af = aI;
      ay = (this.az = 10);
      aA = 0.0F;
      a(aO(), ba(), getAdultSoundPitch());
      a(nb.j, 0.0F);
    }
    else if (par1 == 3)
    {
      a(aP(), ba(), getAdultSoundPitch());
      g(0.0F);
      a(nb.j);
    }
    else
    {
      super.a(par1);
    }
  }
  



  protected void C()
  {
    a(nb.i, 4.0F);
  }
  



  protected void aW()
  {
    int i = h();
    
    if (au)
    {
      av += 1;
      
      if (av >= i)
      {
        av = 0;
        au = false;
      }
    }
    else
    {
      av = 0;
    }
    
    aE = (av / i);
  }
  
  public os a(or par1Attribute)
  {
    return aX().a(par1Attribute);
  }
  
  public ov aX()
  {
    if (d == null)
    {
      d = new pa();
    }
    
    return d;
  }
  



  public oj aY()
  {
    return oj.a;
  }
  



  public abstract ye aZ();
  



  public abstract ye n(int paramInt);
  



  public abstract void c(int paramInt, ye paramYe);
  



  public void c(boolean par1)
  {
    super.c(par1);
    os attributeinstance = a(tp.d);
    
    if (attributeinstance.a(b) != null)
    {
      attributeinstance.b(c);
    }
    
    if (par1)
    {
      attributeinstance.a(c);
    }
  }
  


  public abstract ye[] ae();
  

  protected float ba()
  {
    return 1.0F;
  }
  
  protected float getAdultSoundPitch()
  {
    float pitch = (ab.nextFloat() - ab.nextFloat()) * 0.2F;
    pitch += 0.6F + 0.4F / getSizeMultiplierRoot();
    
    return pitch;
  }
  



  protected float bb()
  {
    return g_() ? getAdultSoundPitch() + 0.5F : getAdultSoundPitch();
  }
  



  protected boolean bc()
  {
    return aN() <= 0.0F;
  }
  



  public void a(double par1, double par3, double par5)
  {
    if (holdingEntity != null)
    {
      holdingEntity.dropHeldEntity(this);
    }
    
    b(par1, par3, par5, A, B);
  }
  



  public void l(nn par1Entity)
  {
    double d0 = u;
    double d1 = E.b + P;
    double d2 = w;
    boolean graceful = (((par1Entity instanceof of)) && (((par1Entity instanceof rs)) || (((of)o).getSaddled())) && (O >= o.O * 0.2F)) || (GulliverEnvoy.isHoldingStringOrLeash(this));
    boolean issmaller = (isTinierThan(par1Entity)) && (P < P * 0.5F);
    double rmult = getSizeMultiplier() >= 1.0F ? getSizeMultiplierRoot() : getSizeMultiplier();
    rmult = (rmult + par1Entity.getSizeMultiplierRoot()) / 2.0D;
    double drsizemult = par1Entity.getSizeMultiplier();
    double dsizeroot = getSizeMultiplierRoot();
    double downmax = P * 2.0D;
    if ((graceful) || (drsizemult < downmax))
    {
      downmax = drsizemult;
    }
    if (((par1Entity instanceof of)) && (issmaller))
    {
      d0 = u;
      d1 = v + P * 0.5D;
      d2 = w;
      if (graceful)
      {
        d1 -= P / getSizeMultiplierRoot();
        if (d1 < E.b + 0.25D)
        {
          d1 = E.b + 0.25D;
        }
      }
    }
    
    for (double d3 = -1.5D * rmult; d3 < 2.0D * rmult; d3 += 1.0D)
    {
      for (double d4 = -1.5D * rmult; d4 < 2.0D * rmult; d4 += 1.0D)
      {
        if ((d3 != 0.0D) || (d4 != 0.0D))
        {
          int i = (int)(u + d3);
          int j = (int)(w + d4);
          asx axisalignedbb = E.c(d3, 1.0D * dsizeroot, d4);
          
          if (q.a(axisalignedbb).isEmpty())
          {
            if ((q.w(i, (int)v, j)) || (q.g(i, (int)v, j) == akc.j))
            {
              a(u + d3, (int)(v + 1.0D) + 0.25D * dsizeroot, w + d4);
              return;
            }
            
            for (double down = drsizemult > 1.0D ? 1.0D : drsizemult; down < downmax + 0.5D; down += 1.0D)
            {
              if ((q.w(i, (int)(v - down), j)) || (q.g(i, (int)(v - down), j) == akc.j) || (q.g(i, (int)(v - drsizemult), j) == akc.h))
              {
                d0 = u + d3;
                d1 = (int)(v - down + 1.0D) + 0.25D * dsizeroot;
                d2 = w + d4;
                break;
              }
            }
          }
        }
      }
    }
    
    a(d0, d1, d2);
  }
  
  @SideOnly(Side.CLIENT)
  public boolean bd()
  {
    return false;
  }
  




  @SideOnly(Side.CLIENT)
  public ms b(ye par1ItemStack, int par2)
  {
    return par1ItemStack.c();
  }
  



  protected void be()
  {
    if (getSizeMultiplier() == 1.0F)
    {
      y = 0.41999998688697815D;

    }
    else
    {
      y = (0.375D + (getSizeMultiplier() <= 1.0F ? getSizeMultiplier() : getSizeMultiplierRoot()) * 0.04499998688697815D);
      
      if ((isWeighted()) || ((isSticky()) && (isTiny())))
      {

        y *= getSizeMultiplierRoot();
      }
      else if ((ah()) && ((!(this instanceof uf)) || (((uf)this).bI().a() > 6.0F) || (bG.c)))
      {
        if (getSizeMultiplier() > 1.0F)
        {
          y *= getSizeMultiplierRoot();
        }
        

      }
      else if (getSizeMultiplier() > 1.0F)
      {
        y *= Math.sqrt(getSizeMultiplierRoot());
      }
      else if ((isTiny()) && (!ai()) && (((this instanceof uf)) || ((ab.nextInt(5) != 0) && (n == null))))
      {


        y *= Math.cbrt(getSizeMultiplierRoot());
      }
    }
    

    if (a(ni.j))
    {
      y += (b(ni.j).c() + 1) * 0.1F * Math.sqrt(getSizeMultiplierRoot());
    }
    
    if ((isSticky()) && (isTiny()))
    {

      a("mob.slime.small", 0.4F, 0.75F);
    }
    
    if (ai())
    {
      float f = A * 0.017453292F;
      x -= ls.a(f) * 0.2F;
      z += ls.b(f) * 0.2F;
    }
    
    an = true;
    ForgeHooks.onLivingJump(this);
  }
  
  public float getEyeDistanceToEntityLiving(of par1Entity)
  {
    float f = (float)(u - u);
    float f1 = (float)(v - v) + f() - X - par1Entity.f() + X;
    float f2 = (float)(w - w);
    return ls.c(f * f + f1 * f1 + f2 * f2);
  }
  
  public float getEyeDistanceSqToEntityLiving(of par1Entity)
  {
    float f = (float)(u - u);
    float f1 = (float)(v - v) + f() - X - par1Entity.f() + X;
    float f2 = (float)(w - w);
    return f * f + f1 * f1 + f2 * f2;
  }
  



  public boolean isWeighted()
  {
    for (int j = 0; j < 4; j++)
    {
      if ((n(j + 1) != null) && (n1d == aqcv - j))
      {
        return true;
      }
    }
    
    return false;
  }
  



  public void e(float par1, float par2)
  {
    float sizeroot = getSizeMultiplierRoot();
    float sizeadj = 1.0F;
    
    if (!isWeighted())
    {
      sizeadj = sizeroot;
    }
    

    boolean ladder = e();
    boolean seated = ((this instanceof oq)) && (((oq)this).bU());
    
    if ((H()) && ((!(this instanceof uf)) || (!bG.b)))
    {
      double d0 = v;
      a(par1, par2, sizeroot * (bf() ? 0.04F : 0.02F));
      d(this.x, this.y, this.z);
      this.x *= 0.800000011920929D;
      this.y *= 0.800000011920929D;
      this.z *= 0.800000011920929D;
      this.y -= 0.02D * sizeroot;
      
      if ((G) && (!seated) && ((ladder) || (ladderRate > 0.0F) || (c(this.x, this.y + 0.6000000238418579D * getSizeMultiplier() - v + d0, this.z))))
      {
        this.y = (0.30000001192092896D * sizeroot);
        
        if (ladderRate > 0.0F)
        {
          this.y *= ladderRate * 0.5F * sizeroot * (isSticky() ? 0.5F : 1.0F);
        }
      }
    }
    else if ((J()) && ((!(this instanceof uf)) || (!bG.b)))
    {
      double d0 = v;
      a(par1, par2, sizeroot * 0.02F);
      d(this.x, this.y, this.z);
      this.x *= 0.5D;
      this.y *= 0.5D;
      this.z *= 0.5D;
      this.y -= 0.02D * sizeroot;
      
      if ((G) && (!seated) && ((ladder) || (ladderRate > 0.0F) || (c(this.x, this.y + 0.6000000238418579D * getSizeMultiplier() - v + d0, this.z))))
      {
        this.y = (0.30000001192092896D * sizeroot);
        
        if (ladderRate > 0.0F)
        {
          this.y *= ladderRate * 0.25F * sizeroot;
        }
      }
    }
    else
    {
      float f2 = 0.91F;
      int x = ls.c(u);
      int y = ls.c(E.b);
      int z = ls.c(w);
      
      if (F)
      {
        f2 = 0.54600006F;
        int i = q.a(x, ls.c(E.b - 0.125D), z);
        
        if (i > 0)
        {
          f2 = scV * 0.91F;
        }
      }
      
      float f3 = 0.16277136F / (f2 * f2 * f2);
      
      float f4;
      if (F)
      {
        float f4 = bg();
        
        if (!isSticky())
        {
          f4 *= f3;
        }
      }
      else
      {
        f4 = aR;
        
        if ((getSizeMultiplier() < 1.0F) && (!isWeighted()) && (((isGliding()) && (ah())) || ((!isGliding()) && (!isSticky()) && ((!(this instanceof uf)) || (!bG.b)))))
        {
          f4 = (float)(f4 * (Math.cbrt(getSizeMultiplier()) / getSizeMovementMultiplier()));
        }
      }
      
      a(par1, par2, getSizeMovementMultiplier() * f4);
      f2 = 0.91F;
      boolean tinyWithinPlant = (isTiny()) && (!ag()) && (GulliverEnvoy.isEntityIntersectingPlant(this));
      
      if (F)
      {
        f2 = 0.54600006F;
        int j = q.a(x, ls.c(E.b - 0.125D), z);
        
        if (j > 0)
        {
          f2 = scV * 0.91F;
        }
        
        if (isSticky())
        {
          f2 *= 0.02F * sizeadj;
        }
        else if ((getSizeMultiplier() < 0.5F) && (q.a(x, y, z) == bhcF))
        {

          f2 *= 0.3F * sizeadj;
          isStruggling = true;
        }
        else if ((isTiny()) && (q.a(x, y - 1, z) == aFcF))
        {

          f2 *= sizeadj;
          isStruggling = true;
        }
        else if ((isTiny()) && (q.g(x, y - 1, z) == akc.j))
        {

          f2 *= sizeadj;
        }
        else if ((isTiny()) && (q.a(x, y, z) == cCcF))
        {

          f2 *= 0.4F;
          
          if (isExtraTiny())
          {
            f2 *= 0.5F * sizeadj;
            isStruggling = true;
          }
        }
        else if ((getSizeMultiplier() < 0.5F) && (q.a(x, y, z) == aXcF))
        {

          float depth = 2 * ((q.h(x, y, z) & 0x7) + 1) / 16.0F;
          
          if (depth >= P)
          {
            f2 *= 0.2F;
          }
          else
          {
            f2 *= (1.0F - 0.8F * depth / P);
          }
          
          f2 *= sizeadj;
          isStruggling = true;
        }
        else if ((isTiny()) && (q.g(x, y, z) == akc.E))
        {

          asx axisalignedbb = aqz.s[q.a(x, y, z)].b(q, x, y, z);
          
          if ((axisalignedbb != null) && (axisalignedbb.b(0.0D, 0.1F * getSizeMultiplier(), 0.0D).b(E)))
          {
            f2 *= 0.1F * sizeadj;
            isStruggling = true;
          }
        }
        else if ((getSizeMultiplier() < 1.0F) && (G))
        {

          f2 *= sizeadj;
        }
        else if (tinyWithinPlant)
        {

          f2 *= sizeadj;
          isStruggling = true;
        }
      }
      else if (tinyWithinPlant)
      {

        f2 *= sizeadj;
      }
      
      if ((ladder) || (ladderRate > 0.0F) || ((isSticky()) && (G)))
      {
        float f5 = 0.15F * getSizeMovementMultiplier();
        
        if ((!F) && (getSizeMultiplier() < 1.0F))
        {
          f5 *= sizeadj;
        }
        
        if (isSticky())
        {
          f5 *= 0.5F;
        }
        else if (ladderRate > 0.0F)
        {
          f5 *= ladderRate;
        }
        
        if (this.x < -f5)
        {
          this.x = (-f5);
        }
        
        if (this.x > f5)
        {
          this.x = f5;
        }
        
        if (this.z < -f5)
        {
          this.z = (-f5);
        }
        
        if (this.z > f5)
        {
          this.z = f5;
        }
        
        T = 0.0F;
        float minrate = sizeroot;
        if ((!ladder) && (ladderRate > 0.0F))
        {
          minrate *= ladderRate;
        }
        
        if (this.y < -0.15D * minrate)
        {
          this.y = (-0.15D * minrate);
        }
        
        boolean flag = (ah()) && ((this instanceof uf));
        
        if ((flag) && (this.y < 0.0D))
        {
          if ((ladder) || (isSticky()))
          {
            this.y = 0.0D;
          }
          else
          {
            this.y *= sizeroot;
          }
        }
        
        if (isSticky())
        {
          this.y *= sizeroot;
          
          if (!G)
          {
            this.y *= 0.5D;
          }
        }
      }
      
      if (isGliding())
      {
        if (this.y < 0.0625D + 0.1D * getSizeMultiplier())
        {
          if (this.y < 0.0D)
          {
            this.y = 0.0D;
          }
          
          double draft = GulliverEnvoy.getRisingUpdraft(this) - 0.1D * getSizeMultiplier();
          
          if (draft > 0.0625D)
          {
            draft = 0.0625D;
          }
          
          this.y += draft;
          
          if (this.y < -0.1D * getSizeMultiplier())
          {
            this.y = (-0.1D * getSizeMultiplier());
          }
        }
        
        T = 0.0F;
      }
      else if ((!ladder) && (tinyWithinPlant))
      {
        this.y *= (isExtraTiny() ? 0.95D : 0.99D);
        if (this.y < -0.2D * sizeroot)
        {
          this.y = (-0.2D * sizeroot);
        }
        T *= 0.8F;
      }
      
      d(this.x, this.y, this.z);
      
      if ((G) && (!seated) && ((ladder) || (isSticky())))
      {
        this.y = (0.08D + 0.12000000000000001D * sizeroot * (isSticky() ? 1.0F : ladderRate));
      }
      
      if ((q.I) && ((!q.f((int)u, 0, (int)w)) || (!q.d((int)u, (int)w).d)))
      {
        if (v > 0.0D)
        {
          this.y = -0.1D;
        }
        else
        {
          this.y = 0.0D;
        }
        
      }
      else {
        this.y -= 0.08D;
      }
      
      this.y *= 0.9800000190734863D;
      this.x *= f2;
      this.z *= f2;
    }
    
    aF = aG;
    double d0 = u - r;
    double d1 = w - t;
    float f6 = ls.a(d0 * d0 + d1 * d1) * 4.0F / getSizeMovementMultiplier();
    
    if (f6 > 1.0F)
    {
      f6 = 1.0F;
    }
    
    aG += (f6 - aG) * 0.4F;
    aH += aG;
  }
  



  protected boolean bf()
  {
    return false;
  }
  



  public float bg()
  {
    return bf() ? bp : 0.1F;
  }
  



  public void i(float par1)
  {
    bp = par1;
  }
  
  public boolean m(nn par1Entity)
  {
    k(par1Entity);
    return false;
  }
  



  public boolean bh()
  {
    return false;
  }
  



  public boolean isGliding()
  {
    return isGlidingFlag;
  }
  



  public boolean doesUmbrella()
  {
    return couldUseUmbrella;
  }
  



  public boolean isRafting()
  {
    return isRaftingFlag;
  }
  



  public boolean isSticky()
  {
    ye itemstack = aZ();
    return (isTiny()) && (((itemstack != null) && (d == aOcv)) || (GulliverEnvoy.alongStickySurface(this)) || (!q.a(ts.class, E).isEmpty()));
  }
  



  public boolean inRisingUpdraft()
  {
    return GulliverEnvoy.getRisingUpdraft(this) > 0.0D;
  }
  
  public void updateResizingFlags()
  {
    isGlidingFlag = false;
    isRaftingFlag = false;
    couldUseUmbrella = false;
    isStruggling = false;
  }
  



  public void l_()
  {
    if (ForgeHooks.onLivingUpdate(this))
    {
      return;
    }
    
    double mx = x;
    double mz = z;
    
    super.l_();
    

    updateResizingFlags();
    
    if (H())
    {
      float f = 1.0F;
      
      if ((F) || (I))
      {
        if (isHuge())
        {
          f = 0.0F;
        }
        else if (getSizeMultiplierRoot() < 1.0F)
        {
          f = getSizeMultiplierRoot();
        }
      }
      
      x = ((x - mx) * f + mx);
      z = ((z - mz) * f + mz);
    }
    
    if (!q.I)
    {
      int i = aU();
      
      if (i > 0)
      {
        if (aw <= 0)
        {
          aw = (20 * (30 - i));
        }
        
        aw -= 1;
        
        if (aw <= 0)
        {
          m(i - 1);
        }
      }
      
      for (int j = 0; j < 5; j++)
      {
        ye itemstack = g[j];
        ye itemstack1 = n(j);
        
        if (!ye.b(itemstack1, itemstack))
        {
          ((js)q).q().a(this, new fq(k, j, itemstack1));
          
          if (itemstack != null)
          {
            d.a(itemstack.D());
          }
          
          if (itemstack1 != null)
          {
            d.b(itemstack1.D());
          }
          
          g[j] = (itemstack1 == null ? null : itemstack1.m());
        }
      }
    }
    
    c();
    double d0 = u - r;
    double d1 = w - t;
    float f = (float)(d0 * d0 + d1 * d1);
    float f1 = aN;
    float f2 = 0.0F;
    aW = aX;
    float f3 = 0.0F;
    
    if (f > 0.0025000002F * getSizeMovementMultiplier() * getSizeMovementMultiplier() * (isStruggling ? getSizeMultiplier() : 1.0F))
    {
      f3 = 1.0F;
      f2 = (float)Math.sqrt(f) * 3.0F;
      f1 = (float)Math.atan2(d1, d0) * 180.0F / 3.1415927F - 90.0F;
    }
    
    if (aE > 0.0F)
    {
      f1 = A;
    }
    
    if (!F)
    {
      f3 = 0.0F;
    }
    
    aX += (f3 - aX) * 0.3F;
    q.C.a("headTurn");
    f2 = f(f1, f2);
    q.C.b();
    q.C.a("rangeChecks");
    
    while (A - C < -180.0F)
    {
      C -= 360.0F;
    }
    
    while (A - C >= 180.0F)
    {
      C += 360.0F;
    }
    
    while (aN - aO < -180.0F)
    {
      aO -= 360.0F;
    }
    
    while (aN - aO >= 180.0F)
    {
      aO += 360.0F;
    }
    
    while (B - D < -180.0F)
    {
      D -= 360.0F;
    }
    
    while (B - D >= 180.0F)
    {
      D += 360.0F;
    }
    
    while (aP - aQ < -180.0F)
    {
      aQ -= 360.0F;
    }
    
    while (aP - aQ >= 180.0F)
    {
      aQ += 360.0F;
    }
    
    q.C.b();
    aY += f2;
  }
  
  protected float f(float par1, float par2)
  {
    float f2 = ls.g(par1 - aN);
    aN += f2 * 0.3F;
    float f3 = ls.g(A - aN);
    boolean flag = (f3 < -90.0F) || (f3 >= 90.0F);
    
    if (f3 < -75.0F)
    {
      f3 = -75.0F;
    }
    
    if (f3 >= 75.0F)
    {
      f3 = 75.0F;
    }
    
    aN = (A - f3);
    
    if (f3 * f3 > 2500.0F)
    {
      aN += f3 * 0.2F;
    }
    
    if (flag)
    {
      par2 *= -1.0F;
    }
    
    return par2;
  }
  
  public float maxRiderWidth(nn par1Entity)
  {
    return O * (g_() ? 1.0F : 1.2F);
  }
  



  public void a(float par1, float par2)
  {
    normalWidth = par1;
    normalHeight = par2;
    super.a(par1 * getSizeMultiplier(), par2 * getSizeMultiplier());
  }
  




  public void c()
  {
    float sizemult = getSizeMultiplier();
    float sizeroot = getSizeMultiplierRoot();
    isStruggling = isSticky();
    
    if (bq > 0)
    {
      bq -= 1;
    }
    
    if (bh > 0)
    {
      double d0 = u + (bi - u) / bh;
      double d1 = v + (bj - v) / bh;
      double d2 = w + (bk - w) / bh;
      double d3 = ls.g(bl - A);
      A = ((float)(A + d3 / bh));
      B = ((float)(B + (bm - B) / bh));
      bh -= 1;
      b(d0, d1, d2);
      b(A, B);
    }
    else if (!bm())
    {
      x *= 0.98D;
      y *= 0.98D;
      z *= 0.98D;
    }
    
    double threshold = sizemult == 1.0F ? 0.005D : 0.005D * sizemult;
    if (Math.abs(x) < threshold)
    {
      x = 0.0D;
    }
    
    if (Math.abs(y) < threshold)
    {
      y = 0.0D;
    }
    
    if (Math.abs(z) < threshold)
    {
      z = 0.0D;
    }
    
    q.C.a("ai");
    
    if (bc())
    {
      bd = false;
      be = 0.0F;
      bf = 0.0F;
      bg = 0.0F;
    }
    else if (bm())
    {
      if (bf())
      {
        q.C.a("newAi");
        bi();
        q.C.b();
      }
      else
      {
        q.C.a("oldAi");
        bl();
        q.C.b();
        aP = A;
      }
    }
    
    q.C.b();
    q.C.a("jump");
    
    if (H())
    {
      if ((F) || (I))
      {
        if (isSticky())
        {
          x = 0.0D;
          z = 0.0D;
          
          if ((G) && (!bd))
          {
            y += 0.03999999910593033D * (sizeroot * 0.75F);
          }
        }
      }
      
      if (isRafting())
      {

        int i = 3;
        double da = 0.0D;
        
        for (int j = 0; j < i; j++)
        {
          double d2a = E.b + (E.e - E.b) * (j + 0) / i + 0.23D * sizeroot;
          double d8a = E.b + (E.e - E.b) * (j + 1) / i + 0.23D * sizeroot;
          asx axisalignedbb = asx.a().a(E.a, d2a, E.c, E.d, d8a, E.f);
          
          if (q.b(axisalignedbb, akc.h))
          {
            da += 1.0D / i;
          }
        }
        
        double d1a = Math.sqrt(x * x + z * z);
        
        if (d1a > 0.15D * sizemult)
        {
          double d3a = Math.cos(A * 3.141592653589793D / 180.0D) * sizemult;
          double d9a = Math.sin(A * 3.141592653589793D / 180.0D) * sizemult;
          
          for (int i1 = 0; i1 < 1.0D + d1a * 60.0D * sizemult; i1++)
          {
            double d16a = ab.nextFloat() * 2.0F - 1.0F;
            double d19a = (ab.nextInt(2) * 2 - 1) * 0.7D * sizemult;
            
            if (ab.nextBoolean())
            {
              double d21a = u - d3a * d16a * 0.8D + d9a * d19a;
              double d23a = w - d9a * d16a * 0.8D - d3a * d19a;
              q.a("splash", d21a, v - 0.125D * sizemult, d23a, x, y, z);
            }
            else
            {
              double d22a = u + d3a + d9a * d16a * 0.7D;
              double d24a = w + d9a - d3a * d16a * 0.7D;
              q.a("splash", d22a, v - 0.125D * sizemult, d24a, x, y, z);
            }
          }
        }
        
        if (da < 1.0D)
        {
          double d6a = da * 2.0D - 1.0D;
          y += 0.03999999910593033D * d6a;
        }
        else
        {
          if (y < 0.0D)
          {
            y *= 0.4D;
          }
          
          y += 0.007000000216066837D;
        }
        
        if (G)
        {
          y += 0.03999999910593033D;
        }
        if (bd)
        {
          y += 0.03999999910593033D * sizeroot;
        }
      }
    }
    
    if (bd)
    {
      if ((!H()) && (!J()))
      {
        if ((F) && (bq == 0))
        {
          be();
          bq = 10;
        }
        else if ((isTiny()) && (e()) && (bq == 0))
        {
          be();
          y *= sizeroot;
          bq = 10;
        }
        
      }
      else {
        y += 0.03999999910593033D * sizeroot;
      }
      
    }
    else {
      bq = 0;
    }
    
    q.C.b();
    q.C.a("travel");
    be *= 0.98F;
    bf *= 0.98F;
    bg *= 0.9F;
    e(be, bf);
    q.C.b();
    q.C.a("push");
    
    if (!q.I)
    {
      bj();
    }
    
    q.C.b();
    
    q.C.a("resizing");
    
    if (!q.I)
    {
      refreshSizeDestMultiplier();
      if (sizeRate != 0.0F)
      {
        if (((sizeRate > 0.0F) && (getSizeMultiplier() + sizeRate > sizeDestMultiplier)) || ((sizeRate < 0.0F) && (getSizeMultiplier() + sizeRate < sizeDestMultiplier)))
        {

          doWalkingResize(sizeDestMultiplier, true);
          sizeRate = 0.0F;
        }
        else
        {
          doWalkingResize(getSizeMultiplier() + sizeRate, true);
        }
      }
    }
    
    q.C.b();
  }
  
  protected void bi() {}
  
  protected void bj()
  {
    double border = getSizeMultiplier() >= 1.0F ? 1.0D : getSizeMultiplier();
    List list = q.b(this, E.b(0.20000000298023224D * border, 0.0D, 0.20000000298023224D * border));
    
    if ((list != null) && (!list.isEmpty()))
    {
      for (int i = 0; i < list.size(); i++)
      {
        nn entity = (nn)list.get(i);
        
        if (collideableRideEntity(entity))
        {

          if ((!q.I) && (T > P * 0.5F) && ((!ah()) || (T > getAdjStepHeight() * 2.2F)) && (canSquish(entity)))
          {
            entity.a(new EntityDamageSourcePassive("squish", this), ls.d((T > 1.0F ? T : 1.0F) * 2.0F * getSizeMultiplierRoot() / entity.getSizeMultiplierRoot()));
          }
          

          asx bb1 = getEntityCollisionBox();
          asx bb2 = entity.getEntityCollisionBox();
          
          if ((bb1.b(bb2)) && ((!q.I) || (isTinierThan(entity))))
          {
            n(entity);
          }
        }
      }
    }
  }
  
  public boolean cannotEquipItemOrArmor(int par1, ye par2ItemStack)
  {
    if (par1 == 0)
    {
      return false;
    }
    
    if ((isHuge()) || (isTiny()))
    {


      if (par2ItemStack != null)
      {
        if (!(par2ItemStack.b() instanceof wh))
        {
          if ((par1 == 4) && ((par2ItemStack.b() instanceof zb)))
          {


            return false;
          }
          

          return true;
        }
        
        if ((isHuge()) && ((par1 != 2) || (((wh)par2ItemStack.b()).d().a(4 - par1) >= yc.ap.d().a(4 - par1))))
        {

          return true;
        }
        
        if ((isTiny()) && (par1 < 4) && (((wh)par2ItemStack.b()).d().a(4 - par1) >= yc.ae.d().a(4 - par1)))
        {

          return true;
        }
        
        return false;
      }
    }
    
    return false;
  }
  
  protected void n(nn par1Entity)
  {
    par1Entity.f(this);
  }
  
  public void W()
  {
    if (O * 2.5F < P)
    {

      if (n.O < O * 0.4F)
      {

        double d = Math.cos(aN * 3.141592653589793D / 180.0D) * O * (g_() ? 0.8D : 0.7D);
        double d1 = Math.sin(aN * 3.141592653589793D / 180.0D) * O * (g_() ? 0.8D : 0.7D);
        
        n.b(u + d, v - N + Y() + n.X(), w + d1);
      }
      else if (n.O * 2.5F >= n.P)
      {

        n.b(u, v - N + Y() * 1.45D + n.X(), w);

      }
      else
      {
        double d = Math.cos((aN - 90.0F) * 3.141592653589793D / 180.0D) * O * (g_() ? 0.7D : 0.6D);
        double d1 = Math.sin((aN - 90.0F) * 3.141592653589793D / 180.0D) * O * (g_() ? 0.7D : 0.6D);
        
        n.b(u + d, v - N + Y() + n.X() - n.P * 0.1F, w + d1);
      }
      
    }
    else {
      n.b(u, v - N + Y() + n.X(), w);
    }
  }
  
  public boolean isEntityHoldingOn()
  {
    return (isSticky()) || (((this instanceof ts)) && (isSlimy)) || ((isTiny()) && (aZ() != null) && (aZd == Mcv)) || ((!isTiny()) && (!isHuge()) && (aZ() != null) && (aZd == chcv));
  }
  

  public void updateHeldPosition()
  {
    double d = Math.cos(aN * 3.141592653589793D / 180.0D) * O * -0.375D + Math.cos((aN - 90.0F) * 3.141592653589793D / 180.0D) * O * -0.85D;
    double d1 = Math.sin(aN * 3.141592653589793D / 180.0D) * O * -0.375D + Math.sin((aN - 90.0F) * 3.141592653589793D / 180.0D) * O * -0.85D;
    double dy = heldEntity.N - N + getHeldYOffset() - heldEntity.P * (O * 2.5F >= P ? 1.2D : 0.5D);
    
    if (aG >= 0.01F)
    {
      dy += Math.cos((aH - aG) * 0.6662F) * 0.03D * P;
    }
    
    heldEntity.b(u + d, v + dy, w + d1);
  }
  
  public void positionHeldForDrop(nn par1Entity)
  {
    double d = Math.cos(A * 3.141592653589793D / 180.0D) * O * -0.375D + Math.cos((aN - 90.0F) * 3.141592653589793D / 180.0D) * O * -0.85D;
    double d1 = Math.sin(A * 3.141592653589793D / 180.0D) * O * -0.375D + Math.sin((aN - 90.0F) * 3.141592653589793D / 180.0D) * O * -0.85D;
    double dy = N - N + getHeldYOffset() * (ah() ? 0.5D : 1.0D) - P;
    N = 0.0F;
    par1Entity.b(u + d, v + dy, w + d1, A, B);
  }
  
  public void throwHeldEntity(nn par1Entity)
  {
    dropHeldEntity(par1Entity);
    
    if (par1Entity != null)
    {

      float psize = getSizeMultiplier();
      par1Entity.b(u, v + f(), w, A, B);
      u -= ls.b(A / 180.0F * 3.1415927F) * 0.16F * psize;
      v -= 0.10000000149011612D * psize;
      w -= ls.a(A / 180.0F * 3.1415927F) * 0.16F * psize;
      par1Entity.b(u, v, w);
      N = 0.0F;
      float var3 = 1.6F * getSizeMultiplierRoot();
      x = (-ls.a(A / 180.0F * 3.1415927F) * ls.b(B / 180.0F * 3.1415927F) * var3);
      z = (ls.b(A / 180.0F * 3.1415927F) * ls.b(B / 180.0F * 3.1415927F) * var3);
      y = (-ls.a((B + 0.0F) / 180.0F * 3.1415927F) * var3);
      
      if ((par1Entity instanceof jv))
      {
        jv toy = (jv)par1Entity;
        a.a(u, v, w, A, B);
        a.b(new fp(k, x, y, z));
      }
    }
  }
  



  public void V()
  {
    super.V();
    aW = aX;
    aX = 0.0F;
    T = 0.0F;
  }
  



  public double Y()
  {
    if (!g_())
    {
      return P * 0.7D;
    }
    

    return P * 0.5D;
  }
  




  public boolean getSaddled()
  {
    return false;
  }
  



  public asx getEntityCollisionBox()
  {
    asx bb = super.getEntityCollisionBox();
    

    if (O * 2.5F < P)
    {

      b += P * (!ah() ? 0.3D : 0.1D);

    }
    else
    {
      b += P * 0.4D;
    }
    
    return bb;
  }
  



  public asx getEntityHitBox()
  {
    asx bb = super.getEntityHitBox();
    

    if ((O != P) && (O * 2.5F >= P))
    {

      b += P * 0.4D;
    }
    
    return bb;
  }
  





  @SideOnly(Side.CLIENT)
  public void a(double par1, double par3, double par5, float par7, float par8, int par9)
  {
    N = 0.0F;
    bi = par1;
    bj = par3;
    bk = par5;
    bl = par7;
    bm = par8;
    bh = par9;
  }
  


  protected void bk() {}
  

  protected void bl()
  {
    aV += 1;
  }
  
  public void f(boolean par1)
  {
    bd = par1;
  }
  



  public void a(nn par1Entity, int par2)
  {
    if ((!M) && (!q.I))
    {
      jm entitytracker = ((js)q).q();
      
      if ((par1Entity instanceof ss))
      {
        entitytracker.a(par1Entity, new ga(k, k));
      }
      
      if ((par1Entity instanceof uh))
      {
        entitytracker.a(par1Entity, new ga(k, k));
      }
      
      if ((par1Entity instanceof oa))
      {
        entitytracker.a(par1Entity, new ga(k, k));
      }
    }
  }
  



  public boolean o(nn par1Entity)
  {
    return q.a(q.V().a(u, v + f(), w), q.V().a(u, v + par1Entity.f(), w)) == null;
  }
  



  public atc aa()
  {
    return j(1.0F);
  }
  








  public atc j(float par1)
  {
    if (par1 == 1.0F)
    {
      float f1 = ls.b(-A * 0.017453292F - 3.1415927F);
      float f2 = ls.a(-A * 0.017453292F - 3.1415927F);
      float f3 = -ls.b(-B * 0.017453292F);
      float f4 = ls.a(-B * 0.017453292F);
      return q.V().a(f2 * f3, f4, f1 * f3);
    }
    

    float f1 = D + (B - D) * par1;
    float f2 = C + (A - C) * par1;
    float f3 = ls.b(-f2 * 0.017453292F - 3.1415927F);
    float f4 = ls.a(-f2 * 0.017453292F - 3.1415927F);
    float f5 = -ls.b(-f1 * 0.017453292F);
    float f6 = ls.a(-f1 * 0.017453292F);
    return q.V().a(f4 * f5, f6, f3 * f5);
  }
  





  @SideOnly(Side.CLIENT)
  public float k(float par1)
  {
    float f1 = aE - aD;
    
    if (f1 < 0.0F)
    {
      f1 += 1.0F;
    }
    
    return aD + f1 * par1;
  }
  




  @SideOnly(Side.CLIENT)
  public atc l(float par1)
  {
    if (par1 == 1.0F)
    {
      return q.V().a(u, v, w);
    }
    

    double d0 = r + (u - r) * par1;
    double d1 = s + (v - s) * par1;
    double d2 = t + (w - t) * par1;
    return q.V().a(d0, d1, d2);
  }
  





  @SideOnly(Side.CLIENT)
  public ata a(double par1, float par3)
  {
    atc vec3 = l(par3);
    atc vec31 = j(par3);
    atc vec32 = vec3.c(c * par1, d * par1, e * par1);
    return q.a(vec3, vec32);
  }
  



  public boolean bm()
  {
    return !q.I;
  }
  



  public boolean L()
  {
    return !M;
  }
  



  public boolean M()
  {
    return !M;
  }
  
  public float f()
  {
    return P * 0.85F;
  }
  



  protected void K()
  {
    J = (ab.nextDouble() >= a(tp.c).e());
  }
  
  public float ap()
  {
    return aP;
  }
  




  @SideOnly(Side.CLIENT)
  public void e(float par1)
  {
    aP = par1;
  }
  
  public float bn()
  {
    return br;
  }
  
  public void m(float par1)
  {
    if (par1 < 0.0F)
    {
      par1 = 0.0F;
    }
    
    br = par1;
  }
  
  public atl bo()
  {
    return null;
  }
  
  public boolean c(of par1EntityLivingBase)
  {
    return a(par1EntityLivingBase.bo());
  }
  



  public boolean a(atl par1Team)
  {
    return bo() != null ? bo().a(par1Team) : false;
  }
  




  public void curePotionEffects(ye curativeItem)
  {
    Iterator<Integer> potionKey = f.keySet().iterator();
    
    if (q.I)
    {
      return;
    }
    
    while (potionKey.hasNext())
    {
      Integer key = (Integer)potionKey.next();
      nj effect = (nj)f.get(key);
      
      if (effect.isCurativeItem(curativeItem))
      {
        potionKey.remove();
        b(effect);
      }
    }
  }
  







  public boolean shouldRiderFaceForward(uf player)
  {
    return this instanceof ry;
  }
}
