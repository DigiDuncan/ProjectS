import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import gulliver.common.GulliverOMHelper;
import java.util.List;
import java.util.Random;
import net.minecraftforge.common.ForgeDirection;

















public abstract class anf
  extends aqz
{
  protected boolean a;
  
  protected anf(int par1, boolean par2)
  {
    super(par1, akc.q);
    b(true);
    a(ww.d);
    a = par2;
  }
  




  public asx b(abw par1World, int par2, int par3, int par4)
  {
    return null;
  }
  



  public int a(abw par1World)
  {
    return a ? 30 : 20;
  }
  




  public boolean c()
  {
    return false;
  }
  



  public boolean b()
  {
    return false;
  }
  



  public boolean c(abw par1World, int par2, int par3, int par4, int par5)
  {
    ForgeDirection dir = ForgeDirection.getOrientation(par5);
    return ((dir == ForgeDirection.NORTH) && (par1World.isBlockSolidOnSide(par2, par3, par4 + 1, ForgeDirection.NORTH))) || ((dir == ForgeDirection.SOUTH) && (par1World.isBlockSolidOnSide(par2, par3, par4 - 1, ForgeDirection.SOUTH))) || ((dir == ForgeDirection.WEST) && (par1World.isBlockSolidOnSide(par2 + 1, par3, par4, ForgeDirection.WEST))) || ((dir == ForgeDirection.EAST) && (par1World.isBlockSolidOnSide(par2 - 1, par3, par4, ForgeDirection.EAST)));
  }
  






  public boolean c(abw par1World, int par2, int par3, int par4)
  {
    return (par1World.isBlockSolidOnSide(par2 - 1, par3, par4, ForgeDirection.EAST)) || (par1World.isBlockSolidOnSide(par2 + 1, par3, par4, ForgeDirection.WEST)) || (par1World.isBlockSolidOnSide(par2, par3, par4 - 1, ForgeDirection.SOUTH)) || (par1World.isBlockSolidOnSide(par2, par3, par4 + 1, ForgeDirection.NORTH));
  }
  






  public int a(abw par1World, int par2, int par3, int par4, int par5, float par6, float par7, float par8, int par9)
  {
    int j1 = par1World.h(par2, par3, par4);
    int k1 = j1 & 0x8;
    j1 &= 0x7;
    

    ForgeDirection dir = ForgeDirection.getOrientation(par5);
    
    if ((dir == ForgeDirection.NORTH) && (par1World.isBlockSolidOnSide(par2, par3, par4 + 1, ForgeDirection.NORTH)))
    {
      j1 = 4;
    }
    else if ((dir == ForgeDirection.SOUTH) && (par1World.isBlockSolidOnSide(par2, par3, par4 - 1, ForgeDirection.SOUTH)))
    {
      j1 = 3;
    }
    else if ((dir == ForgeDirection.WEST) && (par1World.isBlockSolidOnSide(par2 + 1, par3, par4, ForgeDirection.WEST)))
    {
      j1 = 2;
    }
    else if ((dir == ForgeDirection.EAST) && (par1World.isBlockSolidOnSide(par2 - 1, par3, par4, ForgeDirection.EAST)))
    {
      j1 = 1;
    }
    else
    {
      j1 = k(par1World, par2, par3, par4);
    }
    
    return j1 + k1;
  }
  



  private int k(abw par1World, int par2, int par3, int par4)
  {
    if (par1World.isBlockSolidOnSide(par2 - 1, par3, par4, ForgeDirection.EAST)) return 1;
    if (par1World.isBlockSolidOnSide(par2 + 1, par3, par4, ForgeDirection.WEST)) return 2;
    if (par1World.isBlockSolidOnSide(par2, par3, par4 - 1, ForgeDirection.SOUTH)) return 3;
    if (par1World.isBlockSolidOnSide(par2, par3, par4 + 1, ForgeDirection.NORTH)) return 4;
    return 1;
  }
  




  public void a(abw par1World, int par2, int par3, int par4, int par5)
  {
    if (m(par1World, par2, par3, par4))
    {
      int i1 = par1World.h(par2, par3, par4) & 0x7;
      boolean flag = false;
      
      if ((!par1World.isBlockSolidOnSide(par2 - 1, par3, par4, ForgeDirection.EAST)) && (i1 == 1))
      {
        flag = true;
      }
      
      if ((!par1World.isBlockSolidOnSide(par2 + 1, par3, par4, ForgeDirection.WEST)) && (i1 == 2))
      {
        flag = true;
      }
      
      if ((!par1World.isBlockSolidOnSide(par2, par3, par4 - 1, ForgeDirection.SOUTH)) && (i1 == 3))
      {
        flag = true;
      }
      
      if ((!par1World.isBlockSolidOnSide(par2, par3, par4 + 1, ForgeDirection.NORTH)) && (i1 == 4))
      {
        flag = true;
      }
      
      if (flag)
      {
        c(par1World, par2, par3, par4, par1World.h(par2, par3, par4), 0);
        par1World.i(par2, par3, par4);
      }
    }
  }
  



  private boolean m(abw par1World, int par2, int par3, int par4)
  {
    if (!c(par1World, par2, par3, par4))
    {
      c(par1World, par2, par3, par4, par1World.h(par2, par3, par4), 0);
      par1World.i(par2, par3, par4);
      return false;
    }
    

    return true;
  }
  




  public void a(acf par1IBlockAccess, int par2, int par3, int par4)
  {
    int l = par1IBlockAccess.h(par2, par3, par4);
    d(l);
  }
  
  private void d(int par1)
  {
    int j = par1 & 0x7;
    boolean flag = (par1 & 0x8) > 0;
    float f = 0.375F;
    float f1 = 0.625F;
    float f2 = 0.1875F;
    float f3 = 0.125F;
    
    if (flag)
    {
      f3 = 0.0625F;
    }
    
    if (j == 1)
    {
      a(0.0F, f, 0.5F - f2, f3, f1, 0.5F + f2);
    }
    else if (j == 2)
    {
      a(1.0F - f3, f, 0.5F - f2, 1.0F, f1, 0.5F + f2);
    }
    else if (j == 3)
    {
      a(0.5F - f2, f, 0.0F, 0.5F + f2, f1, f3);
    }
    else if (j == 4)
    {
      a(0.5F - f2, f, 1.0F - f3, 0.5F + f2, f1, 1.0F);
    }
  }
  




  public void a(abw par1World, int par2, int par3, int par4, asx par5AxisAlignedBB, List par6List, nn par7Entity)
  {
    int var5 = par1World.h(par2, par3, par4);
    
    if ((var5 & 0x8) == 0)
    {
      d(var5);
      
      if ((par7Entity != null) && ((par7Entity instanceof of)) && (par7Entity.isTiny()) && (!GulliverOMHelper.isLittleBlocksWorld(par1World)))
      {
        asx var8 = asx.a().a(par2 + cM, par3 + cN, par4 + cO, par2 + cP, par3 + cQ, par4 + cR);
        
        if ((var8 != null) && (par5AxisAlignedBB.b(var8)))
        {
          par6List.add(var8);
        }
      }
    }
  }
  



  public void a(abw par1World, int par2, int par3, int par4, uf par5EntityPlayer) {}
  



  public boolean a(abw par1World, int par2, int par3, int par4, uf par5EntityPlayer, int par6, float par7, float par8, float par9)
  {
    int i1 = par1World.h(par2, par3, par4);
    int j1 = i1 & 0x7;
    int k1 = 8 - (i1 & 0x8);
    
    if (k1 == 0)
    {
      return true;
    }
    

    par1World.b(par2, par3, par4, j1 + k1, 3);
    par1World.g(par2, par3, par4, par2, par3, par4);
    par1World.a(par2 + 0.5D, par3 + 0.5D, par4 + 0.5D, "random.click", 0.3F, 0.6F);
    d(par1World, par2, par3, par4, j1);
    par1World.a(par2, par3, par4, cF, a(par1World));
    return true;
  }
  






  public void a(abw par1World, int par2, int par3, int par4, int par5, int par6)
  {
    if ((par6 & 0x8) > 0)
    {
      int j1 = par6 & 0x7;
      d(par1World, par2, par3, par4, j1);
    }
    
    super.a(par1World, par2, par3, par4, par5, par6);
  }
  





  public int b(acf par1IBlockAccess, int par2, int par3, int par4, int par5)
  {
    return (par1IBlockAccess.h(par2, par3, par4) & 0x8) > 0 ? 15 : 0;
  }
  




  public int c(acf par1IBlockAccess, int par2, int par3, int par4, int par5)
  {
    int i1 = par1IBlockAccess.h(par2, par3, par4);
    
    if ((i1 & 0x8) == 0)
    {
      return 0;
    }
    

    int j1 = i1 & 0x7;
    return (j1 == 1) && (par5 == 5) ? 15 : (j1 == 2) && (par5 == 4) ? 15 : (j1 == 3) && (par5 == 3) ? 15 : (j1 == 4) && (par5 == 2) ? 15 : (j1 == 5) && (par5 == 1) ? 15 : 0;
  }
  




  public boolean f()
  {
    return true;
  }
  



  public void a(abw par1World, int par2, int par3, int par4, Random par5Random)
  {
    if (!I)
    {
      int l = par1World.h(par2, par3, par4);
      
      if ((l & 0x8) != 0)
      {
        if (a)
        {
          n(par1World, par2, par3, par4);
        }
        else
        {
          par1World.b(par2, par3, par4, l & 0x7, 3);
          int i1 = l & 0x7;
          d(par1World, par2, par3, par4, i1);
          par1World.a(par2 + 0.5D, par3 + 0.5D, par4 + 0.5D, "random.click", 0.3F, 0.5F);
          par1World.g(par2, par3, par4, par2, par3, par4);
        }
      }
    }
  }
  



  public void g()
  {
    float f = 0.1875F;
    float f1 = 0.125F;
    float f2 = 0.125F;
    a(0.5F - f, 0.5F - f1, 0.5F - f2, 0.5F + f, 0.5F + f1, 0.5F + f2);
  }
  



  public void a(abw par1World, int par2, int par3, int par4, nn par5Entity)
  {
    if (!I)
    {
      if (a)
      {
        if ((par1World.h(par2, par3, par4) & 0x8) == 0)
        {
          n(par1World, par2, par3, par4);
        }
      }
    }
  }
  
  protected void n(abw par1World, int par2, int par3, int par4)
  {
    int l = par1World.h(par2, par3, par4);
    int i1 = l & 0x7;
    boolean flag = (l & 0x8) != 0;
    d(l);
    List list = par1World.a(uh.class, asx.a().a(par2 + cM, par3 + cN, par4 + cO, par2 + cP, par3 + cQ, par4 + cR));
    boolean flag1 = !list.isEmpty();
    
    if ((flag1) && (!flag))
    {
      par1World.b(par2, par3, par4, i1 | 0x8, 3);
      d(par1World, par2, par3, par4, i1);
      par1World.g(par2, par3, par4, par2, par3, par4);
      par1World.a(par2 + 0.5D, par3 + 0.5D, par4 + 0.5D, "random.click", 0.3F, 0.6F);
    }
    
    if ((!flag1) && (flag))
    {
      par1World.b(par2, par3, par4, i1, 3);
      d(par1World, par2, par3, par4, i1);
      par1World.g(par2, par3, par4, par2, par3, par4);
      par1World.a(par2 + 0.5D, par3 + 0.5D, par4 + 0.5D, "random.click", 0.3F, 0.5F);
    }
    
    if (flag1)
    {
      par1World.a(par2, par3, par4, cF, a(par1World));
    }
  }
  
  private void d(abw par1World, int par2, int par3, int par4, int par5)
  {
    par1World.f(par2, par3, par4, cF);
    
    if (par5 == 1)
    {
      par1World.f(par2 - 1, par3, par4, cF);
    }
    else if (par5 == 2)
    {
      par1World.f(par2 + 1, par3, par4, cF);
    }
    else if (par5 == 3)
    {
      par1World.f(par2, par3, par4 - 1, cF);
    }
    else if (par5 == 4)
    {
      par1World.f(par2, par3, par4 + 1, cF);
    }
    else
    {
      par1World.f(par2, par3 - 1, par4, cF);
    }
  }
  
  @SideOnly(Side.CLIENT)
  public void a(mt par1IconRegister) {}
}
