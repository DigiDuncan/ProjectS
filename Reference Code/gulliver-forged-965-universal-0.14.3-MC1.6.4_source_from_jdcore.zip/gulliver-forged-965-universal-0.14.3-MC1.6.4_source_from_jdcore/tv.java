import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import gulliver.potion.PotionResizing;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.UUID;























public class tv
  extends tm
  implements to
{
  private static final UUID bp = UUID.fromString("5CD17E52-A79A-43D3-A529-90FDE04B181E");
  private static final ot bq = new ot(bp, "Drinking speed penalty", -0.25D, 0).a(false);
  

  private static final int[] br = { aVcv, bacv, aEcv, bwcv, bvcv, Ocv, Fcv, Fcv };
  


  private int bs;
  


  public tv(abw par1World)
  {
    super(par1World);
    minLookSize = 0.15F;
    maxLookSize = 0.0F;
    minTargetSize = 0.1F;
    maxTargetSize = 0.0F;
    c.a(1, new pp(this));
    c.a(2, new qn(this, 1.0D, 60, 10.0F));
    c.a(2, new qm(this, 1.0D));
    c.a(3, new px(this, uf.class, 8.0F));
    c.a(3, new ql(this));
    d.a(1, new qx(this, false));
    d.a(2, new qy(this, uf.class, 0, true));
  }
  
  protected void a()
  {
    super.a();
    v().a(21, Byte.valueOf((byte)0));
  }
  



  protected String r()
  {
    return "mob.witch.idle";
  }
  



  protected String aO()
  {
    return "mob.witch.hurt";
  }
  



  protected String aP()
  {
    return "mob.witch.death";
  }
  



  public void a(boolean par1)
  {
    v().b(21, Byte.valueOf((byte)(par1 ? 1 : 0)));
  }
  



  public boolean bT()
  {
    return v().a(21) == 1;
  }
  
  protected void az()
  {
    super.az();
    a(tp.a).a(26.0D);
    a(tp.d).a(0.25D);
  }
  



  public boolean bf()
  {
    return true;
  }
  




  public void c()
  {
    if (!q.I)
    {
      if (bT())
      {
        if (bs-- <= 0)
        {
          a(false);
          ye itemstack = aZ();
          c(0, (ye)null);
          
          if ((itemstack != null) && (d == bucv))
          {
            List list = yc.bu.g(itemstack);
            
            if (list != null)
            {
              Iterator iterator = list.iterator();
              
              while (iterator.hasNext())
              {
                nj potioneffect = (nj)iterator.next();
                c(new nj(potioneffect));
              }
            }
          }
          
          a(tp.d).b(bq);
        }
      }
      else
      {
        short short1 = -1;
        
        if ((ab.nextFloat() < 0.15F) && (af()) && (!a(ni.n)))
        {
          short1 = 16307;
        }
        else if ((ab.nextFloat() < 0.05F) && (aN() < aT()))
        {
          short1 = 16341;
        }
        else if ((ab.nextFloat() < 0.1F) && (!a(PotionResizing.tiny)) && (((isHuge()) && (sizeRate == 0.0F)) || ((U()) && (!q.u(ls.c(u), ls.c(v), ls.c(w))))))
        {
          short1 = 8207;
        }
        else if ((ab.nextFloat() < 0.05F) && ((isTiny()) || (holdingEntity != null)) && (!a(PotionResizing.huge)) && (!q.u(ls.c(u), ls.c(v + f()) + 1, ls.c(w))) && (sizeRate == 0.0F))
        {
          short1 = 8199;
        }
        else if ((ab.nextFloat() < 0.25F) && (m() != null) && (!a(ni.c)) && (m().e(this) > 121.0D))
        {
          short1 = 16274;
        }
        else if ((ab.nextFloat() < 0.25F) && (m() != null) && (!a(ni.c)) && (m().e(this) > 121.0D))
        {
          short1 = 16274;
        }
        
        if (short1 > -1)
        {
          c(0, new ye(yc.bu, 1, short1));
          bs = aZ().n();
          a(true);
          os attributeinstance = a(tp.d);
          attributeinstance.b(bq);
          attributeinstance.a(bq);
        }
      }
      
      if (ab.nextFloat() < 7.5E-4F)
      {
        q.a(this, (byte)15);
      }
    }
    
    super.c();
  }
  



  protected float c(nb par1DamageSource, float par2)
  {
    par2 = super.c(par1DamageSource, par2);
    
    if (par1DamageSource.i() == this)
    {
      par2 = 0.0F;
    }
    
    if (par1DamageSource.q())
    {
      par2 = (float)(par2 * 0.15D);
    }
    
    return par2;
  }
  
  @SideOnly(Side.CLIENT)
  public void a(byte par1)
  {
    if (par1 == 15)
    {
      for (int i = 0; i < ab.nextInt(35) + 10; i++)
      {
        q.a("witchMagic", u + ab.nextGaussian() * 0.12999999523162842D, E.e + 0.5D + ab.nextGaussian() * 0.12999999523162842D, w + ab.nextGaussian() * 0.12999999523162842D, 0.0D, 0.0D, 0.0D);
      }
      
    }
    else {
      super.a(par1);
    }
  }
  




  protected void b(boolean par1, int par2)
  {
    int j = ab.nextInt(3) + 1;
    
    for (int k = 0; k < j; k++)
    {
      int l = ab.nextInt(3);
      int i1 = br[ab.nextInt(br.length)];
      
      if (par2 > 0)
      {
        l += ab.nextInt(par2 + 1);
      }
      
      for (int j1 = 0; j1 < l; j1++)
      {
        b(i1, 1);
      }
    }
  }
  



  public boolean o(nn par1Entity)
  {
    return (super.o(par1Entity)) && ((aE() == par1Entity) || (aG() == par1Entity) || (isEntityInRelativeSizeRange(par1Entity, minLookSize, 0.0F)) || ((isEntityInRelativeSizeRange(par1Entity, minTargetSize, 0.0F)) && (((!par1Entity.ah()) && (e(par1Entity) < 9.0D * (getRangeMultiplier() * getRangeMultiplier()))) || ((par1Entity.ah()) && (e(par1Entity) < 1.0D * (getRangeMultiplier() * getRangeMultiplier()))))));
  }
  



  public void a(of par1EntityLivingBase, float par2)
  {
    if (!bT())
    {
      int pval = 32732;
      double d0 = u + x - u;
      double d1 = v + par1EntityLivingBase.f() - 1.100000023841858D * getSizeMultiplier() - v;
      double d2 = w + z - w;
      float f1 = ls.a(d0 * d0 + d2 * d2);
      
      if ((!par1EntityLivingBase.a(PotionResizing.tiny)) && (isEntityInRelativeSizeRange(par1EntityLivingBase, 1.0F, 0.0F)) && (ab.nextFloat() < 0.25F))
      {
        pval = 16399;
      }
      else if ((!par1EntityLivingBase.a(PotionResizing.huge)) && (((isEntityInRelativeSizeRange(par1EntityLivingBase, 0.0F, minLookSize)) && (ab.nextFloat() < 0.15F)) || ((isEntityInRelativeSizeRange(par1EntityLivingBase, minLookSize, 0.5F)) && (o(par1EntityLivingBase)) && (ab.nextFloat() < 1.0E-4F) && (q.u(ls.c(u), ls.c(v + par1EntityLivingBase.f()) + 1, ls.c(w))) && (q.a(this, E.b(O, 0.0D, O)).isEmpty()))))
      {
        pval = 16391;
      }
      else if ((f1 >= 8.0F * getRangeMultiplier()) && (!par1EntityLivingBase.a(ni.d)))
      {
        pval = 32698;
      }
      else if (((par1EntityLivingBase.aN() >= 8.0F) || (par1EntityLivingBase.isTiny())) && (!par1EntityLivingBase.a(ni.u)))
      {
        pval = 32660;
      }
      else if ((f1 <= 3.0F * getRangeMultiplier()) && (!par1EntityLivingBase.a(ni.t)) && (ab.nextFloat() < 0.25F))
      {
        pval = 32696;
      }
      else if ((canSquish(par1EntityLivingBase)) && (aN() > aT() / 2.0F) && ((!o(par1EntityLivingBase)) || (f1 < 8.0F * getRangeMultiplier()) || (ab.nextFloat() < 0.999F)))
      {
        return;
      }
      
      uu entitypotion = new uu(q, this, pval);
      B -= -20.0F;
      float psize = entitypotion.getSizeMultiplier();
      entitypotion.c(d0, d1 + f1 * 0.2F / (psize <= 1.0F ? psize : 1.0F), d2, 0.75F * (psize <= 1.0F ? 1.0F : psize), 8.0F * psize);
      q.d(entitypotion);
    }
  }
}
