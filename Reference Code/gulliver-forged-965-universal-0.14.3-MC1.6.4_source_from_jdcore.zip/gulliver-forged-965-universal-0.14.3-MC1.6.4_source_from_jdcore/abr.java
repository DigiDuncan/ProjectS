import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
















public class abr
{
  public boolean a;
  public boolean b = true;
  private int i = 16;
  private Random j = new Random();
  
  private abw k;
  
  public double c;
  public double d;
  public double e;
  public nn f;
  public float g;
  public List h = new ArrayList();
  private Map l = new HashMap();
  
  public abr(abw par1World, nn par2Entity, double par3, double par5, double par7, float par9)
  {
    k = par1World;
    f = par2Entity;
    g = par9;
    c = par3;
    d = par5;
    e = par7;
  }
  



  public void a()
  {
    float f = g;
    HashSet hashset = new HashSet();
    






    for (int i = 0; i < this.i; i++)
    {
      for (int j = 0; j < this.i; j++)
      {
        for (int k = 0; k < this.i; k++)
        {
          if ((i == 0) || (i == this.i - 1) || (j == 0) || (j == this.i - 1) || (k == 0) || (k == this.i - 1))
          {
            double d3 = i / (this.i - 1.0F) * 2.0F - 1.0F;
            double d4 = j / (this.i - 1.0F) * 2.0F - 1.0F;
            double d5 = k / (this.i - 1.0F) * 2.0F - 1.0F;
            double d6 = Math.sqrt(d3 * d3 + d4 * d4 + d5 * d5);
            d3 /= d6;
            d4 /= d6;
            d5 /= d6;
            float f1 = g * (0.7F + ks.nextFloat() * 0.6F);
            double d0 = c;
            double d1 = d;
            double d2 = e;
            
            for (float f2 = 0.3F; f1 > 0.0F; f1 -= f2 * 0.75F)
            {
              int l = ls.c(d0);
              int i1 = ls.c(d1);
              int j1 = ls.c(d2);
              int k1 = this.k.a(l, i1, j1);
              
              if (k1 > 0)
              {
                aqz block = aqz.s[k1];
                float f3 = this.f != null ? this.f.a(this, this.k, l, i1, j1, block) : block.getExplosionResistance(this.f, this.k, l, i1, j1, c, d, e);
                f1 -= (f3 + 0.3F) * f2;
              }
              
              if ((f1 > 0.0F) && ((this.f == null) || (this.f.a(this, this.k, l, i1, j1, k1, f1))))
              {
                hashset.add(new aco(l, i1, j1));
              }
              
              d0 += d3 * f2;
              d1 += d4 * f2;
              d2 += d5 * f2;
            }
          }
        }
      }
    }
    
    h.addAll(hashset);
    g *= 2.0F;
    i = ls.c(c - g - 1.0D);
    int j = ls.c(c + g + 1.0D);
    int k = ls.c(d - g - 1.0D);
    int l1 = ls.c(d + g + 1.0D);
    int i2 = ls.c(e - g - 1.0D);
    int j2 = ls.c(e + g + 1.0D);
    List list = this.k.b(this.f, asx.a().a(i, k, i2, j, l1, j2));
    atc vec3 = this.k.V().a(c, d, e);
    
    for (int k2 = 0; k2 < list.size(); k2++)
    {
      nn entity = (nn)list.get(k2);
      
      double d0 = u - c;
      double d1 = v + P / 2.0D - d;
      double d2 = w - e;
      double d7 = ls.a(d0 * d0 + d1 * d1 + d2 * d2) / g;
      
      if (d7 <= 1.0D)
      {
        d1 = v + entity.f() - d;
        double d8 = ls.a(d0 * d0 + d1 * d1 + d2 * d2);
        
        if (d8 != 0.0D)
        {
          d0 /= d8;
          d1 /= d8;
          d2 /= d8;
          double d9 = this.k.a(vec3, E);
          double d10 = (1.0D - d7) * d9;
          entity.a(nb.a(this), (int)((d10 * d10 + d10) / 2.0D * 8.0D * g + 1.0D));
          double d11 = abg.a(entity, d10);
          x += d0 * d11;
          y += d1 * d11;
          z += d2 * d11;
          
          if ((entity instanceof uf))
          {
            this.l.put((uf)entity, this.k.V().a(d0 * d10, d1 * d10, d2 * d10));
          }
        }
      }
    }
    
    g = f;
  }
  



  public void a(boolean par1)
  {
    this.k.a(c, d, e, "random.explode", 4.0F, (1.0F + (ks.nextFloat() - ks.nextFloat()) * 0.2F) * 0.7F);
    
    if ((g >= 2.0F) && (b))
    {
      this.k.a("hugeexplosion", c, d, e, 1.0D, 0.0D, 0.0D);
    }
    else
    {
      this.k.a("largeexplode", c, d, e, 1.0D, 0.0D, 0.0D);
    }
    







    if (b)
    {
      Iterator iterator = h.iterator();
      
      while (iterator.hasNext())
      {
        aco chunkposition = (aco)iterator.next();
        int i = a;
        int j = b;
        int k = c;
        int l = this.k.a(i, j, k);
        
        if (par1)
        {
          double d0 = i + ks.nextFloat();
          double d1 = j + ks.nextFloat();
          double d2 = k + ks.nextFloat();
          double d3 = d0 - c;
          double d4 = d1 - d;
          double d5 = d2 - e;
          double d6 = ls.a(d3 * d3 + d4 * d4 + d5 * d5);
          d3 /= d6;
          d4 /= d6;
          d5 /= d6;
          double d7 = 0.5D / (d6 / g + 0.1D);
          d7 *= (ks.nextFloat() * ks.nextFloat() + 0.3F);
          d3 *= d7;
          d4 *= d7;
          d5 *= d7;
          this.k.a("explode", (d0 + c * 1.0D) / 2.0D, (d1 + d * 1.0D) / 2.0D, (d2 + e * 1.0D) / 2.0D, d3, d4, d5);
          this.k.a("smoke", d0, d1, d2, d3, d4, d5);
        }
        
        if (l > 0)
        {
          aqz block = aqz.s[l];
          
          if (block.a(this))
          {
            block.a(this.k, i, j, k, this.k.h(i, j, k), 1.0F / g, 0);
          }
          
          block.onBlockExploded(this.k, i, j, k, this);
        }
      }
    }
    
    if (a)
    {
      Iterator iterator = h.iterator();
      
      while (iterator.hasNext())
      {
        aco chunkposition = (aco)iterator.next();
        int i = a;
        int j = b;
        int k = c;
        int l = this.k.a(i, j, k);
        int i1 = this.k.a(i, j - 1, k);
        
        if ((l == 0) && (aqz.t[i1] != 0) && (this.j.nextInt(3) == 0))
        {
          this.k.c(i, j, k, awcF);
        }
      }
    }
  }
  
  public Map b()
  {
    return l;
  }
  



  public of c()
  {
    return (f instanceof of) ? (of)f : (f instanceof tc) ? ((tc)f).c() : f == null ? null : null;
  }
}
