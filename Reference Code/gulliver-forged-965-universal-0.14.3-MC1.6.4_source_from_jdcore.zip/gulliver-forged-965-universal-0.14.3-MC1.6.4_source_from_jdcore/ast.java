import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import java.util.Random;























public class ast
  extends aqz
{
  private final boolean a;
  @SideOnly(Side.CLIENT)
  private ms b;
  @SideOnly(Side.CLIENT)
  private ms c;
  @SideOnly(Side.CLIENT)
  private ms d;
  
  public ast(int par1, boolean par2)
  {
    super(par1, akc.G);
    a = par2;
    a(k);
    c(0.5F);
    a(ww.d);
  }
  






  @SideOnly(Side.CLIENT)
  public ms q()
  {
    return d;
  }
  
  @SideOnly(Side.CLIENT)
  public void b(float par1, float par2, float par3, float par4, float par5, float par6)
  {
    a(par1, par2, par3, par4, par5, par6);
  }
  




  @SideOnly(Side.CLIENT)
  public ms a(int par1, int par2)
  {
    int k = d(par2);
    return par1 == s.a[k] ? c : par1 == k ? b : (!e(par2)) && (cM <= 0.0D) && (cN <= 0.0D) && (cO <= 0.0D) && (cP >= 1.0D) && (cQ >= 1.0D) && (cR >= 1.0D) ? d : k > 5 ? d : cW;
  }
  
  @SideOnly(Side.CLIENT)
  public static ms b(String par0Str)
  {
    return par0Str == "piston_inner" ? aeb : par0Str == "piston_top_sticky" ? aad : par0Str == "piston_top_normal" ? aed : par0Str == "piston_side" ? aecW : null;
  }
  





  @SideOnly(Side.CLIENT)
  public void a(mt par1IconRegister)
  {
    cW = par1IconRegister.a("piston_side");
    d = par1IconRegister.a(a ? "piston_top_sticky" : "piston_top_normal");
    b = par1IconRegister.a("piston_inner");
    c = par1IconRegister.a("piston_bottom");
  }
  



  public int d()
  {
    return 16;
  }
  




  public boolean c()
  {
    return false;
  }
  



  public boolean a(abw par1World, int par2, int par3, int par4, uf par5EntityPlayer, int par6, float par7, float par8, float par9)
  {
    return false;
  }
  



  public void a(abw par1World, int par2, int par3, int par4, of par5EntityLivingBase, ye par6ItemStack)
  {
    int l = a(par1World, par2, par3, par4, par5EntityLivingBase);
    par1World.b(par2, par3, par4, l, 2);
    
    if (!I)
    {
      k(par1World, par2, par3, par4);
    }
  }
  




  public void a(abw par1World, int par2, int par3, int par4, int par5)
  {
    if (!I)
    {
      k(par1World, par2, par3, par4);
    }
  }
  



  public void a(abw par1World, int par2, int par3, int par4)
  {
    if ((!I) && (par1World.r(par2, par3, par4) == null))
    {
      k(par1World, par2, par3, par4);
    }
  }
  



  private void k(abw par1World, int par2, int par3, int par4)
  {
    int l = par1World.h(par2, par3, par4);
    int i1 = d(l);
    
    if (i1 != 7)
    {
      boolean flag = d(par1World, par2, par3, par4, i1);
      
      if ((flag) && (!e(l)))
      {
        if (e(par1World, par2, par3, par4, i1))
        {
          par1World.d(par2, par3, par4, cF, 0, i1);
        }
      }
      else if ((!flag) && (e(l)))
      {
        par1World.b(par2, par3, par4, i1, 2);
        par1World.d(par2, par3, par4, cF, 1, i1);
      }
    }
  }
  



  private boolean d(abw par1World, int par2, int par3, int par4, int par5)
  {
    return par1World.k(par2 - 1, par3 + 1, par4, 4) ? true : par1World.k(par2, par3 + 1, par4 + 1, 3) ? true : par1World.k(par2, par3 + 1, par4 - 1, 2) ? true : par1World.k(par2, par3 + 2, par4, 1) ? true : par1World.k(par2, par3, par4, 0) ? true : (par5 != 4) && (par1World.k(par2 - 1, par3, par4, 4)) ? true : (par5 != 5) && (par1World.k(par2 + 1, par3, par4, 5)) ? true : (par5 != 3) && (par1World.k(par2, par3, par4 + 1, 3)) ? true : (par5 != 2) && (par1World.k(par2, par3, par4 - 1, 2)) ? true : (par5 != 1) && (par1World.k(par2, par3 + 1, par4, 1)) ? true : (par5 != 0) && (par1World.k(par2, par3 - 1, par4, 0)) ? true : par1World.k(par2 + 1, par3 + 1, par4, 5);
  }
  




  public boolean b(abw par1World, int par2, int par3, int par4, int par5, int par6)
  {
    if (!I)
    {
      boolean flag = d(par1World, par2, par3, par4, par6);
      
      if ((flag) && (par5 == 1))
      {
        par1World.b(par2, par3, par4, par6 | 0x8, 2);
        return false;
      }
      
      if ((!flag) && (par5 == 0))
      {
        return false;
      }
    }
    
    if (par5 == 0)
    {
      if (!f(par1World, par2, par3, par4, par6))
      {
        return false;
      }
      
      par1World.b(par2, par3, par4, par6 | 0x8, 2);
      par1World.a(par2 + 0.5D, par3 + 0.5D, par4 + 0.5D, "tile.piston.out", 0.5F, s.nextFloat() * 0.25F + 0.6F);
    }
    else if (par5 == 1)
    {
      asp tileentity = par1World.r(par2 + s.b[par6], par3 + s.c[par6], par4 + s.d[par6]);
      
      if ((tileentity instanceof asw))
      {
        ((asw)tileentity).f();
      }
      
      par1World.f(par2, par3, par4, ahcF, par6, 3);
      par1World.a(par2, par3, par4, asv.a(cF, par6, par6, false, true));
      
      if (a)
      {
        int j1 = par2 + s.b[par6] * 2;
        int k1 = par3 + s.c[par6] * 2;
        int l1 = par4 + s.d[par6] * 2;
        int i2 = par1World.a(j1, k1, l1);
        int j2 = par1World.h(j1, k1, l1);
        boolean flag1 = false;
        
        if (i2 == ahcF)
        {
          asp tileentity1 = par1World.r(j1, k1, l1);
          
          if ((tileentity1 instanceof asw))
          {
            asw tileentitypiston = (asw)tileentity1;
            
            if ((tileentitypiston.c() == par6) && (tileentitypiston.b()))
            {
              tileentitypiston.f();
              i2 = tileentitypiston.a();
              j2 = tileentitypiston.p();
              flag1 = true;
            }
          }
        }
        
        if ((!flag1) && (i2 > 0) && (a(i2, par1World, j1, k1, l1, false)) && ((aqz.s[i2].h() == 0) || (i2 == aecF) || (i2 == aacF)))
        {
          par2 += s.b[par6];
          par3 += s.c[par6];
          par4 += s.d[par6];
          par1World.f(par2, par3, par4, ahcF, j2, 3);
          par1World.a(par2, par3, par4, asv.a(i2, j2, par6, false, false));
          par1World.i(j1, k1, l1);
        }
        else if (!flag1)
        {
          par1World.i(par2 + s.b[par6], par3 + s.c[par6], par4 + s.d[par6]);
        }
      }
      else
      {
        par1World.i(par2 + s.b[par6], par3 + s.c[par6], par4 + s.d[par6]);
      }
      
      par1World.a(par2 + 0.5D, par3 + 0.5D, par4 + 0.5D, "tile.piston.in", 0.5F, s.nextFloat() * 0.15F + 0.6F);
    }
    
    return true;
  }
  



  public void a(acf par1IBlockAccess, int par2, int par3, int par4)
  {
    int l = par1IBlockAccess.h(par2, par3, par4);
    
    if (e(l))
    {
      float f = 0.25F;
      
      switch (d(l))
      {
      case 0: 
        a(0.0F, 0.25F, 0.0F, 1.0F, 1.0F, 1.0F);
        break;
      case 1: 
        a(0.0F, 0.0F, 0.0F, 1.0F, 0.75F, 1.0F);
        break;
      case 2: 
        a(0.0F, 0.0F, 0.25F, 1.0F, 1.0F, 1.0F);
        break;
      case 3: 
        a(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 0.75F);
        break;
      case 4: 
        a(0.25F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
        break;
      case 5: 
        a(0.0F, 0.0F, 0.0F, 0.75F, 1.0F, 1.0F);
      }
    }
    else
    {
      a(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
    }
  }
  



  public void g()
  {
    a(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
  }
  




  public void a(abw par1World, int par2, int par3, int par4, asx par5AxisAlignedBB, List par6List, nn par7Entity)
  {
    a(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
    super.a(par1World, par2, par3, par4, par5AxisAlignedBB, par6List, par7Entity);
  }
  




  public asx b(abw par1World, int par2, int par3, int par4)
  {
    a(par1World, par2, par3, par4);
    return super.b(par1World, par2, par3, par4);
  }
  



  public boolean b()
  {
    return false;
  }
  



  public static int d(int par0)
  {
    return par0 & 0x7;
  }
  



  public static boolean e(int par0)
  {
    return (par0 & 0x8) != 0;
  }
  



  public static int a(abw par0World, int par1, int par2, int par3, of par4EntityLivingBase)
  {
    double worldScale = par0World.R() / q.R();
    
    if (worldScale != 1.0D)
    {
      if ((ls.e((float)u - (float)(par1 / worldScale)) < 2.0F * par4EntityLivingBase.getSizeMultiplier()) && (ls.e((float)w - (float)(par3 / worldScale)) < 2.0F * par4EntityLivingBase.getSizeMultiplier()))
      {
        double d0 = v + 1.82D * par4EntityLivingBase.getSizeMultiplier() - N;
        
        if (d0 - par2 / worldScale > 2.0D * par4EntityLivingBase.getSizeMultiplier())
        {
          return 1;
        }
        
        if (par2 / worldScale - d0 > 0.0D)
        {
          return 0;
        }
      }
    }
    else if ((ls.e((float)u - par1) < 2.0F * par4EntityLivingBase.getSizeMultiplier()) && (ls.e((float)w - par3) < 2.0F * par4EntityLivingBase.getSizeMultiplier()))
    {

      double d0 = v + 1.82D * par4EntityLivingBase.getSizeMultiplier() - N;
      
      if (d0 - par2 > 2.0D * par4EntityLivingBase.getSizeMultiplier())
      {
        return 1;
      }
      
      if (par2 - d0 > 0.0D)
      {
        return 0;
      }
    }
    
    int l = ls.c(A * 4.0F / 360.0F + 0.5D) & 0x3;
    return l == 3 ? 4 : l == 2 ? 3 : l == 1 ? 5 : l == 0 ? 2 : 0;
  }
  



  private static boolean a(int par0, abw par1World, int par2, int par3, int par4, boolean par5)
  {
    if (par0 == aucF)
    {
      return false;
    }
    

    if ((par0 != aecF) && (par0 != aacF))
    {
      if (aqz.s[par0].l(par1World, par2, par3, par4) == -1.0F)
      {
        return false;
      }
      
      if (aqz.s[par0].h() == 2)
      {
        return false;
      }
      
      if (aqz.s[par0].h() == 1)
      {
        if (!par5)
        {
          return false;
        }
        
        return true;
      }
    }
    else if (e(par1World.h(par2, par3, par4)))
    {
      return false;
    }
    
    return !par1World.d(par2, par3, par4);
  }
  




  private static boolean e(abw par0World, int par1, int par2, int par3, int par4)
  {
    int i1 = par1 + s.b[par4];
    int j1 = par2 + s.c[par4];
    int k1 = par3 + s.d[par4];
    int l1 = 0;
    


    while (l1 < 13)
    {
      if ((j1 <= 0) || (j1 >= par0World.R() - 1))
      {
        return false;
      }
      
      int i2 = par0World.a(i1, j1, k1);
      
      if (par0World.c(i1, j1, k1))
        break;
      if (!a(i2, par0World, i1, j1, k1, true))
      {
        return false;
      }
      
      if (aqz.s[i2].h() == 1)
        break;
      if (l1 == 12)
      {
        return false;
      }
      
      i1 += s.b[par4];
      j1 += s.c[par4];
      k1 += s.d[par4];
      l1++;
    }
    



    return true;
  }
  




  private boolean f(abw par1World, int par2, int par3, int par4, int par5)
  {
    int i1 = par2 + s.b[par5];
    int j1 = par3 + s.c[par5];
    int k1 = par4 + s.d[par5];
    int l1 = 0;
    




    while (l1 < 13)
    {
      if ((j1 <= 0) || (j1 >= par1World.R() - 1))
      {
        return false;
      }
      
      int i2 = par1World.a(i1, j1, k1);
      
      if (!par1World.c(i1, j1, k1))
      {
        if (!a(i2, par1World, i1, j1, k1, true))
        {
          return false;
        }
        
        if (aqz.s[i2].h() != 1)
        {
          if (l1 == 12)
          {
            return false;
          }
          
          i1 += s.b[par5];
          j1 += s.c[par5];
          k1 += s.d[par5];
          l1++;

        }
        else
        {
          float chance = (aqz.s[i2] instanceof arf) ? -1.0F : 1.0F;
          aqz.s[i2].a(par1World, i1, j1, k1, par1World.h(i1, j1, k1), chance, 0);
          par1World.i(i1, j1, k1);
        }
      }
    }
    l1 = i1;
    int i2 = j1;
    int j2 = k1;
    int k2 = 0;
    

    int j3;
    

    for (int[] aint = new int[13]; (i1 != par2) || (j1 != par3) || (k1 != par4); k1 = j3)
    {
      int l2 = i1 - s.b[par5];
      int i3 = j1 - s.c[par5];
      j3 = k1 - s.d[par5];
      int k3 = par1World.a(l2, i3, j3);
      int l3 = par1World.h(l2, i3, j3);
      
      if ((k3 == cF) && (l2 == par2) && (i3 == par3) && (j3 == par4))
      {
        par1World.f(i1, j1, k1, ahcF, par5 | (a ? 8 : 0), 4);
        par1World.a(i1, j1, k1, asv.a(afcF, par5 | (a ? 8 : 0), par5, true, false));
      }
      else
      {
        par1World.f(i1, j1, k1, ahcF, l3, 4);
        par1World.a(i1, j1, k1, asv.a(k3, l3, par5, true, false));
      }
      
      aint[(k2++)] = k3;
      i1 = l2;
      j1 = i3;
    }
    
    i1 = l1;
    j1 = i2;
    k1 = j2;
    int j3;
    for (k2 = 0; (i1 != par2) || (j1 != par3) || (k1 != par4); k1 = j3)
    {
      int l2 = i1 - s.b[par5];
      int i3 = j1 - s.c[par5];
      j3 = k1 - s.d[par5];
      par1World.f(l2, i3, j3, aint[(k2++)]);
      i1 = l2;
      j1 = i3;
    }
    
    return true;
  }
}
