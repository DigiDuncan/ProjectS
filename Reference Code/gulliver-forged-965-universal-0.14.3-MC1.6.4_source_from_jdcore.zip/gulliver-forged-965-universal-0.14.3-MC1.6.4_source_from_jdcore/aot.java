import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import java.util.Random;





















public class aot
  extends amw
{
  private final Random a = new Random();
  @SideOnly(Side.CLIENT)
  private ms b;
  @SideOnly(Side.CLIENT)
  private ms c;
  @SideOnly(Side.CLIENT)
  private ms d;
  
  public aot(int par1)
  {
    super(par1, akc.f);
    a(ww.d);
    a(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
  }
  












  public void a(abw par1World, int par2, int par3, int par4, asx par5AxisAlignedBB, List par6List, nn par7Entity)
  {
    a(0.25F, 0.25F, 0.25F, 0.75F, 0.5625F, 0.75F);
    super.a(par1World, par2, par3, par4, par5AxisAlignedBB, par6List, par7Entity);
    a(0.0F, 0.5625F, 0.0F, 1.0F, 0.6875F, 1.0F);
    super.a(par1World, par2, par3, par4, par5AxisAlignedBB, par6List, par7Entity);
    float f = 0.125F;
    a(0.0F, 0.625F, 0.0F, f, 1.0F, 1.0F);
    super.a(par1World, par2, par3, par4, par5AxisAlignedBB, par6List, par7Entity);
    a(0.0F, 0.625F, 0.0F, 1.0F, 1.0F, f);
    super.a(par1World, par2, par3, par4, par5AxisAlignedBB, par6List, par7Entity);
    a(1.0F - f, 0.625F, 0.0F, 1.0F, 1.0F, 1.0F);
    super.a(par1World, par2, par3, par4, par5AxisAlignedBB, par6List, par7Entity);
    a(0.0F, 0.625F, 1.0F - f, 1.0F, 1.0F, 1.0F);
    super.a(par1World, par2, par3, par4, par5AxisAlignedBB, par6List, par7Entity);
    a(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
  }
  




  public ata a(abw par1World, int par2, int par3, int par4, atc par5Vec3, atc par6Vec3)
  {
    ata[] hits = new ata[6];
    a(0.25F, 0.25F, 0.25F, 0.75F, 0.5625F, 0.75F);
    hits[0] = super.a(par1World, par2, par3, par4, par5Vec3, par6Vec3);
    a(0.0F, 0.5625F, 0.0F, 1.0F, 0.6875F, 1.0F);
    hits[1] = super.a(par1World, par2, par3, par4, par5Vec3, par6Vec3);
    float var8 = 0.125F;
    a(0.0F, 0.625F, 0.0F, var8, 1.0F, 1.0F);
    hits[2] = super.a(par1World, par2, par3, par4, par5Vec3, par6Vec3);
    a(0.0F, 0.625F, 0.0F, 1.0F, 1.0F, var8);
    hits[3] = super.a(par1World, par2, par3, par4, par5Vec3, par6Vec3);
    a(1.0F - var8, 0.625F, 0.0F, 1.0F, 1.0F, 1.0F);
    hits[4] = super.a(par1World, par2, par3, par4, par5Vec3, par6Vec3);
    a(0.0F, 0.625F, 1.0F - var8, 1.0F, 1.0F, 1.0F);
    hits[5] = super.a(par1World, par2, par3, par4, par5Vec3, par6Vec3);
    double mlen = 0.0D;
    ata ray = null;
    int var16 = hits.length;
    
    for (int var17 = 0; var17 < var16; var17++)
    {
      ata var18 = hits[var17];
      
      if (var18 != null)
      {
        double var19 = f.e(par6Vec3);
        
        if (var19 > mlen)
        {
          ray = var18;
          mlen = var19;
        }
      }
    }
    
    a(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
    return ray;
  }
  



  public int a(abw par1World, int par2, int par3, int par4, int par5, float par6, float par7, float par8, int par9)
  {
    int j1 = s.a[par5];
    
    if (j1 == 1)
    {
      j1 = 0;
    }
    
    return j1;
  }
  



  public asp b(abw par1World)
  {
    return new asi();
  }
  



  public void a(abw par1World, int par2, int par3, int par4, of par5EntityLivingBase, ye par6ItemStack)
  {
    super.a(par1World, par2, par3, par4, par5EntityLivingBase, par6ItemStack);
    
    if (par6ItemStack.u())
    {
      asi tileentityhopper = d(par1World, par2, par3, par4);
      tileentityhopper.a(par6ItemStack.s());
    }
  }
  



  public void a(abw par1World, int par2, int par3, int par4)
  {
    super.a(par1World, par2, par3, par4);
    k(par1World, par2, par3, par4);
  }
  



  public boolean a(abw par1World, int par2, int par3, int par4, uf par5EntityPlayer, int par6, float par7, float par8, float par9)
  {
    if (I)
    {
      return true;
    }
    

    asi tileentityhopper = d(par1World, par2, par3, par4);
    
    if (tileentityhopper != null)
    {
      par5EntityPlayer.a(tileentityhopper);
    }
    
    return true;
  }
  





  public void a(abw par1World, int par2, int par3, int par4, int par5)
  {
    k(par1World, par2, par3, par4);
  }
  



  private void k(abw par1World, int par2, int par3, int par4)
  {
    int l = par1World.h(par2, par3, par4);
    int i1 = c(l);
    boolean flag = !par1World.C(par2, par3, par4);
    boolean flag1 = d(l);
    
    if (flag != flag1)
    {
      par1World.b(par2, par3, par4, i1 | (flag ? 0 : 8), 4);
    }
  }
  





  public void a(abw par1World, int par2, int par3, int par4, int par5, int par6)
  {
    asi tileentityhopper = (asi)par1World.r(par2, par3, par4);
    
    if (tileentityhopper != null)
    {
      for (int j1 = 0; j1 < tileentityhopper.j_(); j1++)
      {
        ye itemstack = tileentityhopper.a(j1);
        
        if (itemstack != null)
        {
          float f = a.nextFloat() * 0.8F + 0.1F;
          float f1 = a.nextFloat() * 0.8F + 0.1F;
          float f2 = a.nextFloat() * 0.8F + 0.1F;
          
          while (b > 0)
          {
            int k1 = a.nextInt(21) + 10;
            
            if (k1 > b)
            {
              k1 = b;
            }
            
            b -= k1;
            ss entityitem = new ss(par1World, par2 + f, par3 + f1, par4 + f2, new ye(d, k1, itemstack.k()));
            
            if (itemstack.p())
            {
              entityitem.d().d((by)itemstack.q().b());
            }
            
            float f3 = 0.05F;
            x = ((float)a.nextGaussian() * f3);
            y = ((float)a.nextGaussian() * f3 + 0.2F);
            z = ((float)a.nextGaussian() * f3);
            par1World.d(entityitem);
          }
        }
      }
      
      par1World.m(par2, par3, par4, par5);
    }
    
    super.a(par1World, par2, par3, par4, par5, par6);
  }
  



  public int d()
  {
    return 38;
  }
  



  public boolean b()
  {
    return false;
  }
  




  public boolean c()
  {
    return false;
  }
  
  public static int c(int par0)
  {
    return par0 & 0x7;
  }
  





  @SideOnly(Side.CLIENT)
  public boolean a(acf par1IBlockAccess, int par2, int par3, int par4, int par5)
  {
    return true;
  }
  




  @SideOnly(Side.CLIENT)
  public ms a(int par1, int par2)
  {
    return par1 == 1 ? c : b;
  }
  
  public static boolean d(int par0)
  {
    return (par0 & 0x8) != 8;
  }
  




  public boolean q_()
  {
    return true;
  }
  




  public int b_(abw par1World, int par2, int par3, int par4, int par5)
  {
    return uy.b(d(par1World, par2, par3, par4));
  }
  





  @SideOnly(Side.CLIENT)
  public void a(mt par1IconRegister)
  {
    b = par1IconRegister.a("hopper_outside");
    c = par1IconRegister.a("hopper_top");
    d = par1IconRegister.a("hopper_inside");
  }
  
  @SideOnly(Side.CLIENT)
  public static ms b(String par0Str)
  {
    return par0Str.equals("hopper_inside") ? cvd : par0Str.equals("hopper_outside") ? cvb : null;
  }
  




  @SideOnly(Side.CLIENT)
  public String u_()
  {
    return "hopper";
  }
  
  public static asi d(acf par0IBlockAccess, int par1, int par2, int par3)
  {
    return (asi)par0IBlockAccess.r(par1, par2, par3);
  }
}
