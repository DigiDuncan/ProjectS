import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import gulliver.common.GulliverEnvoy;
import java.util.List;
import java.util.Random;











public class aro
  extends ane
{
  protected aro(int par1)
  {
    super(par1);
    float f = 0.5F;
    float f1 = 0.015625F;
    a(0.5F - f, 0.0F, 0.5F - f, 0.5F + f, f1, 0.5F + f);
    a(ww.c);
  }
  



  public int d()
  {
    return 23;
  }
  




  public void a(abw par1World, int par2, int par3, int par4, asx par5AxisAlignedBB, List par6List, nn par7Entity)
  {
    if ((par7Entity == null) || ((!(par7Entity instanceof sq)) && ((!(par7Entity instanceof of)) || (!par7Entity.isHuge()))))
    {

      super.a(par1World, par2, par3, par4, par5AxisAlignedBB, par6List, par7Entity);
    }
  }
  




  public asx b(abw par1World, int par2, int par3, int par4)
  {
    return asx.a().a(par2 + cM, par3 + cN, par4 + cO, par2 + cP, par3 + cQ, par4 + cR);
  }
  
  @SideOnly(Side.CLIENT)
  public int o()
  {
    return 2129968;
  }
  




  @SideOnly(Side.CLIENT)
  public int b(int par1)
  {
    return 2129968;
  }
  





  @SideOnly(Side.CLIENT)
  public int c(acf par1IBlockAccess, int par2, int par3, int par4)
  {
    return 2129968;
  }
  




  protected boolean g_(int par1)
  {
    return par1 == GcF;
  }
  



  public boolean f(abw par1World, int par2, int par3, int par4)
  {
    return (par1World.g(par2, par3 - 1, par4) == akc.h) && (par1World.h(par2, par3 - 1, par4) == 0);
  }
  




  public void a(abw par1World, int par2, int par3, int par4, nn par5Entity)
  {
    if ((!I) && (par5Entity.isHuge()) && (!par5Entity.ah()) && (GulliverEnvoy.canSizeGrief(par5Entity)) && ((!(par5Entity instanceof uf)) || (par1World.a((uf)par5Entity, par2, par3, par4))) && (!par5Entity.ah()) && (s.nextInt(50) == 0))
    {
      int i = par1World.a(par2, par3, par4);
      aqz.s[i].c(par1World, par2, par3, par4, par1World.h(par2, par3, par4), 0);
      par1World.i(par2, par3, par4);
    }
  }
}
