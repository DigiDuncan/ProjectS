import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.ArrayList;
import java.util.List;








public class xu
  extends yc
{
  public xu(int par1)
  {
    super(par1);
  }
  




  public boolean a(ye par1ItemStack, uf par2EntityPlayer, abw par3World, int par4, int par5, int par6, int par7, float par8, float par9, float par10)
  {
    if ((!I) && ((!par2EntityPlayer.isTiny()) || (o == null)))
    {
      uk entityfireworkrocket = new uk(par3World, par4 + par8, par5 + par9, par6 + par10, par1ItemStack);
      par3World.d(entityfireworkrocket);
      
      if (!bG.d)
      {
        b -= 1;
      }
      
      if (holdingEntity != null)
      {
        par2EntityPlayer.getDroppedByEntity(holdingEntity);
      }
      
      if (par2EntityPlayer.isTiny())
      {
        if (o != null)
        {
          par2EntityPlayer.a(o);
        }
        
        par2EntityPlayer.a(entityfireworkrocket);
      }
      
      return true;
    }
    

    return false;
  }
  





  @SideOnly(Side.CLIENT)
  public ye a(ye par1ItemStack, abw par2World, uf par3EntityPlayer)
  {
    if ((holdingEntity != null) || ((par3EntityPlayer.isTiny()) && (o != null)))
    {
      if (!bG.d)
      {
        b -= 1;
      }
      
      if (!I)
      {
        uk var11 = new uk(par2World, u, v, w, par1ItemStack);
        par2World.d(var11);
        
        if (holdingEntity != null)
        {
          par3EntityPlayer.getDroppedByEntity(holdingEntity);
        }
        
        if (par3EntityPlayer.isTiny())
        {
          if (o != null)
          {
            par3EntityPlayer.a(o);
          }
          
          par3EntityPlayer.a(var11);
        }
      }
    }
    
    return par1ItemStack;
  }
  



  public void a(ye par1ItemStack, uf par2EntityPlayer, List par3List, boolean par4)
  {
    if (par1ItemStack.p())
    {
      by nbttagcompound = par1ItemStack.q().l("Fireworks");
      
      if (nbttagcompound != null)
      {
        if (nbttagcompound.b("Flight"))
        {
          par3List.add(bu.a("item.fireworks.flight") + " " + nbttagcompound.c("Flight"));
        }
        
        cg nbttaglist = nbttagcompound.m("Explosions");
        
        if ((nbttaglist != null) && (nbttaglist.c() > 0))
        {
          for (int i = 0; i < nbttaglist.c(); i++)
          {
            by nbttagcompound1 = (by)nbttaglist.b(i);
            ArrayList arraylist = new ArrayList();
            xt.a(nbttagcompound1, arraylist);
            
            if (arraylist.size() > 0)
            {
              for (int j = 1; j < arraylist.size(); j++)
              {
                arraylist.set(j, "  " + (String)arraylist.get(j));
              }
              
              par3List.addAll(arraylist);
            }
          }
        }
      }
    }
  }
}
