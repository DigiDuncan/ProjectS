



public class qj
  extends ps
{
  private on a;
  private double b;
  private double c;
  private double d;
  private double e;
  
  public qj(on par1EntityCreature, double par2)
  {
    a = par1EntityCreature;
    b = par2;
    a(1);
  }
  



  public boolean a()
  {
    if ((a.aE() == null) && (!a.af()))
    {
      return false;
    }
    

    atc vec3 = rh.a(a, (int)(2.0F + 3.0F * a.getSizeMultiplierRoot()), (int)(2.0F + 2.0F * a.getSizeMultiplierRoot()));
    
    if (vec3 == null)
    {
      return false;
    }
    

    c = c;
    d = d;
    e = e;
    return true;
  }
  





  public void c()
  {
    a.k().a(c, d, e, b);
  }
  



  public boolean b()
  {
    return !a.k().g();
  }
}
