import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import gulliver.common.GulliverEnvoy;
import java.util.List;
import java.util.Random;















public class arh
  extends aqz
{
  public boolean d;
  
  protected arh(int par1, akc par2Material, boolean par3)
  {
    super(par1, par2Material);
    d = par3;
  }
  




  public boolean c()
  {
    return false;
  }
  





  @SideOnly(Side.CLIENT)
  public boolean a(acf par1IBlockAccess, int par2, int par3, int par4, int par5)
  {
    int i1 = par1IBlockAccess.a(par2, par3, par4);
    return (!d) && (i1 == cF) ? false : super.a(par1IBlockAccess, par2, par3, par4, par5);
  }
  



  public void a(abw par1World, int par2, int par3, int par4, asx par5AxisAlignedBB, List par6List, nn par7Entity)
  {
    if ((par7Entity == null) || (!(par7Entity instanceof of)) || (!par7Entity.isHuge()))
    {
      super.a(par1World, par2, par3, par4, par5AxisAlignedBB, par6List, par7Entity);
    }
  }
  



  public void a(abw par1World, int par2, int par3, int par4, nn par5Entity)
  {
    if ((!I) && (par5Entity.isHuge()))
    {
      if ((!par5Entity.ah()) && (GulliverEnvoy.canSizeGrief(par5Entity)) && ((!(par5Entity instanceof uf)) || (par1World.a((uf)par5Entity, par2, par3, par4))) && (s.nextInt(200) == 0))
      {

        c(par1World, par2, par3, par4, par1World.h(par2, par3, par4), 0);
        par1World.i(par2, par3, par4);
        par1World.e(2001, par2, par3, par4, cF + (par1World.h(par2, par3, par4) << 12));
      }
      else if (((par5Entity instanceof sb)) && (aqz.aX.c(par1World, par2, par3 + 1, par4)))
      {
        par1World.f(par2, par3 + 1, par4, aXcF, 0, 3);
      }
    }
    
    if (par5Entity.isHuge())
    {

      if ((par1World.h(par2, par3, par4) & 0x3) != 3)
      {
        x *= 0.95D;
        y *= 0.999D;
        z *= 0.95D;
        T *= 0.995F;
      }
      else
      {
        x *= 0.9D;
        y *= 0.99D;
        z *= 0.9D;
        T *= 0.99F;
      }
    }
  }
}
