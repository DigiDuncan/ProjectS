import java.util.ArrayList;
import java.util.Random;
import net.minecraftforge.common.IShearable;










public class rw
  extends rr
  implements IShearable
{
  public rw(abw par1World)
  {
    super(par1World);
    a(0.9F, 1.3F);
  }
  



  public boolean a(uf par1EntityPlayer)
  {
    ye itemstack = bn.h();
    
    if ((itemstack != null) && (d == Gcv) && (b() >= 0))
    {
      if (b == 1)
      {
        bn.a(bn.c, new ye(yc.H));
        return true;
      }
      
      if ((bn.a(new ye(yc.H))) && (!bG.d))
      {
        bn.a(bn.c, 1);
        return true;
      }
    }
    
    if ((itemstack != null) && (d == bgcv) && (b() >= 0))
    {
      if (!q.I)
      {
        boolean sheared = false;
        

        int var5 = 1;
        int chance = ls.d(5.0F * getSizeMultiplierRoot());
        
        if (chance >= 3)
        {

          int roll = ab.nextInt(chance);
          
          if (!par1EntityPlayer.isTinierThan(this))
          {
            var5 = chance;
            sheared = true;
          }
          else if (roll == 0)
          {
            sheared = true;
          }
        }
        else
        {
          sheared = true;
        }
        
        if (sheared)
        {
          q.a("largeexplode", u, v + P / 2.0F, w, 0.0D, 0.0D, 0.0D);
          x();
          rr var3 = new rr(q);
          var3.setSizeBaseMultiplier(sizeBaseMultiplier);
          var3.doResize(getSizeMultiplier(), false);
          var3.j(this);
          var3.g(aN());
          aN = aN;
          q.d(var3);
        }
        ss entityitem;
        for (int var4 = 0; var4 < var5; var4++)
        {
          entityitem = a(new ye(aqz.al), P);
        }
      }
      
      return true;
    }
    

    return super.a(par1EntityPlayer);
  }
  

  public rw c(nk par1EntityAgeable)
  {
    return new rw(q);
  }
  



  public rr b(nk par1EntityAgeable)
  {
    return c(par1EntityAgeable);
  }
  
  public nk a(nk par1EntityAgeable)
  {
    return c(par1EntityAgeable);
  }
  

  public boolean isShearable(ye item, abw world, int X, int Y, int Z)
  {
    return b() >= 0;
  }
  

  public ArrayList<ye> onSheared(ye item, abw world, int X, int Y, int Z, int fortune)
  {
    x();
    rr entitycow = new rr(q);
    entitycow.b(u, v, w, A, B);
    entitycow.g(aN());
    aN = aN;
    q.d(entitycow);
    q.a("largeexplode", u, v + P / 2.0F, w, 0.0D, 0.0D, 0.0D);
    
    ArrayList<ye> ret = new ArrayList();
    for (int x = 0; x < 5; x++)
    {
      ret.add(new ye(aqz.al));
    }
    return ret;
  }
}
