












public abstract class pm
  extends ps
{
  protected og a;
  protected int b;
  protected int c;
  protected int d;
  protected anz e;
  boolean f;
  float g;
  float h;
  
  public pm(og par1EntityLiving)
  {
    a = par1EntityLiving;
    minTargetSize = 0.15F;
    maxTargetSize = 2.0F;
  }
  



  public boolean a()
  {
    if ((!a.G) || ((minTargetSize > 0.0F) && (a.getSizeMultiplier() < minTargetSize)) || ((maxTargetSize > 0.0F) && (a.getSizeMultiplier() > maxTargetSize)))
    {
      return false;
    }
    

    rf pathnavigate = a.k();
    alf pathentity = pathnavigate.e();
    
    if ((pathentity != null) && (!pathentity.b()) && (pathnavigate.c()))
    {
      for (int i = 0; i < Math.min(pathentity.e() + 2, pathentity.d()); i++)
      {
        ale pathpoint = pathentity.a(i);
        b = a;
        c = (b + 1);
        d = c;
        
        if (a.e(b, a.v, d) <= 2.25D * a.getSizeMultiplier())
        {
          e = a(b, c, d);
          
          if (e != null)
          {
            return true;
          }
        }
      }
      
      b = ls.c(a.u);
      c = ls.c(a.v + 1.0D);
      d = ls.c(a.w);
      e = a(b, c, d);
      return e != null;
    }
    

    return false;
  }
  





  public boolean b()
  {
    return !f;
  }
  



  public void c()
  {
    f = false;
    g = ((float)(b + 0.5F - a.u));
    h = ((float)(d + 0.5F - a.w));
  }
  



  public void e()
  {
    float f = (float)(b + 0.5F - a.u);
    float f1 = (float)(d + 0.5F - a.w);
    float f2 = g * f + h * f1;
    
    if (f2 < 0.0F)
    {
      this.f = true;
    }
  }
  



  private anz a(int par1, int par2, int par3)
  {
    int l = a.q.a(par1, par2, par3);
    
    if ((l != aJcF) || (a.isExtraTiny()))
    {
      return null;
    }
    

    return (anz)aqz.s[l];
  }
}
