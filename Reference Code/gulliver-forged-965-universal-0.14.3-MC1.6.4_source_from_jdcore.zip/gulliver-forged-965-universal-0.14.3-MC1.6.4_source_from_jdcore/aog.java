import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;














public class aog
  extends anw
{
  public aog(int par1)
  {
    super(par1, akc.d);
    a(ww.d);
  }
  




  @SideOnly(Side.CLIENT)
  public ms a(int par1, int par2)
  {
    return aqz.C.m(par1);
  }
  



  public boolean c(abw par1World, int par2, int par3, int par4)
  {
    return !par1World.g(par2, par3 - 1, par4).a() ? false : super.c(par1World, par2, par3, par4);
  }
  




  public asx b(abw par1World, int par2, int par3, int par4)
  {
    int l = par1World.h(par2, par3, par4);
    return (l != 2) && (l != 0) ? asx.a().a(par2 + 0.375F, par3 + 0.3125F, par4, par2 + 0.625F, par3 + 1.5F, par4 + 1) : m_(l) ? null : asx.a().a(par2, par3 + 0.3125F, par4 + 0.375F, par2 + 1, par3 + 1.5F, par4 + 0.625F);
  }
  



  public void a(acf par1IBlockAccess, int par2, int par3, int par4)
  {
    int l = j(par1IBlockAccess.h(par2, par3, par4));
    
    if ((l != 2) && (l != 0))
    {
      a(0.375F, 0.3125F, 0.0F, 0.625F, 1.0F, 1.0F);
    }
    else
    {
      a(0.0F, 0.3125F, 0.375F, 1.0F, 1.0F, 0.625F);
    }
  }
  




  public boolean c()
  {
    return false;
  }
  



  public boolean b()
  {
    return false;
  }
  
  public boolean b(acf par1IBlockAccess, int par2, int par3, int par4)
  {
    return m_(par1IBlockAccess.h(par2, par3, par4));
  }
  



  public int d()
  {
    return 21;
  }
  



  public void a(abw par1World, int par2, int par3, int par4, of par5EntityLivingBase, ye par6ItemStack)
  {
    int l = (ls.c(A * 4.0F / 360.0F + 0.5D) & 0x3) % 4;
    par1World.b(par2, par3, par4, l, 2);
  }
  



  public boolean a(abw par1World, int par2, int par3, int par4, uf par5EntityPlayer, int par6, float par7, float par8, float par9)
  {
    int i1 = par1World.h(par2, par3, par4);
    
    if (m_(i1))
    {
      par1World.b(par2, par3, par4, i1 & 0xFFFFFFFB, 2);
    }
    else
    {
      int j1 = (ls.c(A * 4.0F / 360.0F + 0.5D) & 0x3) % 4;
      int k1 = j(i1);
      
      if (k1 == (j1 + 2) % 4)
      {
        i1 = j1;
      }
      
      par1World.b(par2, par3, par4, i1 | 0x4, 2);
    }
    
    par1World.a(par5EntityPlayer, 1003, par2, par3, par4, 0);
    return true;
  }
  




  public void a(abw par1World, int par2, int par3, int par4, int par5)
  {
    if (!I)
    {
      int i1 = par1World.h(par2, par3, par4);
      boolean flag = par1World.C(par2, par3, par4);
      
      if ((flag) || ((par5 > 0) && (aqz.s[par5].f())))
      {
        if ((flag) && (!m_(i1)))
        {
          par1World.b(par2, par3, par4, i1 | 0x4, 2);
          par1World.a((uf)null, 1003, par2, par3, par4, 0);
        }
        else if ((!flag) && (m_(i1)))
        {
          par1World.b(par2, par3, par4, i1 & 0xFFFFFFFB, 2);
          par1World.a((uf)null, 1003, par2, par3, par4, 0);
        }
      }
    }
  }
  



  public static boolean m_(int par0)
  {
    return (par0 & 0x4) != 0;
  }
  





  @SideOnly(Side.CLIENT)
  public boolean a(acf par1IBlockAccess, int par2, int par3, int par4, int par5)
  {
    return true;
  }
  
  @SideOnly(Side.CLIENT)
  public void a(mt par1IconRegister) {}
}
