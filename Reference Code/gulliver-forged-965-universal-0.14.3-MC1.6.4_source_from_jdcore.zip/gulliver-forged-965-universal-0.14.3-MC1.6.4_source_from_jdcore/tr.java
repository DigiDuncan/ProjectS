import java.util.Calendar;
import java.util.Random;
































public class tr
  extends tm
  implements to
{
  private qn bp = new qn(this, 1.0D, 20, 60, 15.0F);
  private qa bq = new qa(this, uf.class, 1.2D, false);
  
  public tr(abw par1World)
  {
    super(par1World);
    c.a(1, new pp(this));
    c.a(2, new qp(this));
    c.a(3, new po(this, 1.0D));
    c.a(5, new qm(this, 1.0D));
    c.a(6, new px(this, uf.class, 8.0F));
    c.a(6, new ql(this));
    d.a(1, new qx(this, false));
    d.a(2, new qy(this, uf.class, 0, true));
    
    if ((par1World != null) && (!I))
    {
      bT();
    }
  }
  
  protected void az()
  {
    super.az();
    a(tp.d).a(0.25D);
  }
  
  protected void a()
  {
    super.a();
    ah.a(13, new Byte((byte)0));
  }
  



  public boolean bf()
  {
    return true;
  }
  



  protected String r()
  {
    return "mob.skeleton.say";
  }
  



  protected String aO()
  {
    return "mob.skeleton.hurt";
  }
  



  protected String aP()
  {
    return "mob.skeleton.death";
  }
  



  protected void a(int par1, int par2, int par3, int par4)
  {
    a("mob.skeleton.step", 0.15F, 1.0F);
  }
  
  public boolean m(nn par1Entity)
  {
    if (super.m(par1Entity))
    {
      if ((bV() == 1) && ((par1Entity instanceof of)))
      {
        ((of)par1Entity).c(new nj(vH, 200));
      }
      
      return true;
    }
    

    return false;
  }
  




  public oj aY()
  {
    return oj.b;
  }
  




  public void c()
  {
    if ((q.v()) && (!q.I))
    {
      float f = d(1.0F);
      
      if ((f > 0.5F) && (ab.nextFloat() * 30.0F < (f - 0.4F) * 2.0F) && (q.l(ls.c(u), ls.c(v), ls.c(w))))
      {
        boolean flag = true;
        ye itemstack = n(4);
        
        if (itemstack != null)
        {
          if (itemstack.g())
          {
            itemstack.b(itemstack.j() + ab.nextInt(2));
            
            if (itemstack.j() >= itemstack.l())
            {
              a(itemstack);
              c(4, (ye)null);
            }
          }
          
          flag = false;
        }
        
        if (flag)
        {
          d(8);
        }
      }
    }
    
    if ((q.I) && (bV() == 1))
    {
      a(0.72F, 2.34F);
    }
    
    super.c();
  }
  



  public void V()
  {
    super.V();
    
    if ((o instanceof on))
    {
      on entitycreature = (on)o;
      aN = aN;
    }
  }
  





  public double X()
  {
    float sizemult = getSizeMultiplier();
    
    if ((o != null) && ((o instanceof of)))
    {

      if (((of)o).getSaddled())
      {


        return N - (float)o.Y() / o.P * sizemult + 0.24F * o.getSizeMultiplier() + 0.01F * sizemult * sizemult / o.getSizeMultiplier();
      }
      

      return N - (float)o.Y() / o.P * sizemult + 0.21F * o.getSizeMultiplier() + 0.01F * sizemult * sizemult / o.getSizeMultiplier();
    }
    



    return N - 0.62F * getSizeMultiplier() + 0.12F;
  }
  




  public void a(nb par1DamageSource)
  {
    super.a(par1DamageSource);
    
    if (((par1DamageSource.h() instanceof uh)) && ((par1DamageSource.i() instanceof uf)))
    {
      uf entityplayer = (uf)par1DamageSource.i();
      double d0 = u - u;
      double d1 = w - w;
      
      if (d0 * d0 + d1 * d1 >= 2500.0D)
      {
        entityplayer.a(kp.v);
      }
    }
  }
  



  protected int s()
  {
    return ncv;
  }
  







  protected void b(boolean par1, int par2)
  {
    if (bV() == 1)
    {
      dropItemSizedAmount(par2 + 2, ocv, -1, 0);
    }
    else
    {
      dropItemSizedAmount(par2 + 2, ncv, 0, 0);
    }
    
    dropItemSizedAmount(par2 + 2, aZcv, 0, 0);
  }
  
  protected void l(int par1)
  {
    if (bV() == 1)
    {
      a(new ye(bScv, 1, 1), 0.0F);
    }
  }
  



  protected void bw()
  {
    super.bw();
    c(0, new ye(yc.m));
  }
  
  public oi a(oi par1EntityLivingData)
  {
    par1EntityLivingData = super.a(par1EntityLivingData);
    
    if (((q.t instanceof aej)) && (aD().nextInt(5) > 0))
    {
      c.a(4, bq);
      a(1);
      c(0, new ye(yc.x));
      a(tp.e).a(4.0D);
    }
    else
    {
      c.a(4, bp);
      bw();
      bx();
    }
    
    h(ab.nextFloat() < 0.55F * q.b(u, v, w));
    
    if (n(4) == null)
    {
      Calendar calendar = q.W();
      
      if ((calendar.get(2) + 1 == 10) && (calendar.get(5) == 31) && (ab.nextFloat() < 0.25F))
      {
        c(4, new ye(ab.nextFloat() < 0.1F ? aqz.bk : aqz.bf));
        e[4] = 0.0F;
      }
    }
    
    return par1EntityLivingData;
  }
  



  public void bT()
  {
    c.a(bq);
    c.a(bp);
    ye itemstack = aZ();
    
    if ((itemstack != null) && (d == mcv))
    {
      c.a(4, bp);
    }
    else
    {
      c.a(4, bq);
    }
  }
  



  public void a(of par1EntityLivingBase, float par2)
  {
    uh entityarrow = new uh(q, this, par1EntityLivingBase, 1.6F, 14 - q.r * 4);
    int i = aaw.a(vz, aZ());
    int j = aaw.a(wz, aZ());
    entityarrow.b(par2 * 2.0F + ab.nextGaussian() * 0.25D + q.r * 0.11F);
    
    if (i > 0)
    {
      entityarrow.b(entityarrow.c() + i * 0.5D + 0.5D);
    }
    
    if (j > 0)
    {
      entityarrow.a(j);
    }
    
    if ((aaw.a(xz, aZ()) > 0) || (bV() == 1))
    {
      entityarrow.d(100);
    }
    
    a("random.bow", 1.0F, 1.0F / (aD().nextFloat() * 0.4F + 0.8F));
    q.d(entityarrow);
  }
  



  public int bV()
  {
    return ah.a(13);
  }
  



  public void a(int par1)
  {
    ah.b(13, Byte.valueOf((byte)par1));
    ag = (par1 == 1);
    
    if (par1 == 1)
    {
      a(0.72F, 2.34F);
    }
    else
    {
      a(0.6F, 1.8F);
    }
  }
  



  public void a(by par1NBTTagCompound)
  {
    super.a(par1NBTTagCompound);
    
    if (par1NBTTagCompound.b("SkeletonType"))
    {
      byte b0 = par1NBTTagCompound.c("SkeletonType");
      a(b0);
    }
    
    bT();
  }
  



  public void b(by par1NBTTagCompound)
  {
    super.b(par1NBTTagCompound);
    par1NBTTagCompound.a("SkeletonType", (byte)bV());
  }
  



  public void c(int par1, ye par2ItemStack)
  {
    super.c(par1, par2ItemStack);
    
    if ((!q.I) && (par1 == 0))
    {
      bT();
    }
  }
}
