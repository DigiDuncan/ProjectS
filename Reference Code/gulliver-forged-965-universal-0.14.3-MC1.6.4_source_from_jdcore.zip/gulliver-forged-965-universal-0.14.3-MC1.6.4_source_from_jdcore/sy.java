import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.EventBus;
import net.minecraftforge.event.entity.minecart.MinecartInteractEvent;




public class sy
  extends st
{
  public sy(abw par1World)
  {
    super(par1World);
  }
  
  public sy(abw par1World, double par2, double par4, double par6)
  {
    super(par1World, par2, par4, par6);
  }
  



  public boolean c(uf par1EntityPlayer)
  {
    if (MinecraftForge.EVENT_BUS.post(new MinecartInteractEvent(this, par1EntityPlayer)))
    {
      return true;
    }
    if ((n != null) && ((n instanceof uf)) && (n != par1EntityPlayer))
    {
      return true;
    }
    if ((n != null) && (n != par1EntityPlayer))
    {
      return false;
    }
    

    if ((!q.I) && (O <= maxRiderWidth(par1EntityPlayer)))
    {
      par1EntityPlayer.a(this);
    }
    
    return true;
  }
  

  public float maxRiderWidth(nn par1Entity)
  {
    return 0.90000004F;
  }
  
  public int l()
  {
    return 0;
  }
}
