import gulliver.common.GulliverEnvoy;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.server.MinecraftServer;











public class ae
{
  private static final Pattern a = Pattern.compile("^@([parf])(?:\\[([\\w=,!.-]*)\\])?$");
  



  private static final Pattern b = Pattern.compile("\\G([-!]?[\\w-]*)(?:$|,)");
  



  private static final Pattern c = Pattern.compile("\\G(\\w+)=([-!]?(?:[\\w-]*(?:|[.]\\w+)){1,2})(?:$|,)");
  

  public ae() {}
  
  public static jv a(ad par0ICommandSender, String par1Str)
  {
    jv[] aentityplayermp = c(par0ICommandSender, par1Str);
    return (aentityplayermp != null) && (aentityplayermp.length == 1) ? aentityplayermp[0] : null;
  }
  



  public static String b(ad par0ICommandSender, String par1Str)
  {
    jv[] aentityplayermp = c(par0ICommandSender, par1Str);
    
    if ((aentityplayermp != null) && (aentityplayermp.length != 0))
    {
      String[] astring = new String[aentityplayermp.length];
      
      for (int i = 0; i < astring.length; i++)
      {
        astring[i] = aentityplayermp[i].ay();
      }
      
      return z.a(astring);
    }
    

    return null;
  }
  

  public static float parseFloatWithDefault(String par0Str, float par1)
  {
    float var3 = par1;
    
    try
    {
      var3 = Float.parseFloat(par0Str);
    }
    catch (Throwable var6) {}
    



    return var3;
  }
  
  public static float parseHeightWithDefault(String par0Str, float par1)
  {
    float var3 = par1;
    
    try
    {
      var3 = GulliverEnvoy.parsePlayerHeight(par0Str);
    }
    catch (Throwable var6) {}
    



    return var3;
  }
  



  public static jv[] c(ad par0ICommandSender, String par1Str)
  {
    Matcher matcher = a.matcher(par1Str);
    
    if (!matcher.matches())
    {
      return null;
    }
    

    Map map = h(matcher.group(2));
    String s1 = matcher.group(1);
    int i = c(s1);
    int j = d(s1);
    int k = f(s1);
    int l = e(s1);
    int i1 = g(s1);
    int j1 = ace.a.a();
    t chunkcoordinates = par0ICommandSender.b();
    Map map1 = a(map);
    String s2 = null;
    String s3 = null;
    float maxsizemult = 0.0F;
    float minsizemult = 0.0F;
    float maxbasesize = 0.0F;
    float minbasesize = 0.0F;
    boolean flag = false;
    
    if (map.containsKey("sm"))
    {
      minsizemult = parseHeightWithDefault((String)map.get("sm"), minsizemult);
    }
    
    if (map.containsKey("s"))
    {
      maxsizemult = parseHeightWithDefault((String)map.get("s"), maxsizemult);
    }
    
    if (map.containsKey("bm"))
    {
      minbasesize = parseHeightWithDefault((String)map.get("bm"), minbasesize);
    }
    
    if (map.containsKey("b"))
    {
      maxbasesize = parseHeightWithDefault((String)map.get("b"), maxbasesize);
    }
    
    if (map.containsKey("rm"))
    {
      i = ls.a((String)map.get("rm"), i);
      flag = true;
    }
    
    if (map.containsKey("r"))
    {
      j = ls.a((String)map.get("r"), j);
      flag = true;
    }
    
    if (map.containsKey("lm"))
    {
      k = ls.a((String)map.get("lm"), k);
    }
    
    if (map.containsKey("l"))
    {
      l = ls.a((String)map.get("l"), l);
    }
    
    if (map.containsKey("x"))
    {
      a = ls.a((String)map.get("x"), a);
      flag = true;
    }
    
    if (map.containsKey("y"))
    {
      b = ls.a((String)map.get("y"), b);
      flag = true;
    }
    
    if (map.containsKey("z"))
    {
      c = ls.a((String)map.get("z"), c);
      flag = true;
    }
    
    if (map.containsKey("m"))
    {
      j1 = ls.a((String)map.get("m"), j1);
    }
    
    if (map.containsKey("c"))
    {
      i1 = ls.a((String)map.get("c"), i1);
    }
    
    if (map.containsKey("team"))
    {
      s3 = (String)map.get("team");
    }
    
    if (map.containsKey("name"))
    {
      s2 = (String)map.get("name");
    }
    
    abw world = flag ? par0ICommandSender.f_() : null;
    

    if ((!s1.equals("p")) && (!s1.equals("a")))
    {
      if (!s1.equals("r"))
      {
        return null;
      }
      

      List list = MinecraftServer.F().af().findPlayersSized(chunkcoordinates, i, j, 0, j1, k, l, map1, s2, s3, minsizemult, maxsizemult, minbasesize, maxbasesize, world);
      Collections.shuffle(list);
      list = list.subList(0, Math.min(i1, list.size()));
      return (list != null) && (!list.isEmpty()) ? (jv[])list.toArray(new jv[0]) : new jv[0];
    }
    


    List list = MinecraftServer.F().af().findPlayersSized(chunkcoordinates, i, j, i1, j1, k, l, map1, s2, s3, minsizemult, maxsizemult, minbasesize, maxbasesize, world);
    return (list != null) && (!list.isEmpty()) ? (jv[])list.toArray(new jv[0]) : new jv[0];
  }
  


  public static Map a(Map par0Map)
  {
    HashMap hashmap = new HashMap();
    Iterator iterator = par0Map.keySet().iterator();
    
    while (iterator.hasNext())
    {
      String s = (String)iterator.next();
      
      if ((s.startsWith("score_")) && (s.length() > "score_".length()))
      {
        String s1 = s.substring("score_".length());
        hashmap.put(s1, Integer.valueOf(ls.a((String)par0Map.get(s), 1)));
      }
    }
    
    return hashmap;
  }
  



  public static boolean a(String par0Str)
  {
    Matcher matcher = a.matcher(par0Str);
    
    if (matcher.matches())
    {
      Map map = h(matcher.group(2));
      String s1 = matcher.group(1);
      int i = g(s1);
      
      if (map.containsKey("c"))
      {
        i = ls.a((String)map.get("c"), i);
      }
      
      return i != 1;
    }
    

    return false;
  }
  




  public static boolean a(String par0Str, String par1Str)
  {
    Matcher matcher = a.matcher(par0Str);
    
    if (matcher.matches())
    {
      String s2 = matcher.group(1);
      return (par1Str == null) || (par1Str.equals(s2));
    }
    

    return false;
  }
  




  public static boolean b(String par0Str)
  {
    return a(par0Str, (String)null);
  }
  



  private static final int c(String par0Str)
  {
    return 0;
  }
  



  private static final int d(String par0Str)
  {
    return 0;
  }
  



  private static final int e(String par0Str)
  {
    return Integer.MAX_VALUE;
  }
  



  private static final int f(String par0Str)
  {
    return 0;
  }
  



  private static final int g(String par0Str)
  {
    return par0Str.equals("a") ? 0 : 1;
  }
  



  private static Map h(String par0Str)
  {
    HashMap hashmap = new HashMap();
    
    if (par0Str == null)
    {
      return hashmap;
    }
    

    Matcher matcher = b.matcher(par0Str);
    int i = 0;
    

    for (int j = -1; matcher.find(); j = matcher.end())
    {
      String s1 = null;
      
      switch (i++)
      {
      case 0: 
        s1 = "x";
        break;
      case 1: 
        s1 = "y";
        break;
      case 2: 
        s1 = "z";
        break;
      case 3: 
        s1 = "r";
      }
      
      if ((s1 != null) && (matcher.group(1).length() > 0))
      {
        hashmap.put(s1, matcher.group(1));
      }
    }
    
    if (j < par0Str.length())
    {
      matcher = c.matcher(j == -1 ? par0Str : par0Str.substring(j));
      
      while (matcher.find())
      {
        hashmap.put(matcher.group(1), matcher.group(2));
      }
    }
    
    return hashmap;
  }
}
