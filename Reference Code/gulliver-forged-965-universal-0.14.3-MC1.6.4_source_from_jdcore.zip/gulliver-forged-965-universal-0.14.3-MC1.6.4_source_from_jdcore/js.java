import com.google.common.collect.ImmutableSetMultimap;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import gulliver.network.packet.Packet171EntitySize;
import java.io.File;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.TreeSet;
import net.minecraft.server.MinecraftServer;
import net.minecraftforge.common.ChestGenHooks;
import net.minecraftforge.common.DimensionManager;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.EventBus;
import net.minecraftforge.event.ForgeEventFactory;
import net.minecraftforge.event.world.WorldEvent.Save;






















































public class js
  extends abw
{
  private final MinecraftServer a;
  private final jm J;
  private final jp K;
  private Set L;
  private TreeSet M;
  public jr b;
  public boolean c;
  public boolean N;
  private int O;
  private final acj P;
  private final aci Q = new aci();
  



  private ju[] R = { new ju((jt)null), new ju((jt)null) };
  


  private int S;
  

  public static final mk[] T = { new mk(Fcv, 0, 1, 3, 10), new mk(CcF, 0, 1, 3, 10), new mk(OcF, 0, 1, 3, 10), new mk(Acv, 0, 1, 1, 3), new mk(wcv, 0, 1, 1, 5), new mk(zcv, 0, 1, 1, 3), new mk(vcv, 0, 1, 1, 5), new mk(lcv, 0, 2, 3, 5), new mk(Wcv, 0, 2, 3, 3) };
  private List U = new ArrayList();
  

  private lm V;
  

  protected Set<abp> doneChunks = new HashSet();
  public List<acj> customTeleporters = new ArrayList();
  
  public js(MinecraftServer par1MinecraftServer, amc par2ISaveHandler, String par3Str, int par4, acd par5WorldSettings, lv par6Profiler, lp par7ILogAgent)
  {
    super(par2ISaveHandler, par3Str, par5WorldSettings, aei.a(par4), par6Profiler, par7ILogAgent);
    a = par1MinecraftServer;
    J = new jm(this);
    K = new jp(this, par1MinecraftServer.af().o());
    
    if (V == null)
    {
      V = new lm();
    }
    
    if (L == null)
    {
      L = new HashSet();
    }
    
    if (M == null)
    {
      M = new TreeSet();
    }
    
    P = new acj(this);
    D = new hp(par1MinecraftServer);
    atk scoreboardsavedata = (atk)z.a(atk.class, "scoreboard");
    
    if (scoreboardsavedata == null)
    {
      scoreboardsavedata = new atk();
      z.a("scoreboard", scoreboardsavedata);
    }
    
    if (!(this instanceof jl))
    {
      scoreboardsavedata.a(D);
    }
    ((hp)D).a(scoreboardsavedata);
    DimensionManager.setWorld(par4, this);
  }
  



  public void b()
  {
    super.b();
    
    if ((N().t()) && (r < 3))
    {
      r = 3;
    }
    
    t.e.b();
    
    if (e())
    {
      if (O().b("doDaylightCycle"))
      {
        long i = x.g() + 24000L;
        x.c(i - i % 24000L);
      }
      
      d();
    }
    
    C.a("mobSpawner");
    
    if (O().b("doMobSpawning"))
    {
      Q.a(this, E, F, x.f() % 400L == 0L);
    }
    
    C.c("chunkSource");
    v.c();
    int j = a(1.0F);
    
    if (j != this.j)
    {
      this.j = j;
    }
    
    x.b(x.f() + 1L);
    
    if (O().b("doDaylightCycle"))
    {
      x.c(x.g() + 1L);
    }
    
    C.c("tickPending");
    a(false);
    C.c("tickTiles");
    g();
    C.c("chunkMap");
    K.b();
    C.c("village");
    A.a();
    B.a();
    C.c("portalForcer");
    P.a(I());
    for (acj tele : customTeleporters)
    {
      tele.a(I());
    }
    C.b();
    aa();
  }
  



  public acr a(oh par1EnumCreatureType, int par2, int par3, int par4)
  {
    List list = L().a(par1EnumCreatureType, par2, par3, par4);
    list = ForgeEventFactory.getPotentialSpawns(this, par1EnumCreatureType, par2, par3, par4, list);
    return (list != null) && (!list.isEmpty()) ? (acr)mi.a(s, list) : null;
  }
  



  public void c()
  {
    N = (!h.isEmpty());
    Iterator iterator = h.iterator();
    
    while (iterator.hasNext())
    {
      uf entityplayer = (uf)iterator.next();
      
      if (!entityplayer.bh())
      {
        N = false;
        break;
      }
    }
  }
  
  protected void d()
  {
    N = false;
    Iterator iterator = h.iterator();
    
    while (iterator.hasNext())
    {
      uf entityplayer = (uf)iterator.next();
      
      if (entityplayer.bh())
      {
        entityplayer.a(false, false, true);
      }
    }
    
    Z();
  }
  
  private void Z()
  {
    t.resetRainAndThunder();
  }
  
  public boolean e()
  {
    if ((N) && (!I))
    {
      Iterator iterator = h.iterator();
      
      uf entityplayer;
      do
      {
        if (!iterator.hasNext())
        {
          return true;
        }
        
        entityplayer = (uf)iterator.next();
      }
      while (entityplayer.bD());
      
      return false;
    }
    

    return false;
  }
  





  @SideOnly(Side.CLIENT)
  public void f()
  {
    if (x.d() <= 0)
    {
      x.b(64);
    }
    
    int i = x.c();
    int j = x.e();
    int k = 0;
    
    while (b(i, j) == 0)
    {
      i += s.nextInt(8) - s.nextInt(8);
      j += s.nextInt(8) - s.nextInt(8);
      k++;
      
      if (k == 10000) {
        break;
      }
    }
    

    x.a(i);
    x.c(j);
  }
  




  protected void g()
  {
    super.g();
    int i = 0;
    int j = 0;
    Iterator iterator = G.iterator();
    
    doneChunks.retainAll(G);
    if (doneChunks.size() == G.size())
    {
      doneChunks.clear();
    }
    
    long startTime = System.nanoTime();
    
    while (iterator.hasNext())
    {
      abp chunkcoordintpair = (abp)iterator.next();
      int k = a * 16;
      int l = b * 16;
      C.a("getChunk");
      adr chunk = e(a, b);
      a(k, l, chunk);
      C.c("tickChunk");
      
      if ((System.nanoTime() - startTime <= 4000000L) && (doneChunks.add(chunkcoordintpair)))
      {
        chunk.k();
      }
      C.c("thunder");
      




      if ((t.canDoLightning(chunk)) && (s.nextInt(100000) == 0) && (Q()) && (P()))
      {
        this.k = (this.k * 3 + 1013904223);
        int i1 = this.k >> 2;
        int j1 = k + (i1 & 0xF);
        int k1 = l + (i1 >> 8 & 0xF);
        int l1 = h(j1, k1);
        
        if (F(j1, l1, k1))
        {
          c(new sp(this, j1, l1, k1));
        }
      }
      
      C.c("iceandsnow");
      

      if ((t.canDoRainSnowIce(chunk)) && (s.nextInt(16) == 0))
      {
        this.k = (this.k * 3 + 1013904223);
        int i1 = this.k >> 2;
        int j1 = i1 & 0xF;
        int k1 = i1 >> 8 & 0xF;
        int l1 = h(j1 + k, k1 + l);
        
        if (y(j1 + k, l1 - 1, k1 + l))
        {
          c(j1 + k, l1 - 1, k1 + l, aYcF);
        }
        
        if ((Q()) && (z(j1 + k, l1, k1 + l)))
        {
          c(j1 + k, l1, k1 + l, aXcF);
        }
        
        if (Q())
        {
          acq biomegenbase = a(j1 + k, k1 + l);
          
          if (biomegenbase.d())
          {
            int i2 = a(j1 + k, l1 - 1, k1 + l);
            
            if (i2 != 0)
            {
              aqz.s[i2].g(this, j1 + k, l1 - 1, k1 + l);
            }
          }
        }
      }
      
      C.c("tickTiles");
      ads[] aextendedblockstorage = chunk.i();
      int j1 = aextendedblockstorage.length;
      
      for (int k1 = 0; k1 < j1; k1++)
      {
        ads extendedblockstorage = aextendedblockstorage[k1];
        
        if ((extendedblockstorage != null) && (extendedblockstorage.b()))
        {
          for (int j2 = 0; j2 < 3; j2++)
          {
            this.k = (this.k * 3 + 1013904223);
            int i2 = this.k >> 2;
            int k2 = i2 & 0xF;
            int l2 = i2 >> 8 & 0xF;
            int i3 = i2 >> 16 & 0xF;
            int j3 = extendedblockstorage.a(k2, i3, l2);
            j++;
            aqz block = aqz.s[j3];
            
            if ((block != null) && (block.s()))
            {
              i++;
              block.a(this, k2 + k, i3 + extendedblockstorage.d(), l2 + l, s);
            }
          }
        }
      }
      
      C.b();
    }
  }
  



  public boolean a(int par1, int par2, int par3, int par4)
  {
    acm nextticklistentry = new acm(par1, par2, par3, par4);
    return U.contains(nextticklistentry);
  }
  



  public void a(int par1, int par2, int par3, int par4, int par5)
  {
    a(par1, par2, par3, par4, par5, 0);
  }
  
  public void a(int par1, int par2, int par3, int par4, int par5, int par6)
  {
    acm nextticklistentry = new acm(par1, par2, par3, par4);
    


    byte b0 = 0;
    
    if ((d) && (par4 > 0))
    {
      if (aqz.s[par4].l())
      {
        b0 = 8;
        
        if (e(a - b0, b - b0, c - b0, a + b0, b + b0, c + b0))
        {
          int k1 = a(a, b, c);
          
          if ((k1 == d) && (k1 > 0))
          {
            aqz.s[k1].a(this, a, b, c, s);
          }
        }
        
        return;
      }
      
      par5 = 1;
    }
    
    if (e(par1 - b0, par2 - b0, par3 - b0, par1 + b0, par2 + b0, par3 + b0))
    {
      if (par4 > 0)
      {
        nextticklistentry.a(par5 + x.f());
        nextticklistentry.a(par6);
      }
      
      if (!L.contains(nextticklistentry))
      {
        L.add(nextticklistentry);
        M.add(nextticklistentry);
      }
    }
  }
  



  public void b(int par1, int par2, int par3, int par4, int par5, int par6)
  {
    acm nextticklistentry = new acm(par1, par2, par3, par4);
    nextticklistentry.a(par6);
    
    if (par4 > 0)
    {
      nextticklistentry.a(par5 + x.f());
    }
    
    if (!L.contains(nextticklistentry))
    {
      L.add(nextticklistentry);
      M.add(nextticklistentry);
    }
  }
  



  public void h()
  {
    if ((h.isEmpty()) && (getPersistentChunks().isEmpty()))
    {
      if (O++ < 1200) {}


    }
    else
    {

      i();
    }
    
    super.h();
  }
  



  public void i()
  {
    O = 0;
  }
  



  public boolean a(boolean par1)
  {
    int i = M.size();
    
    if (i != L.size())
    {
      throw new IllegalStateException("TickNextTick list out of synch");
    }
    

    if (i > 1000)
    {
      i = 1000;
    }
    
    C.a("cleaning");
    

    for (int j = 0; j < i; j++)
    {
      acm nextticklistentry = (acm)M.first();
      
      if ((!par1) && (e > x.f())) {
        break;
      }
      

      M.remove(nextticklistentry);
      L.remove(nextticklistentry);
      U.add(nextticklistentry);
    }
    
    C.b();
    C.a("ticking");
    Iterator iterator = U.iterator();
    
    while (iterator.hasNext())
    {
      acm nextticklistentry = (acm)iterator.next();
      iterator.remove();
      


      byte b0 = 0;
      
      if (e(a - b0, b - b0, c - b0, a + b0, b + b0, c + b0))
      {
        int k = a(a, b, c);
        
        if ((k > 0) && (aqz.b(k, d)))
        {
          try
          {
            aqz.s[k].a(this, a, b, c, s);
          }
          catch (Throwable throwable)
          {
            b crashreport = b.a(throwable, "Exception while ticking a block");
            m crashreportcategory = crashreport.a("Block being ticked");
            
            int l;
            try
            {
              l = h(a, b, c);
            }
            catch (Throwable throwable1)
            {
              l = -1;
            }
            
            m.a(crashreportcategory, a, b, c, k, l);
            throw new u(crashreport);
          }
        }
      }
      else
      {
        a(a, b, c, d, 0);
      }
    }
    
    C.b();
    U.clear();
    return !M.isEmpty();
  }
  

  public List a(adr par1Chunk, boolean par2)
  {
    ArrayList arraylist = null;
    abp chunkcoordintpair = par1Chunk.l();
    int i = (a << 4) - 2;
    int j = i + 16 + 2;
    int k = (b << 4) - 2;
    int l = k + 16 + 2;
    
    for (int i1 = 0; i1 < 2; i1++)
    {
      Iterator iterator;
      Iterator iterator;
      if (i1 == 0)
      {
        iterator = M.iterator();
      }
      else
      {
        iterator = U.iterator();
        
        if (!U.isEmpty())
        {
          System.out.println(U.size());
        }
      }
      
      while (iterator.hasNext())
      {
        acm nextticklistentry = (acm)iterator.next();
        
        if ((a >= i) && (a < j) && (c >= k) && (c < l))
        {
          if (par2)
          {
            L.remove(nextticklistentry);
            iterator.remove();
          }
          
          if (arraylist == null)
          {
            arraylist = new ArrayList();
          }
          
          arraylist.add(nextticklistentry);
        }
      }
    }
    
    return arraylist;
  }
  




  public void a(nn par1Entity, boolean par2)
  {
    if ((!a.X()) && (((par1Entity instanceof rp)) || ((par1Entity instanceof se))))
    {
      par1Entity.x();
    }
    
    if ((!a.Y()) && ((par1Entity instanceof ua)))
    {
      par1Entity.x();
    }
    
    super.a(par1Entity, par2);
  }
  



  protected ado j()
  {
    adw ichunkloader = w.a(t);
    b = new jr(this, ichunkloader, t.c());
    return b;
  }
  



  public List c(int par1, int par2, int par3, int par4, int par5, int par6)
  {
    ArrayList arraylist = new ArrayList();
    
    for (int x = par1 >> 4; x <= par4 >> 4; x++)
    {
      for (int z = par3 >> 4; z <= par6 >> 4; z++)
      {
        adr chunk = e(x, z);
        if (chunk != null)
        {
          for (Object obj : i.values())
          {
            asp entity = (asp)obj;
            if (!entity.r())
            {
              if ((l >= par1) && (m >= par2) && (n >= par3) && (l <= par4) && (m <= par5) && (n <= par6))
              {

                arraylist.add(entity);
              }
            }
          }
        }
      }
    }
    return arraylist;
  }
  



  public boolean a(uf par1EntityPlayer, int par2, int par3, int par4)
  {
    return super.a(par1EntityPlayer, par2, par3, par4);
  }
  
  public boolean canMineBlockBody(uf par1EntityPlayer, int par2, int par3, int par4)
  {
    return !a.a(this, par2, par3, par4, par1EntityPlayer);
  }
  
  protected void a(acd par1WorldSettings)
  {
    if (V == null)
    {
      V = new lm();
    }
    
    if (L == null)
    {
      L = new HashSet();
    }
    
    if (M == null)
    {
      M = new TreeSet();
    }
    
    b(par1WorldSettings);
    super.a(par1WorldSettings);
  }
  



  protected void b(acd par1WorldSettings)
  {
    if (!t.e())
    {
      x.a(0, t.i(), 0);
    }
    else
    {
      y = true;
      acv worldchunkmanager = t.e;
      List list = worldchunkmanager.a();
      Random random = new Random(H());
      aco chunkposition = worldchunkmanager.a(0, 0, 256, list, random);
      int i = 0;
      int j = t.i();
      int k = 0;
      
      if (chunkposition != null)
      {
        i = a;
        k = c;
      }
      else
      {
        Y().b("Unable to find spawn biome");
      }
      
      int l = 0;
      
      while (!t.a(i, k))
      {
        i += random.nextInt(64) - random.nextInt(64);
        k += random.nextInt(64) - random.nextInt(64);
        l++;
        
        if (l == 1000) {
          break;
        }
      }
      

      x.a(i, j, k);
      y = false;
      
      if (par1WorldSettings.c())
      {
        k();
      }
    }
  }
  



  protected void k()
  {
    aey worldgeneratorbonuschest = new aey(ChestGenHooks.getItems("bonusChest", s), ChestGenHooks.getCount("bonusChest", s));
    
    for (int i = 0; i < 10; i++)
    {
      int j = x.c() + s.nextInt(6) - s.nextInt(6);
      int k = x.e() + s.nextInt(6) - s.nextInt(6);
      int l = i(j, k) + 1;
      
      if (worldgeneratorbonuschest.a(this, s, j, l, k)) {
        break;
      }
    }
  }
  




  public t l()
  {
    return t.h();
  }
  


  public void a(boolean par1, lx par2IProgressUpdate)
    throws aca
  {
    if (v.d())
    {
      if (par2IProgressUpdate != null)
      {
        par2IProgressUpdate.a("Saving level");
      }
      
      a();
      
      if (par2IProgressUpdate != null)
      {
        par2IProgressUpdate.c("Saving chunks");
      }
      
      v.a(par1, par2IProgressUpdate);
      MinecraftForge.EVENT_BUS.post(new WorldEvent.Save(this));
    }
  }
  



  public void m()
  {
    if (v.d())
    {
      v.b();
    }
  }
  


  protected void a()
    throws aca
  {
    G();
    w.a(x, a.af().q());
    z.a();
    perWorldStorage.a();
  }
  
  protected void a(nn par1Entity)
  {
    super.a(par1Entity);
    V.a(k, par1Entity);
    nn[] aentity = par1Entity.ao();
    
    if (aentity != null)
    {
      for (int i = 0; i < aentity.length; i++)
      {
        V.a(k, aentity[i]);
      }
    }
  }
  
  public void b(nn par1Entity)
  {
    super.b(par1Entity);
    V.d(k);
    nn[] aentity = par1Entity.ao();
    
    if (aentity != null)
    {
      for (int i = 0; i < aentity.length; i++)
      {
        V.d(k);
      }
    }
  }
  



  public nn a(int par1)
  {
    return (nn)V.a(par1);
  }
  



  public boolean c(nn par1Entity)
  {
    if (super.c(par1Entity))
    {
      a.af().a(u, v, w, 512.0D, t.i, new df(par1Entity));
      return true;
    }
    

    return false;
  }
  




  public void a(nn par1Entity, byte par2)
  {
    ed packet38entitystatus = new ed(k, par2);
    q().b(par1Entity, packet38entitystatus);
  }
  



  public void setEntitySize(nn par1Entity, float par2)
  {
    Packet171EntitySize packet171entitysize = new Packet171EntitySize(par1Entity, par2);
    q().b(par1Entity, packet171entitysize);
  }
  



  public abr a(nn par1Entity, double par2, double par4, double par6, float par8, boolean par9, boolean par10)
  {
    abr explosion = new abr(this, par1Entity, par2, par4, par6, par8);
    a = par9;
    b = par10;
    explosion.a();
    explosion.a(false);
    
    if (!par10)
    {
      h.clear();
    }
    
    Iterator iterator = h.iterator();
    
    while (iterator.hasNext())
    {
      uf entityplayer = (uf)iterator.next();
      
      if (entityplayer.e(par2, par4, par6) < 4096.0D)
      {
        a.b(new ee(par2, par4, par6, par8, h, (atc)explosion.b().get(entityplayer)));
      }
    }
    
    return explosion;
  }
  




  public void d(int par1, int par2, int par3, int par4, int par5, int par6)
  {
    acn blockeventdata = new acn(par1, par2, par3, par4, par5, par6);
    Iterator iterator = R[S].iterator();
    
    acn blockeventdata1;
    do
    {
      if (!iterator.hasNext())
      {
        R[S].add(blockeventdata);
        return;
      }
      
      blockeventdata1 = (acn)iterator.next();
    }
    while (!blockeventdata1.equals(blockeventdata));
  }
  



  private void aa()
  {
    while (!R[S].isEmpty())
    {
      int i = S;
      S ^= 0x1;
      Iterator iterator = R[i].iterator();
      
      while (iterator.hasNext())
      {
        acn blockeventdata = (acn)iterator.next();
        
        if (a(blockeventdata))
        {
          a.af().a(blockeventdata.a(), blockeventdata.b(), blockeventdata.c(), 64.0D, t.i, new gf(blockeventdata.a(), blockeventdata.b(), blockeventdata.c(), blockeventdata.f(), blockeventdata.d(), blockeventdata.e()));
        }
      }
      
      R[i].clear();
    }
  }
  



  private boolean a(acn par1BlockEventData)
  {
    int i = a(par1BlockEventData.a(), par1BlockEventData.b(), par1BlockEventData.c());
    return i == par1BlockEventData.f() ? aqz.s[i].b(this, par1BlockEventData.a(), par1BlockEventData.b(), par1BlockEventData.c(), par1BlockEventData.d(), par1BlockEventData.e()) : false;
  }
  



  public void n()
  {
    w.a();
  }
  



  protected void o()
  {
    boolean flag = Q();
    super.o();
    
    if (flag != Q())
    {
      if (flag)
      {
        a.af().a(new ef(2, 0));
      }
      else
      {
        a.af().a(new ef(1, 0));
      }
    }
  }
  



  public MinecraftServer p()
  {
    return a;
  }
  



  public jm q()
  {
    return J;
  }
  
  public jp s()
  {
    return K;
  }
  
  public acj t()
  {
    return P;
  }
  
  public File getChunkSaveLocation()
  {
    return b.e).d;
  }
}
