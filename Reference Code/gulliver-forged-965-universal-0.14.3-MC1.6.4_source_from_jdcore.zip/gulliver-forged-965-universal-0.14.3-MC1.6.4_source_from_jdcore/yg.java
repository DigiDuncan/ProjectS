import java.util.Iterator;
import java.util.List;









public class yg
  extends yc
{
  public yg(int par1)
  {
    super(par1);
    a(ww.i);
  }
  




  public boolean a(ye par1ItemStack, uf par2EntityPlayer, abw par3World, int par4, int par5, int par6, int par7, float par8, float par9, float par10)
  {
    int i1 = par3World.a(par4, par5, par6);
    
    if ((aqz.s[i1] != null) && (aqz.s[i1].d() == 11))
    {
      if (I)
      {
        return true;
      }
      

      a(par2EntityPlayer, par3World, par4, par5, par6);
      return true;
    }
    


    return false;
  }
  

  public static boolean a(uf par0EntityPlayer, abw par1World, int par2, int par3, int par4)
  {
    oe entityleashknot = oe.b(par1World, par2, par3, par4);
    boolean flag = false;
    double d0 = 7.0D * par0EntityPlayer.getSizeMultiplierRoot();
    List list = par1World.a(og.class, asx.a().a(par2 - d0, par3 - d0, par4 - d0, par2 + d0, par3 + d0, par4 + d0));
    
    if (list != null)
    {
      Iterator iterator = list.iterator();
      
      while (iterator.hasNext())
      {
        og entityliving = (og)iterator.next();
        
        if ((entityliving.bH()) && (entityliving.bI() == par0EntityPlayer))
        {
          if (entityleashknot == null)
          {
            entityleashknot = oe.a(par1World, par2, par3, par4);
          }
          
          entityliving.b(entityleashknot, true);
          flag = true;
        }
      }
    }
    
    return flag;
  }
}
