








public class qs
  extends ps
{
  tf a;
  of b;
  
  public qs(tf par1EntityCreeper)
  {
    a = par1EntityCreeper;
    a(1);
  }
  



  public boolean a()
  {
    of entitylivingbase = a.m();
    return (a.bV() > 0) || ((entitylivingbase != null) && (a.e(entitylivingbase) < 9.0D * a.getSizeMultiplier()));
  }
  



  public void c()
  {
    a.k().h();
    b = a.m();
  }
  



  public void d()
  {
    b = null;
  }
  



  public void e()
  {
    if (b == null)
    {
      a.a(-1);
    }
    else if (a.e(b) > 49.0D * a.getSizeMultiplier())
    {
      a.a(-1);
    }
    else if (!a.l().a(b))
    {
      a.a(-1);
    }
    else
    {
      a.a(1);
    }
  }
}
