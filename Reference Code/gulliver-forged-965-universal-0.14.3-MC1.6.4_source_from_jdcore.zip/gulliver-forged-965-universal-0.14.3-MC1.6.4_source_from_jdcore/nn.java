import cpw.mods.fml.common.FMLLog;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import gulliver.EntityDamageSourcePassive;
import gulliver.api.IResizeableEntity;
import gulliver.common.GulliverEnvoy;
import gulliver.common.GulliverOMHelper;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.UUID;
import net.minecraft.server.MinecraftServer;
import net.minecraftforge.common.IExtendedEntityProperties;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.EventBus;
import net.minecraftforge.event.entity.EntityEvent.EntityConstructing;





























































































































































public abstract class nn
  implements IResizeableEntity
{
  private static int b;
  public int k;
  public double l;
  public boolean m;
  public nn n;
  public nn riddenByEntity2;
  public nn heldEntity;
  public nn holdingEntity;
  public nn o;
  public boolean p;
  public abw q;
  public double r;
  public double s;
  public double t;
  public double u;
  public double v;
  public double w;
  public double x;
  public double y;
  public double z;
  public float A;
  public float B;
  public float C;
  public float D;
  public final asx E;
  public boolean F;
  public boolean G;
  public boolean H;
  public boolean I;
  public boolean J;
  protected boolean K;
  public boolean L;
  public boolean M;
  public float N;
  public float O;
  public float P;
  public float Q;
  public float R;
  public float S;
  public float T;
  private int c;
  public double U;
  public double V;
  public double W;
  public float X;
  public float Y;
  public boolean Z;
  public float aa;
  protected Random ab;
  public int ac;
  public int ad;
  private int d;
  protected boolean ae;
  public int af;
  private boolean e;
  protected boolean ag;
  protected oo ah;
  private double f;
  private double g;
  public boolean ai;
  public int aj;
  public int ak;
  public int al;
  @SideOnly(Side.CLIENT)
  public int bZ;
  @SideOnly(Side.CLIENT)
  public int ca;
  @SideOnly(Side.CLIENT)
  public int cb;
  public boolean am;
  public boolean an;
  public int ao;
  protected boolean ap;
  protected int aq;
  public int ar;
  protected int as;
  private boolean h;
  private UUID i;
  public nr at;
  private by customEntityData;
  public boolean captureDrops = false;
  public ArrayList<ss> capturedDrops = new ArrayList();
  
  private UUID persistentID;
  
  private HashMap<String, IExtendedEntityProperties> extendedProperties;
  
  protected float sizeMultiplier;
  
  protected float sizeMultiplierRoot;
  
  public static final float maxSizeMultiplier = 8.0F;
  
  public static final float minSizeMultiplier = 0.125F;
  public static final float defaultMinTargetSize = 0.3F;
  public static final float defaultMaxTargetSize = 20.0F;
  
  public void setSizeMultiplier(float f)
  {
    if (f < 0.125F)
    {
      sizeMultiplier = 0.125F;
    }
    else if (f > 8.0F)
    {
      sizeMultiplier = 8.0F;
    }
    else
    {
      sizeMultiplier = f;
    }
    
    sizeMultiplierRoot = ls.c(sizeMultiplier);
  }
  
  public float getSizeMultiplier()
  {
    return sizeMultiplier;
  }
  

  public float getSizeMultiplierRoot()
  {
    return sizeMultiplierRoot;
  }
  
  public float getRangeMultiplier()
  {
    if (getSizeMultiplier() >= 1.0F)
    {
      return getSizeMultiplier();
    }
    

    return getSizeMultiplierRoot();
  }
  

  public float getSizeMovementMultiplier()
  {
    if (!isWeighted())
    {
      return getSizeMultiplierRoot();
    }
    

    return getSizeMultiplier();
  }
  

  public float getMinTargetSize()
  {
    return 0.3F;
  }
  
  public float getMaxTargetSize()
  {
    return 20.0F;
  }
  

  public void doResize(float f, boolean reposition)
  {
    setSizeMultiplier(f);
  }
  


  public void halveSize() {}
  

  public void doubleSize() {}
  

  public boolean isTiny()
  {
    return getSizeMultiplier() < 0.3F;
  }
  
  public boolean isExtraTiny()
  {
    return getSizeMultiplier() < 0.15F;
  }
  
  public boolean isHuge()
  {
    return getSizeMultiplier() >= 2.4F;
  }
  
  public float getStepHeight()
  {
    return Y;
  }
  


  public int getStepSide()
  {
    return 0;
  }
  
  public boolean isResizable()
  {
    return false;
  }
  
  public nn(abw par1World)
  {
    k = (b++);
    l = 1.0D;
    E = asx.a(0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D);
    L = true;
    O = 0.6F;
    P = 1.8F;
    c = 1;
    ab = new Random();
    ad = 1;
    e = true;
    ah = new oo();
    i = UUID.randomUUID();
    at = nr.b;
    q = par1World;
    sizeMultiplier = 1.0F;
    sizeMultiplierRoot = 1.0F;
    b(0.0D, 0.0D, 0.0D);
    
    if (par1World != null)
    {
      ar = t.i;
    }
    
    ah.a(0, Byte.valueOf((byte)0));
    ah.a(1, Short.valueOf((short)300));
    a();
    
    extendedProperties = new HashMap();
    
    MinecraftForge.EVENT_BUS.post(new EntityEvent.EntityConstructing(this));
    
    for (IExtendedEntityProperties props : extendedProperties.values())
    {
      props.init(this, par1World);
    }
  }
  
  protected abstract void a();
  
  public Random getEntityRNG()
  {
    return ab;
  }
  
  public oo v()
  {
    return ah;
  }
  
  public boolean equals(Object par1Obj)
  {
    return k == k;
  }
  
  public int hashCode()
  {
    return k;
  }
  





  @SideOnly(Side.CLIENT)
  protected void w()
  {
    if (q != null)
    {
      while (v > 0.0D)
      {
        b(u, v, w);
        
        if (q.a(this, E).isEmpty()) {
          break;
        }
        

        v += 1.0D;
      }
      
      x = (this.y = this.z = 0.0D);
      B = 0.0F;
    }
  }
  



  public void x()
  {
    M = true;
  }
  





  public void a(float par1, float par2)
  {
    if ((par1 != O) || (par2 != P))
    {
      float f2 = O;
      O = par1;
      P = par2;
      b(u, v, w);
      

      if ((!e) && (!q.I) && ((this instanceof nk)) && (((nk)this).g_()))
      {

        GulliverEnvoy.resizeCollision((nk)this, f2, O);
      }
    }
    
    float f2 = par1 % 2.0F;
    
    if (f2 < 0.375D)
    {
      at = nr.a;
    }
    else if (f2 < 0.75D)
    {
      at = nr.b;
    }
    else if (f2 < 1.0D)
    {
      at = nr.c;
    }
    else if (f2 < 1.375D)
    {
      at = nr.d;
    }
    else if (f2 < 1.75D)
    {
      at = nr.e;
    }
    else
    {
      at = nr.f;
    }
  }
  



  protected void b(float par1, float par2)
  {
    A = (par1 % 360.0F);
    B = (par2 % 360.0F);
  }
  



  public void b(double par1, double par3, double par5)
  {
    u = par1;
    v = par3;
    w = par5;
    float f = O / 2.0F;
    float f1 = P;
    E.b(par1 - f, par3 - N + X, par5 - f, par1 + f, par3 - N + X + f1, par5 + f);
  }
  





  @SideOnly(Side.CLIENT)
  public void c(float par1, float par2)
  {
    float f2 = B;
    float f3 = A;
    A = ((float)(A + par1 * 0.15D));
    B = ((float)(B - par2 * 0.15D));
    
    if (B < -90.0F)
    {
      B = -90.0F;
    }
    
    if (B > 90.0F)
    {
      B = 90.0F;
    }
    
    D += B - f2;
    C += A - f3;
  }
  



  public void l_()
  {
    y();
  }
  



  public void y()
  {
    q.C.a("entityBaseTick");
    
    if ((o != null) && (o.M))
    {
      a(null);
    }
    
    if ((heldEntity != null) && (heldEntity.M))
    {
      heldEntity.holdingEntity = null;
      heldEntity = null;
    }
    
    Q = R;
    r = u;
    s = v;
    t = w;
    D = B;
    C = A;
    

    if ((!q.I) && ((q instanceof js)))
    {
      q.C.a("portal");
      MinecraftServer minecraftserver = ((js)q).p();
      int i = z();
      
      if (ap)
      {
        if (minecraftserver.u())
        {
          if ((o == null) && (aq++ >= i))
          {
            aq = i;
            ao = ac();
            byte b0;
            byte b0;
            if (q.t.i == -1)
            {
              b0 = 0;
            }
            else
            {
              b0 = -1;
            }
            
            b(b0);
          }
          
          ap = false;
        }
      }
      else
      {
        if (aq > 0)
        {
          aq -= 4;
        }
        
        if (aq < 0)
        {
          aq = 0;
        }
      }
      
      if (ao > 0)
      {
        ao -= 1;
      }
      
      q.C.b();
    }
    
    if ((ai()) && (!H()))
    {
      int j = ls.c(u);
      int i = ls.c(v - 0.20000000298023224D - N);
      int k = ls.c(w);
      int l = q.a(j, i, k);
      
      if ((l > 0) && ((getSizeMultiplier() >= 0.5F) || (ab.nextInt((int)(1.0F / getSizeMultiplier())) == 0)))
      {
        int cnt = getSizeMultiplierRoot() <= 1.0F ? 1 : (int)getSizeMultiplierRoot();
        
        for (int p = 0; p < cnt; p++)
        {
          q.a("tilecrack_" + l + "_" + q.h(j, i, k), u + (ab.nextFloat() - 0.5D) * O, E.b + 0.1D * getSizeMultiplier(), w + (ab.nextFloat() - 0.5D) * O, -x * 4.0D, 1.5D * getSizeMultiplier(), -z * 4.0D);
        }
      }
    }
    
    I();
    
    if (q.I)
    {
      d = 0;
    }
    else if (d > 0)
    {
      if (ag)
      {
        d -= 4;
        
        if (d < 0)
        {
          d = 0;
        }
      }
      else
      {
        if (d % 20 == 0)
        {
          a(nb.b, 1.0F);
        }
        
        d -= 1;
      }
    }
    
    if (J())
    {
      A();
      T *= 0.5F;
    }
    
    if (v < -64.0D)
    {
      C();
    }
    
    if (!q.I)
    {
      a(0, d > 0);
    }
    
    e = false;
    q.C.b();
  }
  



  public int z()
  {
    return 0;
  }
  



  protected void A()
  {
    if (!ag)
    {
      a(nb.c, 4.0F);
      d(15);
    }
  }
  



  public void d(int par1)
  {
    int j = par1 * 20;
    j = abg.a(this, j);
    
    if (d < j)
    {
      d = j;
    }
  }
  



  public void B()
  {
    d = 0;
  }
  



  protected void C()
  {
    x();
  }
  



  public boolean c(double par1, double par3, double par5)
  {
    asx axisalignedbb = E.c(par1, par3, par5);
    List list = q.a(this, axisalignedbb);
    return list.isEmpty();
  }
  



  public void d(double par1, double par3, double par5)
  {
    float sizemult = getSizeMultiplier();
    float sizeroot = getSizeMultiplierRoot();
    
    if (Z)
    {
      E.d(par1, par3, par5);
      u = ((E.a + E.d) / 2.0D);
      v = (E.b + N - X);
      w = ((E.c + E.f) / 2.0D);
    }
    else
    {
      q.C.a("move");
      X *= 0.4F;
      double d3 = u;
      double d4 = v;
      double d5 = w;
      
      if (K)
      {
        K = false;
        
        if (!isHuge())
        {
          par1 *= 0.25D;
          par3 *= 0.05000000074505806D;
          par5 *= 0.25D;
          
          if (isTiny())
          {
            par1 *= sizeroot;
            par3 *= sizeroot;
            par5 *= sizeroot;
          }
          
          x = 0.0D;
          y = 0.0D;
          z = 0.0D;
        }
      }
      
      double d6 = par1;
      double d7 = par3;
      double d8 = par5;
      asx axisalignedbb = E.c();
      boolean flag = (F) && (ah()) && ((this instanceof uf));
      
      if (flag)
      {


        for (double d9 = 0.05D; (par1 != 0.0D) && (q.a(this, E.c(par1, -1.0D * sizemult, 0.0D)).isEmpty()); d6 = par1)
        {
          if ((par1 < d9) && (par1 >= -d9))
          {
            par1 = 0.0D;
          }
          else if (par1 > 0.0D)
          {
            par1 -= d9;
          }
          else
          {
            par1 += d9;
          }
        }
        for (; 
            (par5 != 0.0D) && (q.a(this, E.c(0.0D, -1.0D * sizemult, par5)).isEmpty()); d8 = par5)
        {
          if ((par5 < d9) && (par5 >= -d9))
          {
            par5 = 0.0D;
          }
          else if (par5 > 0.0D)
          {
            par5 -= d9;
          }
          else
          {
            par5 += d9;
          }
        }
        
        while ((par1 != 0.0D) && (par5 != 0.0D) && (q.a(this, E.c(par1, -1.0D * sizemult, par5)).isEmpty()))
        {
          if ((par1 < d9) && (par1 >= -d9))
          {
            par1 = 0.0D;
          }
          else if (par1 > 0.0D)
          {
            par1 -= d9;
          }
          else
          {
            par1 += d9;
          }
          
          if ((par5 < d9) && (par5 >= -d9))
          {
            par5 = 0.0D;
          }
          else if (par5 > 0.0D)
          {
            par5 -= d9;
          }
          else
          {
            par5 += d9;
          }
          
          d6 = par1;
          d8 = par5;
        }
      }
      
      List list = q.a(this, E.a(par1, par3, par5));
      
      for (int i = 0; i < list.size(); i++)
      {
        par3 = ((asx)list.get(i)).b(E, par3);
      }
      
      E.d(0.0D, par3, 0.0D);
      
      if ((!L) && (d7 != par3))
      {
        par5 = 0.0D;
        par3 = 0.0D;
        par1 = 0.0D;
      }
      
      boolean flag1 = (F) || ((d7 != par3) && (d7 < 0.0D));
      

      for (int j = 0; j < list.size(); j++)
      {
        par1 = ((asx)list.get(j)).a(E, par1);
      }
      
      E.d(par1, 0.0D, 0.0D);
      
      if ((!L) && (d6 != par1))
      {
        par5 = 0.0D;
        par3 = 0.0D;
        par1 = 0.0D;
      }
      
      for (j = 0; j < list.size(); j++)
      {
        par5 = ((asx)list.get(j)).c(E, par5);
      }
      
      E.d(0.0D, 0.0D, par5);
      
      if ((!L) && (d8 != par5))
      {
        par5 = 0.0D;
        par3 = 0.0D;
        par1 = 0.0D;
      }
      





      if ((getStepHeight() > 0.0F) && (flag1)) { if (!flag) { if (X >= (sizemult < 1.0F ? 0.05F * sizemult : 0.05F)) {} } else if ((d6 != par1) || (d8 != par5))
        {
          double d12 = par1;
          double d10 = par3;
          double d11 = par5;
          par1 = d6;
          par3 = getStepHeight();
          par5 = d8;
          asx axisalignedbb1 = E.c();
          E.d(axisalignedbb);
          list = q.a(this, E.a(d6, par3, d8));
          
          for (int k = 0; k < list.size(); k++)
          {
            par3 = ((asx)list.get(k)).b(E, par3);
          }
          
          E.d(0.0D, par3, 0.0D);
          
          if ((!L) && (d7 != par3))
          {
            par5 = 0.0D;
            par3 = 0.0D;
            par1 = 0.0D;
          }
          
          for (k = 0; k < list.size(); k++)
          {
            par1 = ((asx)list.get(k)).a(E, par1);
          }
          
          E.d(par1, 0.0D, 0.0D);
          
          if ((!L) && (d6 != par1))
          {
            par5 = 0.0D;
            par3 = 0.0D;
            par1 = 0.0D;
          }
          
          for (k = 0; k < list.size(); k++)
          {
            par5 = ((asx)list.get(k)).c(E, par5);
          }
          
          E.d(0.0D, 0.0D, par5);
          
          if ((!L) && (d8 != par5))
          {
            par5 = 0.0D;
            par3 = 0.0D;
            par1 = 0.0D;
          }
          
          if ((!L) && (d7 != par3))
          {
            par5 = 0.0D;
            par3 = 0.0D;
            par1 = 0.0D;
          }
          else
          {
            par3 = -getStepHeight();
            
            for (k = 0; k < list.size(); k++)
            {
              par3 = ((asx)list.get(k)).b(E, par3);
            }
            
            E.d(0.0D, par3, 0.0D);
          }
          
          if (d12 * d12 + d11 * d11 >= par1 * par1 + par5 * par5)
          {
            par1 = d12;
            par3 = d10;
            par5 = d11;
            E.d(axisalignedbb1);
          }
        }
      }
      q.C.b();
      q.C.a("rest");
      u = ((E.a + E.d) / 2.0D);
      v = (E.b + N - X);
      w = ((E.c + E.f) / 2.0D);
      G = ((d6 != par1) || (d8 != par5));
      H = (d7 != par3);
      F = ((d7 != par3) && (d7 < 0.0D));
      I = ((G) || (H));
      a(par3, F);
      
      if (d6 != par1)
      {
        x = 0.0D;
      }
      
      if (d7 != par3)
      {
        y = 0.0D;
      }
      
      if (d8 != par5)
      {
        z = 0.0D;
      }
      
      double d12 = u - d3;
      double d10 = v - d4;
      double d11 = w - d5;
      
      if ((e_()) && (!flag) && (o == null) && (holdingEntity == null))
      {
        int l = ls.c(u);
        int k = ls.c(v - 0.20000000298023224D - N);
        int i1 = ls.c(w);
        int j1 = q.a(l, k, i1);
        
        if (j1 == 0)
        {
          int k1 = q.e(l, k - 1, i1);
          
          if ((k1 == 11) || (k1 == 32) || (k1 == 21))
          {
            j1 = q.a(l, k - 1, i1);
          }
        }
        boolean tinyladder = false;
        if (((this instanceof of)) && (isTiny()))
        {
          tinyladder = ((of)this).e();
          if (!isSticky())
          {
            if ((tinyladder) || (ladderRate > 0.0F))
            {
              j1 = ladderBlockId;
            }
            else if (j1 != aKcF)
            {
              d10 = 0.0D;
            }
          }
          else if (ladderRate > 0.0F)
          {
            tinyladder = true;
          }
        }
        else if ((j1 != aKcF) && (!isSticky()))
        {
          d10 = 0.0D;
        }
        
        if ((!q.I) && ((this instanceof of)) && (isHuge()) && (F) && (!ah()) && (GulliverEnvoy.canSizeGrief(this)))
        {

          GulliverEnvoy.checkSupportingBlocksForHuge(this, ab);
        }
        
        R = ((float)(R + ls.a(d12 * d12 + d11 * d11) * 0.6D / getSizeMovementMultiplier()));
        S = ((float)(S + ls.a(d12 * d12 + d10 * d10 + d11 * d11) * 0.6D / getSizeMovementMultiplier()));
        
        if ((S > c) && ((j1 > 0) || ((isSticky()) && (isTiny()))))
        {
          c = ((int)S + 1);
          
          if (H())
          {
            float f = ls.a(x * x * 0.20000000298023224D + y * y + z * z * 0.20000000298023224D) * 0.35F;
            
            if (f > 1.0F * getSizeMultiplierRoot())
            {
              f = 1.0F * getSizeMultiplierRoot();
            }
            
            a("liquid.swim", f / getSizeMultiplierRoot(), 1.0F + (ab.nextFloat() - ab.nextFloat()) * 0.4F);
          }
          
          if ((isSticky()) && ((G) || (tinyladder) || ((j1 > 0) && (aqz.s[j1] != null) && (!(aqz.s[j1] instanceof apc)) && ((F) || (GulliverEnvoy.isEntityIntersectingPlant(this))))))
          {
            a("mob.slime.small", 0.25F, 1.0F);
          }
          
          if (j1 > 0)
          {
            if (!isSticky())
            {
              if (isWeighted())
              {
                a("mob.irongolem.walk", 0.05F, 1.0F);
              }
              a(l, k, i1, j1);
            }
            
            if ((!isHuge()) || (getStepSide() == 0))
            {
              aqz.s[j1].b(q, l, k, i1, this);
            }
            
            if (!q.I)
            {
              if ((isHuge()) && ((!(this instanceof uf)) || (bG.e)))
              {

                GulliverEnvoy.leaveHugeFootprints(this);
              }
              
              if (!ah())
              {
                GulliverEnvoy.stepOnSmallerEntities(this);
              }
            }
          }
        }
      }
      
      try
      {
        D();
      }
      catch (Throwable throwable)
      {
        b crashreport = b.a(throwable, "Checking entity tile collision");
        m crashreportcategory = crashreport.a("Entity being checked for collision");
        a(crashreportcategory);
        throw new u(crashreport);
      }
      
      boolean flag2 = G();
      
      if (q.e(E.e(0.001D, 0.001D, 0.001D)))
      {
        e(1);
        
        if (!flag2)
        {
          d += 1;
          
          if (d == 0)
          {
            d(8);
          }
        }
      }
      else if (d <= 0)
      {
        d = (-ad);
      }
      
      if ((flag2) && (d > 0))
      {
        a("random.fizz", 0.7F, 1.6F + (ab.nextFloat() - ab.nextFloat()) * 0.4F);
        d = (-ad);
      }
      
      q.C.b();
    }
  }
  

  protected boolean isEntityAttached(nn par1Entity)
  {
    return (n == par1Entity) || (riddenByEntity2 == par1Entity) || (heldEntity == par1Entity);
  }
  

  protected nn getEntityAttachedTo()
  {
    return holdingEntity != null ? holdingEntity : o != null ? o : null;
  }
  
  public boolean collideableRideEntity(nn par1Entity)
  {
    if ((par1Entity.M()) && (!isEntityAttached(par1Entity)) && (o != par1Entity))
    {

      if (((par1Entity.getEntityAttachedTo() == null) || (par1Entity.getEntityAttachedTo().getEntityAttachedTo() == null) || (O * 0.5F <= O)) && ((getEntityAttachedTo() == null) || (getEntityAttachedTo().getEntityAttachedTo() == null) || (O * 0.5F <= O)))
      {
        return true;
      }
    }
    
    return false;
  }
  



  public boolean isEntityInRelativeSizeRange(nn par1Entity, float min, float max)
  {
    return ((min <= 0.0F) || (par1Entity.getSizeMultiplier() / getSizeMultiplier() >= min)) && ((max <= 0.0F) || (par1Entity.getSizeMultiplier() / getSizeMultiplier() <= max));
  }
  
  public boolean isQuiteSmallerThan(nn par1Entity)
  {
    return !par1Entity.isEntityInRelativeSizeRange(this, 0.4F, 0.0F);
  }
  
  public boolean isTinierThan(nn par1Entity)
  {
    return !par1Entity.isEntityInRelativeSizeRange(this, 0.3F, 0.0F);
  }
  
  public boolean isMuchTinierThan(nn par1Entity)
  {
    return !par1Entity.isEntityInRelativeSizeRange(this, 0.15F, 0.0F);
  }
  
  public boolean canSquish(nn par1Entity)
  {
    return (!GulliverEnvoy.isClientsideEntity(this)) && (!(this instanceof oa)) && ((par1Entity instanceof of)) && (P > P * 1.5F) && (par1Entity.isQuiteSmallerThan(this));
  }
  



  protected void D()
  {
    int i = ls.c(E.a + 0.001D);
    int j = ls.c(E.b + 0.001D);
    int k = ls.c(E.c + 0.001D);
    int l = ls.c(E.d - 0.001D);
    int i1 = ls.c(E.e - 0.001D);
    int j1 = ls.c(E.f - 0.001D);
    
    if (q.e(i, j, k, l, i1, j1))
    {
      for (int k1 = i; k1 <= l; k1++)
      {
        for (int l1 = j; l1 <= i1; l1++)
        {
          for (int i2 = k; i2 <= j1; i2++)
          {
            int j2 = q.a(k1, l1, i2);
            
            if (j2 > 0)
            {
              try
              {
                aqz.s[j2].a(q, k1, l1, i2, this);
              }
              catch (Throwable throwable)
              {
                b crashreport = b.a(throwable, "Colliding entity with tile");
                m crashreportcategory = crashreport.a("Tile being collided with");
                m.a(crashreportcategory, k1, l1, i2, j2, q.h(k1, l1, i2));
                throw new u(crashreport);
              }
            }
          }
        }
      }
    }
  }
  



  protected void a(int par1, int par2, int par3, int par4)
  {
    ard stepsound = scS;
    
    if (q.a(par1, par2 + 1, par3) == aXcF)
    {
      stepsound = aXcS;
      a(stepsound.e(), stepsound.c() * 0.15F, stepsound.d());
    }
    else if (!scU.d())
    {
      a(stepsound.e(), stepsound.c() * 0.15F, stepsound.d());
    }
  }
  
  public void a(String par1Str, float par2, float par3)
  {
    q.a(this, par1Str, par2 * getSizeMultiplierRoot(), par3);
  }
  




  protected boolean e_()
  {
    return true;
  }
  




  protected void a(double par1, boolean par3)
  {
    if (par3)
    {
      if (T > 0.0F)
      {
        b(T);
        T = 0.0F;
      }
    }
    else if (par1 < 0.0D)
    {
      T = ((float)(T - par1));
    }
  }
  



  public asx E()
  {
    return null;
  }
  




  protected void e(int par1)
  {
    if (!ag)
    {
      a(nb.a, par1);
    }
  }
  
  public final boolean F()
  {
    return ag;
  }
  



  protected void b(float par1)
  {
    if (n != null)
    {
      n.b(par1);
    }
    
    if (riddenByEntity2 != null)
    {
      riddenByEntity2.b(par1);
    }
  }
  



  public boolean G()
  {
    return (ae) || (q.F(ls.c(u), ls.c(v), ls.c(w))) || (q.F(ls.c(u), ls.c(v + P), ls.c(w)));
  }
  




  public boolean H()
  {
    return ae;
  }
  



  public boolean I()
  {
    if (q.a(E.b(0.0D, -0.4000000059604645D * getSizeMultiplier(), 0.0D).e(0.001D, 0.001D, 0.001D), akc.h, this))
    {
      if ((!ae) && (!e))
      {
        float f = ls.a(x * x * 0.20000000298023224D + y * y + z * z * 0.20000000298023224D) * 0.2F;
        
        if (f > 1.0F * getSizeMultiplierRoot())
        {
          f = 1.0F * getSizeMultiplierRoot();
        }
        
        a("liquid.splash", f / getSizeMultiplierRoot(), 1.0F + (ab.nextFloat() - ab.nextFloat()) * 0.4F);
        float f1 = ls.c(E.b);
        



        for (int i = 0; i < 1.0F + O * 20.0F; i++)
        {
          float f2 = (ab.nextFloat() * 2.0F - 1.0F) * O;
          float f3 = (ab.nextFloat() * 2.0F - 1.0F) * O;
          q.a("bubble", u + f2, f1 + 1.0F, w + f3, x, y - ab.nextFloat() * 0.2F, z);
        }
        
        for (i = 0; i < 1.0F + O * 20.0F; i++)
        {
          float f2 = (ab.nextFloat() * 2.0F - 1.0F) * O;
          float f3 = (ab.nextFloat() * 2.0F - 1.0F) * O;
          q.a("splash", u + f2, f1 + 1.0F, w + f3, x, y, z);
        }
      }
      
      T = 0.0F;
      ae = true;
      d = 0;
    }
    else
    {
      ae = false;
    }
    
    return ae;
  }
  



  public boolean a(akc par1Material)
  {
    double d0 = v + f();
    int i = ls.c(u);
    int j = ls.d(ls.c(d0));
    int k = ls.c(w);
    int l = q.a(i, j, k);
    
    aqz block = aqz.s[l];
    if ((block != null) && (cU == par1Material))
    {
      double filled = block.getFilledPercentage(q, i, j, k);
      if (filled < 0.0D)
      {
        filled *= -1.0D;
        
        return d0 > j + (1.0D - filled);
      }
      

      return d0 < j + filled;
    }
    
    if ((l != 0) && (l == bLcF) && (par1Material == akc.h) && (q.h(i, j, k) > 0))
    {

      float f1 = q.h(i, j, k) * 0.1875F + 0.3125F + 0.15625F;
      return d0 < j + f1;
    }
    

    return false;
  }
  

  public float f()
  {
    return 0.0F;
  }
  



  public boolean J()
  {
    double f = getSizeMultiplier() >= 1.0F ? 1.0D : getSizeMultiplier();
    return q.a(E.b(-0.10000000149011612D * f, -0.4000000059604645D * f, -0.10000000149011612D * f), akc.i);
  }
  



  public void a(float par1, float par2, float par3)
  {
    float f3 = par1 * par1 + par2 * par2;
    
    if ((f3 >= 1.0E-4F) || ((isTiny()) && (f3 >= 1.0E-7F)))
    {
      f3 = ls.c(f3);
      
      if (f3 < 1.0F)
      {
        f3 = 1.0F;
      }
      
      f3 = par3 / f3;
      par1 *= f3;
      par2 *= f3;
      float f4 = ls.a(A * 3.1415927F / 180.0F);
      float f5 = ls.b(A * 3.1415927F / 180.0F);
      x += par1 * f5 - par2 * f4;
      z += par2 * f5 + par1 * f4;
    }
  }
  
  @SideOnly(Side.CLIENT)
  public int c(float par1)
  {
    int i = ls.c(u);
    int j = ls.c(w);
    
    if (q.f(i, 0, j))
    {
      double d0 = (E.e - E.b) * 0.66D;
      int k = ls.c(v - N + d0);
      return q.h(i, k, j, 0);
    }
    

    return 0;
  }
  




  public float d(float par1)
  {
    int i = ls.c(u);
    int j = ls.c(w);
    
    if (q.f(i, 0, j))
    {
      double d0 = (E.e - E.b) * 0.66D;
      int k = ls.c(v - N + d0);
      return q.q(i, k, j);
    }
    

    return 0.0F;
  }
  




  public void a(abw par1World)
  {
    q = par1World;
  }
  



  public void a(double par1, double par3, double par5, float par7, float par8)
  {
    r = (this.u = par1);
    s = (this.v = par3);
    t = (this.w = par5);
    C = (this.A = par7);
    D = (this.B = par8);
    X = 0.0F;
    double d3 = C - par7;
    
    if (d3 < -180.0D)
    {
      C += 360.0F;
    }
    
    if (d3 >= 180.0D)
    {
      C -= 360.0F;
    }
    
    b(u, v, w);
    b(par7, par8);
  }
  



  public void b(double par1, double par3, double par5, float par7, float par8)
  {
    U = (this.r = this.u = par1);
    V = (this.s = this.v = par3 + N);
    W = (this.t = this.w = par5);
    A = par7;
    B = par8;
    b(u, v, w);
  }
  



  public float d(nn par1Entity)
  {
    float f = (float)(u - u);
    float f1 = (float)(E.b - E.b);
    float f2 = (float)(w - w);
    return ls.c(f * f + f1 * f1 + f2 * f2);
  }
  
  public float getDistanceToEntityPlayer(nn par1Entity)
  {
    float f = (float)(u - u);
    float f1 = (float)(v - v);
    float f2 = (float)(w - w);
    return ls.c(f * f + f1 * f1 + f2 * f2);
  }
  



  public double e(double par1, double par3, double par5)
  {
    double d3 = u - par1;
    double d4 = v - par3;
    double d5 = w - par5;
    return d3 * d3 + d4 * d4 + d5 * d5;
  }
  



  public double f(double par1, double par3, double par5)
  {
    double d3 = u - par1;
    double d4 = v - par3;
    double d5 = w - par5;
    return ls.a(d3 * d3 + d4 * d4 + d5 * d5);
  }
  




  public double e(nn par1Entity)
  {
    double d0 = u - u;
    double d1 = E.b - E.b;
    double d2 = w - w;
    return d0 * d0 + d1 * d1 + d2 * d2;
  }
  

  public double getDistanceSqToEntityPlayer(nn par1Entity)
  {
    double d = u - u;
    double d1 = v - v;
    double d2 = w - w;
    return d * d + d1 * d1 + d2 * d2;
  }
  



  public void b_(uf par1EntityPlayer) {}
  



  public void f(nn par1Entity)
  {
    if ((!par1Entity.isEntityAttached(this)) && (o != this))
    {
      double d0 = u - u;
      double d1 = w - w;
      double d2 = ls.a(d0, d1);
      


      double mass1 = getRangeMultiplier();
      double mass2 = par1Entity.getRangeMultiplier();
      double mo = d2 / ((mass1 + mass2) / 2.0D);
      
      if (mo >= 0.009999999776482582D)
      {
        d0 /= mo;
        d1 /= mo;
        double d3 = 1.0D / mo;
        
        if (d3 > 1.0D)
        {
          d3 = 1.0D;
        }
        
        d0 *= d3;
        d1 *= d3;
        d0 *= 0.05000000074505806D;
        d1 *= 0.05000000074505806D;
        d0 *= (1.0F - aa);
        d1 *= (1.0F - aa);
        double sfactor = isSticky() ? 0.1D : 1.0D;
        double sfactor1 = par1Entity.isSticky() ? 0.1D : 1.0D;
        



        boolean b1 = !par1Entity.isTinierThan(this);
        boolean b2 = !isTinierThan(par1Entity);
        
        if (b1)
        {
          if (b2)
          {
            g(-d0 / mass1, 0.0D, -d1 / mass1);
          }
          else
          {
            g(-d0 / mass1 * 0.25D, 0.0D, -d1 / mass1 * 0.25D);
          }
        }
        
        if (b2)
        {
          if (b1)
          {
            par1Entity.g(d0 / mass2, 0.0D, d1 / mass2);
          }
          else
          {
            par1Entity.g(d0 / mass2 * 0.25D, 0.0D, d1 / mass2 * 0.25D);
          }
        }
      }
    }
  }
  



  public void g(double par1, double par3, double par5)
  {
    x += par1;
    y += par3;
    z += par5;
    an = true;
  }
  



  protected void K()
  {
    J = true;
  }
  



  public boolean a(nb par1DamageSource, float par2)
  {
    if (ar())
    {
      return false;
    }
    

    K();
    return false;
  }
  




  public boolean L()
  {
    return false;
  }
  



  public boolean M()
  {
    return false;
  }
  



  public boolean isSticky()
  {
    return false;
  }
  



  public boolean isWeighted()
  {
    return false;
  }
  




  public void b(nn par1Entity, int par2) {}
  




  @SideOnly(Side.CLIENT)
  public boolean a(atc par1Vec3)
  {
    double d0 = u - c;
    double d1 = v - d;
    double d2 = w - e;
    double d3 = d0 * d0 + d1 * d1 + d2 * d2;
    
    if ((wp != null) && (GulliverOMHelper.getOptifineZoom()))
    {
      d3 /= 8.0D;
    }
    
    if (wi != null)
    {
      float sizeroot = wi.getSizeMultiplierRoot();
      if (sizeroot > 1.0F)
      {
        d3 /= sizeroot;
      }
      else if (sizeroot < 1.0F)
      {
        d3 *= sizeroot;
      }
      if (getSizeMultiplier() < 1.0F)
      {
        d3 *= (float)Math.cbrt(getSizeMultiplier());
      }
    }
    
    return a(d3);
  }
  





  @SideOnly(Side.CLIENT)
  public boolean a(double par1)
  {
    double d1 = E.b();
    d1 *= 64.0D * l;
    return par1 < d1 * d1;
  }
  




  public boolean c(by par1NBTTagCompound)
  {
    String s = Q();
    
    if ((!M) && (s != null))
    {
      par1NBTTagCompound.a("id", s);
      e(par1NBTTagCompound);
      return true;
    }
    

    return false;
  }
  






  public boolean d(by par1NBTTagCompound)
  {
    String s = Q();
    
    if ((!M) && (s != null) && (n == null))
    {
      par1NBTTagCompound.a("id", s);
      e(par1NBTTagCompound);
      return true;
    }
    

    return false;
  }
  




  public void e(by par1NBTTagCompound)
  {
    try
    {
      par1NBTTagCompound.a("Pos", a(new double[] { u, v + X, w }));
      par1NBTTagCompound.a("Motion", a(new double[] { x, y, z }));
      par1NBTTagCompound.a("Rotation", a(new float[] { A, B }));
      par1NBTTagCompound.a("FallDistance", T);
      par1NBTTagCompound.a("Fire", (short)d);
      par1NBTTagCompound.a("Air", (short)al());
      par1NBTTagCompound.a("OnGround", F);
      par1NBTTagCompound.a("Dimension", ar);
      par1NBTTagCompound.a("Invulnerable", h);
      par1NBTTagCompound.a("PortalCooldown", ao);
      par1NBTTagCompound.a("UUIDMost", i.getMostSignificantBits());
      par1NBTTagCompound.a("UUIDLeast", i.getLeastSignificantBits());
      
      if (getSizeMultiplier() != 1.0F)
      {
        par1NBTTagCompound.a("SizeMult", getSizeMultiplier());
      }
      
      if (customEntityData != null)
      {
        par1NBTTagCompound.a("ForgeData", customEntityData);
      }
      
      for (String identifier : extendedProperties.keySet()) {
        try {
          IExtendedEntityProperties props = (IExtendedEntityProperties)extendedProperties.get(identifier);
          props.saveNBTData(par1NBTTagCompound);
        } catch (Throwable t) {
          FMLLog.severe("Failed to save extended properties for %s.  This is a mod issue.", new Object[] { identifier });
          t.printStackTrace();
        }
      }
      
      b(par1NBTTagCompound);
      
      if (o != null)
      {
        by nbttagcompound1 = new by("Riding");
        
        if (o.c(nbttagcompound1))
        {
          par1NBTTagCompound.a("Riding", nbttagcompound1);
        }
      }
    }
    catch (Throwable throwable)
    {
      b crashreport = b.a(throwable, "Saving entity NBT");
      m crashreportcategory = crashreport.a("Entity being saved");
      a(crashreportcategory);
      throw new u(crashreport);
    }
  }
  



  public void f(by par1NBTTagCompound)
  {
    try
    {
      cg nbttaglist = par1NBTTagCompound.m("Pos");
      cg nbttaglist1 = par1NBTTagCompound.m("Motion");
      cg nbttaglist2 = par1NBTTagCompound.m("Rotation");
      x = b0a;
      y = b1a;
      z = b2a;
      
      if (Math.abs(x) > 10.0D)
      {
        x = 0.0D;
      }
      
      if (Math.abs(y) > 10.0D)
      {
        y = 0.0D;
      }
      
      if (Math.abs(z) > 10.0D)
      {
        z = 0.0D;
      }
      
      r = (this.U = this.u = b0a);
      s = (this.V = this.v = b1a);
      this.t = (this.W = this.w = b2a);
      C = (this.A = b0a);
      D = (this.B = b1a);
      T = par1NBTTagCompound.g("FallDistance");
      d = par1NBTTagCompound.d("Fire");
      g(par1NBTTagCompound.d("Air"));
      F = par1NBTTagCompound.n("OnGround");
      ar = par1NBTTagCompound.e("Dimension");
      h = par1NBTTagCompound.n("Invulnerable");
      ao = par1NBTTagCompound.e("PortalCooldown");
      
      if ((par1NBTTagCompound.b("UUIDMost")) && (par1NBTTagCompound.b("UUIDLeast")))
      {
        i = new UUID(par1NBTTagCompound.f("UUIDMost"), par1NBTTagCompound.f("UUIDLeast"));
      }
      
      if (!par1NBTTagCompound.b("SizeMult"))
      {
        doResize(1.0F, false);
      }
      else
      {
        doResize(par1NBTTagCompound.g("SizeMult"), false);
      }
      
      b(u, v, w);
      b(A, B);
      if (par1NBTTagCompound.b("ForgeData"))
      {
        customEntityData = par1NBTTagCompound.l("ForgeData");
      }
      
      for (String identifier : extendedProperties.keySet()) {
        try {
          IExtendedEntityProperties props = (IExtendedEntityProperties)extendedProperties.get(identifier);
          props.loadNBTData(par1NBTTagCompound);
        } catch (Throwable t) {
          FMLLog.severe("Failed to load extended properties for %s.  This is a mod issue.", new Object[] { identifier });
          t.printStackTrace();
        }
      }
      

      if ((par1NBTTagCompound.b("PersistentIDMSB")) && (par1NBTTagCompound.b("PersistentIDLSB")))
      {
        i = new UUID(par1NBTTagCompound.f("PersistentIDMSB"), par1NBTTagCompound.f("PersistentIDLSB"));
      }
      a(par1NBTTagCompound);
      
      if (P())
      {
        b(u, v, w);
      }
    }
    catch (Throwable throwable)
    {
      b crashreport = b.a(throwable, "Loading entity NBT");
      m crashreportcategory = crashreport.a("Entity being loaded");
      a(crashreportcategory);
      throw new u(crashreport);
    }
  }
  
  protected boolean P()
  {
    return true;
  }
  



  protected final String Q()
  {
    return nt.b(this);
  }
  



  protected abstract void a(by paramBy);
  


  protected abstract void b(by paramBy);
  


  public void R() {}
  


  protected cg a(double... par1ArrayOfDouble)
  {
    cg nbttaglist = new cg();
    double[] adouble = par1ArrayOfDouble;
    int i = par1ArrayOfDouble.length;
    
    for (int j = 0; j < i; j++)
    {
      double d1 = adouble[j];
      nbttaglist.a(new cb((String)null, d1));
    }
    
    return nbttaglist;
  }
  



  protected cg a(float... par1ArrayOfFloat)
  {
    cg nbttaglist = new cg();
    float[] afloat = par1ArrayOfFloat;
    int i = par1ArrayOfFloat.length;
    
    for (int j = 0; j < i; j++)
    {
      float f1 = afloat[j];
      nbttaglist.a(new cd((String)null, f1));
    }
    
    return nbttaglist;
  }
  
  @SideOnly(Side.CLIENT)
  public float S()
  {
    return P / 2.0F;
  }
  



  public ss b(int par1, int par2)
  {
    return a(par1, par2, 0.0F);
  }
  



  public ss a(int par1, int par2, float par3)
  {
    return a(new ye(par1, par2, 0), par3);
  }
  



  public ss a(ye par1ItemStack, float par2)
  {
    if (b == 0)
    {
      return null;
    }
    
    ss entityitem = new ss(q, u, v + par2, w, par1ItemStack);
    entityitem.setSizeMultiplier(getSizeMultiplierRoot());
    entityitem.a(O * entityitem.getSizeMultiplier(), P * entityitem.getSizeMultiplier());
    N = (P / 2.0F);
    x *= entityitem.getSizeMultiplier();
    y *= (getSizeMultiplier() >= 1.0F ? 1.0D : getSizeMultiplier());
    z *= entityitem.getSizeMultiplier();
    b = 10;
    if (captureDrops)
    {
      capturedDrops.add(entityitem);
    }
    else
    {
      q.d(entityitem);
    }
    return entityitem;
  }
  



  public boolean T()
  {
    return !M;
  }
  



  public boolean U()
  {
    for (int i = 0; i < 8; i++)
    {
      float f = ((i >> 0) % 2 - 0.5F) * O * 0.8F;
      float f1 = ((i >> 1) % 2 - 0.5F) * 0.1F * getSizeMultiplier();
      float f2 = ((i >> 2) % 2 - 0.5F) * O * 0.8F;
      int j = ls.c(u + f);
      int k = ls.c(v + f() + f1);
      int l = ls.c(w + f2);
      
      if (q.u(j, k, l))
      {
        return true;
      }
    }
    
    return false;
  }
  



  public boolean c(uf par1EntityPlayer)
  {
    return false;
  }
  




  public asx g(nn par1Entity)
  {
    return null;
  }
  



  public asx getEntityCollisionBox()
  {
    return E.c();
  }
  



  public asx getEntityHitBox()
  {
    return E.c();
  }
  



  public void V()
  {
    if ((o != null) && (o.M))
    {
      a(null);
    }
    else if ((holdingEntity != null) && (holdingEntity.M))
    {
      getDroppedByEntity(holdingEntity);
    }
    else
    {
      x = 0.0D;
      y = 0.0D;
      z = 0.0D;
      l_();
      


      if ((o != null) && (!q.I) && (((this instanceof uf)) || (getSizeMultiplier() > o.getSizeMultiplier())) && (O > o.maxRiderWidth(this)))
      {
        nn ride = o;
        ride.throwRider(0.5F);
        
        if ((!isTiny()) || ((ride instanceof of)))
        {
          ride.a(new EntityDamageSourcePassive("squish", this), getSizeMultiplierRoot() / ride.getSizeMultiplierRoot());
        }
      }
      

      if ((holdingEntity != null) && (!q.I) && ((O > holdingEntity.maxHeldWidth(this)) || (((holdingEntity instanceof of)) && (((of)holdingEntity).aZ() != null))))
      {
        getDroppedByEntity(holdingEntity);
      }
      
      nn ridehold = null;
      
      if (holdingEntity != null)
      {
        ridehold = holdingEntity;
        ridehold.updateHeldPosition();
      }
      
      if (o != null)
      {
        ridehold = o;
        ridehold.W();
      }
      
      if (ridehold != null)
      {
        g += A - C;
        
        for (this.f += B - D; g >= 180.0D; g -= 360.0D) {}
        



        while (g < -180.0D)
        {
          g += 360.0D;
        }
        
        while (this.f >= 180.0D)
        {
          this.f -= 360.0D;
        }
        
        while (this.f < -180.0D)
        {
          this.f += 360.0D;
        }
        


        double d0 = g * 0.5D;
        double d1 = this.f * 0.5D;
        float f = 10.0F;
        
        if (ridehold == holdingEntity)
        {
          d0 *= 0.25D;
          d1 *= 0.25D;
          f = 2.0F;
        }
        
        if (d0 > f)
        {
          d0 = f;
        }
        
        if (d0 < -f)
        {
          d0 = -f;
        }
        
        if (d1 > f)
        {
          d1 = f;
        }
        
        if (d1 < -f)
        {
          d1 = -f;
        }
        
        g -= d0;
        this.f -= d1;
      }
    }
  }
  








  public float maxHeldWidth(nn par1Entity)
  {
    return O * 0.5F;
  }
  
  public float maxRiderWidth(nn par1Entity)
  {
    return (O < 0.6F ? O : 0.6F) * 1.5F;
  }
  
  protected void throwRider(float par1)
  {
    if (n != null)
    {
      nn rider = n;
      float yaw = A + 180.0F;
      rider.a((rider instanceof uf) ? this : null);
      
      if ((rider instanceof of))
      {
        ((of)rider).be();
      }
      

      float f = par1 * O / getSizeMultiplierRoot();
      
      if ((rider instanceof jv))
      {
        a.b(new fp(k, ls.b(yaw * 3.1415927F / 180.0F) * f, 0.0D, ls.a(yaw * 3.1415927F / 180.0F) * f));
      }
      
      rider.g(ls.b(yaw * 3.1415927F / 180.0F) * f, 0.0D, ls.a(yaw * 3.1415927F / 180.0F) * f);
    }
  }
  
  public void W()
  {
    if (n != null)
    {
      n.b(u, v + Y() + n.X(), w);
    }
  }
  
  public void updateHeldPosition()
  {
    if (heldEntity != null)
    {
      heldEntity.b(u, v + getHeldYOffset() + heldEntity.X(), w);
    }
  }
  
  public void positionHeldForDrop(nn par1Entity)
  {
    N = 0.0F;
    
    if (!q.I)
    {
      par1Entity.b(u, v + getHeldYOffset(), w, A, B);
    }
  }
  



  public double X()
  {
    return N;
  }
  



  public double Y()
  {
    return P * 0.75D;
  }
  
  public double getHeldYOffset()
  {
    return P * (ah() ? 0.5D : 0.675D);
  }
  
  public void pickUpEntity(nn par1Entity)
  {
    if (par1Entity != null)
    {





      heldEntity = par1Entity;
      holdingEntity = this;
    }
  }
  


  public void getPickedUpByEntity(nn par1Entity)
  {
    if (par1Entity != null)
    {

      par1Entity.pickUpEntity(this);

    }
    else
    {
      holdingEntity = par1Entity;
      g = (A - holdingEntity.A);
    }
  }
  

  public void dropHeldEntity(nn par1Entity)
  {
    if (heldEntity != null)
    {
      heldEntity = null;
    }
    
    if (par1Entity != null)
    {
      holdingEntity = null;
    }
  }
  

  public void getDroppedByEntity(nn par1Entity)
  {
    if (par1Entity != null)
    {
      par1Entity.dropHeldEntity(this);
      par1Entity.positionHeldForDrop(this);
    }
    else
    {
      holdingEntity = null;
    }
    
    f = 0.0D;
    g = 0.0D;
  }
  



  public void a(nn par1Entity)
  {
    f = 0.0D;
    g = 0.0D;
    
    if (par1Entity == null)
    {
      if (o != null)
      {
        b(o.u, o.E.b + o.P, o.w, A, B);
        o.n = null;
      }
      
      o = null;
    }
    else
    {
      if (o != null)
      {
        o.n = null;
      }
      
      o = par1Entity;
      n = this;
    }
  }
  





  @SideOnly(Side.CLIENT)
  public void a(double par1, double par3, double par5, float par7, float par8, int par9)
  {
    b(par1, par3, par5);
    b(par7, par8);
    double camt = getSizeMultiplier() >= 1.0F ? 0.03125D : 0.03125D * getSizeMultiplierRoot();
    List list = q.a(this, E.e(camt, 0.0D, camt));
    
    if (!list.isEmpty())
    {
      double d3 = 0.0D;
      
      for (int j = 0; j < list.size(); j++)
      {
        asx axisalignedbb = (asx)list.get(j);
        
        if (e > d3)
        {
          d3 = e;
        }
      }
      
      par3 += d3 - E.b;
      b(par1, par3, par5);
    }
  }
  
  public float Z()
  {
    return 0.1F * getSizeMultiplierRoot();
  }
  



  public atc aa()
  {
    return null;
  }
  



  public void ab()
  {
    if (ao > 0)
    {
      ao = ac();
    }
    else
    {
      double d0 = r - u;
      double d1 = t - w;
      
      if ((!q.I) && (!ap))
      {
        as = r.a(d0, d1);
      }
      
      ap = true;
    }
  }
  



  public int ac()
  {
    return 900;
  }
  




  @SideOnly(Side.CLIENT)
  public void h(double par1, double par3, double par5)
  {
    x = par1;
    y = par3;
    z = par5;
  }
  


  @SideOnly(Side.CLIENT)
  public void a(byte par1) {}
  

  @SideOnly(Side.CLIENT)
  public void ad() {}
  

  public ye[] ae()
  {
    return null;
  }
  



  public void c(int par1, ye par2ItemStack) {}
  



  public boolean af()
  {
    return (!ag) && ((d > 0) || (f(0)));
  }
  




  public boolean ag()
  {
    return (o != null) && (o.shouldRiderSit());
  }
  



  public boolean ah()
  {
    return f(1);
  }
  



  public void b(boolean par1)
  {
    a(1, par1);
  }
  



  public boolean ai()
  {
    return f(3);
  }
  



  public void c(boolean par1)
  {
    a(3, par1);
  }
  
  public boolean aj()
  {
    return f(5);
  }
  






  @SideOnly(Side.CLIENT)
  public boolean d(uf par1EntityPlayer)
  {
    return aj();
  }
  
  public void d(boolean par1)
  {
    a(5, par1);
  }
  
  @SideOnly(Side.CLIENT)
  public boolean ak()
  {
    return f(4);
  }
  
  public void e(boolean par1)
  {
    a(4, par1);
  }
  




  protected boolean f(int par1)
  {
    return (ah.a(0) & 1 << par1) != 0;
  }
  



  protected void a(int par1, boolean par2)
  {
    byte b0 = ah.a(0);
    
    if (par2)
    {
      ah.b(0, Byte.valueOf((byte)(b0 | 1 << par1)));
    }
    else
    {
      ah.b(0, Byte.valueOf((byte)(b0 & (1 << par1 ^ 0xFFFFFFFF))));
    }
  }
  
  public int al()
  {
    return ah.b(1);
  }
  
  public void g(int par1)
  {
    ah.b(1, Short.valueOf((short)par1));
  }
  



  public void a(sp par1EntityLightningBolt)
  {
    e(5);
    d += 1;
    
    if (d == 0)
    {
      d(8);
    }
  }
  



  public void a(of par1EntityLivingBase) {}
  



  protected boolean i(double par1, double par3, double par5)
  {
    int i = ls.c(par1);
    int j = ls.c(par3);
    int k = ls.c(par5);
    double d3 = par1 - i;
    double d4 = par3 - j;
    double d5 = par5 - k;
    List list = q.a(E);
    
    if ((list.isEmpty()) && (!q.v(i, j, k)))
    {
      return false;
    }
    

    boolean flag = !q.v(i - 1, j, k);
    boolean flag1 = !q.v(i + 1, j, k);
    boolean flag2 = !q.v(i, j - 1, k);
    boolean flag3 = !q.v(i, j + 1, k);
    boolean flag4 = !q.v(i, j, k - 1);
    boolean flag5 = !q.v(i, j, k + 1);
    byte b0 = 3;
    double d6 = 9999.0D;
    
    if ((flag) && (d3 < d6))
    {
      d6 = d3;
      b0 = 0;
    }
    
    if ((flag1) && (1.0D - d3 < d6))
    {
      d6 = 1.0D - d3;
      b0 = 1;
    }
    
    if ((flag3) && (1.0D - d4 < d6))
    {
      d6 = 1.0D - d4;
      b0 = 3;
    }
    
    if ((flag4) && (d5 < d6))
    {
      d6 = d5;
      b0 = 4;
    }
    
    if ((flag5) && (1.0D - d5 < d6))
    {
      d6 = 1.0D - d5;
      b0 = 5;
    }
    
    float f = ab.nextFloat() * 0.2F + 0.1F;
    
    if (b0 == 0)
    {
      x = (-f);
    }
    
    if (b0 == 1)
    {
      x = f;
    }
    
    if (b0 == 2)
    {
      y = (-f);
    }
    
    if (b0 == 3)
    {
      y = f;
    }
    
    if (b0 == 4)
    {
      z = (-f);
    }
    
    if (b0 == 5)
    {
      z = f;
    }
    
    return true;
  }
  




  public void am()
  {
    if (!isHuge())
    {
      K = true;
      T = 0.0F;
    }
  }
  



  public String an()
  {
    String s = nt.b(this);
    
    if (s == null)
    {
      s = "generic";
    }
    
    return bu.a("entity." + s + ".name");
  }
  



  public nn[] ao()
  {
    return null;
  }
  



  public boolean h(nn par1Entity)
  {
    return this == par1Entity;
  }
  
  public float ap()
  {
    return 0.0F;
  }
  




  @SideOnly(Side.CLIENT)
  public void e(float par1) {}
  



  public boolean aq()
  {
    return true;
  }
  



  public boolean i(nn par1Entity)
  {
    return false;
  }
  
  public String toString()
  {
    return String.format("%s['%s'/%d, l='%s', x=%.2f, y=%.2f, z=%.2f, s=%.4f]", new Object[] { getClass().getSimpleName(), an(), Integer.valueOf(k), q == null ? "~NULL~" : q.N().k(), Double.valueOf(u), Double.valueOf(v), Double.valueOf(w), Float.valueOf(getSizeMultiplier()) });
  }
  



  public boolean ar()
  {
    return h;
  }
  



  public void j(nn par1Entity)
  {
    b(u, v, w, A, B);
  }
  





  public void a(nn par1Entity, boolean par2)
  {
    by nbttagcompound = new by();
    par1Entity.e(nbttagcompound);
    f(nbttagcompound);
    ao = ao;
    as = as;
  }
  



  public void b(int par1)
  {
    if ((!q.I) && (!M))
    {
      q.C.a("changeDimension");
      MinecraftServer minecraftserver = MinecraftServer.F();
      int j = ar;
      js worldserver = minecraftserver.a(j);
      js worldserver1 = minecraftserver.a(par1);
      ar = par1;
      
      if ((j == 1) && (par1 == 1))
      {
        worldserver1 = minecraftserver.a(0);
        ar = 0;
      }
      
      q.e(this);
      M = false;
      q.C.a("reposition");
      minecraftserver.af().a(this, j, worldserver, worldserver1);
      q.C.c("reloading");
      nn entity = nt.a(nt.b(this), worldserver1);
      
      if (entity != null)
      {
        entity.a(this, true);
        
        if ((j == 1) && (par1 == 1))
        {
          t chunkcoordinates = worldserver1.K();
          b = q.i(a, c);
          entity.b(a, b, c, A, B);
        }
        
        worldserver1.d(entity);
      }
      
      M = true;
      q.C.b();
      worldserver.i();
      worldserver1.i();
      q.C.b();
    }
  }
  




  public float a(abr par1Explosion, abw par2World, int par3, int par4, int par5, aqz par6Block)
  {
    return par6Block.getExplosionResistance(this, par2World, par3, par4, par5, u, v + f(), w);
  }
  
  public boolean a(abr par1Explosion, abw par2World, int par3, int par4, int par5, int par6, float par7)
  {
    return true;
  }
  



  public int as()
  {
    return 3;
  }
  
  public int at()
  {
    return as;
  }
  



  public boolean au()
  {
    return false;
  }
  
  public void a(m par1CrashReportCategory)
  {
    par1CrashReportCategory.a("Entity Type", new no(this));
    par1CrashReportCategory.a("Entity ID", Integer.valueOf(k));
    par1CrashReportCategory.a("Entity Name", new np(this));
    par1CrashReportCategory.a("Entity's Size multiplier", String.format("%.4f", new Object[] { Float.valueOf(getSizeMultiplier()) }));
    par1CrashReportCategory.a("Entity's Exact location", String.format("%.2f, %.2f, %.2f", new Object[] { Double.valueOf(u), Double.valueOf(v), Double.valueOf(w) }));
    par1CrashReportCategory.a("Entity's Block location", m.a(ls.c(u), ls.c(v), ls.c(w)));
    par1CrashReportCategory.a("Entity's Momentum", String.format("%.2f, %.2f, %.2f", new Object[] { Double.valueOf(x), Double.valueOf(y), Double.valueOf(z) }));
  }
  




  @SideOnly(Side.CLIENT)
  public boolean av()
  {
    return af();
  }
  
  public UUID aw()
  {
    return i;
  }
  
  public boolean ax()
  {
    return true;
  }
  



  public String ay()
  {
    return an();
  }
  






  public by getEntityData()
  {
    if (customEntityData == null)
    {
      customEntityData = new by();
    }
    return customEntityData;
  }
  




  public boolean shouldRiderSit()
  {
    return true;
  }
  






  public ye getPickedResult(ata target)
  {
    if ((this instanceof ol))
    {
      return new ye(yc.au);
    }
    if ((this instanceof st))
    {
      return ((st)this).getCartItem();
    }
    if ((this instanceof sq))
    {
      return new ye(yc.aG);
    }
    if ((this instanceof od))
    {
      ye held = ((od)this).h();
      if (held == null)
      {
        return new ye(yc.bK);
      }
      

      return held.m();
    }
    
    if ((this instanceof oe))
    {
      return new ye(yc.ch);
    }
    

    int id = nt.a(this);
    if ((id > 0) && (nt.a.containsKey(Integer.valueOf(id))))
    {
      return new ye(yc.bE, 1, id);
    }
    
    return null;
  }
  
  public UUID getPersistentID()
  {
    return i;
  }
  



  public final void resetEntityId()
  {
    k = (b++);
  }
  
  public boolean shouldRenderInPass(int pass)
  {
    return pass == 0;
  }
  






  public boolean isCreatureType(oh type, boolean forSpawnCount)
  {
    return type.a().isAssignableFrom(getClass());
  }
  






  public String registerExtendedProperties(String identifier, IExtendedEntityProperties properties)
  {
    if (identifier == null)
    {
      FMLLog.warning("Someone is attempting to register extended properties using a null identifier.  This is not allowed.  Aborting.  This may have caused instability.", new Object[0]);
      return "";
    }
    if (properties == null)
    {
      FMLLog.warning("Someone is attempting to register null extended properties.  This is not allowed.  Aborting.  This may have caused instability.", new Object[0]);
      return "";
    }
    
    String baseIdentifier = identifier;
    int identifierModCount = 1;
    while (extendedProperties.containsKey(identifier))
    {
      identifier = String.format("%s%d", new Object[] { baseIdentifier, Integer.valueOf(identifierModCount++) });
    }
    
    if (baseIdentifier != identifier)
    {
      FMLLog.info("An attempt was made to register exended properties using an existing key.  The duplicate identifier (%s) has been remapped to %s.", new Object[] { baseIdentifier, identifier });
    }
    
    extendedProperties.put(identifier, properties);
    return identifier;
  }
  





  public IExtendedEntityProperties getExtendedProperties(String identifier)
  {
    return (IExtendedEntityProperties)extendedProperties.get(identifier);
  }
  






  public boolean canRiderInteract()
  {
    return false;
  }
  





  public boolean shouldDismountInWater(nn rider)
  {
    return this instanceof of;
  }
}
