






public abstract class nk
  extends on
{
  private float bp = -1.0F;
  private float bq;
  
  public nk(abw par1World)
  {
    super(par1World);
  }
  


  public abstract nk a(nk paramNk);
  

  public boolean a(uf par1EntityPlayer)
  {
    ye itemstack = bn.h();
    
    if ((itemstack != null) && (d == bEcv))
    {
      if (!q.I)
      {
        Class oclass = nt.a(itemstack.k());
        
        if ((oclass != null) && (oclass.isAssignableFrom(getClass())))
        {
          nk entityageable = a(this);
          
          if (entityageable != null)
          {
            entityageable.c(41536);
            
            entityageable.setSizeBaseMultiplier(getSizeMultiplier());
            entityageable.doResize(getSizeMultiplier(), false);
            entityageable.b(u, v, w, 0.0F, 0.0F);
            q.d(entityageable);
            
            if (itemstack.u())
            {
              entityageable.a(itemstack.s());
            }
            
            if (!bG.d)
            {
              b -= 1;
              
              if (b <= 0)
              {
                bn.a(bn.c, (ye)null);
              }
            }
          }
        }
      }
      
      return true;
    }
    

    return false;
  }
  

  protected void a()
  {
    super.a();
    ah.a(12, new Integer(0));
  }
  





  public int b()
  {
    return ah.c(12);
  }
  




  public void a(int par1)
  {
    int j = b();
    j += par1 * 20;
    
    if (j > 0)
    {
      j = 0;
    }
    
    c(j);
  }
  




  public void c(int par1)
  {
    ah.b(12, Integer.valueOf(par1));
    a(g_());
  }
  



  public void b(by par1NBTTagCompound)
  {
    super.b(par1NBTTagCompound);
    par1NBTTagCompound.a("Age", b());
  }
  



  public void a(by par1NBTTagCompound)
  {
    super.a(par1NBTTagCompound);
    c(par1NBTTagCompound.e("Age"));
  }
  




  public void c()
  {
    super.c();
    
    if (q.I)
    {
      a(g_());
    }
    else
    {
      int i = b();
      
      if (i < 0)
      {
        i++;
        c(i);
      }
      else if (i > 0)
      {
        i--;
        c(i);
      }
    }
  }
  



  public boolean g_()
  {
    return b() < 0;
  }
  



  public void a(boolean par1)
  {
    a(par1 ? 0.5F : 1.0F);
  }
  



  public final void a(float par1, float par2)
  {
    boolean flag = bp > 0.0F;
    bp = par1;
    bq = par2;
    
    if (!flag)
    {
      a(1.0F);
    }
  }
  
  protected final void a(float par1)
  {
    super.a(bp * par1, bq * par1);
  }
}
