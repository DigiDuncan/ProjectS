import cpw.mods.fml.common.network.FMLNetworkHandler;
import gulliver.common.GulliverEnvoy;
import gulliver.network.packet.Packet171EntitySize;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.logging.Logger;
import net.minecraft.server.MinecraftServer;
import net.minecraftforge.common.ForgeHooks;
import net.minecraftforge.event.Event.Result;
import net.minecraftforge.event.ForgeEventFactory;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent.Action;

















































































public class ka
  extends ez
{
  public final cm a;
  private final MinecraftServer d;
  public boolean b;
  public jv c;
  private int e;
  public int f;
  private boolean g;
  private int h;
  private long i;
  private static Random j = new Random();
  

  private long k;
  
  private int l;
  
  private int m;
  
  private double n;
  
  private double o;
  
  private double p;
  
  private boolean q = true;
  private lm r = new lm();
  
  public ka(MinecraftServer par1MinecraftServer, cm par2INetworkManager, jv par3EntityPlayerMP)
  {
    d = par1MinecraftServer;
    a = par2INetworkManager;
    par2INetworkManager.a(this);
    c = par3EntityPlayerMP;
    a = this;
  }
  



  public void e()
  {
    g = false;
    e += 1;
    d.a.a("packetflow");
    a.b();
    d.a.c("keepAlive");
    
    if (e - k > 20L)
    {
      k = e;
      i = (System.nanoTime() / 1000000L);
      h = j.nextInt();
      b(new ei(h));
    }
    
    if (l > 0)
    {
      l -= 1;
    }
    
    if (m > 0)
    {
      m -= 1;
    }
    
    d.a.c("playerTick");
    d.a.b();
  }
  
  public void c(String par1Str)
  {
    if (!b)
    {
      c.l();
      b(new eb(par1Str));
      a.d();
      d.af().a(cv.b("multiplayer.player.left", new Object[] { c.ay() }).a(a.o));
      d.af().e(c);
      b = true;
    }
  }
  
  public void a(fe par1Packet27PlayerInput)
  {
    c.a(par1Packet27PlayerInput.d(), par1Packet27PlayerInput.f(), par1Packet27PlayerInput.g(), par1Packet27PlayerInput.h());
  }
  
  public void a(eu par1Packet10Flying)
  {
    js worldserver = d.a(c.ar);
    g = true;
    
    if (!c.j)
    {


      if (!q)
      {
        double d0 = b - o;
        
        if ((a == n) && (d0 * d0 < 0.01D) && (c == p))
        {
          q = true;
        }
        else if ((c.T()) && (c.U()) && ((b != -999.0D) || (d != -999.0D)))
        {
          GulliverEnvoy.getLogger().warning(c.bu + " seems to be stuck in a Wall!");
          GulliverEnvoy.getLogger().warning("   s = (" + n + "," + o + "," + p + "), c=(" + a + "," + b + "," + c);
          double r = c.getSizeMultiplierRoot();
          if ((Math.abs(a - n) <= r * 2.0D) && (d0 * d0 <= r * 4.0D) && (Math.abs(c - p) <= r * 2.0D))
          {
            GulliverEnvoy.getLogger().warning("   " + c.bu + " is close enough, using client position");
            q = true;
          }
        }
      }
      
      if (q)
      {




        if (c.o != null)
        {
          float f = c.A;
          float f1 = c.B;
          
          if (c.o != null)
          {
            c.o.W();
          }
          else
          {
            c.holdingEntity.updateHeldPosition();
          }
          
          double d1 = c.u;
          double d2 = c.v;
          double d3 = c.w;
          
          if (i)
          {
            f = e;
            f1 = f;
          }
          
          c.F = g;
          c.h();
          c.X = 0.0F;
          c.a(d1, d2, d3, f, f1);
          
          if (c.o != null)
          {
            c.o.W();
          }
          else if (c.holdingEntity != null)
          {
            c.holdingEntity.updateHeldPosition();
          }
          
          if (!q)
          {
            return;
          }
          
          d.af().d(c);
          
          if (q)
          {
            n = c.u;
            o = c.v;
            p = c.w;
          }
          
          worldserver.g(c);
          return;
        }
        
        if (c.bh())
        {
          c.h();
          c.a(n, o, p, c.A, c.B);
          worldserver.g(c);
          return;
        }
        
        double d0 = c.v;
        n = c.u;
        o = c.v;
        p = c.w;
        double d1 = c.u;
        double d2 = c.v;
        double d3 = c.w;
        float f2 = c.A;
        float f3 = c.B;
        
        if ((h) && (b == -999.0D) && (d == -999.0D))
        {
          h = false;
        }
        


        if (h)
        {
          d1 = a;
          d2 = b;
          d3 = c;
          double d4 = d - b;
          

          float sizemult = c.getSizeMultiplier();
          if ((!c.bh()) && ((sizemult > 8.0F) || (sizemult < 0.125F) || (d4 > 13.2D) || (d4 < 0.0125D)))
          {

            if ((d4 < 0.0125D) && (sizemult < 1.0F))
            {
              d.an().b(c.c_() + " (sizemult " + sizemult + ") had a bad stance: " + d4);
            }
            else
            {
              c("Illegal stance");
              d.an().b(c.c_() + " had an illegal stance: " + d4);
              return;
            }
          }
          
          if ((Math.abs(a) > 3.2E7D) || (Math.abs(c) > 3.2E7D))
          {
            c("Illegal position");
            return;
          }
        }
        
        if (i)
        {
          f2 = e;
          f3 = f;
        }
        
        c.h();
        c.X = 0.0F;
        c.a(n, o, p, f2, f3);
        
        if (!q)
        {
          return;
        }
        
        double d4 = d1 - c.u;
        double d5 = d2 - c.v;
        double d6 = d3 - c.w;
        
        double d7 = Math.max(Math.abs(d4), Math.abs(c.x));
        double d8 = Math.max(Math.abs(d5), Math.abs(c.y));
        double d9 = Math.max(Math.abs(d6), Math.abs(c.z));
        double d10 = d7 * d7 + d8 * d8 + d9 * d9;
        
        if ((d10 > 100.0D) && ((!d.K()) || (!d.J().equals(c.c_()))))
        {
          d.an().b(c.c_() + " moved too quickly! " + d4 + "," + d5 + "," + d6 + " (" + d7 + ", " + d8 + ", " + d9 + ")");
          a(n, o, p, c.A, c.B);
          return;
        }
        
        float f4 = 0.0625F * c.getSizeMultiplier();
        boolean flag = worldserver.a(c, c.E.c().e(f4, f4, f4)).isEmpty();
        
        if ((c.F) && (!g) && (d5 > 0.0D))
        {
          c.a(0.2F);
        }
        
        if (!q)
        {
          return;
        }
        
        c.d(d4, d5, d6);
        c.F = g;
        c.j(d4, d5, d6);
        double d11 = d5;
        d4 = d1 - c.u;
        d5 = d2 - c.v;
        
        if ((d5 > -0.5D) || (d5 < 0.5D))
        {
          d5 = 0.0D;
        }
        
        d6 = d3 - c.w;
        d10 = d4 * d4 + d5 * d5 + d6 * d6;
        boolean flag1 = false;
        
        if ((d10 > 0.0625D) && (!c.bh()) && (!c.c.d()))
        {
          flag1 = true;
          d.an().b(c.c_() + " moved wrongly!");
        }
        
        if (!q)
        {
          return;
        }
        
        c.a(d1, d2, d3, f2, f3);
        boolean flag2 = worldserver.a(c, c.E.c().e(f4, f4, f4)).isEmpty();
        
        if ((flag) && ((flag1) || (!flag2)) && (!c.bh()) && (!c.Z))
        {
          a(n, o, p, f2, f3);
          return;
        }
        
        asx axisalignedbb = c.E.c().b(f4, f4, f4).a(0.0D, -0.55D, 0.0D);
        
        if ((!d.aa()) && (!c.c.d()) && (!worldserver.c(axisalignedbb)) && (!c.bG.c) && (!c.isGliding()) && (c.o == null) && (c.holdingEntity == null))
        {
          if (d11 >= -0.03125D)
          {
            this.f += 1;
            
            if (this.f > 80)
            {
              d.an().b(c.c_() + " was kicked for floating too long!");
              c("Flying is not enabled on this server");
            }
            
          }
          
        }
        else {
          this.f = 0;
        }
        
        if (!q)
        {
          return;
        }
        
        c.F = g;
        d.af().d(c);
        c.b(c.v - d0, g);
      }
      else if (e % 20 == 0)
      {
        a(n, o, p, c.A, c.B);
      }
    }
  }
  



  public void a(double par1, double par3, double par5, float par7, float par8)
  {
    q = false;
    n = par1;
    o = par3;
    p = par5;
    c.a(par1, par3, par5, par7, par8);
    c.a.b(new ew(par1, par3 + 1.6200000047683716D * c.getSizeMultiplier(), par3, par5, par7, par8, false));
  }
  



  public void resizeTo(float par1)
  {
    c.doResize(par1, false);
    c.a.b(new Packet171EntitySize(c, par1));
  }
  
  public void a(fb par1Packet14BlockDig)
  {
    js worldserver = d.a(c.ar);
    c.u();
    
    if (e == 4)
    {
      c.a(false);
    }
    else if (e == 3)
    {
      c.a(true);
    }
    else if (e == 5)
    {
      c.bt();
    }
    else if (c.heldEntity == null)
    {




      boolean flag = false;
      
      if (e == 0)
      {
        flag = true;
      }
      
      if (e == 1)
      {
        flag = true;
      }
      
      if (e == 2)
      {
        flag = true;
      }
      
      int i = a;
      int j = b;
      int k = c;
      
      if (flag)
      {
        double d0 = c.u - (i + 0.5D);
        double d1 = c.v - (j + 0.5D) + 1.5D * c.getSizeMultiplier();
        double d2 = c.w - (k + 0.5D);
        double d3 = d0 * d0 + d1 * d1 + d2 * d2;
        
        double rmult = c.getRangeMultiplier();
        if ((c.getSizeMultiplier() < 1.0F) && (c.holdingPointyItem()))
        {
          rmult = Math.cbrt(c.getSizeMultiplier());
        }
        double dist = c.c.getBlockReachDistance() * rmult + 1.0D;
        dist *= dist;
        
        if (d3 > dist)
        {
          return;
        }
        
        if (j >= d.ad())
        {
          return;
        }
      }
      
      if (e == 0)
      {
        if (!d.a(worldserver, i, j, k, c))
        {
          c.c.a(i, j, k, d);
        }
        else
        {
          c.a.b(new gg(i, j, k, worldserver));
        }
      }
      else if (e == 2)
      {
        c.c.a(i, j, k);
        
        if (worldserver.a(i, j, k) != 0)
        {
          c.a.b(new gg(i, j, k, worldserver));
        }
      }
      else if (e == 1)
      {
        c.c.c(i, j, k);
        
        if (worldserver.a(i, j, k) != 0)
        {
          c.a.b(new gg(i, j, k, worldserver));
        }
      }
    }
  }
  
  public void a(gk par1Packet15Place)
  {
    js worldserver = d.a(c.ar);
    ye itemstack = c.bn.h();
    boolean flag = false;
    int i = par1Packet15Place.d();
    int j = par1Packet15Place.f();
    int k = par1Packet15Place.g();
    int l = par1Packet15Place.h();
    c.u();
    
    if (par1Packet15Place.h() == 255)
    {
      if (itemstack == null)
      {
        return;
      }
      
      PlayerInteractEvent event = ForgeEventFactory.onPlayerInteract(c, PlayerInteractEvent.Action.RIGHT_CLICK_AIR, 0, 0, 0, -1);
      if (useItem != Event.Result.DENY)
      {
        c.c.a(c, worldserver, itemstack);
      }
    }
    else if ((itemstack == null) && (c.heldEntity != null))
    {




      nn held = c.heldEntity;
      double xpos = i + 0.5D;
      double ypos = j + 0.5D;
      double zpos = k + 0.5D;
      int bid = worldserver.a(i, j, k);
      
      if (aqz.s[bid] != null)
      {
        double off = aqz.l(bid) ? 1.0D : 0.5D;
        
        if (l == 0)
        {
          ypos -= off;
        }
        
        if (l == 1)
        {
          ypos += off;
        }
        
        if (l == 2)
        {
          zpos -= off;
        }
        
        if (l == 3)
        {
          zpos += off;
        }
        
        if (l == 4)
        {
          xpos -= off;
        }
        
        if (l == 5)
        {
          xpos += off;
        }
        
        if ((!aqz.l(bid)) || (O < 0.5F))
        {
          xpos = (xpos + i + par1Packet15Place.j()) * 0.5D;
          ypos = (ypos + j + par1Packet15Place.k()) * 0.5D;
          zpos = (zpos + k + par1Packet15Place.l()) * 0.5D;
        }
      }
      
      c.dropHeldEntity(held);
      held.b(xpos, ypos, zpos, A, B);
      
      if ((held instanceof jv))
      {
        jv toy = (jv)held;
        a.a(u, v, w, A, B);
      }
    }
    else if ((par1Packet15Place.f() >= d.ad() - 1) && ((par1Packet15Place.h() == 1) || (par1Packet15Place.f() >= d.ad())))
    {
      c.a.b(new dm(cv.b("build.tooHigh", new Object[] { Integer.valueOf(d.ad()) }).a(a.m)));
      flag = true;
    }
    else
    {
      double dist = c.c.getBlockReachDistance() + 1.0D;
      dist *= dist;
      double rmult = c.getRangeMultiplier();
      if ((c.getSizeMultiplier() < 1.0F) && (c.holdingPointyItem()))
      {
        rmult = Math.cbrt(c.getSizeMultiplier());
      }
      if ((q) && (c.e(i + 0.5D, j + 0.5D, k + 0.5D) < dist * rmult * rmult) && (!d.a(worldserver, i, j, k, c)))
      {
        c.c.a(c, worldserver, itemstack, i, j, k, l, par1Packet15Place.j(), par1Packet15Place.k(), par1Packet15Place.l());
      }
      
      flag = true;
    }
    
    if (flag)
    {
      c.a.b(new gg(i, j, k, worldserver));
      
      if (l == 0)
      {
        j--;
      }
      
      if (l == 1)
      {
        j++;
      }
      
      if (l == 2)
      {
        k--;
      }
      
      if (l == 3)
      {
        k++;
      }
      
      if (l == 4)
      {
        i--;
      }
      
      if (l == 5)
      {
        i++;
      }
      
      c.a.b(new gg(i, j, k, worldserver));
    }
    
    itemstack = c.bn.h();
    
    if ((itemstack != null) && (b == 0))
    {
      c.bn.a[c.bn.c] = null;
      itemstack = null;
    }
    
    if ((itemstack == null) || (itemstack.n() == 0))
    {
      c.h = true;
      c.bn.a[c.bn.c] = ye.b(c.bn.a[c.bn.c]);
      we slot = c.bp.a(c.bn, c.bn.c);
      c.bp.b();
      c.h = false;
      
      if (!ye.b(c.bn.h(), par1Packet15Place.i()))
      {
        b(new dz(c.bp.d, g, c.bn.h()));
      }
    }
    
    if ((c.isHuge()) && (c.heldEntity == null) && ((itemstack == null) || (d == aycv)))
    {

      double xpos = par1Packet15Place.d() + par1Packet15Place.j();
      double ypos = par1Packet15Place.f() + par1Packet15Place.k();
      double zpos = par1Packet15Place.g() + par1Packet15Place.l();
      boolean hasBucket = (itemstack != null) && (d == aycv);
      double r = c.getSizeMultiplierRoot() * (hasBucket ? 1.0D : 0.5D);
      List stuff = worldserver.a(ss.class, asx.a(xpos - r, ypos - r * 0.75D, zpos - r, xpos + r, ypos + r * 0.75D, zpos + r));
      
      if (stuff != null)
      {
        for (int p = 0; p < stuff.size(); p++)
        {
          nn thing = (nn)stuff.get(p);
          
          if (!M)
          {
            thing.b_(c);
          }
        }
      }
      
      if (!hasBucket)
      {
        stuff = worldserver.a(uh.class, asx.a(xpos - r, ypos - r * 0.5D, zpos - r, xpos + r, ypos + r * 0.5D, zpos + r));
        
        if (stuff != null)
        {
          for (int p = 0; p < stuff.size(); p++)
          {
            nn thing = (nn)stuff.get(p);
            
            if (!M)
            {
              thing.b_(c);
            }
          }
        }
      }
    }
  }
  
  public void a(String par1Str, Object[] par2ArrayOfObj)
  {
    d.an().a(c.c_() + " lost connection: " + par1Str);
    d.af().a(cv.b("multiplayer.player.left", new Object[] { c.ay() }).a(a.o));
    d.af().e(c);
    b = true;
    
    if ((d.K()) && (c.c_().equals(d.J())))
    {
      d.an().a("Stopping singleplayer server as player logged out");
      d.p();
    }
  }
  




  public void a(ey par1Packet)
  {
    d.an().b(getClass() + " wasn't prepared to deal with a " + par1Packet.getClass());
    c("Protocol error, unexpected packet");
  }
  



  public void b(ey par1Packet)
  {
    if ((par1Packet instanceof dm))
    {
      dm packet3chat = (dm)par1Packet;
      int i = c.t();
      
      if (i == 2)
      {
        return;
      }
      
      if ((i == 1) && (!packet3chat.d()))
      {
        return;
      }
    }
    
    try
    {
      a.a(par1Packet);
    }
    catch (Throwable throwable)
    {
      b crashreport = b.a(throwable, "Sending packet");
      m crashreportcategory = crashreport.a("Packet being sent");
      crashreportcategory.a("Packet ID", new kb(this, par1Packet));
      crashreportcategory.a("Packet class", new kc(this, par1Packet));
      throw new u(crashreport);
    }
  }
  
  public void a(fk par1Packet16BlockItemSwitch)
  {
    if ((a >= 0) && (a < ud.i()))
    {
      c.bn.c = a;
      c.u();
    }
    else
    {
      d.an().b(c.c_() + " tried to set an invalid carried item");
    }
  }
  
  public void a(dm par1Packet3Chat)
  {
    par1Packet3Chat = FMLNetworkHandler.handleChatMessage(this, par1Packet3Chat);
    
    if ((par1Packet3Chat == null) || (a == null))
    {
      return;
    }
    if (c.t() == 2)
    {
      b(new dm(cv.e("chat.cannotSend").a(a.m)));
    }
    else
    {
      c.u();
      String s = a;
      
      if (s.length() > 100)
      {
        c("Chat message too long");
      }
      else
      {
        for (int i = 0; i < s.length(); i++)
        {
          if (!v.a(s.charAt(i)))
          {
            c("Illegal characters in chat");
            return;
          }
        }
        
        if (s.startsWith("/"))
        {
          d(s);
        }
        else
        {
          if (c.t() == 1)
          {
            b(new dm(cv.e("chat.cannotSend").a(a.m)));
            return;
          }
          
          cv chatmessagecomponent = cv.b("chat.type.text", new Object[] { c.ay(), s });
          chatmessagecomponent = ForgeHooks.onServerChatEvent(this, s, chatmessagecomponent);
          if (chatmessagecomponent == null) return;
          d.af().a(chatmessagecomponent, false);
        }
        
        l += 20;
        
        if ((l > 200) && (!d.af().e(c.c_())))
        {
          c("disconnect.spam");
        }
      }
    }
  }
  



  private void d(String par1Str)
  {
    d.G().a(c, par1Str);
  }
  
  public void a(dj par1Packet18Animation)
  {
    c.u();
    
    if (b == 1)
    {
      c.aV();
    }
  }
  



  public void a(fc par1Packet19EntityAction)
  {
    c.u();
    
    if (b == 1)
    {
      c.b(true);
    }
    else if (b == 2)
    {
      c.b(false);
    }
    else if (b == 4)
    {
      c.c(true);
    }
    else if (b == 5)
    {
      c.c(false);
    }
    else if (b == 3)
    {
      c.a(false, true, true);
      q = false;
    }
    else if (b == 6)
    {
      if ((c.o != null) && ((c.o instanceof rs)))
      {
        ((rs)c.o).u(c);
      }
    }
    else if ((b == 7) && (c.o != null) && ((c.o instanceof rs)))
    {
      ((rs)c.o).f(c);
    }
  }
  
  public void a(eb par1Packet255KickDisconnect)
  {
    a.a("disconnect.quitting", new Object[0]);
  }
  



  public int f()
  {
    return a.e();
  }
  
  public void a(eh par1Packet7UseEntity)
  {
    js worldserver = d.a(c.ar);
    nn entity = worldserver.a(b);
    c.u();
    
    if (entity != null)
    {
      boolean flag = c.o(entity);
      double d0 = 6.0D;
      
      if (!flag)
      {
        d0 = 3.0D;
      }
      

      double rmult = c.getRangeMultiplier();
      if ((c.getSizeMultiplier() < 1.0F) && (c.holdingPointyItem()))
      {
        rmult = Math.cbrt(c.getSizeMultiplier());
      }
      if ((c.o == entity) || (c.d(entity) < d0 * rmult + Math.sqrt(P * P + O * O)))
      {
        if (c == 0)
        {
          c.p(entity);
        }
        else if (c == 1)
        {
          if (((entity instanceof ss)) || ((entity instanceof oa)) || ((entity instanceof uh)) || (entity == c))
          {
            c("Attempting to attack an invalid entity");
            d.f("Player " + c.c_() + " tried to attack an invalid entity");
            return;
          }
          
          c.q(entity);
        }
      }
    }
  }
  
  public void a(do par1Packet205ClientCommand)
  {
    c.u();
    
    if (a == 1)
    {
      if (c.j)
      {
        c = d.af().a(c, 0, true);
      }
      else if (c.p().N().t())
      {
        if ((d.K()) && (c.c_().equals(d.J())))
        {
          c.a.c("You have died. Game over, man, it's game over!");
          d.R();
        }
        else
        {
          gm banentry = new gm(c.c_());
          banentry.b("Death in Hardcore");
          d.af().e().a(banentry);
          c.a.c("You have died. Game over, man, it's game over!");
        }
      }
      else
      {
        if (c.aN() > 0.0F)
        {
          return;
        }
        
        c = d.af().a(c, c.ar, false);
      }
    }
  }
  





  public boolean b()
  {
    return true;
  }
  


  public void a(fh par1Packet9Respawn) {}
  

  public void a(dv par1Packet101CloseWindow)
  {
    c.k();
  }
  
  public void a(du par1Packet102WindowClick)
  {
    c.u();
    
    if ((c.bp.d == a) && (c.bp.c(c)))
    {
      ye itemstack = c.bp.a(b, c, f, c);
      
      if (ye.b(e, itemstack))
      {
        c.a.b(new ds(a, d, true));
        c.h = true;
        c.bp.b();
        c.j();
        c.h = false;
      }
      else
      {
        r.a(c.bp.d, Short.valueOf(d));
        c.a.b(new ds(a, d, false));
        c.bp.a(c, false);
        ArrayList arraylist = new ArrayList();
        
        for (int i = 0; i < c.bp.c.size(); i++)
        {
          arraylist.add(((we)c.bp.c.get(i)).d());
        }
        
        c.a(c.bp, arraylist);
      }
    }
  }
  
  public void a(dt par1Packet108EnchantItem)
  {
    c.u();
    
    if ((c.bp.d == a) && (c.bp.c(c)))
    {
      c.bp.a(c, b);
      c.bp.b();
    }
  }
  



  public void a(fl par1Packet107CreativeSetSlot)
  {
    if (c.c.d())
    {
      boolean flag = a < 0;
      ye itemstack = b;
      boolean flag1 = (a >= 1) && (a < 36 + ud.i());
      boolean flag2 = (itemstack == null) || ((d < yc.g.length) && (d >= 0) && (yc.g[d] != null));
      boolean flag3 = (itemstack == null) || ((itemstack.k() >= 0) && (itemstack.k() >= 0) && (b <= 64) && (b > 0));
      
      if ((flag1) && (flag2) && (flag3))
      {
        if (itemstack == null)
        {
          c.bo.a(a, (ye)null);
        }
        else
        {
          c.bo.a(a, itemstack);
        }
        
        c.bo.a(c, true);
      }
      else if ((flag) && (flag2) && (flag3) && (m < 200))
      {
        m += 20;
        ss entityitem = c.b(itemstack);
        
        if (entityitem != null)
        {
          entityitem.c();
        }
      }
    }
  }
  
  public void a(ds par1Packet106Transaction)
  {
    Short oshort = (Short)r.a(c.bp.d);
    
    if ((oshort != null) && (b == oshort.shortValue()) && (c.bp.d == a) && (!c.bp.c(c)))
    {
      c.bp.a(c, true);
    }
  }
  



  public void a(fz par1Packet130UpdateSign)
  {
    c.u();
    js worldserver = d.a(c.ar);
    
    if (worldserver.f(a, b, c))
    {
      asp tileentity = worldserver.r(a, b, c);
      
      if ((tileentity instanceof asm))
      {
        asm tileentitysign = (asm)tileentity;
        
        if ((!tileentitysign.a()) || (tileentitysign.b() != c))
        {
          d.f("Player " + c.c_() + " just tried to change non-editable sign");
          return;
        }
      }
      



      for (int j = 0; j < 4; j++)
      {
        boolean flag = true;
        
        if (d[j].length() > 15)
        {
          flag = false;
        }
        else
        {
          for (int i = 0; i < d[j].length(); i++)
          {
            if (v.a.indexOf(d[j].charAt(i)) < 0)
            {
              flag = false;
            }
          }
        }
        
        if (!flag)
        {
          d[j] = "!?";
        }
      }
      
      if ((tileentity instanceof asm))
      {
        j = a;
        int k = b;
        int i = c;
        asm tileentitysign1 = (asm)tileentity;
        System.arraycopy(d, 0, a, 0, 4);
        tileentitysign1.e();
        worldserver.j(j, k, i);
      }
    }
  }
  



  public void a(ei par1Packet0KeepAlive)
  {
    if (a == h)
    {
      int i = (int)(System.nanoTime() / 1000000L - this.i);
      c.i = ((c.i * 3 + i) / 4);
    }
  }
  



  public boolean a()
  {
    return true;
  }
  



  public void a(fa par1Packet202PlayerAbilities)
  {
    c.bG.b = ((par1Packet202PlayerAbilities.f()) && (c.bG.c));
  }
  
  public void a(dl par1Packet203AutoComplete)
  {
    StringBuilder stringbuilder = new StringBuilder();
    
    String s;
    for (Iterator iterator = d.a(c, par1Packet203AutoComplete.d()).iterator(); iterator.hasNext(); stringbuilder.append(s))
    {
      s = (String)iterator.next();
      
      if (stringbuilder.length() > 0)
      {
        stringbuilder.append("\000");
      }
    }
    
    c.a.b(new dl(stringbuilder.toString()));
  }
  
  public void a(dp par1Packet204ClientInfo)
  {
    c.a(par1Packet204ClientInfo);
  }
  
  public void a(ea par1Packet250CustomPayload)
  {
    FMLNetworkHandler.handlePacket250Packet(par1Packet250CustomPayload, a, this);
  }
  

  public void handleVanilla250Packet(ea par1Packet250CustomPayload)
  {
    DataInputStream datainputstream;
    ye itemstack;
    ye itemstack1;
    if ("MC|BEdit".equals(a))
    {
      try
      {
        datainputstream = new DataInputStream(new ByteArrayInputStream(c));
        itemstack = ey.c(datainputstream);
        
        if (!zn.a(itemstack.q()))
        {
          throw new IOException("Invalid book tag!");
        }
        
        itemstack1 = c.bn.h();
        
        if ((itemstack != null) && (d == bHcv) && (d == d))
        {
          itemstack1.a("pages", itemstack.q().m("pages"));
        }
      }
      catch (Exception exception)
      {
        exception.printStackTrace();
      }
    }
    else if ("MC|BSign".equals(a))
    {
      try
      {
        datainputstream = new DataInputStream(new ByteArrayInputStream(c));
        itemstack = ey.c(datainputstream);
        
        if (!zo.a(itemstack.q()))
        {
          throw new IOException("Invalid book tag!");
        }
        
        itemstack1 = c.bn.h();
        
        if ((itemstack != null) && (d == bIcv) && (d == bHcv))
        {
          itemstack1.a("author", new ck("author", c.c_()));
          itemstack1.a("title", new ck("title", itemstack.q().i("title")));
          itemstack1.a("pages", itemstack.q().m("pages"));
          d = bIcv;
        }
      }
      catch (Exception exception1)
      {
        exception1.printStackTrace();
      }
    }
    else
    {
      int i;
      
      if ("MC|TrSel".equals(a))
      {
        try
        {
          datainputstream = new DataInputStream(new ByteArrayInputStream(c));
          i = datainputstream.readInt();
          uy container = c.bp;
          
          if ((container instanceof vz))
          {
            ((vz)container).e(i);
          }
        }
        catch (Exception exception2)
        {
          exception2.printStackTrace();
        }
      }
      else
      {
        int j;
        
        if ("MC|AdvCdm".equals(a))
        {
          if (!d.ab())
          {
            c.a(cv.e("advMode.notEnabled"));
          }
          else if ((c.a(2, "")) && (c.bG.d))
          {
            try
            {
              datainputstream = new DataInputStream(new ByteArrayInputStream(c));
              i = datainputstream.readInt();
              j = datainputstream.readInt();
              int k = datainputstream.readInt();
              String s = ey.a(datainputstream, 256);
              asp tileentity = c.q.r(i, j, k);
              
              if ((tileentity != null) && ((tileentity instanceof arz)))
              {
                ((arz)tileentity).a(s);
                c.q.j(i, j, k);
                c.a(cv.b("advMode.setCommand.success", new Object[] { s }));
              }
            }
            catch (Exception exception3)
            {
              exception3.printStackTrace();
            }
            
          }
          else {
            c.a(cv.e("advMode.notAllowed"));
          }
        }
        else if ("MC|Beacon".equals(a))
        {
          if ((c.bp instanceof vd))
          {
            try
            {
              datainputstream = new DataInputStream(new ByteArrayInputStream(c));
              i = datainputstream.readInt();
              j = datainputstream.readInt();
              vd containerbeacon = (vd)c.bp;
              we slot = containerbeacon.a(0);
              
              if (slot.e())
              {
                slot.a(1);
                arw tileentitybeacon = containerbeacon.e();
                tileentitybeacon.d(i);
                tileentitybeacon.e(j);
                tileentitybeacon.e();
              }
            }
            catch (Exception exception4)
            {
              exception4.printStackTrace();
            }
          }
        }
        else if (("MC|ItemName".equals(a)) && ((c.bp instanceof va)))
        {
          va containerrepair = (va)c.bp;
          
          if ((c != null) && (c.length >= 1))
          {
            String s1 = v.a(new String(c));
            
            if (s1.length() <= 30)
            {
              containerrepair.a(s1);
            }
          }
          else
          {
            containerrepair.a("");
          }
        }
      }
    }
  }
  
  public boolean c()
  {
    return b;
  }
  






  public void a(dr par1Packet131MapData)
  {
    FMLNetworkHandler.handlePacket131Packet(this, par1Packet131MapData);
  }
  


  public jv getPlayer()
  {
    return c;
  }
}
