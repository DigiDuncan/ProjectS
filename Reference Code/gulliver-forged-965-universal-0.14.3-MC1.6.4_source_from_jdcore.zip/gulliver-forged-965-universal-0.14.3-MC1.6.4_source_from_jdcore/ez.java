import gulliver.network.packet.Packet171EntitySize;
import gulliver.network.packet.Packet172AttachEntitySpecial;












public abstract class ez
{
  public ez() {}
  
  public abstract boolean a();
  
  public void a(ej par1Packet51MapChunk) {}
  
  public void a(ey par1Packet) {}
  
  public void a(String par1Str, Object[] par2ArrayOfObj) {}
  
  public void a(eb par1Packet255KickDisconnect)
  {
    a(par1Packet255KickDisconnect);
  }
  
  public void a(ep par1Packet1Login)
  {
    a(par1Packet1Login);
  }
  
  public void a(eu par1Packet10Flying)
  {
    a(par1Packet10Flying);
  }
  
  public void a(dn par1Packet52MultiBlockChange)
  {
    a(par1Packet52MultiBlockChange);
  }
  
  public void a(fb par1Packet14BlockDig)
  {
    a(par1Packet14BlockDig);
  }
  
  public void a(gg par1Packet53BlockChange)
  {
    a(par1Packet53BlockChange);
  }
  
  public void a(di par1Packet20NamedEntitySpawn)
  {
    a(par1Packet20NamedEntitySpawn);
  }
  
  public void a(eq par1Packet30Entity)
  {
    a(par1Packet30Entity);
  }
  
  public void handleEntitySize(Packet171EntitySize par1Packet171EntitySize)
  {
    a(par1Packet171EntitySize);
  }
  
  public void handleAttachEntitySpecial(Packet172AttachEntitySpecial par1Packet172AttachEntitySpecial)
  {
    a(par1Packet172AttachEntitySpecial);
  }
  
  public void a(gb par1Packet34EntityTeleport)
  {
    a(par1Packet34EntityTeleport);
  }
  
  public void a(gk par1Packet15Place)
  {
    a(par1Packet15Place);
  }
  
  public void a(fk par1Packet16BlockItemSwitch)
  {
    a(par1Packet16BlockItemSwitch);
  }
  
  public void a(ff par1Packet29DestroyEntity)
  {
    a(par1Packet29DestroyEntity);
  }
  
  public void a(ga par1Packet22Collect)
  {
    a(par1Packet22Collect);
  }
  
  public void a(dm par1Packet3Chat)
  {
    a(par1Packet3Chat);
  }
  
  public void a(dd par1Packet23VehicleSpawn)
  {
    a(par1Packet23VehicleSpawn);
  }
  
  public void a(dj par1Packet18Animation)
  {
    a(par1Packet18Animation);
  }
  



  public void a(fc par1Packet19EntityAction)
  {
    a(par1Packet19EntityAction);
  }
  
  public void a(dq par1Packet2ClientProtocol)
  {
    a(par1Packet2ClientProtocol);
  }
  
  public void a(fj par1Packet253ServerAuthData)
  {
    a(par1Packet253ServerAuthData);
  }
  
  public void a(fy par1Packet252SharedKey)
  {
    a(par1Packet252SharedKey);
  }
  
  public void a(dg par1Packet24MobSpawn)
  {
    a(par1Packet24MobSpawn);
  }
  
  public void a(fx par1Packet4UpdateTime)
  {
    a(par1Packet4UpdateTime);
  }
  
  public void a(fw par1Packet6SpawnPosition)
  {
    a(par1Packet6SpawnPosition);
  }
  



  public void a(fp par1Packet28EntityVelocity)
  {
    a(par1Packet28EntityVelocity);
  }
  



  public void a(fn par1Packet40EntityMetadata)
  {
    a(par1Packet40EntityMetadata);
  }
  



  public void a(fo par1Packet39AttachEntity)
  {
    a(par1Packet39AttachEntity);
  }
  
  public void a(eh par1Packet7UseEntity)
  {
    a(par1Packet7UseEntity);
  }
  



  public void a(ed par1Packet38EntityStatus)
  {
    a(par1Packet38EntityStatus);
  }
  



  public void a(fs par1Packet8UpdateHealth)
  {
    a(par1Packet8UpdateHealth);
  }
  



  public void a(fh par1Packet9Respawn)
  {
    a(par1Packet9Respawn);
  }
  
  public void a(ee par1Packet60Explosion)
  {
    a(par1Packet60Explosion);
  }
  
  public void a(dw par1Packet100OpenWindow)
  {
    a(par1Packet100OpenWindow);
  }
  
  public void a(dv par1Packet101CloseWindow)
  {
    a(par1Packet101CloseWindow);
  }
  
  public void a(du par1Packet102WindowClick)
  {
    a(par1Packet102WindowClick);
  }
  
  public void a(dz par1Packet103SetSlot)
  {
    a(par1Packet103SetSlot);
  }
  
  public void a(dx par1Packet104WindowItems)
  {
    a(par1Packet104WindowItems);
  }
  



  public void a(fz par1Packet130UpdateSign)
  {
    a(par1Packet130UpdateSign);
  }
  
  public void a(dy par1Packet105UpdateProgressbar)
  {
    a(par1Packet105UpdateProgressbar);
  }
  
  public void a(fq par1Packet5PlayerInventory)
  {
    a(par1Packet5PlayerInventory);
  }
  
  public void a(ds par1Packet106Transaction)
  {
    a(par1Packet106Transaction);
  }
  



  public void a(dh par1Packet25EntityPainting)
  {
    a(par1Packet25EntityPainting);
  }
  
  public void a(gf par1Packet54PlayNoteBlock)
  {
    a(par1Packet54PlayNoteBlock);
  }
  



  public void a(dk par1Packet200Statistic)
  {
    a(par1Packet200Statistic);
  }
  
  public void a(ec par1Packet17Sleep)
  {
    a(par1Packet17Sleep);
  }
  
  public void a(fe par1Packet27PlayerInput)
  {
    a(par1Packet27PlayerInput);
  }
  
  public void a(ef par1Packet70GameEvent)
  {
    a(par1Packet70GameEvent);
  }
  



  public void a(df par1Packet71Weather)
  {
    a(par1Packet71Weather);
  }
  



  public void a(dr par1Packet131MapData)
  {
    a(par1Packet131MapData);
  }
  
  public void a(em par1Packet61DoorChange)
  {
    a(par1Packet61DoorChange);
  }
  



  public void a(eg par1Packet254ServerPing)
  {
    a(par1Packet254ServerPing);
  }
  



  public void a(gj par1Packet41EntityEffect)
  {
    a(par1Packet41EntityEffect);
  }
  



  public void a(fg par1Packet42RemoveEntityEffect)
  {
    a(par1Packet42RemoveEntityEffect);
  }
  



  public void a(fd par1Packet201PlayerInfo)
  {
    a(par1Packet201PlayerInfo);
  }
  



  public void a(ei par1Packet0KeepAlive)
  {
    a(par1Packet0KeepAlive);
  }
  



  public void a(fr par1Packet43Experience)
  {
    a(par1Packet43Experience);
  }
  



  public void a(fl par1Packet107CreativeSetSlot)
  {
    a(par1Packet107CreativeSetSlot);
  }
  



  public void a(de par1Packet26EntityExpOrb)
  {
    a(par1Packet26EntityExpOrb);
  }
  
  public void a(dt par1Packet108EnchantItem) {}
  
  public void a(ea par1Packet250CustomPayload) {}
  
  public void a(fi par1Packet35EntityHeadRotation)
  {
    a(par1Packet35EntityHeadRotation);
  }
  
  public void a(ge par1Packet132TileEntityData)
  {
    a(par1Packet132TileEntityData);
  }
  



  public void a(fa par1Packet202PlayerAbilities)
  {
    a(par1Packet202PlayerAbilities);
  }
  
  public void a(dl par1Packet203AutoComplete)
  {
    a(par1Packet203AutoComplete);
  }
  
  public void a(dp par1Packet204ClientInfo)
  {
    a(par1Packet204ClientInfo);
  }
  
  public void a(eo par1Packet62LevelSound)
  {
    a(par1Packet62LevelSound);
  }
  
  public void a(gc par1Packet55BlockDestroy)
  {
    a(par1Packet55BlockDestroy);
  }
  
  public void a(do par1Packet205ClientCommand) {}
  
  public void a(el par1Packet56MapChunks)
  {
    a(par1Packet56MapChunks);
  }
  





  public boolean b()
  {
    return false;
  }
  



  public void a(ft par1Packet206SetObjective)
  {
    a(par1Packet206SetObjective);
  }
  



  public void a(fv par1Packet207SetScore)
  {
    a(par1Packet207SetScore);
  }
  



  public void a(fm par1Packet208SetDisplayObjective)
  {
    a(par1Packet208SetDisplayObjective);
  }
  



  public void a(fu par1Packet209SetPlayerTeam)
  {
    a(par1Packet209SetPlayerTeam);
  }
  



  public void a(en par1Packet63WorldParticles)
  {
    a(par1Packet63WorldParticles);
  }
  
  public void a(gh par1Packet44UpdateAttributes)
  {
    a(par1Packet44UpdateAttributes);
  }
  
  public void a(gd par1Packet133TileEditorOpen) {}
  
  public boolean c()
  {
    return false;
  }
  
  public abstract void handleVanilla250Packet(ea paramEa);
  
  public abstract uf getPlayer();
}
