import cpw.mods.fml.common.FMLCommonHandler;
import cpw.mods.fml.common.network.FMLNetworkHandler;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import gulliver.api.IResizeablePlayer;
import gulliver.common.GulliverEnvoy;
import gulliver.common.GulliverOMHelper;
import gulliver.network.packet.Packet171EntitySize;
import gulliver.network.packet.Packet172AttachEntitySpecial;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Random;
import net.minecraftforge.common.ForgeHooks;
import net.minecraftforge.common.ISpecialArmor.ArmorProperties;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.EventBus;
import net.minecraftforge.event.ForgeEventFactory;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.event.entity.player.EntityInteractEvent;
import net.minecraftforge.event.entity.player.PlayerDestroyItemEvent;
import net.minecraftforge.event.entity.player.PlayerDropsEvent;
import net.minecraftforge.event.entity.player.PlayerFlyableFallEvent;
import net.minecraftforge.event.entity.player.PlayerSleepInBedEvent;









































































public abstract class uf
  extends of
  implements ad, IResizeablePlayer
{
  public static final String PERSISTED_NBT_TAG = "PlayerPersisted";
  public static float playerNormalHeight = 1.8F;
  public static float playerNormalWidth = 0.6F;
  
  public static float playerNormalYOffset = 1.62F;
  

  public ud bn = new ud(this);
  private wb a = new wb();
  


  public uy bo;
  


  public uy bp;
  

  protected ux bq = new ux();
  
  protected int br;
  
  public float bs;
  
  public float bt;
  
  public final String bu;
  
  public int bv;
  
  public double bw;
  
  public double bx;
  
  public double by;
  
  public double bz;
  
  public double bA;
  
  public double bB;
  
  protected boolean bC;
  
  public t bD;
  
  public int b;
  
  public float bE;
  
  @SideOnly(Side.CLIENT)
  public float cc;
  
  public float bF;
  
  private t c;
  
  private HashMap<Integer, t> spawnChunkMap = new HashMap();
  

  private boolean d;
  

  private HashMap<Integer, Boolean> spawnForcedMap = new HashMap();
  

  private t e;
  

  public uc bG = new uc();
  



  public int bH;
  


  public int bI;
  


  public float bJ;
  


  private ye f;
  


  private int g;
  


  protected float bK = 0.1F;
  protected float bL = 0.02F;
  

  private int h;
  

  public float ySizeOld;
  

  public ul bM;
  

  public int bedScale = 1;
  public float eyeHeight;
  private String displayname;
  
  public void doResize(float f, boolean reposition) { float pOffset = N;
    float oldw = O;
    super.doResize(f, false);
    d_();
    
    if (bC)
    {
      N *= 0.2F / playerNormalHeight;
      a(0.2F, 0.2F);
    }
    else if (M)
    {
      N *= 0.1F / playerNormalHeight;
      a(0.2F, 0.2F);
    }
    else
    {
      a(playerNormalWidth, playerNormalHeight);
    }
    
    if ((reposition) && (!bC) && (!(this instanceof jv)))
    {

      b(u, v + N - pOffset + (getSizeMultiplier() >= 1.0D ? 0.001D : getSizeMultiplier() * 0.001D), w);
      GulliverEnvoy.resizeCollision(this, oldw, O);
    }
  }
  
  public void doWalkingResize(float f, boolean reposition)
  {
    float pOffset = N;
    float oldw = O;
    super.doWalkingResize(f, false);
    d_();
    
    if (bC)
    {
      N *= 0.2F / playerNormalHeight;
      a(0.2F, 0.2F);
    }
    else if (M)
    {
      N *= 0.1F / playerNormalHeight;
      a(0.2F, 0.2F);
    }
    else
    {
      a(playerNormalWidth, playerNormalHeight);
    }
    
    if ((this instanceof jv))
    {
      a.b(new Packet171EntitySize(this, getSizeMultiplier()));
    }
    else if ((reposition) && (!bC))
    {

      b(u, v + N - pOffset + (getSizeMultiplier() >= 1.0D ? 0.01D : getSizeMultiplier() * 0.01D), w);
      GulliverEnvoy.resizeCollision(this, oldw, O);
    }
  }
  


  public float getSizeItemMultiplier()
  {
    float osize = 1.0F;
    
    for (int i = 0; i < bn.a.length; i++)
    {
      if ((GulliverEnvoy.isDyeResizingEnabled()) && (bn.a[i] != null) && ((bn.a[i].b() instanceof xl)))
      {
        if (bn.a[i].k() == 6)
        {
          osize *= 0.5F;
        }
        else if (bn.a[i].k() == 5)
        {
          osize *= 2.0F;
        }
      }
    }
    
    return osize;
  }
  
  public boolean applyKarma()
  {
    if (GulliverEnvoy.isKarmaModeEnabled())
    {
      float bsize = GulliverEnvoy.getNewBasePlayerSize();
      setSizeBaseMultiplier(bsize);
      q.lastSizeBase = bsize;
      return true;
    }
    
    return false;
  }
  
  public uf(abw par1World, String par2Str)
  {
    super(par1World);
    bu = par2Str;
    bo = new vv(bn, !I, this);
    bp = bo;
    ySizeOld = X;
    setSizeMultiplier(1.0F);
    d_();
    Y = 0.5F;
    t chunkcoordinates = par1World.K();
    b(a + 0.5D, b + 1, c + 0.5D, 0.0F, 0.0F);
    ba = 180.0F;
    ad = 20;
    eyeHeight = (getDefaultEyeHeight() * getSizeMultiplier());
    
    if (!I)
    {
      if (!applyKarma())
      {
        setSizeBaseMultiplier(lastSizeBase);
      }
      
      doResize(sizeBaseMultiplier, false);
      refreshSizeDestMultiplier();
    }
  }
  
  protected void az()
  {
    super.az();
    aX().b(tp.e).a(1.0D);
  }
  
  protected void a()
  {
    super.a();
    ah.a(16, Byte.valueOf((byte)0));
    ah.a(17, Float.valueOf(0.0F));
    ah.a(18, Integer.valueOf(0));
  }
  




  @SideOnly(Side.CLIENT)
  public ye bp()
  {
    return f;
  }
  




  @SideOnly(Side.CLIENT)
  public int bq()
  {
    return g;
  }
  



  public boolean br()
  {
    return f != null;
  }
  




  @SideOnly(Side.CLIENT)
  public int bs()
  {
    if (br())
    {
      if ((f.o() == zj.b) || (f.o() == zj.c))
      {
        return (int)(f.n() / getRangeMultiplier()) - g;
      }
      

      return f.n() - g;
    }
    


    return 0;
  }
  

  public void bt()
  {
    if (f != null)
    {
      f.b(q, this, g);
    }
    
    bu();
  }
  
  public void bu()
  {
    f = null;
    g = 0;
    
    if (!q.I)
    {
      e(false);
    }
  }
  
  public boolean bv()
  {
    return (br()) && (yc.g[f.d].c_(f) == zj.d);
  }
  



  public void l_()
  {
    FMLCommonHandler.instance().onPlayerPreTick(this);
    if (f != null)
    {
      ye itemstack = bn.h();
      
      if (itemstack == f)
      {
        zj action = f.o();
        f.b().onUsingItemTick(f, this, g);
        if ((action == zj.b) || (action == zj.c))
        {
          if ((g <= (int)(25.0F / getRangeMultiplier())) && (g % 4 == 0))
          {
            c(itemstack, (int)(5.0F * getSizeMultiplierRoot()));
          }
        }
        else if ((g <= 25) && (g % 4 == 0))
        {
          c(itemstack, 5);
        }
        
        if ((--g == 0) && (!q.I))
        {
          n();
        }
      }
      else
      {
        bu();
      }
    }
    
    if (bv > 0)
    {
      bv -= 1;
    }
    
    if (bh())
    {
      b += 1;
      
      if (b > 100)
      {
        b = 100;
      }
      
      if (!q.I)
      {
        if (!h())
        {
          a(true, true, false);
        }
        else if (q.v())
        {
          a(false, true, true);
        }
        else if (bedScale == 1)
        {
          maybeShoveOtherSleeper();
        }
      }
    }
    else if (b > 0)
    {
      b += 1;
      
      if (b >= 110)
      {
        b = 0;
      }
    }
    
    super.l_();
    
    if ((!q.I) && (bp != null) && (!ForgeHooks.canInteractWith(this, bp)))
    {
      i();
      bp = bo;
    }
    
    if ((af()) && (bG.a))
    {
      B();
    }
    
    bw = bz;
    bx = bA;
    by = bB;
    double d0 = u - bz;
    double d1 = v - bA;
    double d2 = w - bB;
    double d3 = 10.0D;
    
    if (d0 > d3)
    {
      bw = (this.bz = u);
    }
    
    if (d2 > d3)
    {
      by = (this.bB = w);
    }
    
    if (d1 > d3)
    {
      bx = (this.bA = v);
    }
    
    if (d0 < -d3)
    {
      bw = (this.bz = u);
    }
    
    if (d2 < -d3)
    {
      by = (this.bB = w);
    }
    
    if (d1 < -d3)
    {
      bx = (this.bA = v);
    }
    
    bz += d0 * 0.25D;
    bB += d2 * 0.25D;
    bA += d1 * 0.25D;
    a(la.k, 1);
    
    if (o == null)
    {
      e = null;
    }
    
    if (!q.I)
    {
      bq.a(this);
    }
    FMLCommonHandler.instance().onPlayerPostTick(this);
  }
  



  public int z()
  {
    return bG.a ? 0 : 80;
  }
  



  public int ac()
  {
    return 10;
  }
  
  public void a(String par1Str, float par2, float par3)
  {
    q.a(this, par1Str, par2 * getSizeMultiplierRoot(), par3);
  }
  



  protected void c(ye par1ItemStack, int par2)
  {
    if (par1ItemStack.o() == zj.c)
    {
      a("random.drink", 0.5F * getSizeMultiplierRoot(), q.s.nextFloat() * 0.1F + 0.7F + 0.2F / getSizeMultiplierRoot());
    }
    
    if (par1ItemStack.o() == zj.b)
    {
      double dsizemult = getSizeMultiplier();
      double dsizeroot = getSizeMultiplierRoot();
      
      for (int j = 0; j < par2; j++)
      {
        atc var4 = q.V().a((ab.nextFloat() - 0.5D) * 0.1D * dsizeroot, (Math.random() * 0.1D + 0.1D) * dsizeroot, 0.0D);
        var4.a(-B * 3.1415927F / 180.0F);
        var4.b(-A * 3.1415927F / 180.0F);
        atc var5 = q.V().a((ab.nextFloat() - 0.5D) * 0.3D * dsizemult, (-ab.nextFloat() * 0.6D - 0.3D) * dsizemult, 0.6D * dsizemult);
        var5.a(-B * 3.1415927F / 180.0F);
        var5.b(-A * 3.1415927F / 180.0F);
        var5 = var5.c(u, v + f(), w);
        q.a("iconcrack_" + bcv + "_" + par1ItemStack.k(), c, d, e, c, d + 0.05D * dsizemult, e);
      }
      
      a("random.eat", (0.5F + 0.5F * ab.nextInt(2)) * getSizeMultiplierRoot(), (ab.nextFloat() - ab.nextFloat()) * 0.2F + 0.8F + 0.2F / getSizeMultiplierRoot());
    }
  }
  



  protected void n()
  {
    if (f != null)
    {
      c(f, 16);
      int i = f.b;
      ye itemstack = f.b(q, this);
      
      if ((itemstack != f) || ((itemstack != null) && (b != i)))
      {
        bn.a[bn.c] = itemstack;
        
        if (b == 0)
        {
          bn.a[bn.c] = null;
        }
      }
      
      bu();
    }
  }
  
  @SideOnly(Side.CLIENT)
  public void a(byte par1)
  {
    if (par1 == 9)
    {
      n();
    }
    else
    {
      super.a(par1);
    }
  }
  



  protected boolean bc()
  {
    return (aN() <= 0.0F) || (bh());
  }
  



  public void i()
  {
    bp = bo;
  }
  



  public void a(nn par1Entity)
  {
    if ((o != null) && (par1Entity == null))
    {
      if (!q.I)
      {
        l(o);
      }
      
      if (o != null)
      {
        o.n = null;
      }
      
      o = null;
    } else {
      if ((n != null) && ((n == par1Entity) || (!n.isTinierThan(this))))
      {

        return;
      }
      if ((o != null) && (par1Entity == o))
      {
        super.a(par1Entity);
        
        if (o != null)
        {
          o.n = null;
        }
        
        o = null;
      }
      else
      {
        super.a(par1Entity);
      }
    }
  }
  


  public void V()
  {
    if ((!q.I) && (ah()))
    {
      a((nn)null);
      b(false);
    }
    else
    {
      double d0 = u;
      double d1 = v;
      double d2 = w;
      float f = A;
      float f1 = B;
      super.V();
      bs = bt;
      bt = 0.0F;
      k(u - d0, v - d1, w - d2);
      
      if (((o instanceof of)) && (((of)o).shouldRiderFaceForward(this)) && (O >= o.O * 0.5F))
      {
        B = f1;
        A = f;
        aN = o).aN;
      }
    }
  }
  
  public float maxHeldWidth(nn par1Entity)
  {
    if ((par1Entity instanceof sq))
    {
      return O * 0.75F;
    }
    if ((par1Entity instanceof rs))
    {
      return O * 0.8F;
    }
    

    return O * (O * 2.5F >= P ? 0.5F : 0.3F);
  }
  


  public boolean isEntityHoldingOn()
  {
    if (((o instanceof rz)) && (!((rz)o).bU()) && (isQuiteSmallerThan(o)))
    {
      return true;
    }
    
    if (((o instanceof oq)) && (((oq)o).bT()) && (o.isEntityInRelativeSizeRange(this, 0.075F, 1.5F)))
    {
      return true;
    }
    
    if (((o instanceof ro)) && (((ro)o).bB()) && (o.isEntityInRelativeSizeRange(this, 0.075F, 0.75F)) && (!a(akc.h)))
    {
      return true;
    }
    
    return super.isEntityHoldingOn();
  }
  






  @SideOnly(Side.CLIENT)
  public void w()
  {
    setSizeMultiplier(sizeBaseMultiplier * sizeBaseAdjustMultiplier);
    d_();
    a(playerNormalWidth, playerNormalHeight);
    super.w();
    g(aT());
    aB = 0;
  }
  
  protected void bl()
  {
    super.bl();
    aW();
  }
  





  public void c()
  {
    if (GulliverEnvoy.isClientPlayerEntity(this))
    {
      if (bG.b)
      {
        if (GulliverEnvoy.getClientPlayerMovementSneak(this))
        {
          y += 0.15D * (1.0F - getSizeMultiplierRoot());
        }
        
        if (GulliverEnvoy.getClientPlayerMovementJump(this))
        {
          y -= 0.15D * (1.0F - getSizeMultiplierRoot());
        }
      }
    }
    
    if (br > 0)
    {
      br -= 1;
    }
    
    if ((q.r == 0) && (aN() < aT()) && (q.O().b("naturalRegeneration")) && (ac % 20 * 12 == 0))
    {
      f(1.0F);
    }
    
    bn.k();
    bs = bt;
    super.c();
    os attributeinstance = a(tp.d);
    
    if (!q.I)
    {
      attributeinstance.a(bG.b());
    }
    
    aR = bL;
    
    if (ai())
    {
      aR = ((float)(aR + bL * 0.3D));
    }
    
    i((float)attributeinstance.e());
    float f = ls.a(x * x + z * z);
    float f1 = (float)Math.atan(-y * 0.20000000298023224D) * 15.0F;
    
    if (f > 0.1F)
    {
      f = 0.1F;
    }
    
    if ((!F) || (aN() <= 0.0F))
    {
      f = 0.0F;
    }
    
    if ((F) || (aN() <= 0.0F))
    {
      f1 = 0.0F;
    }
    

    bt += (f - bt) * 0.4F;
    aK += (f1 - aK) * 0.8F;
    
    if (aN() > 0.0F)
    {

      for (int j = 0; j < bn.b.length; j++)
      {
        if (cannotEquipItemOrArmor(j + 1, n(j + 1)))
        {
          ye stack = bn.b[j];
          if ((isHuge()) && ((stack.b() instanceof wh)))
          {
            stack.a(1, this);
          }
          a(stack, true);
          bn.b[j] = null;
        }
      }
      asx axisalignedbb = null;
      
      if ((o != null) && (!o.M))
      {
        axisalignedbb = E.a(o.E).b(1.0D * (o.getSizeMultiplier() > 1.0F ? o.getSizeMultiplierRoot() : o.getSizeMultiplier()), 0.0D, 1.0D * (o.getSizeMultiplier() > 1.0F ? o.getSizeMultiplierRoot() : o.getSizeMultiplier()));
      }
      else
      {
        axisalignedbb = E.b(1.0D * (getSizeMultiplier() > 1.0F ? getSizeMultiplierRoot() : getSizeMultiplier()), 0.5D * getSizeMultiplierRoot(), 1.0D * (getSizeMultiplier() > 1.0F ? getSizeMultiplierRoot() : getSizeMultiplier()));
      }
      
      List list = q.b(this, axisalignedbb);
      

      if (list != null)
      {
        for (int i = 0; i < list.size(); i++)
        {
          nn entity = (nn)list.get(i);
          
          if ((!M) && (((!(entity instanceof ss)) && (!(entity instanceof uh))) || (!isHuge())))
          {
            r(entity);
          }
        }
      }
      
      if (isHuge())
      {

        list = q.a(ss.class, E.b(0.5D * getSizeMultiplierRoot(), -0.25D * getSizeMultiplier(), 0.5D * getSizeMultiplierRoot()).c(0.0D, 0.25D * getSizeMultiplier(), 0.0D));
        
        if (list != null)
        {
          for (int i = 0; i < list.size(); i++)
          {
            nn entity = (nn)list.get(i);
            
            if (!M)
            {
              r(entity);
            }
          }
        }
      }
    }
  }
  
  private void r(nn par1Entity)
  {
    par1Entity.b_(this);
  }
  
  public int bw()
  {
    return ah.c(18);
  }
  



  public void c(int par1)
  {
    ah.b(18, Integer.valueOf(par1));
  }
  



  public void p(int par1)
  {
    int j = bw();
    ah.b(18, Integer.valueOf(j + par1));
  }
  



  public void a(nb par1DamageSource)
  {
    if (ForgeHooks.onLivingDeath(this, par1DamageSource)) return;
    super.a(par1DamageSource);
    a(0.2F, 0.2F);
    b(u, v, w);
    y = 0.10000000149011612D;
    
    captureDrops = true;
    capturedDrops.clear();
    
    if (bu.equals("Notch"))
    {
      a(new ye(yc.l, 1), true);
    }
    
    if (!q.O().b("keepInventory"))
    {
      bn.m();
    }
    
    captureDrops = false;
    
    if (!q.I)
    {
      PlayerDropsEvent event = new PlayerDropsEvent(this, par1DamageSource, capturedDrops, aT > 0);
      if (!MinecraftForge.EVENT_BUS.post(event))
      {
        for (ss item : capturedDrops)
        {
          a(item);
        }
      }
    }
    
    if (par1DamageSource != null)
    {
      x = (-ls.b((aA + A) * 3.1415927F / 180.0F) * 0.1F);
      z = (-ls.a((aA + A) * 3.1415927F / 180.0F) * 0.1F);
    }
    else
    {
      x = (this.z = 0.0D);
    }
    
    N = (0.1F * getSizeMultiplier());
    a(la.y, 1);
  }
  




  public void b(nn par1Entity, int par2)
  {
    p(par2);
    Collection collection = bM().a(ato.e);
    
    if ((par1Entity instanceof uf))
    {
      a(la.A, 1);
      collection.addAll(bM().a(ato.d));
    }
    else
    {
      a(la.z, 1);
    }
    
    Iterator iterator = collection.iterator();
    
    while (iterator.hasNext())
    {
      ate scoreobjective = (ate)iterator.next();
      atg score = bM().a(an(), scoreobjective);
      score.a();
    }
  }
  



  public ss a(boolean par1)
  {
    ye stack = bn.h();
    
    if (stack == null)
    {
      return heldEntity == null ? null : a(bn.a(bn.c, (par1) && (bn.h() != null) ? bn.h().b : 1), false);
    }
    
    if (stack.b().onDroppedByPlayer(stack, this))
    {
      int count = (par1) && (bn.h() != null) ? bn.h().b : 1;
      return ForgeHooks.onPlayerTossEvent(this, bn.a(bn.c, count));
    }
    
    return null;
  }
  




  public ss b(ye par1ItemStack)
  {
    return ForgeHooks.onPlayerTossEvent(this, par1ItemStack);
  }
  



  public ss a(ye par1ItemStack, boolean par2)
  {
    if ((par1ItemStack == null) && ((heldEntity == null) || (((heldEntity instanceof of)) && (((of)heldEntity).isEntityHoldingOn()))))
    {
      return null;
    }
    if ((par1ItemStack != null) && (b == 0))
    {
      return null;
    }
    
    nn held;
    
    nn held;
    if (par1ItemStack != null)
    {
      ss entityitem = new ss(q, u, v - 0.30000001192092896D * getSizeMultiplier() + f(), w, par1ItemStack);
      entityitem.setSizeMultiplier(getSizeMultiplierRoot());
      entityitem.a(0.25F * entityitem.getSizeMultiplier(), 0.25F * entityitem.getSizeMultiplier());
      b = 40;
      held = entityitem;
    }
    else
    {
      held = heldEntity;
      held.getDroppedByEntity(this);
    }
    






    float f = 0.1F;
    

    if (par2)
    {


      float f1 = ab.nextFloat() * 0.5F * getSizeMultiplierRoot();
      float f2 = ab.nextFloat() * 3.1415927F * 2.0F;
      x = (-ls.a(f2) * f1);
      z = (ls.b(f2) * f1);
      y = (0.20000000298023224D * (getSizeMultiplier() >= 1.0F ? 1.0D : getSizeMultiplier()));

    }
    else
    {
      f = 0.3F * (0.5F + 0.5F * getSizeMultiplierRoot());
      
      if (par1ItemStack == null)
      {
        f *= 2.0F;
      }
      
      x = (-ls.a(A / 180.0F * 3.1415927F) * ls.b(B / 180.0F * 3.1415927F) * f);
      z = (ls.b(A / 180.0F * 3.1415927F) * ls.b(B / 180.0F * 3.1415927F) * f);
      y = (-ls.a(B / 180.0F * 3.1415927F) * f + 0.1F * getSizeMultiplierRoot());
      f = 0.02F;
      float f1 = ab.nextFloat() * 3.1415927F * 2.0F;
      f *= ab.nextFloat();
      x += Math.cos(f1) * f;
      y += (ab.nextFloat() - ab.nextFloat()) * 0.1F * getSizeMultiplierRoot();
      z += Math.sin(f1) * f;
    }
    
    if (par1ItemStack != null)
    {
      a((ss)held);
      a(la.v, 1);
      return (ss)held;
    }
    if ((held instanceof jv))
    {
      a.b(new fp(k, x, y, z));
    }
    
    return null;
  }
  




  public void a(ss par1EntityItem)
  {
    if (captureDrops)
    {
      capturedDrops.add(par1EntityItem);
      return;
    }
    q.d(par1EntityItem);
  }
  




  @Deprecated
  public float a(aqz par1Block, boolean par2)
  {
    return getCurrentPlayerStrVsBlock(par1Block, par2, 0);
  }
  
  public float getCurrentPlayerStrVsBlock(aqz par1Block, boolean par2, int meta)
  {
    ye stack = bn.h();
    float f = stack == null ? 1.0F : stack.b().getStrVsBlock(stack, par1Block, meta);
    
    if (f > 1.0F)
    {
      int i = aaw.c(this);
      ye itemstack = bn.h();
      
      if ((i > 0) && (itemstack != null))
      {
        float f1 = i * i + 1;
        
        boolean canHarvest = ForgeHooks.canToolHarvestBlock(par1Block, meta, itemstack);
        
        if ((!canHarvest) && (f <= 1.0F))
        {
          f += f1 * 0.08F;
        }
        else
        {
          f += f1;
        }
      }
    }
    
    if (a(ni.e))
    {
      f *= (1.0F + (b(ni.e).c() + 1) * 0.2F);
    }
    
    if (a(ni.f))
    {
      f *= (1.0F - (b(ni.f).c() + 1) * 0.2F);
    }
    
    if ((a(akc.h)) && (!aaw.h(this)))
    {
      f /= 5.0F;
    }
    
    if (!F)
    {
      f /= 5.0F;
    }
    
    f = ForgeEventFactory.getBreakSpeed(this, par1Block, meta, f);
    return f < 0.0F ? 0.0F : f;
  }
  

  public boolean smallerAndNotUseBlock()
  {
    return (getSizeMultiplier() < 1.0F) && (q.s.nextFloat() > getSizeMultiplierRoot());
  }
  



  public boolean a(aqz par1Block)
  {
    return ForgeEventFactory.doPlayerHarvestCheck(this, par1Block, bn.b(par1Block));
  }
  



  public void a(by par1NBTTagCompound)
  {
    super.a(par1NBTTagCompound);
    cg nbttaglist = par1NBTTagCompound.m("Inventory");
    bn.b(nbttaglist);
    bn.c = par1NBTTagCompound.e("SelectedItemSlot");
    bC = par1NBTTagCompound.n("Sleeping");
    b = par1NBTTagCompound.d("SleepTimer");
    bJ = par1NBTTagCompound.g("XpP");
    bH = par1NBTTagCompound.e("XpLevel");
    bI = par1NBTTagCompound.e("XpTotal");
    c(par1NBTTagCompound.e("Score"));
    
    if (bC)
    {
      bD = new t(ls.c(u), ls.c(v), ls.c(w));
      a(true, true, false);
    }
    
    if ((par1NBTTagCompound.b("SpawnX")) && (par1NBTTagCompound.b("SpawnY")) && (par1NBTTagCompound.b("SpawnZ")))
    {
      c = new t(par1NBTTagCompound.e("SpawnX"), par1NBTTagCompound.e("SpawnY"), par1NBTTagCompound.e("SpawnZ"));
      d = par1NBTTagCompound.n("SpawnForced");
    }
    cg spawnlist = null;
    spawnlist = par1NBTTagCompound.m("Spawns");
    for (int i = 0; i < spawnlist.c(); i++) {
      by spawndata = (by)spawnlist.b(i);
      int spawndim = spawndata.e("Dim");
      spawnChunkMap.put(Integer.valueOf(spawndim), new t(spawndata.e("SpawnX"), spawndata.e("SpawnY"), spawndata.e("SpawnZ")));
      spawnForcedMap.put(Integer.valueOf(spawndim), Boolean.valueOf(spawndata.n("SpawnForced")));
    }
    
    bq.a(par1NBTTagCompound);
    bG.b(par1NBTTagCompound);
    
    if (par1NBTTagCompound.b("EnderItems"))
    {
      cg nbttaglist1 = par1NBTTagCompound.m("EnderItems");
      a.a(nbttaglist1);
    }
  }
  



  public void b(by par1NBTTagCompound)
  {
    super.b(par1NBTTagCompound);
    par1NBTTagCompound.a("Inventory", bn.a(new cg()));
    par1NBTTagCompound.a("SelectedItemSlot", bn.c);
    par1NBTTagCompound.a("Sleeping", bC);
    par1NBTTagCompound.a("SleepTimer", (short)b);
    par1NBTTagCompound.a("XpP", bJ);
    par1NBTTagCompound.a("XpLevel", bH);
    par1NBTTagCompound.a("XpTotal", bI);
    par1NBTTagCompound.a("Score", bw());
    
    if (c != null)
    {
      par1NBTTagCompound.a("SpawnX", c.a);
      par1NBTTagCompound.a("SpawnY", c.b);
      par1NBTTagCompound.a("SpawnZ", c.c);
      par1NBTTagCompound.a("SpawnForced", d);
    }
    cg spawnlist = new cg();
    for (Map.Entry<Integer, t> entry : spawnChunkMap.entrySet()) {
      by spawndata = new by();
      t spawn = (t)entry.getValue();
      if (spawn != null) {
        Boolean forced = (Boolean)spawnForcedMap.get(entry.getKey());
        if (forced == null) forced = Boolean.valueOf(false);
        spawndata.a("Dim", ((Integer)entry.getKey()).intValue());
        spawndata.a("SpawnX", a);
        spawndata.a("SpawnY", b);
        spawndata.a("SpawnZ", c);
        spawndata.a("SpawnForced", forced.booleanValue());
        spawnlist.a(spawndata);
      } }
    par1NBTTagCompound.a("Spawns", spawnlist);
    
    bq.b(par1NBTTagCompound);
    bG.a(par1NBTTagCompound);
    par1NBTTagCompound.a("EnderItems", a.h());
  }
  


  public void a(mo par1IInventory) {}
  


  public void a(asi par1TileEntityHopper) {}
  


  public void a(sx par1EntityMinecartHopper) {}
  


  public void a(rs par1EntityHorse, mo par2IInventory) {}
  

  public void a(int par1, int par2, int par3, String par4Str) {}
  

  public void c(int par1, int par2, int par3) {}
  

  public void b(int par1, int par2, int par3) {}
  

  @SideOnly(Side.CLIENT)
  public ata a(double par1, float par3)
  {
    atc var4 = l(par3);
    atc var5 = j(par3);
    atc var6 = var4.c(c * par1, d * par1, e * par1);
    

    if ((isHuge()) && ((by() == null) || ((!bG.d) && (!holdingPointyItem()) && (!(by().b() instanceof zh)))))
    {
      return q.rayTraceBlocks_do_do_limit(var4, var6, false, false, true);
    }
    

    return q.a(var4, var6);
  }
  


  public float f()
  {
    return eyeHeight;
  }
  



  protected void d_()
  {
    N = (playerNormalYOffset * getSizeMultiplier());
    eyeHeight = (getDefaultEyeHeight() * getSizeMultiplier());
  }
  



  public boolean a(nb par1DamageSource, float par2)
  {
    if (ForgeHooks.onLivingAttack(this, par1DamageSource, par2)) return false;
    if (ar())
    {
      return false;
    }
    if ((bG.a) && (!par1DamageSource.g()))
    {
      return false;
    }
    

    aV = 0;
    
    if (aN() <= 0.0F)
    {
      return false;
    }
    

    if ((bh()) && (!q.I))
    {
      a(true, true, false);
    }
    
    if (par1DamageSource.p())
    {
      if (q.r == 0)
      {
        par2 = 0.0F;
      }
      
      if (q.r == 1)
      {
        par2 = par2 / 2.0F + 1.0F;
      }
      
      if (q.r == 3)
      {
        par2 = par2 * 3.0F / 2.0F;
      }
    }
    
    if (par2 == 0.0F)
    {
      return false;
    }
    

    nn entity = par1DamageSource.i();
    
    if (((entity instanceof uh)) && (c != null))
    {
      entity = c;
    }
    

    a(la.x, Math.round(par2 * 10.0F));
    boolean tmp = super.a(par1DamageSource, par2);
    maybeKnockoff();
    return tmp;
  }
  





  public void maybeKnockoff()
  {
    if ((o != null) && ((o instanceof of)) && ((!(o instanceof of)) || (!((of)o).getSaddled()) || (O < o.O * 0.25F)))
    {
      if (!isEntityHoldingOn())
      {
        nn ride = o;
        
        if (!q.I)
        {


          a(ride);
        }
      }
    }
  }
  

  public boolean a(uf par1EntityPlayer)
  {
    atl team = bo();
    atl team1 = par1EntityPlayer.bo();
    return !team.a(team1) ? true : team == null ? true : team.g();
  }
  
  protected void h(float par1)
  {
    bn.a(par1);
  }
  



  public int aQ()
  {
    return bn.l();
  }
  




  public float bx()
  {
    int i = 0;
    ye[] aitemstack = bn.b;
    int j = aitemstack.length;
    
    for (int k = 0; k < j; k++)
    {
      ye itemstack = aitemstack[k];
      
      if (itemstack != null)
      {
        i++;
      }
    }
    
    return i / bn.b.length;
  }
  




  protected void d(nb par1DamageSource, float par2)
  {
    if (!ar())
    {
      par2 = ForgeHooks.onLivingHurt(this, par1DamageSource, par2);
      if (par2 <= 0.0F) return;
      if ((!par1DamageSource.e()) && (bv()) && (par2 > 0.0F))
      {
        par2 = (1.0F + par2) * 0.5F;
      }
      
      par2 = ISpecialArmor.ArmorProperties.ApplyArmor(this, bn.b, par1DamageSource, par2);
      if (par2 <= 0.0F) return;
      par2 = c(par1DamageSource, par2);
      float f1 = par2;
      par2 = Math.max(par2 - bn(), 0.0F);
      m(bn() - (f1 - par2));
      
      if (par2 != 0.0F)
      {
        a(par1DamageSource.f());
        float f2 = aN();
        g(aN() - par2);
        aR().a(par1DamageSource, f2, par2);
      }
    }
  }
  



  public void a(asg par1TileEntityFurnace) {}
  



  public void a(asc par1TileEntityDispenser) {}
  


  public void a(asp par1TileEntity) {}
  


  public void a(arx par1TileEntityBrewingStand) {}
  


  public void a(arw par1TileEntityBeacon) {}
  


  public void a(abk par1IMerchant, String par2Str) {}
  


  public void c(ye par1ItemStack) {}
  


  public boolean p(nn par1Entity)
  {
    ye itemstack = by();
    ye itemstack1 = itemstack != null ? itemstack.m() : null;
    if ((itemstack == null) && (heldEntity == null) && (par1Entity.isQuiteSmallerThan(this)) && (O <= maxHeldWidth(par1Entity)) && (!GulliverEnvoy.isUnholdableEntity(par1Entity)))
    {

      if (!q.I)
      {
        if (o != null)
        {
          par1Entity.a(null);
        }
        
        if (holdingEntity != null)
        {
          par1Entity.getDroppedByEntity(holdingEntity);
        }
        
        pickUpEntity(par1Entity);
      }
      














      return true;
    }
    if ((itemstack == null) && (heldEntity != null))
    {

      if (GulliverEnvoy.isUnrideableEntity(par1Entity))
      {
        return false;
      }
      
      if (!q.I)
      {
        nn held = heldEntity;
        dropHeldEntity(held);
        
        if (held != par1Entity)
        {
          held.a(par1Entity);
        }
      }
      
      return true;
    }
    if (heldEntity != null)
    {
      if (!q.I)
      {
        nn held = heldEntity;
        dropHeldEntity(held);
        held.b(u, v, w);
      }
      
      return true;
    }
    


    if ((holdingEntity == null) && (n == null) && ((n == null) || (n.isTinierThan(this))) && (itemstack != null) && (((isTiny()) && (d == Mcv)) || ((!isTiny()) && (d == chcv) && (isTinierThan(par1Entity)) && ((par1Entity instanceof of)) && ((!(par1Entity instanceof og)) || ((!((og)par1Entity).bG()) && ((!((og)par1Entity).bH()) || (((og)par1Entity).bI() != this))))) || ((isTiny()) && (isGliding()) && ((par1Entity instanceof of)) && ((float)(v - v) + f() - X - par1Entity.f() + X > P * -0.4F))))
    {
      if (GulliverEnvoy.isUnrideableEntity(par1Entity))
      {
        return false;
      }
      
      if (!q.I)
      {
        a(par1Entity);
      }
      
      return true;
    }
    if ((holdingEntity == null) && (MinecraftForge.EVENT_BUS.post(new EntityInteractEvent(this, par1Entity))))
    {
      return false;
    }
    if ((holdingEntity == null) && (par1Entity.c(this)))
    {
      if ((itemstack != null) && (itemstack == by()))
      {
        if ((b <= 0) && (!bG.d))
        {
          bz();
        }
        else if ((b < b) && (bG.d))
        {
          b = b;
        }
      }
      
      return true;
    }
    

    if ((itemstack != null) && ((par1Entity instanceof of)))
    {
      if (bG.d)
      {
        itemstack = itemstack1;
      }
      
      if (itemstack.a(this, (of)par1Entity))
      {
        if ((b <= 0) && (!bG.d))
        {
          bz();
        }
        
        return true;
      }
    }
    
    return false;
  }
  




  public final boolean c(uf par1EntityPlayer)
  {
    return interact(par1EntityPlayer) ? true : super.c(par1EntityPlayer);
  }
  



  public boolean interact(uf par1EntityPlayer)
  {
    if ((holdingEntity == null) && (bn.h() == null) && (!par1EntityPlayer.ah()) && (n == null) && (ah()) && (isEntityInRelativeSizeRange(par1EntityPlayer, 0.0F, 0.65F)) && (o == null) && (getEyeDistanceToEntityLiving(par1EntityPlayer) <= O * 2.0F) && ((n == null) || (n.isTinierThan(par1EntityPlayer))))
    {
      if (!q.I)
      {
        par1EntityPlayer.a(this);
      }
      
      return true;
    }
    
    return false;
  }
  



  public ye by()
  {
    return bn.h();
  }
  



  public void bz()
  {
    ye orig = by();
    bn.a(bn.c, (ye)null);
    MinecraftForge.EVENT_BUS.post(new PlayerDestroyItemEvent(this, orig));
  }
  





  public double X()
  {
    float sizemult = getSizeMultiplier();
    
    if ((o != null) && ((o instanceof of)))
    {

      if (((of)o).getSaddled())
      {


        return N - (float)o.Y() / o.P * sizemult + 0.24F * o.getSizeMultiplier() + 0.01F * sizemult * sizemult / o.getSizeMultiplier();
      }
      

      return N - (float)o.Y() / o.P * sizemult + 0.21F * o.getSizeMultiplier() + 0.01F * sizemult * sizemult / o.getSizeMultiplier();
    }
    



    return N - 0.62F * getSizeMultiplier() + 0.12F;
  }
  

  public void updateResizingFlags()
  {
    super.updateResizingFlags();
    
    ye itemstack = by();
    boolean onLadder = (e()) || (ladderRate > 0.0F);
    boolean inRain = GulliverEnvoy.couldBeRainedOn(this);
    
    isRaftingFlag = (((!onLadder) || (ae)) && (!bG.b) && (o == null) && (isTiny()) && (!au) && (bn.h() != null) && (byd == bEcF) && (closeAboveOrInWater()));
    
    couldUseUmbrella = ((!onLadder) && (!isRaftingFlag) && (getSizeMultiplier() <= 0.5F) && (!au) && ((!ae) || (o != null)) && (itemstack != null) && (d == bEcF) && (inRain));
    
    if ((onLadder) || (bh()) || (K) || (af()) || (au) || (bG.b) || (!isTiny()) || (inRain) || (G()) || (n != null) || (o != null) || (holdingEntity != null) || ((F) && (GulliverEnvoy.getRisingUpdraft(this) <= 0.125D * getSizeMultiplier())))
    {
      isGlidingFlag = false;

    }
    else
    {
      isGlidingFlag = ((itemstack != null) && (GulliverEnvoy.isGlideableItem(itemstack)) && (!GulliverEnvoy.isEntityIntersectingPlant(this)));
    }
  }
  



  public boolean doesUmbrella()
  {
    return (couldUseUmbrella) && ((o == null) || (((o instanceof of)) && ((!o).couldUseUmbrella) || (((of)o).isRafting()) || (getSizeMultiplier() >= o.getSizeMultiplier() * 0.3F)) && ((n == null) || (((o instanceof of)) && ((!o).couldUseUmbrella) || (n.getSizeMultiplier() < getSizeMultiplier() * 0.3F))))));
  }
  



  protected boolean closeAboveOrInWater()
  {
    if (ae)
    {
      return true;
    }
    
    int l = ls.c(u);
    int m = ls.c(E.b);
    int n = ls.c(w);
    int h = m;
    

    while (h > 0)
    {
      int i = q.a(l, h, n);
      
      if ((i > 0) && ((i == GcF) || (i == FcF) || (aqz.s[i].b(q, l, h, n) != null))) {
        break;
      }
      

      h--;
    }
    
    if ((m - h > 10) || (h < 0))
    {
      return false;
    }
    
    int b = q.a(l, h, n);
    return (b == GcF) || (b == FcF) || ((b == bLcF) && (ls.c(E.b) == h) && (q.h(l, h, n) > 0));
  }
  



  public boolean isWeighted()
  {
    if ((isGliding()) || (isRafting()))
    {
      return false;
    }
    

    if ((bn.a[0] != null) && (bn.a[0].d == rcv) && (bn.a[0].b == 42))
    {
      return true;
    }
    
    return super.isWeighted();
  }
  




  public void q(nn par1Entity)
  {
    if (MinecraftForge.EVENT_BUS.post(new AttackEntityEvent(this, par1Entity)))
    {
      return;
    }
    ye stack = by();
    if ((stack != null) && (stack.b().onLeftClickEntity(stack, this, par1Entity)))
    {
      return;
    }
    if (par1Entity.aq())
    {
      if (!par1Entity.i(this))
      {
        float f = (float)a(tp.e).e();
        int i = 0;
        float f1 = 0.0F;
        
        if ((par1Entity instanceof of))
        {
          f1 = aaw.a(this, (of)par1Entity);
          i += aaw.b(this, (of)par1Entity);
        }
        
        if (ai())
        {
          i++;
        }
        
        if ((f > 0.0F) || (f1 > 0.0F))
        {
          boolean flag = (T > 0.0F) && (!F) && (!e()) && (!H()) && (!a(ni.q)) && (o == null) && ((par1Entity instanceof of));
          
          if ((flag) && (f > 0.0F))
          {
            f *= 1.5F;
          }
          
          f += f1;
          boolean flag1 = false;
          int j = aaw.a(this);
          
          if (((par1Entity instanceof of)) && (j > 0) && (!par1Entity.af()))
          {
            flag1 = true;
            par1Entity.d(1);
          }
          
          boolean flag2 = par1Entity.a(nb.a(this), f);
          
          if (flag2)
          {
            if (i > 0)
            {
              par1Entity.g(-ls.a(A * 3.1415927F / 180.0F) * i * 0.5F, 0.1D, ls.b(A * 3.1415927F / 180.0F) * i * 0.5F);
              x *= 0.6D;
              z *= 0.6D;
              c(false);
            }
            
            if (flag)
            {
              b(par1Entity);
            }
            
            if (f1 > 0.0F)
            {
              c(par1Entity);
            }
            
            if (f >= 18.0F)
            {
              a(kp.E);
            }
            
            k(par1Entity);
            
            if ((par1Entity instanceof of))
            {
              abh.a(this, (of)par1Entity, ab);
            }
          }
          
          ye itemstack = by();
          Object object = par1Entity;
          
          if ((par1Entity instanceof si))
          {
            sh ientitymultipart = a;
            
            if ((ientitymultipart != null) && ((ientitymultipart instanceof of)))
            {
              object = (of)ientitymultipart;
            }
          }
          
          if ((itemstack != null) && ((object instanceof of)))
          {
            itemstack.a((of)object, this);
            
            if (b <= 0)
            {
              bz();
            }
          }
          
          if ((par1Entity instanceof of))
          {
            a(la.w, Math.round(f * 10.0F));
            
            if ((j > 0) && (flag2))
            {
              par1Entity.d(j * 4);
            }
            else if (flag1)
            {
              par1Entity.B();
            }
          }
          
          a(0.3F);
        }
      }
    }
  }
  


  public void b(nn par1Entity) {}
  


  public void c(nn par1Entity) {}
  

  @SideOnly(Side.CLIENT)
  public void bA() {}
  

  public void x()
  {
    super.x();
    bo.b(this);
    
    if (bp != null)
    {
      bp.b(this);
    }
  }
  



  public boolean U()
  {
    return (!bC) && (super.U());
  }
  



  public ug a(int par1, int par2, int par3)
  {
    return sleepInSizedBedAt(q, par1, par2, par3);
  }
  




  public ug sleepInSizedBedAt(abw par0World, int par1, int par2, int par3)
  {
    int worldScale = !GulliverOMHelper.isLittleBlocksWorld(par0World) ? 1 : 8;
    double rwpar1 = par1 / worldScale;
    double rwpar2 = par2 / worldScale;
    double rwpar3 = par3 / worldScale;
    
    PlayerSleepInBedEvent event = new PlayerSleepInBedEvent(this, par1, par2, par3);
    MinecraftForge.EVENT_BUS.post(event);
    if (result != null)
    {
      return result;
    }
    if (!q.I)
    {
      if ((bh()) || (!T()))
      {
        return ug.e;
      }
      
      if (!q.t.d())
      {
        return ug.b;
      }
      
      if (q.v())
      {
        return ug.c;
      }
      
      if (getSizeMultiplier() * worldScale > 1.5F)
      {
        a(bu.a("tile.bed.tooBig").trim());
        return ug.e;
      }
      
      if ((Math.abs(u - rwpar1) > 3.0D) || (Math.abs(v - rwpar2) > 2.0D) || (Math.abs(w - rwpar3) > 3.0D))
      {
        return ug.d;
      }
      
      double d0 = 8.0D;
      double d1 = 5.0D;
      List list = q.a(tm.class, asx.a().a(rwpar1 - d0, rwpar2 - d1, rwpar3 - d0, rwpar1 + d0, rwpar2 + d1, rwpar3 + d0));
      
      if (!list.isEmpty())
      {
        return ug.f;
      }
    }
    
    if (ag())
    {
      a((nn)null);
    }
    
    a(0.2F, 0.2F);
    N = (0.2F * getSizeMultiplier());
    bedScale = worldScale;
    
    if (par0World.a(par1, par2, par3) > 0)
    {
      int l = par0World.h(par1, par2, par3);
      int i1 = anb.j(l);
      aqz block = aqz.s[par0World.a(par1, par2, par3)];
      if (block != null)
      {
        i1 = block.getBedDirection(par0World, par1, par2, par3);
      }
      float f = 0.5F;
      float f1 = 0.5F;
      
      switch (i1)
      {
      case 0: 
        f1 = 0.9F;
        break;
      case 1: 
        f = 0.1F;
        break;
      case 2: 
        f1 = 0.1F;
        break;
      case 3: 
        f = 0.9F;
      }
      
      t(i1);
      
      if (bedScale > 1)
      {
        bedScale += (i1 << 4);
      }
      
      b((float)rwpar1 + f / worldScale, (float)rwpar2 + 0.9375F / worldScale, (float)rwpar3 + f1 / worldScale);
    }
    else
    {
      b((float)rwpar1 + 0.5F / worldScale, (float)rwpar2 + 0.9375F / worldScale, (float)rwpar3 + 0.5F / worldScale);
    }
    
    bC = true;
    b = 0;
    bD = new t((int)rwpar1, (int)rwpar2, (int)rwpar3);
    x = (this.z = this.y = 0.0D);
    
    if (!q.I)
    {
      q.c();
    }
    
    return ug.a;
  }
  
  private void t(int par1)
  {
    bE = 0.0F;
    bF = 0.0F;
    
    switch (par1)
    {
    case 0: 
      bF = -1.8F;
      break;
    case 1: 
      bE = 1.8F;
      break;
    case 2: 
      bF = 1.8F;
      break;
    case 3: 
      bE = -1.8F;
    }
    
  }
  





  public void a(boolean par1, boolean par2, boolean par3)
  {
    a(playerNormalWidth, playerNormalHeight);
    d_();
    t chunkcoordinates = bD;
    t chunkcoordinates1 = bD;
    
    aqz block = chunkcoordinates == null ? null : aqz.s[q.a(a, b, c)];
    boolean isBed = (block != null) && (block.isBed(q, a, b, c, this));
    

    if ((bedScale != 1) && (!isBed)) {
      par3 = false;
    }
    if ((chunkcoordinates != null) && (block != null) && ((bedScale != 1) || (isBed)))
    {
      block.setBedOccupied(q, a, b, c, this, false);
      
      if (isTiny())
      {

        if (bedScale == 1) {
          b(a + 0.5F, b + N + 0.6625F, c + 0.5F);
        }
      }
      else {
        chunkcoordinates1 = block.getBedSpawnPosition(q, a, b, c, this);
        
        if (chunkcoordinates1 == null)
        {
          chunkcoordinates1 = new t(a, b + 1, c);
        }
        
        b(a + 0.5F, b + N + 0.1F, c + 0.5F);
      }
    }
    
    bC = false;
    bedScale = 1;
    
    if ((!q.I) && (par2))
    {
      q.c();
    }
    
    if (par1)
    {
      b = 0;
    }
    else
    {
      b = 100;
    }
    
    if (par3)
    {
      a(bD, false);
    }
  }
  
  private void maybeShoveOtherSleeper()
  {
    int i = q.h(bD.a, bD.b, bD.c);
    
    if ((anb.f_(i)) && (getSizeMultiplier() > 0.5F))
    {
      int j = anb.j(i);
      int x1 = bD.a - anb.a[j][0];
      int z1 = bD.c - anb.a[j][1];
      int i2 = q.h(x1, bD.b, z1);
      
      if (anb.c(i2))
      {
        uf entityplayer = null;
        Iterator iterator = q.h.iterator();
        


        while (iterator.hasNext())
        {



          uf entityplayer1 = (uf)iterator.next();
          
          if (entityplayer1.bh())
          {
            t chunkcoordinates = bD;
            
            if ((a == x1) && (b == bD.b) && (c == z1))
            {
              entityplayer = entityplayer1;
            }
          }
        }
        

        if (entityplayer != null)
        {
          entityplayer.a(true, true, false);
          entityplayer.g(-0.25D * anb.a[j][0], 0.0D, -0.25D * anb.a[j][1]);
        }
      }
    }
  }
  



  private boolean h()
  {
    t c = bD;
    int blockID = q.a(a, b, c);
    boolean isBed = (aqz.s[blockID] != null) && (aqz.s[blockID].isBed(q, a, b, c, this));
    if ((aqz.s[blockID] != null) && ((bedScale != 1) || (isBed)))
    {
      if ((isBed) && (getSizeMultiplier() > 1.5F))
      {

        return false;
      }
      
      if ((bedScale != 1) && (getSizeMultiplier() > 0.1875F))
      {

        return false;
      }
      
      int i = q.h(a, b, c);
      
      if ((isBed) && (!anb.f_(i)) && (getSizeMultiplier() > 0.75F))
      {

        return false;
      }
      
      return true;
    }
    

    return false;
  }
  






  public static t a(abw par0World, t par1ChunkCoordinates, boolean par2)
  {
    ado ichunkprovider = par0World.L();
    ichunkprovider.c(a - 3 >> 4, c - 3 >> 4);
    ichunkprovider.c(a + 3 >> 4, c - 3 >> 4);
    ichunkprovider.c(a - 3 >> 4, c + 3 >> 4);
    ichunkprovider.c(a + 3 >> 4, c + 3 >> 4);
    
    t c = par1ChunkCoordinates;
    aqz block = aqz.s[par0World.a(a, b, c)];
    
    if ((block != null) && (block.isBed(par0World, a, b, c, null)))
    {
      t chunkcoordinates1 = block.getBedSpawnPosition(par0World, a, b, c, null);
      return chunkcoordinates1;
    }
    

    akc material = par0World.g(a, b, c);
    akc material1 = par0World.g(a, b + 1, c);
    boolean flag1 = (!material.a()) && (!material.d());
    boolean flag2 = (!material1.a()) && (!material1.d());
    return (par2) && (flag1) && (flag2) ? par1ChunkCoordinates : null;
  }
  





  @SideOnly(Side.CLIENT)
  public float bC()
  {
    if (bD != null)
    {
      int x = bD.a;
      int y = bD.b;
      int z = bD.c;
      aqz block = aqz.s[q.a(x, y, z)];
      int i = bedScale == 1 ? block.getBedDirection(q, x, y, z) : block == null ? 0 : bedScale >> 4;
      
      switch (i)
      {
      case 0: 
        return 90.0F;
      case 1: 
        return 0.0F;
      case 2: 
        return 270.0F;
      case 3: 
        return 180.0F;
      }
      
    }
    return 0.0F;
  }
  



  public boolean bh()
  {
    return bC;
  }
  



  public boolean bD()
  {
    return (bC) && (b >= 100);
  }
  
  @SideOnly(Side.CLIENT)
  public int bE()
  {
    return b;
  }
  
  public void pickUpEntity(nn par1Entity)
  {
    super.pickUpEntity(par1Entity);
    
    if ((this instanceof jv))
    {
      Packet172AttachEntitySpecial var5 = new Packet172AttachEntitySpecial(heldEntity, this, (byte)3);
      ((jv)this).p().q().a(this, var5);
      a.b(var5);
    }
  }
  
  public void dropHeldEntity(nn par1Entity)
  {
    super.dropHeldEntity(par1Entity);
    
    if ((this instanceof jv))
    {
      Packet172AttachEntitySpecial var5 = new Packet172AttachEntitySpecial(par1Entity, this, (byte)0);
      ((jv)this).p().q().a(this, var5);
      a.b(var5);
    }
  }
  
  public void getDroppedByEntity(nn par1Entity)
  {
    super.getDroppedByEntity(par1Entity);
    
    if (((this instanceof jv)) && (par1Entity != null))
    {
      a.a(u, v, w, A, B);
    }
  }
  
  @SideOnly(Side.CLIENT)
  protected boolean r(int par1)
  {
    return (ah.a(16) & 1 << par1) != 0;
  }
  
  protected void b(int par1, boolean par2)
  {
    byte b0 = ah.a(16);
    
    if (par2)
    {
      ah.b(16, Byte.valueOf((byte)(b0 | 1 << par1)));
    }
    else
    {
      ah.b(16, Byte.valueOf((byte)(b0 & (1 << par1 ^ 0xFFFFFFFF))));
    }
  }
  



  public void a(String par1Str) {}
  



  @Deprecated
  public t bF()
  {
    return getBedLocation(ar);
  }
  
  @Deprecated
  public boolean bG()
  {
    return isSpawnForced(ar);
  }
  




  public t getBedLocation(int dimension)
  {
    if (dimension == 0) return c;
    return (t)spawnChunkMap.get(Integer.valueOf(dimension));
  }
  






  public boolean isSpawnForced(int dimension)
  {
    if (dimension == 0) return d;
    Boolean forced = (Boolean)spawnForcedMap.get(Integer.valueOf(dimension));
    if (forced == null) return false;
    return forced.booleanValue();
  }
  



  public void a(t par1ChunkCoordinates, boolean par2)
  {
    if (ar != 0)
    {
      setSpawnChunk(par1ChunkCoordinates, par2, ar);
      return;
    }
    if (par1ChunkCoordinates != null)
    {
      c = new t(par1ChunkCoordinates);
      d = par2;
    }
    else
    {
      c = null;
      d = false;
    }
  }
  





  public void setSpawnChunk(t chunkCoordinates, boolean forced, int dimension)
  {
    if (dimension == 0)
    {
      if (chunkCoordinates != null)
      {
        c = new t(chunkCoordinates);
        d = forced;
      }
      else
      {
        c = null;
        d = false;
      }
      return;
    }
    if (chunkCoordinates != null)
    {
      spawnChunkMap.put(Integer.valueOf(dimension), new t(chunkCoordinates));
      spawnForcedMap.put(Integer.valueOf(dimension), Boolean.valueOf(forced));
    }
    else
    {
      spawnChunkMap.remove(Integer.valueOf(dimension));
      spawnForcedMap.remove(Integer.valueOf(dimension));
    }
  }
  


  public void a(ku par1StatBase)
  {
    a(par1StatBase, 1);
  }
  



  public void a(ku par1StatBase, int par2) {}
  



  protected void be()
  {
    super.be();
    a(la.u, 1);
    
    if (ai())
    {
      a(0.8F);
    }
    else if ((isTiny()) && (isSticky()))
    {
      a(0.2F / getSizeMultiplierRoot());
    }
    else
    {
      a(0.2F);
    }
  }
  



  public void e(float par1, float par2)
  {
    double d0 = u;
    double d1 = v;
    double d2 = w;
    
    if ((bG.b) && (o == null))
    {
      double d3 = y;
      float f2 = aR;
      aR = bG.a();
      super.e(par1, par2);
      y = (d3 * 0.6D);
      aR = f2;
    }
    else
    {
      super.e(par1, par2);
    }
    
    j(u - d0, v - d1, w - d2);
  }
  



  public float bg()
  {
    return (float)a(tp.d).e();
  }
  



  public void j(double par1, double par3, double par5)
  {
    if ((o == null) && (!isRafting()))
    {


      if (a(akc.h))
      {
        int i = Math.round(ls.a(par1 * par1 + par3 * par3 + par5 * par5) * 100.0F);
        
        if (i > 0)
        {
          a(la.q, i);
          a(0.015F * i * 0.01F / getSizeMovementMultiplier());
        }
      }
      else if (H())
      {
        int i = Math.round(ls.a(par1 * par1 + par5 * par5) * 100.0F);
        
        if (i > 0)
        {
          a(la.m, i);
          a(0.015F * i * 0.01F / getSizeMovementMultiplier());
        }
      }
      else if (e())
      {
        if (par3 > 0.0D)
        {
          a(la.o, (int)Math.round(par3 * 100.0D));
        }
      }
      else if (F)
      {
        int i = Math.round(ls.a(par1 * par1 + par5 * par5) * 100.0F);
        
        if (i > 0)
        {
          a(la.l, i);
          float f = (isStruggling) && (!isWeighted()) ? 1.0F : 1.0F / getSizeMultiplierRoot();
          
          if (ai())
          {
            a(0.099999994F * i * 0.01F * f / getSizeMovementMultiplier());
          }
          else
          {
            a(0.01F * i * 0.01F * f / getSizeMovementMultiplier());
          }
        }
      }
      else
      {
        int i = Math.round(ls.a(par1 * par1 + par5 * par5) * 100.0F);
        
        if (i > 25)
        {
          a(la.p, i);
        }
      }
    }
  }
  



  private void k(double par1, double par3, double par5)
  {
    if (o != null)
    {
      int i = Math.round(ls.a(par1 * par1 + par3 * par3 + par5 * par5) * 100.0F);
      
      if (i > 0)
      {
        if ((o instanceof st))
        {
          a(la.r, i);
          
          if (e == null)
          {
            e = new t(ls.c(u), ls.c(v), ls.c(w));
          }
          else if (e.e(ls.c(u), ls.c(v), ls.c(w)) >= 1000000.0D)
          {
            a(kp.q, 1);
          }
        }
        else if ((o instanceof sq))
        {
          a(la.s, i);
        }
        else if ((o instanceof ry))
        {
          a(la.t, i);
        }
      }
    }
  }
  



  protected void b(float par1)
  {
    if (!bG.c)
    {
      if (par1 >= 2.0F)
      {
        a(la.n, (int)Math.round(par1 * 100.0D));
      }
      
      super.b(par1);


    }
    else if ((n != null) && ((n instanceof uf)) && (!ah()) && (par1 > n.P * 3.0F) && (par1 > getAdjStepHeight() * 1.1F))
    {
      ((uf)n).maybeKnockoff();
    }
    else
    {
      MinecraftForge.EVENT_BUS.post(new PlayerFlyableFallEvent(this, par1));
    }
  }
  

  public float getAdjStepHeight()
  {
    float tmp = Y;
    Y = 0.5F;
    float step = getStepHeight();
    Y = tmp;
    return step;
  }
  



  public void aV()
  {
    if (!au)
    {
      if (heldEntity != null)
      {
        if (GulliverEnvoy.isClientPlayerEntity(this))
        {
          GulliverEnvoy.clearClientMouseover();
        }
        
        if ((!(heldEntity instanceof of)) || (!((of)heldEntity).isEntityHoldingOn()))
        {
          if ((!GulliverEnvoy.isClientPlayerEntity(this)) || (GulliverEnvoy.isClientAttacking()))
          {
            throwHeldEntity(heldEntity);
          }
        }
      }
    }
    
    super.aV();
  }
  



  public void a(of par1EntityLivingBase)
  {
    if ((par1EntityLivingBase instanceof th))
    {
      a(kp.s);
    }
  }
  



  public void am()
  {
    if (!bG.b)
    {
      super.am();
    }
  }
  




  @SideOnly(Side.CLIENT)
  public ms b(ye par1ItemStack, int par2)
  {
    ms icon = super.b(par1ItemStack, par2);
    
    if ((d == aTcv) && (bM != null))
    {
      icon = yc.aT.g();
    }
    else
    {
      if (par1ItemStack.b().b())
      {
        return par1ItemStack.b().getIcon(par1ItemStack, par2);
      }
      
      if ((f != null) && (d == mcv))
      {
        int j = par1ItemStack.n() - g;
        
        if (j >= 18)
        {
          return yc.m.c(2);
        }
        
        if (j > 13)
        {
          return yc.m.c(1);
        }
        
        if (j > 0)
        {
          return yc.m.c(0);
        }
      }
      icon = par1ItemStack.b().getIcon(par1ItemStack, par2, this, f, g);
    }
    
    return icon;
  }
  
  public ye o(int par1)
  {
    return bn.f(par1);
  }
  



  public void s(int par1)
  {
    p(par1);
    int j = Integer.MAX_VALUE - bI;
    
    if (par1 > j)
    {
      par1 = j;
    }
    
    bJ += par1 / bH();
    
    for (bI += par1; bJ >= 1.0F; bJ /= bH())
    {
      bJ = ((bJ - 1.0F) * bH());
      a(1);
    }
  }
  



  public void a(int par1)
  {
    bH += par1;
    
    if (bH < 0)
    {
      bH = 0;
      bJ = 0.0F;
      bI = 0;
    }
    
    if ((par1 > 0) && (bH % 5 == 0) && (h < ac - 100.0F))
    {
      float f = bH > 30 ? 1.0F : bH / 30.0F;
      q.a(this, "random.levelup", f * 0.75F * getSizeMultiplierRoot(), 1.0F);
      h = ac;
    }
  }
  




  public int bH()
  {
    return bH >= 15 ? 17 + (bH - 15) * 3 : bH >= 30 ? 62 + (bH - 30) * 7 : 17;
  }
  



  public void a(float par1)
  {
    if (!bG.a)
    {
      if (!q.I)
      {
        bq.a(par1);
      }
    }
  }
  



  public ux bI()
  {
    return bq;
  }
  
  public boolean g(boolean par1)
  {
    return ((par1) || (bq.c())) && (!bG.a);
  }
  



  public boolean bJ()
  {
    return (aN() > 0.0F) && (aN() < aT());
  }
  



  public void a(ye par1ItemStack, int par2)
  {
    if (par1ItemStack != f)
    {
      f = par1ItemStack;
      
      if ((par1ItemStack != null) && ((par1ItemStack.o() == zj.b) || (par1ItemStack.o() == zj.c)))
      {
        g = ((int)(par2 / getRangeMultiplier()));
      }
      else
      {
        g = par2;
      }
      
      if (!q.I)
      {
        e(true);
      }
    }
  }
  



  public boolean d(int par1, int par2, int par3)
  {
    if (bG.e)
    {
      return true;
    }
    

    int l = q.a(par1, par2, par3);
    
    if (l > 0)
    {
      aqz block = aqz.s[l];
      
      if ((cU.q()) && ((!isTiny()) || (holdingPointyItem())))
      {
        return true;
      }
      
      if (by() != null)
      {
        ye itemstack = by();
        
        if ((itemstack.b(block)) || (itemstack.a(block) > 1.0F))
        {
          return true;
        }
      }
    }
    
    return false;
  }
  

  public boolean a(int par1, int par2, int par3, int par4, ye par5ItemStack)
  {
    return bG.e;
  }
  



  protected int e(uf par1EntityPlayer)
  {
    if (q.O().b("keepInventory"))
    {
      return 0;
    }
    

    int i = bH * 7;
    float f = par1EntityPlayer == null ? 1.0F : par1EntityPlayer.getSizeMultiplier();
    
    if (i > 100)
    {
      i = 100;
    }
    
    return (int)(i * getSizeMultiplier() / f);
  }
  




  protected boolean aC()
  {
    return true;
  }
  



  public String an()
  {
    return bu;
  }
  
  @SideOnly(Side.CLIENT)
  public boolean bd()
  {
    return true;
  }
  




  public void a(uf par1EntityPlayer, boolean par2)
  {
    if (par2)
    {
      bn.b(bn);
      g(par1EntityPlayer.aN());
      bq = bq;
      bH = bH;
      bI = bI;
      bJ = bJ;
      c(par1EntityPlayer.bw());
      as = as;
    }
    else if (q.O().b("keepInventory"))
    {
      bn.b(bn);
      bH = bH;
      bI = bI;
      bJ = bJ;
      c(par1EntityPlayer.bw());
    }
    
    spawnChunkMap = spawnChunkMap;
    spawnForcedMap = spawnForcedMap;
    a = a;
    


    by old = par1EntityPlayer.getEntityData();
    if (old.b("PlayerPersisted"))
    {
      getEntityData().a("PlayerPersisted", old.l("PlayerPersisted"));
    }
  }
  




  protected boolean e_()
  {
    return (!bG.b) && (!isGliding());
  }
  



  public void o() {}
  



  public void a(ace par1EnumGameType) {}
  



  public String c_()
  {
    return bu;
  }
  
  public abw f_()
  {
    return q;
  }
  



  public wb bK()
  {
    return a;
  }
  



  public ye n(int par1)
  {
    return par1 == 0 ? bn.h() : bn.b[(par1 - 1)];
  }
  



  public ye aZ()
  {
    return bn.h();
  }
  



  public void c(int par1, ye par2ItemStack)
  {
    if (par1 == 0)
    {
      bn.a[bn.c] = par2ItemStack;
    }
    else
    {
      bn.b[(par1 - 1)] = par2ItemStack;
    }
  }
  






  @SideOnly(Side.CLIENT)
  public boolean d(uf par1EntityPlayer)
  {
    if (!aj())
    {
      return false;
    }
    

    atl team = bo();
    return (team == null) || (par1EntityPlayer == null) || (par1EntityPlayer.bo() != team) || (!team.h());
  }
  

  public ye[] ae()
  {
    return bn.b;
  }
  
  @SideOnly(Side.CLIENT)
  public boolean bL()
  {
    return r(1);
  }
  
  public boolean ax()
  {
    return !bG.b;
  }
  
  public atj bM()
  {
    return q.X();
  }
  
  public atl bo()
  {
    return bM().i(bu);
  }
  



  public String ay()
  {
    return atf.a(bo(), getDisplayName());
  }
  
  public void m(float par1)
  {
    if (par1 < 0.0F)
    {
      par1 = 0.0F;
    }
    
    v().b(17, Float.valueOf(par1));
  }
  
  public float bn()
  {
    return v().d(17);
  }
  
  public void openGui(Object mod, int modGuiId, abw world, int x, int y, int z)
  {
    FMLNetworkHandler.openGui(this, mod, modGuiId, world, x, y, z);
  }
  









  public float getDefaultEyeHeight()
  {
    return 0.12F;
  }
  




  public String getDisplayName()
  {
    if (displayname == null)
    {
      displayname = ForgeEventFactory.getPlayerDisplayName(this, bu);
    }
    return displayname;
  }
  



  public void refreshDisplayName()
  {
    displayname = ForgeEventFactory.getPlayerDisplayName(this, bu);
  }
}
