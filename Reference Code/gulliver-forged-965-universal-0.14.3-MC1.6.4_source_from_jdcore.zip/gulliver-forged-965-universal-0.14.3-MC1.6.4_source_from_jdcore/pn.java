import java.util.Random;








public class pn
  extends ps
{
  private og b;
  private abw c;
  int a;
  
  public pn(og par1EntityLiving)
  {
    b = par1EntityLiving;
    c = q;
    a(7);
  }
  



  public boolean a()
  {
    if (b.aD().nextInt(b.g_() ? 50 : 1000) != 0)
    {
      return false;
    }
    

    int i = ls.c(b.u);
    int j = ls.c(b.v);
    int k = ls.c(b.w);
    return (!b.isTiny()) && (c.a(i, j, k) == accF) && (c.h(i, j, k) == 1);
  }
  





  public void c()
  {
    a = 40;
    c.a(b, (byte)10);
    b.k().h();
  }
  



  public void d()
  {
    a = 0;
  }
  



  public boolean b()
  {
    return a > 0;
  }
  
  public int f()
  {
    return a;
  }
  



  public void e()
  {
    a = Math.max(0, a - 1);
    
    if (a == 4)
    {
      int i = ls.c(b.u);
      int j = ls.c(b.v);
      int k = ls.c(b.w);
      
      if (b.isHuge())
      {


        int r = (int)(b.O / 2.0F);
        
        for (int l = i - r; l <= i + r; l++)
        {
          for (int m = j - 1; m <= j + r; m++)
          {
            for (int n = k - r; n <= k + r; n++)
            {
              if ((c.g(l, m, n) == akc.k) || (c.g(l, m, n) == akc.j) || (c.g(l, m, n) == akc.l))
              {
                if (b.aD().nextFloat() < 0.7F)
                {
                  c.i(l, m, n);
                }
              }
              else if (c.a(l, m, n) == zcF)
              {
                if (b.aD().nextFloat() < 0.8F)
                {
                  c.f(l, m, n, AcF, 0, 2);
                }
              }
            }
          }
        }
        
        c.e(2001, i, j - 1, k, zcF);
      }
      else if ((!b.isTiny()) && (c.a(i, j, k) == accF))
      {
        c.a(i, j, k, false);
      }
      else if (c.a(i, j - 1, k) == zcF)
      {

        if (!b.isTiny())
        {
          c.e(2001, i, j - 1, k, zcF);
          c.f(i, j - 1, k, AcF, 0, 2);
        }
      }
      
      b.n();
    }
  }
}
