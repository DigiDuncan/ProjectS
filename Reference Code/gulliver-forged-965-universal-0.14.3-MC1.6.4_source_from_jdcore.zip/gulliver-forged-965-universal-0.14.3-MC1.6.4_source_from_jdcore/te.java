








public class te
  extends tt
{
  public te(abw par1World)
  {
    super(par1World);
    a(0.7F, 0.5F);
  }
  
  protected void az()
  {
    super.az();
    a(tp.a).a(12.0D);
  }
  
  public boolean m(nn par1Entity)
  {
    if (super.m(par1Entity))
    {
      if ((par1Entity instanceof of))
      {
        byte b0 = 0;
        
        if (q.r > 1)
        {
          if (q.r == 2)
          {
            b0 = 7;
          }
          else if (q.r == 3)
          {
            b0 = 15;
          }
        }
        
        if (b0 > 0)
        {
          ((of)par1Entity).c(new nj(uH, (int)(b0 * 20.0F * getSizeMultiplierRoot()), 0));
        }
      }
      
      return true;
    }
    

    return false;
  }
  

  public oi a(oi par1EntityLivingData)
  {
    return par1EntityLivingData;
  }
}
