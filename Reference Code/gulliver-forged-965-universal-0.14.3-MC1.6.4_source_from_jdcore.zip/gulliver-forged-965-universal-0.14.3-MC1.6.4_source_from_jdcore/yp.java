import com.google.common.collect.HashMultimap;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import gulliver.common.GulliverEnvoy;
import gulliver.potion.PotionResizing;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.Set;















public class yp
  extends yc
{
  private HashMap a = new HashMap();
  private static final Map b = new LinkedHashMap();
  @SideOnly(Side.CLIENT)
  private ms c;
  @SideOnly(Side.CLIENT)
  private ms d;
  @SideOnly(Side.CLIENT)
  private ms cB;
  
  public yp(int par1)
  {
    super(par1);
    d(1);
    a(true);
    e(0);
    a(ww.k);
  }
  



  public List g(ye par1ItemStack)
  {
    if ((par1ItemStack.p()) && (par1ItemStack.q().b("CustomPotionEffects")))
    {
      ArrayList arraylist = new ArrayList();
      cg nbttaglist = par1ItemStack.q().m("CustomPotionEffects");
      
      for (int i = 0; i < nbttaglist.c(); i++)
      {
        by nbttagcompound = (by)nbttaglist.b(i);
        arraylist.add(nj.b(nbttagcompound));
      }
      
      return arraylist;
    }
    

    List list = (List)a.get(Integer.valueOf(par1ItemStack.k()));
    
    if (list == null)
    {
      list = zp.b(par1ItemStack.k(), false);
      a.put(Integer.valueOf(par1ItemStack.k()), list);
    }
    
    return list;
  }
  




  public List c(int par1)
  {
    List list = (List)a.get(Integer.valueOf(par1));
    
    if (list == null)
    {
      list = zp.b(par1, false);
      a.put(Integer.valueOf(par1), list);
    }
    
    return list;
  }
  
  public ye b(ye par1ItemStack, abw par2World, uf par3EntityPlayer)
  {
    if (!bG.d)
    {
      b -= 1;
    }
    
    if (!I)
    {
      List list = g(par1ItemStack);
      
      if (list != null)
      {
        Iterator iterator = list.iterator();
        
        while (iterator.hasNext())
        {
          nj potioneffect = (nj)iterator.next();
          par3EntityPlayer.c(new nj(potioneffect));
          if (potioneffect.a() == PotionResizing.tiny.c())
          {
            par3EntityPlayer.a(GulliverEnvoy.drinkMe, 1);
          }
        }
      }
    }
    
    if (!bG.d)
    {
      if (b <= 0)
      {
        return new ye(yc.bv);
      }
      
      bn.a(new ye(yc.bv));
    }
    
    return par1ItemStack;
  }
  



  public int d_(ye par1ItemStack)
  {
    return 32;
  }
  



  public zj c_(ye par1ItemStack)
  {
    return zj.c;
  }
  



  public ye a(ye par1ItemStack, abw par2World, uf par3EntityPlayer)
  {
    if (f(par1ItemStack.k()))
    {
      if (!bG.d)
      {
        b -= 1;
      }
      
      par2World.a(par3EntityPlayer, "random.bow", 0.5F, 0.4F / (f.nextFloat() * 0.4F + 0.8F));
      
      if (!I)
      {
        par2World.d(new uu(par2World, par3EntityPlayer, par1ItemStack));
      }
      
      return par1ItemStack;
    }
    

    par3EntityPlayer.a(par1ItemStack, d_(par1ItemStack));
    return par1ItemStack;
  }
  





  public boolean a(ye par1ItemStack, uf par2EntityPlayer, abw par3World, int par4, int par5, int par6, int par7, float par8, float par9, float par10)
  {
    return false;
  }
  




  @SideOnly(Side.CLIENT)
  public ms b_(int par1)
  {
    return f(par1) ? c : d;
  }
  




  @SideOnly(Side.CLIENT)
  public ms a(int par1, int par2)
  {
    return par2 == 0 ? cB : super.a(par1, par2);
  }
  



  public static boolean f(int par0)
  {
    return (par0 & 0x4000) != 0;
  }
  
  @SideOnly(Side.CLIENT)
  public int g(int par1)
  {
    return zp.a(par1, false);
  }
  
  @SideOnly(Side.CLIENT)
  public int a(ye par1ItemStack, int par2)
  {
    return par2 > 0 ? 16777215 : g(par1ItemStack.k());
  }
  
  @SideOnly(Side.CLIENT)
  public boolean b()
  {
    return true;
  }
  
  @SideOnly(Side.CLIENT)
  public boolean h(int par1)
  {
    List list = c(par1);
    
    if ((list != null) && (!list.isEmpty()))
    {
      Iterator iterator = list.iterator();
      
      nj potioneffect;
      do
      {
        if (!iterator.hasNext())
        {
          return false;
        }
        
        potioneffect = (nj)iterator.next();
      }
      while (!ni.a[potioneffect.a()].b());
      
      return true;
    }
    

    return false;
  }
  

  public String l(ye par1ItemStack)
  {
    if (par1ItemStack.k() == 0)
    {
      return bu.a("item.emptyPotion.name").trim();
    }
    

    String s = "";
    
    if (f(par1ItemStack.k()))
    {
      s = bu.a("potion.prefix.grenade").trim() + " ";
    }
    
    List list = yc.bu.g(par1ItemStack);
    

    if ((list != null) && (!list.isEmpty()))
    {
      String s1 = ((nj)list.get(0)).f();
      s1 = s1 + ".postfix";
      return s + bu.a(s1).trim();
    }
    

    String s1 = zp.c(par1ItemStack.k());
    return bu.a(s1).trim() + " " + super.l(par1ItemStack);
  }
  






  @SideOnly(Side.CLIENT)
  public void a(ye par1ItemStack, uf par2EntityPlayer, List par3List, boolean par4)
  {
    if (par1ItemStack.k() != 0)
    {
      List list1 = yc.bu.g(par1ItemStack);
      HashMultimap hashmultimap = HashMultimap.create();
      
      Iterator iterator;
      if ((list1 != null) && (!list1.isEmpty()))
      {
        iterator = list1.iterator();
      }
      while (iterator.hasNext())
      {
        nj potioneffect = (nj)iterator.next();
        String s = bu.a(potioneffect.f()).trim();
        ni potion = ni.a[potioneffect.a()];
        Map map = potion.k();
        
        if ((map != null) && (map.size() > 0))
        {
          Iterator iterator1 = map.entrySet().iterator();
          
          while (iterator1.hasNext())
          {
            Map.Entry entry = (Map.Entry)iterator1.next();
            ot attributemodifier = (ot)entry.getValue();
            ot attributemodifier1 = new ot(attributemodifier.b(), potion.a(potioneffect.c(), attributemodifier), attributemodifier.c());
            hashmultimap.put(((or)entry.getKey()).a(), attributemodifier1);
          }
        }
        
        if (potioneffect.c() > 0)
        {
          s = s + " " + bu.a(new StringBuilder().append("potion.potency.").append(potioneffect.c()).toString()).trim();
        }
        
        if (potioneffect.b() > 20)
        {
          s = s + " (" + ni.a(potioneffect) + ")";
        }
        
        if (potion.f())
        {
          par3List.add(a.m + s);
        }
        else
        {
          par3List.add(a.h + s);
        }
        continue;
        


        String s1 = bu.a("potion.empty").trim();
        par3List.add(a.h + s1);
      }
      
      if (!hashmultimap.isEmpty())
      {
        par3List.add("");
        par3List.add(a.f + bu.a("potion.effects.whenDrank"));
        Iterator iterator = hashmultimap.entries().iterator();
        
        while (iterator.hasNext())
        {
          Map.Entry entry1 = (Map.Entry)iterator.next();
          ot attributemodifier2 = (ot)entry1.getValue();
          double d0 = attributemodifier2.d();
          double d1;
          double d1;
          if ((attributemodifier2.c() != 1) && (attributemodifier2.c() != 2))
          {
            d1 = attributemodifier2.d();
          }
          else
          {
            d1 = attributemodifier2.d() * 100.0D;
          }
          
          if (d0 > 0.0D)
          {
            par3List.add(a.j + bu.a(new StringBuilder().append("attribute.modifier.plus.").append(attributemodifier2.c()).toString(), new Object[] { ye.a.format(d1), bu.a("attribute.name." + (String)entry1.getKey()) }));
          }
          else if (d0 < 0.0D)
          {
            d1 *= -1.0D;
            par3List.add(a.m + bu.a(new StringBuilder().append("attribute.modifier.take.").append(attributemodifier2.c()).toString(), new Object[] { ye.a.format(d1), bu.a("attribute.name." + (String)entry1.getKey()) }));
          }
        }
      }
    }
  }
  
  @SideOnly(Side.CLIENT)
  public boolean e(ye par1ItemStack)
  {
    List list = g(par1ItemStack);
    return (list != null) && (!list.isEmpty());
  }
  




  @SideOnly(Side.CLIENT)
  public void a(int par1, ww par2CreativeTabs, List par3List)
  {
    super.a(par1, par2CreativeTabs, par3List);
    

    if (b.isEmpty())
    {
      for (int k = 0; k <= 15; k++)
      {
        for (int j = 0; j <= 1; j++)
        {
          int l;
          int l;
          if (j == 0)
          {
            l = k | 0x2000;
          }
          else
          {
            l = k | 0x4000;
          }
          
          for (int i1 = 0; i1 <= 2; i1++)
          {
            int j1 = l;
            
            if (i1 != 0)
            {
              if (i1 == 1)
              {
                j1 = l | 0x20;
              }
              else if (i1 == 2)
              {
                j1 = l | 0x40;
              }
            }
            
            List list1 = zp.b(j1, false);
            
            if ((list1 != null) && (!list1.isEmpty()))
            {
              b.put(list1, Integer.valueOf(j1));
            }
          }
        }
      }
    }
    
    Iterator iterator = b.values().iterator();
    
    while (iterator.hasNext())
    {
      int j = ((Integer)iterator.next()).intValue();
      par3List.add(new ye(par1, 1, j));
    }
  }
  
  @SideOnly(Side.CLIENT)
  public void a(mt par1IconRegister)
  {
    d = par1IconRegister.a(A() + "_" + "bottle_drinkable");
    c = par1IconRegister.a(A() + "_" + "bottle_splash");
    cB = par1IconRegister.a(A() + "_" + "overlay");
  }
  
  @SideOnly(Side.CLIENT)
  public static ms e(String par0Str)
  {
    return par0Str.equals("overlay") ? bucB : par0Str.equals("bottle_splash") ? buc : par0Str.equals("bottle_drinkable") ? bud : null;
  }
}
