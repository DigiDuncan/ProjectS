





public abstract class ps
{
  private int a;
  protected float minTargetSize;
  protected float maxTargetSize;
  
  public ps() {}
  
  public ps setTargetSizeRange(float min, float max)
  {
    minTargetSize = min;
    maxTargetSize = max;
    
    return this;
  }
  



  public abstract boolean a();
  



  public boolean b()
  {
    return a();
  }
  



  public boolean i()
  {
    return true;
  }
  




  public void c() {}
  



  public void d() {}
  



  public void e() {}
  



  public void a(int par1)
  {
    a = par1;
  }
  




  public int j()
  {
    return a;
  }
}
