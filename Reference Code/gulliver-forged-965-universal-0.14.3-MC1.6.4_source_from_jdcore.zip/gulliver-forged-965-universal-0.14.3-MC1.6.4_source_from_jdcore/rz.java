import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import gulliver.common.GulliverEnvoy;
import java.util.ArrayList;
import java.util.Random;
import net.minecraftforge.common.IShearable;


























public class rz
  extends rp
  implements IShearable
{
  private final vk bq = new vk(new sa(this), 2, 1);
  



  public static final float[][] bp = { { 1.0F, 1.0F, 1.0F }, { 0.85F, 0.5F, 0.2F }, { 0.7F, 0.3F, 0.85F }, { 0.4F, 0.6F, 0.85F }, { 0.9F, 0.9F, 0.2F }, { 0.5F, 0.8F, 0.1F }, { 0.95F, 0.5F, 0.65F }, { 0.3F, 0.3F, 0.3F }, { 0.6F, 0.6F, 0.6F }, { 0.3F, 0.5F, 0.6F }, { 0.5F, 0.25F, 0.7F }, { 0.2F, 0.3F, 0.7F }, { 0.4F, 0.3F, 0.2F }, { 0.4F, 0.5F, 0.2F }, { 0.6F, 0.2F, 0.2F }, { 0.1F, 0.1F, 0.1F } };
  



  private int br;
  


  private pn bs = new pn(this);
  
  public float getSizeItemMultiplier()
  {
    if (!GulliverEnvoy.isDyeResizingEnabled())
    {
      return 1.0F;
    }
    if (bT() == 10)
    {
      return 2.0F;
    }
    if (bT() == 9)
    {
      return 0.5F;
    }
    

    return 1.0F;
  }
  

  public rz(abw par1World)
  {
    super(par1World);
    a(0.9F, 1.3F);
    k().a(true);
    c.a(0, new pp(this));
    c.a(1, new qj(this, 1.25D));
    c.a(2, new pk(this, 1.0D));
    c.a(3, new qu(this, 1.1D, Vcv, false));
    c.a(4, new pr(this, 1.1D));
    c.a(5, bs);
    c.a(6, new qm(this, 1.0D));
    c.a(7, new px(this, uf.class, 6.0F));
    c.a(8, new ql(this));
    bq.a(0, new ye(yc.aY, 1, 0));
    bq.a(1, new ye(yc.aY, 1, 0));
  }
  



  protected boolean bf()
  {
    return true;
  }
  
  protected void bi()
  {
    br = bs.f();
    super.bi();
  }
  




  public void c()
  {
    if (q.I)
    {
      br = Math.max(0, br - 1);
    }
    
    super.c();
  }
  
  protected void az()
  {
    super.az();
    a(tp.a).a(8.0D);
    a(tp.d).a(0.23000000417232513D);
  }
  
  protected void a()
  {
    super.a();
    ah.a(16, new Byte((byte)0));
  }
  




  protected void b(boolean par1, int par2)
  {
    if (!bU())
    {
      a(new ye(agcF, 1, bT()), 0.0F);
    }
  }
  



  protected int s()
  {
    return agcF;
  }
  
  @SideOnly(Side.CLIENT)
  public void a(byte par1)
  {
    if (par1 == 10)
    {
      br = 40;
    }
    else
    {
      super.a(par1);
    }
  }
  



  public boolean a(uf par1EntityPlayer)
  {
    ye var2 = bn.h();
    
    if ((!q.I) && (var2 != null) && (d == bgcv) && (!bU()) && (!g_()))
    {

      int var3 = 1;
      int chance = ls.d(3.0F * getSizeMultiplierRoot());
      
      if (chance >= 2)
      {

        int roll = ab.nextInt(chance);
        
        if (!par1EntityPlayer.isTinierThan(this))
        {
          var3 += roll;
          i(true);
        }
        else if (roll == 0)
        {
          i(true);
        }
      }
      else
      {
        i(true);
      }
      
      for (int var4 = 0; var4 < var3; var4++)
      {
        ss var5 = a(new ye(agcF, 1, bT()), 1.0F);
        y += ab.nextFloat() * 0.05F;
        x += (ab.nextFloat() - ab.nextFloat()) * 0.1F;
        z += (ab.nextFloat() - ab.nextFloat()) * 0.1F;
      }
      
      var2.a(1, par1EntityPlayer);
      a("mob.sheep.shear", 1.0F * par1EntityPlayer.getSizeMultiplierRoot() / getSizeMultiplierRoot(), 1.0F);
    }
    else if ((holdingEntity == null) && (var2 == null) && (!par1EntityPlayer.ah()) && (!bU()) && (n == null) && (par1EntityPlayer.isQuiteSmallerThan(this)) && (o == null) && ((n == null) || (n.isTinierThan(par1EntityPlayer))))
    {

      if (!q.I)
      {
        par1EntityPlayer.a(this);
      }
      
      return true;
    }
    
    return super.a(par1EntityPlayer);
  }
  



  public double Y()
  {
    if (g_())
    {
      return P * 0.7D;
    }
    if (bU())
    {
      return P * 0.7D;
    }
    

    return P * 0.75D;
  }
  

  @SideOnly(Side.CLIENT)
  public float p(float par1)
  {
    return br < 4 ? (br - par1) / 4.0F : (br >= 4) && (br <= 36) ? 1.0F : br <= 0 ? 0.0F : -(br - 40 - par1) / 4.0F;
  }
  
  @SideOnly(Side.CLIENT)
  public float q(float par1)
  {
    if ((br > 4) && (br <= 36))
    {
      float f1 = (br - 4 - par1) / 32.0F;
      return 0.62831855F + 0.2199115F * ls.a(f1 * 28.7F);
    }
    

    return br > 0 ? 0.62831855F : B / 57.295776F;
  }
  




  public void b(by par1NBTTagCompound)
  {
    super.b(par1NBTTagCompound);
    par1NBTTagCompound.a("Sheared", bU());
    par1NBTTagCompound.a("Color", (byte)bT());
  }
  



  public void a(by par1NBTTagCompound)
  {
    super.a(par1NBTTagCompound);
    i(par1NBTTagCompound.n("Sheared"));
    p(par1NBTTagCompound.c("Color"));
  }
  



  protected String r()
  {
    return "mob.sheep.say";
  }
  



  protected String aO()
  {
    return "mob.sheep.say";
  }
  



  protected String aP()
  {
    return "mob.sheep.say";
  }
  



  protected void a(int par1, int par2, int par3, int par4)
  {
    a("mob.sheep.step", 0.15F, 1.0F);
  }
  
  public int bT()
  {
    return ah.a(16) & 0xF;
  }
  
  public void p(int par1)
  {
    byte b0 = ah.a(16);
    ah.b(16, Byte.valueOf((byte)(b0 & 0xF0 | par1 & 0xF)));
  }
  



  public boolean bU()
  {
    return (ah.a(16) & 0x10) != 0;
  }
  



  public void i(boolean par1)
  {
    byte b0 = ah.a(16);
    
    if (par1)
    {
      ah.b(16, Byte.valueOf((byte)(b0 | 0x10)));
    }
    else
    {
      ah.b(16, Byte.valueOf((byte)(b0 & 0xFFFFFFEF)));
    }
  }
  



  public static int a(Random par0Random)
  {
    int i = par0Random.nextInt(100);
    return par0Random.nextInt(500) == 0 ? 6 : i < 18 ? 12 : i < 15 ? 8 : i < 10 ? 7 : i < 5 ? 15 : 0;
  }
  
  public rz b(nk par1EntityAgeable)
  {
    rz entitysheep = (rz)par1EntityAgeable;
    rz entitysheep1 = new rz(q);
    int i = a(this, entitysheep);
    entitysheep1.p(15 - i);
    return entitysheep1;
  }
  




  public void n()
  {
    i(false);
    
    if (g_())
    {
      a(60);
    }
  }
  
  public oi a(oi par1EntityLivingData)
  {
    par1EntityLivingData = super.a(par1EntityLivingData);
    p(a(q.s));
    return par1EntityLivingData;
  }
  
  private int a(rp par1EntityAnimal, rp par2EntityAnimal)
  {
    int i = b(par1EntityAnimal);
    int j = b(par2EntityAnimal);
    bq.a(0).b(i);
    bq.a(1).b(j);
    ye itemstack = aaf.a().a(bq, q);
    int k;
    int k;
    if ((itemstack != null) && (bcv == aYcv))
    {
      k = itemstack.k();
    }
    else
    {
      k = q.s.nextBoolean() ? i : j;
    }
    
    return k;
  }
  
  private int b(rp par1EntityAnimal)
  {
    return 15 - ((rz)par1EntityAnimal).bT();
  }
  
  public nk a(nk par1EntityAgeable)
  {
    return b(par1EntityAgeable);
  }
  

  public boolean isShearable(ye item, abw world, int X, int Y, int Z)
  {
    return (!bU()) && (!g_());
  }
  

  public ArrayList<ye> onSheared(ye item, abw world, int X, int Y, int Z, int fortune)
  {
    ArrayList<ye> ret = new ArrayList();
    i(true);
    int i = 1 + ab.nextInt(3);
    for (int j = 0; j < i; j++)
    {
      ret.add(new ye(agcF, 1, bT()));
    }
    q.a(this, "mob.sheep.shear", 1.0F, 1.0F);
    return ret;
  }
}
