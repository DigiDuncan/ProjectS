import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import org.lwjgl.opengl.GL11;














@SideOnly(Side.CLIENT)
public class bbj
  extends bbo
{
  public bcu c;
  public bcu d;
  public bcu e;
  public bcu f;
  public bcu g;
  public bcu h;
  public bcu i;
  public bcu j;
  public bcu k;
  public int l;
  public int m;
  public boolean n;
  public boolean isGliding;
  public boolean isRafting;
  public boolean doesUmbrella;
  public boolean o;
  
  public bbj()
  {
    this(0.0F);
  }
  
  public bbj(float par1)
  {
    this(par1, 0.0F, 64, 32);
  }
  
  public bbj(float par1, float par2, int par3, int par4)
  {
    t = par3;
    u = par4;
    k = new bcu(this, 0, 0);
    k.a(-5.0F, 0.0F, -1.0F, 10, 16, 1, par1);
    j = new bcu(this, 24, 0);
    j.a(-3.0F, -6.0F, -1.0F, 6, 6, 1, par1);
    c = new bcu(this, 0, 0);
    c.a(-4.0F, -8.0F, -4.0F, 8, 8, 8, par1);
    c.a(0.0F, 0.0F + par2, 0.0F);
    d = new bcu(this, 32, 0);
    d.a(-4.0F, -8.0F, -4.0F, 8, 8, 8, par1 + 0.5F);
    d.a(0.0F, 0.0F + par2, 0.0F);
    e = new bcu(this, 16, 16);
    e.a(-4.0F, 0.0F, -2.0F, 8, 12, 4, par1);
    e.a(0.0F, 0.0F + par2, 0.0F);
    f = new bcu(this, 40, 16);
    f.a(-3.0F, -2.0F, -2.0F, 4, 12, 4, par1);
    f.a(-5.0F, 2.0F + par2, 0.0F);
    g = new bcu(this, 40, 16);
    g.i = true;
    g.a(-1.0F, -2.0F, -2.0F, 4, 12, 4, par1);
    g.a(5.0F, 2.0F + par2, 0.0F);
    h = new bcu(this, 0, 16);
    h.a(-2.0F, 0.0F, -2.0F, 4, 12, 4, par1);
    h.a(-1.9F, 12.0F + par2, 0.0F);
    i = new bcu(this, 0, 16);
    i.i = true;
    i.a(-2.0F, 0.0F, -2.0F, 4, 12, 4, par1);
    i.a(1.9F, 12.0F + par2, 0.0F);
  }
  



  public void a(nn par1Entity, float par2, float par3, float par4, float par5, float par6, float par7)
  {
    a(par2, par3, par4, par5, par6, par7, par1Entity);
    
    if (s)
    {
      float f6 = 2.0F;
      GL11.glPushMatrix();
      GL11.glScalef(1.5F / f6, 1.5F / f6, 1.5F / f6);
      GL11.glTranslatef(0.0F, 16.0F * par7, 0.0F);
      c.a(par7);
      GL11.glPopMatrix();
      GL11.glPushMatrix();
      GL11.glScalef(1.0F / f6, 1.0F / f6, 1.0F / f6);
      GL11.glTranslatef(0.0F, 24.0F * par7, 0.0F);
      e.a(par7);
      f.a(par7);
      g.a(par7);
      h.a(par7);
      i.a(par7);
      d.a(par7);
      GL11.glPopMatrix();
    }
    else
    {
      c.a(par7);
      e.a(par7);
      f.a(par7);
      g.a(par7);
      h.a(par7);
      i.a(par7);
      d.a(par7);
    }
  }
  





  public void a(float par1, float par2, float par3, float par4, float par5, float par6, nn par7Entity)
  {
    c.g = (par4 / 57.295776F);
    c.f = (par5 / 57.295776F);
    d.g = c.g;
    d.f = c.f;
    f.f = (ls.b(par1 * 0.6662F + 3.1415927F) * 2.0F * par2 * 0.5F * (heldEntity != null ? 0.25F : 1.0F));
    g.f = (ls.b(par1 * 0.6662F) * 2.0F * par2 * 0.5F);
    f.h = 0.0F;
    g.h = 0.0F;
    h.f = (ls.b(par1 * 0.6662F) * 1.4F * par2);
    i.f = (ls.b(par1 * 0.6662F + 3.1415927F) * 1.4F * par2);
    h.g = 0.0F;
    i.g = 0.0F;
    
    if (q)
    {
      f.f += -0.62831855F;
      g.f += -0.62831855F;
      h.f = -1.2566371F;
      i.f = -1.2566371F;
      h.g = 0.31415927F;
      i.g = -0.31415927F;
    }
    else if (isRafting)
    {
      f.f = (ls.b(par1 * 0.6662F * 0.125F + 3.1415927F) * 2.0F * par2 * 0.5F);
      g.f = (ls.b(par1 * 0.6662F) * 2.0F * par2 * 0.5F);
      h.f = -1.2566371F;
      i.f = -1.2566371F;
      h.g = 0.31415927F;
      i.g = -0.31415927F;
    }
    else if (isGliding)
    {
      h.f = (ls.b(par1 * 0.6662F * 0.25F) * 1.4F * par2 * 0.25F);
      i.f = (ls.b(par1 * 0.6662F * 0.25F + 3.1415927F) * 1.4F * par2 * 0.25F);
      h.g = 0.0F;
      i.g = 0.0F;
    }
    
    if (l != 0)
    {
      g.f = (g.f * 0.5F - 0.31415927F * l);
    }
    
    if (m != 0)
    {
      f.f = (f.f * 0.5F - 0.31415927F * m);
    }
    
    f.g = 0.0F;
    g.g = 0.0F;
    


    if ((p > -9990.0F) && (!isGliding))
    {
      float f6 = p;
      e.g = (ls.a(ls.c(f6) * 3.1415927F * 2.0F) * 0.2F);
      f.e = (ls.a(e.g) * 5.0F);
      f.c = (-ls.b(e.g) * 5.0F);
      g.e = (-ls.a(e.g) * 5.0F);
      g.c = (ls.b(e.g) * 5.0F);
      f.g += e.g;
      g.g += e.g;
      g.f += e.g;
      f6 = 1.0F - p;
      f6 *= f6;
      f6 *= f6;
      f6 = 1.0F - f6;
      float f7 = ls.a(f6 * 3.1415927F);
      float f8 = ls.a(p * 3.1415927F) * -(c.f - 0.7F) * 0.75F;
      f.f = ((float)(f.f - (f7 * 1.2D + f8)));
      f.g += e.g * 2.0F;
      f.h = (ls.a(p * 3.1415927F) * -0.4F);
    }
    
    if (n)
    {
      e.f = 0.5F;
      f.f += 0.4F;
      g.f += 0.4F;
      h.e = 4.0F;
      i.e = 4.0F;
      h.d = 9.0F;
      i.d = 9.0F;
      c.d = 1.0F;
      d.d = 1.0F;
    }
    else
    {
      e.f = 0.0F;
      h.e = 0.1F;
      i.e = 0.1F;
      h.d = 12.0F;
      i.d = 12.0F;
      c.d = 0.0F;
      d.d = 0.0F;
    }
    
    f.h += ls.b(par3 * 0.09F) * 0.05F + 0.05F;
    g.h -= ls.b(par3 * 0.09F) * 0.05F + 0.05F;
    f.f += ls.a(par3 * 0.067F) * 0.05F;
    g.f -= ls.a(par3 * 0.067F) * 0.05F;
    
    if (o)
    {
      float f6 = 0.0F;
      float f7 = 0.0F;
      f.h = 0.0F;
      g.h = 0.0F;
      f.g = (-(0.1F - f6 * 0.6F) + c.g);
      g.g = (0.1F - f6 * 0.6F + c.g + 0.4F);
      f.f = (-1.5707964F + c.f);
      g.f = (-1.5707964F + c.f);
      f.f -= f6 * 1.2F - f7 * 0.4F;
      g.f -= f6 * 1.2F - f7 * 0.4F;
      f.h += ls.b(par3 * 0.09F) * 0.05F + 0.05F;
      g.h -= ls.b(par3 * 0.09F) * 0.05F + 0.05F;
      f.f += ls.a(par3 * 0.067F) * 0.05F;
      g.f -= ls.a(par3 * 0.067F) * 0.05F;
    }
    
    if (isGliding)
    {
      f.f = -3.1415927F;
      g.f = -3.1415927F;
    }
    else if (doesUmbrella)
    {
      f.f = -3.1415927F;
    }
  }
  



  public void b(float par1)
  {
    j.g = c.g;
    j.f = c.f;
    j.c = 0.0F;
    j.d = 0.0F;
    j.a(par1);
  }
  



  public void c(float par1)
  {
    k.a(par1);
  }
}
