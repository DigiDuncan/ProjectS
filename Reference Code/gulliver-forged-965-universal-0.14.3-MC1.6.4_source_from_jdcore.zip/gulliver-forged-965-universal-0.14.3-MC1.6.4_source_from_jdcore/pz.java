import java.util.Random;






public class pz
  extends ps
{
  private ub b;
  private ub c;
  private abw d;
  private int e;
  rj a;
  
  public pz(ub par1EntityVillager)
  {
    b = par1EntityVillager;
    d = q;
    a(3);
    
    minTargetSize = 0.5F;
    maxTargetSize = 2.0F;
  }
  



  public boolean a()
  {
    if (b.b() != 0)
    {
      return false;
    }
    if (b.aD().nextInt(500) != 0)
    {
      return false;
    }
    if ((b.P >= 2.0F) || (b.isTiny()))
    {

      return false;
    }
    

    a = d.A.a(ls.c(b.u), ls.c(b.v), ls.c(b.w), 0);
    
    if (a == null)
    {
      return false;
    }
    if (!f())
    {
      return false;
    }
    

    float rmult = b.getRangeMultiplier();
    nn entity = d.a(ub.class, b.E.b(8.0D * rmult, 3.0D * b.getSizeMultiplierRoot(), 8.0D * rmult), b);
    
    if ((entity == null) || (!b.isEntityInRelativeSizeRange(entity, minTargetSize, maxTargetSize)))
    {
      return false;
    }
    

    c = ((ub)entity);
    return c.b() == 0;
  }
  






  public void c()
  {
    e = 300;
    b.i(true);
  }
  



  public void d()
  {
    a = null;
    c = null;
    b.i(false);
  }
  



  public boolean b()
  {
    return (e >= 0) && (f()) && (b.b() == 0);
  }
  



  public void e()
  {
    e -= 1;
    b.h().a(c, 10.0F, 30.0F);
    
    if (b.e(c) > 2.25D * b.getRangeMultiplier() * b.getRangeMultiplier())
    {
      b.k().a(c, 0.25D);
    }
    else if ((e == 0) && (c.bU()))
    {
      g();
    }
    
    if (b.aD().nextInt(35) == 0)
    {
      d.a(b, (byte)12);
    }
  }
  
  private boolean f()
  {
    if (!a.i())
    {
      return false;
    }
    

    int i = (int)(a.c() * 0.35D);
    return a.e() < i;
  }
  

  private void g()
  {
    ub entityvillager = b.b(c);
    c.c(6000);
    b.c(6000);
    entityvillager.c(41536);
    
    float newsize = (b.getSizeMultiplier() + c.getSizeMultiplier()) * 0.5F;
    entityvillager.setSizeBaseMultiplier(newsize);
    entityvillager.doResize(newsize, false);
    entityvillager.b(b.u, b.v, b.w, 0.0F, 0.0F);
    d.d(entityvillager);
    d.a(entityvillager, (byte)12);
  }
}
