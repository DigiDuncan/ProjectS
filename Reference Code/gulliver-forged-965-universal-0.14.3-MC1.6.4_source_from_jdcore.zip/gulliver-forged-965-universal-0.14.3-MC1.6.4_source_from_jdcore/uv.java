import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;










public class uv
  extends uj
{
  public uv(abw par1World)
  {
    super(par1World);
    a(0.3125F, 0.3125F);
  }
  
  public uv(abw par1World, of par2EntityLivingBase, double par3, double par5, double par7)
  {
    super(par1World, par2EntityLivingBase, par3, par5, par7);
    a(0.3125F, 0.3125F);
  }
  



  protected float c()
  {
    return d() ? 0.73F : super.c();
  }
  
  @SideOnly(Side.CLIENT)
  public uv(abw par1World, double par2, double par4, double par6, double par8, double par10, double par12)
  {
    super(par1World, par2, par4, par6, par8, par10, par12);
    a(0.3125F, 0.3125F);
  }
  



  public boolean af()
  {
    return false;
  }
  




  public float a(abr par1Explosion, abw par2World, int par3, int par4, int par5, aqz par6Block)
  {
    float f = super.a(par1Explosion, par2World, par3, par4, par5, par6Block);
    
    if ((d()) && (par6Block != aqz.E) && (par6Block != aqz.bM) && (par6Block != aqz.bN))
    {
      f = Math.min(0.8F, f);
    }
    
    return f;
  }
  



  protected void a(ata par1MovingObjectPosition)
  {
    if (!q.I)
    {
      if (g != null)
      {
        if (a != null)
        {
          if ((g.a(nb.a(a), 8.0F)) && (!g.T()))
          {
            a.f(5.0F);
          }
          
        }
        else {
          g.a(nb.k, 5.0F);
        }
        
        if ((g instanceof of))
        {
          byte b0 = 0;
          
          if (q.r > 1)
          {
            if (q.r == 2)
            {
              b0 = 10;
            }
            else if (q.r == 3)
            {
              b0 = 40;
            }
          }
          
          if (b0 > 0)
          {
            ((of)g).c(new nj(vH, 20 * b0, 1));
          }
        }
      }
      
      q.a(this, u, v, w, 1.0F * getSizeMultiplier(), false, q.O().b("mobGriefing"));
      x();
    }
  }
  



  public boolean L()
  {
    return false;
  }
  



  public boolean a(nb par1DamageSource, float par2)
  {
    return false;
  }
  
  protected void a()
  {
    ah.a(10, Byte.valueOf((byte)0));
  }
  



  public boolean d()
  {
    return ah.a(10) == 1;
  }
  



  public void a(boolean par1)
  {
    ah.b(10, Byte.valueOf((byte)(par1 ? 1 : 0)));
  }
}
