





public class qr
  extends ps
{
  private oq a;
  private boolean b;
  
  public qr(oq par1EntityTameable)
  {
    a = par1EntityTameable;
    a(5);
  }
  



  public boolean a()
  {
    if (!a.bT())
    {
      return false;
    }
    if (a.H())
    {
      return false;
    }
    if (!a.F)
    {
      return false;
    }
    

    of entitylivingbase = a.bV();
    return (!a.isEntityInRelativeSizeRange(entitylivingbase, minTargetSize, maxTargetSize)) && (a.e(entitylivingbase) < 144.0D * a.getSizeMultiplier()) && (entitylivingbase.aE() != null) ? false : entitylivingbase == null ? true : b;
  }
  




  public void c()
  {
    a.k().h();
    a.k(true);
  }
  



  public void d()
  {
    a.k(false);
  }
  



  public void a(boolean par1)
  {
    b = par1;
  }
}
