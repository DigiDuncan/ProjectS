import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;





public class tl
  extends ts
{
  public tl(abw par1World)
  {
    super(par1World);
    ag = true;
    isSlimy = false;
  }
  
  protected void az()
  {
    super.az();
    a(tp.d).a(0.20000000298023224D);
  }
  



  public boolean bs()
  {
    return (q.r > 0) && (q.b(E)) && (q.a(this, E).isEmpty()) && (!q.d(E));
  }
  



  public int aQ()
  {
    return bR() * 3;
  }
  
  @SideOnly(Side.CLIENT)
  public int c(float par1)
  {
    return 15728880;
  }
  



  public float d(float par1)
  {
    return 1.0F;
  }
  



  protected String bJ()
  {
    return "flame";
  }
  
  protected ts bK()
  {
    return new tl(q);
  }
  



  protected int s()
  {
    return bzcv;
  }
  




  protected void b(boolean par1, int par2)
  {
    int j = s();
    
    if ((j > 0) && (bR() > 1))
    {
      dropItemSizedAmount(par2, j, -2, 4);
    }
  }
  



  public boolean af()
  {
    return false;
  }
  



  protected int bL()
  {
    return super.bL() * 4;
  }
  
  protected void bM()
  {
    h *= 0.9F;
  }
  



  protected void be()
  {
    y = (0.42F + bR() * getSizeMultiplier() * 0.1F);
    an = true;
  }
  



  protected void b(float par1) {}
  



  protected boolean bN()
  {
    return true;
  }
  



  protected int bO()
  {
    return super.bO() + 2;
  }
  



  protected String aO()
  {
    return "mob.slime." + (ls.d(bR() * getSizeMultiplier()) > 1 ? "big" : "small");
  }
  



  protected String aP()
  {
    return "mob.slime." + (ls.d(bR() * getSizeMultiplier()) > 1 ? "big" : "small");
  }
  



  protected String bP()
  {
    return ls.d(bR() * getSizeMultiplier()) > 1 ? "mob.magmacube.big" : "mob.magmacube.small";
  }
  



  public boolean J()
  {
    return false;
  }
  



  protected boolean bQ()
  {
    return true;
  }
}
