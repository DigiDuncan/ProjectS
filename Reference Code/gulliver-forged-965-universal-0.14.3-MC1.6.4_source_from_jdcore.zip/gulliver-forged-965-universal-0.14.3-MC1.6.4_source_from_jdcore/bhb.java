import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import java.util.Random;
import net.minecraftforge.client.event.RenderLivingEvent.Post;
import net.minecraftforge.client.event.RenderLivingEvent.Pre;
import net.minecraftforge.client.event.RenderLivingEvent.Specials.Post;
import net.minecraftforge.client.event.RenderLivingEvent.Specials.Pre;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.EventBus;
import org.lwjgl.opengl.GL11;

















@SideOnly(Side.CLIENT)
public abstract class bhb
  extends bgm
{
  private static final bjo a = new bjo("textures/misc/enchanted_item_glint.png");
  
  protected bbo i;
  
  protected bbo j;
  
  public static float NAME_TAG_RANGE = 64.0F;
  public static float NAME_TAG_RANGE_SNEAK = 32.0F;
  
  public bhb(bbo par1ModelBase, float par2)
  {
    i = par1ModelBase;
    d = par2;
  }
  




  public void a(bbo par1ModelBase)
  {
    j = par1ModelBase;
  }
  







  private float a(float par1, float par2, float par3)
  {
    for (float f3 = par2 - par1; f3 < -180.0F; f3 += 360.0F) {}
    



    while (f3 >= 180.0F)
    {
      f3 -= 360.0F;
    }
    
    return par1 + par3 * f3;
  }
  
  public void a(of par1EntityLivingBase, double par2, double par4, double par6, float par8, float par9)
  {
    if (MinecraftForge.EVENT_BUS.post(new RenderLivingEvent.Pre(par1EntityLivingBase, this))) return;
    GL11.glPushMatrix();
    GL11.glDisable(2884);
    ip = d(par1EntityLivingBase, par9);
    
    if (this.j != null)
    {
      jp = ip;
    }
    
    iq = par1EntityLivingBase.ag();
    
    if (this.j != null)
    {
      jq = iq;
    }
    
    if ((this.i instanceof bbj))
    {
      iisGliding = par1EntityLivingBase.isGliding();
      iisRafting = par1EntityLivingBase.isRafting();
      idoesUmbrella = par1EntityLivingBase.doesUmbrella();
      
      if ((this.j != null) && ((this.j instanceof bbj)))
      {
        jisGliding = iisGliding;
        jisRafting = iisRafting;
        jdoesUmbrella = idoesUmbrella;
      }
    }
    
    is = par1EntityLivingBase.g_();
    
    if (this.j != null)
    {
      js = is;
    }
    
    try
    {
      float f2 = a(aO, aN, par9);
      float f3 = a(aQ, aP, par9);
      

      if ((par1EntityLivingBase.ag()) && ((o instanceof of)))
      {
        of entitylivingbase1 = (of)o;
        f2 = a(aO, aN, par9);
        float f4 = ls.g(f3 - f2);
        
        if (f4 < -85.0F)
        {
          f4 = -85.0F;
        }
        
        if (f4 >= 85.0F)
        {
          f4 = 85.0F;
        }
        
        f2 = f3 - f4;
        
        if (f4 * f4 > 2500.0F)
        {
          f2 += f4 * 0.2F;
        }
      }
      
      float f5 = D + (B - D) * par9;
      a(par1EntityLivingBase, par2, par4, par6);
      float f4 = b(par1EntityLivingBase, par9);
      a(par1EntityLivingBase, f4, f2, par9);
      float f6 = 0.0625F;
      GL11.glEnable(32826);
      
      float sizemult = par1EntityLivingBase.getSizeMultiplier();
      GL11.glScalef(-sizemult, -sizemult, sizemult);
      a(par1EntityLivingBase, par9);
      GL11.glTranslatef(0.0F, -24.0F * f6 - 0.0078125F, 0.0F);
      float f7 = aF + (aG - aF) * par9;
      float f8 = aH - aG * (1.0F - par9);
      
      if (par1EntityLivingBase.g_())
      {
        f8 *= 3.0F;
      }
      
      if (f7 > 1.0F)
      {
        f7 = 1.0F;
      }
      
      GL11.glEnable(3008);
      int i = 0;
      float f14 = 0.0F;
      this.i.a(par1EntityLivingBase, f8, f7, par9);
      a(par1EntityLivingBase, f8, f7, f4, f3 - f2, f5, f6);
      



      for (int j = 0; j < 4; j++)
      {
        int i2 = a(par1EntityLivingBase, j, par9);
        
        if (i2 > 0)
        {
          this.j.a(par1EntityLivingBase, f8, f7, par9);
          this.j.a(par1EntityLivingBase, f8, f7, f4, f3 - f2, f5, f6);
          
          if ((i2 & 0xF0) == 16)
          {
            c(par1EntityLivingBase, j, par9);
            this.j.a(par1EntityLivingBase, f8, f7, f4, f3 - f2, f5, f6);
          }
          
          if ((i2 & 0xF) == 15)
          {
            float f9 = ac + par9;
            a(a);
            GL11.glEnable(3042);
            float f10 = 0.5F;
            GL11.glColor4f(f10, f10, f10, 1.0F);
            GL11.glDepthFunc(514);
            GL11.glDepthMask(false);
            
            for (int k = 0; k < 2; k++)
            {
              GL11.glDisable(2896);
              float f11 = 0.76F;
              GL11.glColor4f(0.5F * f11, 0.25F * f11, 0.8F * f11, 1.0F);
              GL11.glBlendFunc(768, 1);
              GL11.glMatrixMode(5890);
              GL11.glLoadIdentity();
              float f12 = f9 * (0.001F + k * 0.003F) * 20.0F;
              float f13 = 0.33333334F;
              GL11.glScalef(f13, f13, f13);
              GL11.glRotatef(30.0F - k * 60.0F, 0.0F, 0.0F, 1.0F);
              GL11.glTranslatef(0.0F, f12, 0.0F);
              GL11.glMatrixMode(5888);
              this.j.a(par1EntityLivingBase, f8, f7, f4, f3 - f2, f5, f6);
            }
            
            GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
            GL11.glMatrixMode(5890);
            GL11.glDepthMask(true);
            GL11.glLoadIdentity();
            GL11.glMatrixMode(5888);
            GL11.glEnable(2896);
            GL11.glDisable(3042);
            GL11.glDepthFunc(515);
          }
          
          GL11.glDisable(3042);
          GL11.glEnable(3008);
        }
      }
      
      GL11.glDepthMask(true);
      c(par1EntityLivingBase, par9);
      f14 = par1EntityLivingBase.d(par9);
      i = a(par1EntityLivingBase, f14, par9);
      bma.a(bma.b);
      GL11.glDisable(3553);
      bma.a(bma.a);
      
      if (((i >> 24 & 0xFF) > 0) || (ay > 0) || (aB > 0))
      {
        GL11.glDisable(3553);
        GL11.glDisable(3008);
        GL11.glEnable(3042);
        GL11.glBlendFunc(770, 771);
        GL11.glDepthFunc(514);
        
        if ((ay > 0) || (aB > 0))
        {
          GL11.glColor4f(f14, 0.0F, 0.0F, 0.4F);
          this.i.a(par1EntityLivingBase, f8, f7, f4, f3 - f2, f5, f6);
          
          for (int l = 0; l < 4; l++)
          {
            if (b(par1EntityLivingBase, l, par9) >= 0)
            {
              GL11.glColor4f(f14, 0.0F, 0.0F, 0.4F);
              this.j.a(par1EntityLivingBase, f8, f7, f4, f3 - f2, f5, f6);
            }
          }
        }
        
        if ((i >> 24 & 0xFF) > 0)
        {
          float f9 = (i >> 16 & 0xFF) / 255.0F;
          float f10 = (i >> 8 & 0xFF) / 255.0F;
          float f15 = (i & 0xFF) / 255.0F;
          float f11 = (i >> 24 & 0xFF) / 255.0F;
          GL11.glColor4f(f9, f10, f15, f11);
          this.i.a(par1EntityLivingBase, f8, f7, f4, f3 - f2, f5, f6);
          
          for (int i1 = 0; i1 < 4; i1++)
          {
            if (b(par1EntityLivingBase, i1, par9) >= 0)
            {
              GL11.glColor4f(f9, f10, f15, f11);
              this.j.a(par1EntityLivingBase, f8, f7, f4, f3 - f2, f5, f6);
            }
          }
        }
        
        GL11.glDepthFunc(515);
        GL11.glDisable(3042);
        GL11.glEnable(3008);
        GL11.glEnable(3553);
      }
      
      GL11.glDisable(32826);
    }
    catch (Exception exception)
    {
      exception.printStackTrace();
    }
    
    bma.a(bma.b);
    GL11.glEnable(3553);
    bma.a(bma.a);
    GL11.glEnable(2884);
    GL11.glPopMatrix();
    b(par1EntityLivingBase, par2, par4, par6);
    MinecraftForge.EVENT_BUS.post(new RenderLivingEvent.Post(par1EntityLivingBase, this));
  }
  



  protected void a(of par1EntityLivingBase, float par2, float par3, float par4, float par5, float par6, float par7)
  {
    b(par1EntityLivingBase);
    
    if (!par1EntityLivingBase.aj())
    {
      i.a(par1EntityLivingBase, par2, par3, par4, par5, par6, par7);
    }
    else if (!par1EntityLivingBase.d(wh))
    {
      GL11.glPushMatrix();
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.15F);
      GL11.glDepthMask(false);
      GL11.glEnable(3042);
      GL11.glBlendFunc(770, 771);
      GL11.glAlphaFunc(516, 0.003921569F);
      i.a(par1EntityLivingBase, par2, par3, par4, par5, par6, par7);
      GL11.glDisable(3042);
      GL11.glAlphaFunc(516, 0.1F);
      GL11.glPopMatrix();
      GL11.glDepthMask(true);
    }
    else
    {
      i.a(par2, par3, par4, par5, par6, par7, par1EntityLivingBase);
    }
  }
  



  protected void a(of par1EntityLivingBase, double par2, double par4, double par6)
  {
    GL11.glTranslatef((float)par2, (float)par4, (float)par6);
  }
  
  protected void a(of par1EntityLivingBase, float par2, float par3, float par4)
  {
    GL11.glRotatef(180.0F - par3, 0.0F, 1.0F, 0.0F);
    
    if (aB > 0)
    {
      float f3 = (aB + par4 - 1.0F) / 20.0F * 1.6F;
      f3 = ls.c(f3);
      
      if (f3 > 1.0F)
      {
        f3 = 1.0F;
      }
      
      GL11.glRotatef(f3 * a(par1EntityLivingBase), 0.0F, 0.0F, 1.0F);
    }
    else
    {
      String s = a.a(par1EntityLivingBase.an());
      
      if (((s.equals("Dinnerbone")) || (s.equals("Grumm"))) && ((!(par1EntityLivingBase instanceof uf)) || (!((uf)par1EntityLivingBase).bL())))
      {
        GL11.glTranslatef(0.0F, P + 0.1F, 0.0F);
        GL11.glRotatef(180.0F, 0.0F, 0.0F, 1.0F);
      }
    }
  }
  
  protected float d(of par1EntityLivingBase, float par2)
  {
    return par1EntityLivingBase.k(par2);
  }
  



  protected float b(of par1EntityLivingBase, float par2)
  {
    return ac + par2;
  }
  


  protected void c(of par1EntityLivingBase, float par2) {}
  

  protected void e(of par1EntityLivingBase, float par2)
  {
    int i = par1EntityLivingBase.aU();
    
    if (i > 0)
    {
      uh entityarrow = new uh(q, u, v, w);
      entityarrow.setSizeMultiplier(1.0F / par1EntityLivingBase.getSizeMultiplierRoot());
      entityarrow.a(0.5F, 0.5F);
      Random random = new Random(k);
      att.a();
      
      for (int j = 0; j < i; j++)
      {
        GL11.glPushMatrix();
        bcu modelrenderer = this.i.a(random);
        bcp modelbox = (bcp)l.get(random.nextInt(l.size()));
        modelrenderer.c(0.0625F);
        float f1 = random.nextFloat();
        float f2 = random.nextFloat();
        float f3 = random.nextFloat();
        float f4 = (a + (d - a) * f1) / 16.0F;
        float f5 = (b + (e - b) * f2) / 16.0F;
        float f6 = (c + (f - c) * f3) / 16.0F;
        GL11.glTranslatef(f4, f5, f6);
        f1 = f1 * 2.0F - 1.0F;
        f2 = f2 * 2.0F - 1.0F;
        f3 = f3 * 2.0F - 1.0F;
        f1 *= -1.0F;
        f2 *= -1.0F;
        f3 *= -1.0F;
        float f7 = ls.c(f1 * f1 + f3 * f3);
        C = (entityarrow.A = (float)(Math.atan2(f1, f3) * 180.0D / 3.141592653589793D));
        D = (entityarrow.B = (float)(Math.atan2(f2, f7) * 180.0D / 3.141592653589793D));
        double d0 = 0.0D;
        double d1 = 0.0D;
        double d2 = 0.0D;
        float f8 = 0.0F;
        b.a(entityarrow, d0, d1, d2, f8, par2);
        GL11.glPopMatrix();
      }
      
      att.b();
    }
  }
  
  protected int b(of par1EntityLivingBase, int par2, float par3)
  {
    return a(par1EntityLivingBase, par2, par3);
  }
  



  protected int a(of par1EntityLivingBase, int par2, float par3)
  {
    return -1;
  }
  
  protected void c(of par1EntityLivingBase, int par2, float par3) {}
  
  protected float a(of par1EntityLivingBase)
  {
    return 90.0F;
  }
  



  protected int a(of par1EntityLivingBase, float par2, float par3)
  {
    return 0;
  }
  




  protected void a(of par1EntityLivingBase, float par2) {}
  



  protected void b(of par1EntityLivingBase, double par2, double par4, double par6)
  {
    if (MinecraftForge.EVENT_BUS.post(new RenderLivingEvent.Specials.Pre(par1EntityLivingBase, this))) return;
    if (b(par1EntityLivingBase))
    {
      float sizemult = par1EntityLivingBase.getSizeMultiplier();
      float f = 1.6F * sizemult;
      float f1 = 0.016666668F * f;
      double d3 = par1EntityLivingBase.getEyeDistanceSqToEntityLiving(b.h);
      float f2 = par1EntityLivingBase.ah() ? NAME_TAG_RANGE_SNEAK : NAME_TAG_RANGE;
      f2 *= sizemult * b.h.getRangeMultiplier();
      
      if ((par1EntityLivingBase.isTinierThan(b.h)) && (!b.h.o(par1EntityLivingBase)))
      {
        f2 *= sizemult / b.h.getSizeMultiplier();
      }
      
      if (d3 < f2 * f2)
      {
        String s = par1EntityLivingBase.ay();
        
        if (par1EntityLivingBase.ah())
        {
          avi fontrenderer = a();
          GL11.glPushMatrix();
          GL11.glTranslatef((float)par2 + 0.0F, (float)par4 + P + 0.5F * sizemult, (float)par6);
          GL11.glNormal3f(0.0F, 1.0F, 0.0F);
          GL11.glRotatef(-b.j, 0.0F, 1.0F, 0.0F);
          GL11.glRotatef(b.k, 1.0F, 0.0F, 0.0F);
          GL11.glScalef(-f1, -f1, f1);
          GL11.glDisable(2896);
          GL11.glTranslatef(0.0F, 0.25F * sizemult / f1, 0.0F);
          GL11.glDepthMask(false);
          GL11.glEnable(3042);
          GL11.glBlendFunc(770, 771);
          bfq tessellator = bfq.a;
          GL11.glDisable(3553);
          tessellator.b();
          int i = fontrenderer.a(s) / 2;
          tessellator.a(0.0F, 0.0F, 0.0F, 0.25F);
          tessellator.a(-i - 1, -1.0D, 0.0D);
          tessellator.a(-i - 1, 8.0D, 0.0D);
          tessellator.a(i + 1, 8.0D, 0.0D);
          tessellator.a(i + 1, -1.0D, 0.0D);
          tessellator.a();
          GL11.glEnable(3553);
          GL11.glDepthMask(true);
          fontrenderer.b(s, -fontrenderer.a(s) / 2, 0, 553648127);
          GL11.glEnable(2896);
          GL11.glDisable(3042);
          GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
          GL11.glPopMatrix();
        }
        else
        {
          a(par1EntityLivingBase, par2, par4, par6, s, f1, d3);
        }
      }
    }
    MinecraftForge.EVENT_BUS.post(new RenderLivingEvent.Specials.Post(par1EntityLivingBase, this));
  }
  
  protected boolean b(of par1EntityLivingBase)
  {
    return (atv.r()) && (par1EntityLivingBase != b.h) && (!par1EntityLivingBase.d(wh)) && (n == null);
  }
  
  protected void a(of par1EntityLivingBase, double par2, double par4, double par6, String par8Str, float par9, double par10)
  {
    if (par1EntityLivingBase.bh())
    {
      a(par1EntityLivingBase, par8Str, par2, par4 - 1.5D * par1EntityLivingBase.getSizeMultiplier(), par6, 64);
    }
    else
    {
      a(par1EntityLivingBase, par8Str, par2, par4, par6, 64);
    }
  }
  



  protected void a(of par1EntityLivingBase, String par2Str, double par3, double par5, double par7, int par9)
  {
    float sizemult = par1EntityLivingBase.getSizeMultiplier();
    double d3 = par1EntityLivingBase.getEyeDistanceSqToEntityLiving(b.h);
    
    if (d3 <= par9 * par9)
    {
      avi fontrenderer = a();
      float f = 1.6F * sizemult;
      float f1 = 0.016666668F * f;
      GL11.glPushMatrix();
      GL11.glTranslatef((float)par3 + 0.0F, (float)par5 + P + 0.5F * sizemult, (float)par7);
      GL11.glNormal3f(0.0F, 1.0F, 0.0F);
      GL11.glRotatef(-b.j, 0.0F, 1.0F, 0.0F);
      GL11.glRotatef(b.k, 1.0F, 0.0F, 0.0F);
      GL11.glScalef(-f1, -f1, f1);
      GL11.glDisable(2896);
      GL11.glDepthMask(false);
      GL11.glDisable(2929);
      GL11.glEnable(3042);
      GL11.glBlendFunc(770, 771);
      bfq tessellator = bfq.a;
      byte b0 = 0;
      
      if (par2Str.equals("deadmau5"))
      {
        b0 = -10;
      }
      
      GL11.glDisable(3553);
      tessellator.b();
      int j = fontrenderer.a(par2Str) / 2;
      tessellator.a(0.0F, 0.0F, 0.0F, 0.25F);
      tessellator.a(-j - 1, -1 + b0, 0.0D);
      tessellator.a(-j - 1, 8 + b0, 0.0D);
      tessellator.a(j + 1, 8 + b0, 0.0D);
      tessellator.a(j + 1, -1 + b0, 0.0D);
      tessellator.a();
      GL11.glEnable(3553);
      fontrenderer.b(par2Str, -fontrenderer.a(par2Str) / 2, b0, 553648127);
      GL11.glEnable(2929);
      GL11.glDepthMask(true);
      fontrenderer.b(par2Str, -fontrenderer.a(par2Str) / 2, b0, -1);
      GL11.glEnable(2896);
      GL11.glDisable(3042);
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
      GL11.glPopMatrix();
    }
  }
  






  public void a(nn par1Entity, double par2, double par4, double par6, float par8, float par9)
  {
    a((of)par1Entity, par2, par4, par6, par8, par9);
  }
}
