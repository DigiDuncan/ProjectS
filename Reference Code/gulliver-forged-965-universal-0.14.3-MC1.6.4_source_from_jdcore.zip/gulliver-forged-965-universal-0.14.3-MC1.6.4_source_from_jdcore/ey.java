import gulliver.network.packet.Packet171EntitySize;
import gulliver.network.packet.Packet172AttachEntitySpecial;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.EOFException;
import java.io.IOException;
import java.net.Socket;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import net.minecraft.server.MinecraftServer;










public abstract class ey
{
  public static lm l = new lm();
  

  private static Map a = new HashMap();
  

  private static Set b = new HashSet();
  

  private static Set c = new HashSet();
  
  protected lp m;
  
  public final long n = MinecraftServer.aq();
  

  public static long o;
  
  public static long p;
  
  public static long q;
  
  public static long r;
  
  public boolean s;
  

  public ey() {}
  

  public static void a(int par0, boolean par1, boolean par2, Class par3Class)
  {
    if (l.b(par0))
    {
      throw new IllegalArgumentException("Duplicate packet id:" + par0);
    }
    if (a.containsKey(par3Class))
    {
      throw new IllegalArgumentException("Duplicate packet class:" + par3Class);
    }
    

    l.a(par0, par3Class);
    a.put(par3Class, Integer.valueOf(par0));
    
    if (par1)
    {
      b.add(Integer.valueOf(par0));
    }
    
    if (par2)
    {
      c.add(Integer.valueOf(par0));
    }
  }
  




  public static ey a(lp par0ILogAgent, int par1)
  {
    try
    {
      Class oclass = (Class)l.a(par1);
      return oclass == null ? null : (ey)oclass.newInstance();
    }
    catch (Exception exception)
    {
      exception.printStackTrace();
      par0ILogAgent.c("Skipping packet with id " + par1); }
    return null;
  }
  



  public static void a(DataOutput par0DataOutput, byte[] par1ArrayOfByte)
    throws IOException
  {
    par0DataOutput.writeShort(par1ArrayOfByte.length);
    par0DataOutput.write(par1ArrayOfByte);
  }
  


  public static byte[] b(DataInput par0DataInput)
    throws IOException
  {
    short short1 = par0DataInput.readShort();
    
    if (short1 < 0)
    {
      throw new IOException("Key was smaller than nothing!  Weird key!");
    }
    

    byte[] abyte = new byte[short1];
    par0DataInput.readFully(abyte);
    return abyte;
  }
  




  public final int n()
  {
    return ((Integer)a.get(getClass())).intValue();
  }
  


  public static ey a(lp par0ILogAgent, DataInput par1DataInput, boolean par2, Socket par3Socket)
    throws IOException
  {
    boolean flag1 = false;
    ey packet = null;
    int i = par3Socket.getSoTimeout();
    
    int j;
    try
    {
      j = par1DataInput.readUnsignedByte();
      
      if (((par2) && (!c.contains(Integer.valueOf(j)))) || ((!par2) && (!b.contains(Integer.valueOf(j)))))
      {
        throw new IOException("Bad packet id " + j);
      }
      
      packet = a(par0ILogAgent, j);
      
      if (packet == null)
      {
        throw new IOException("Bad packet id " + j);
      }
      
      m = par0ILogAgent;
      
      if ((packet instanceof eg))
      {
        par3Socket.setSoTimeout(1500);
      }
      
      packet.a(par1DataInput);
      o += 1L;
      p += packet.a();
    }
    catch (EOFException eofexception)
    {
      par0ILogAgent.c("Reached end of stream for " + par3Socket.getInetAddress());
      return null;
    }
    
    lt.a(j, packet.a());
    o += 1L;
    p += packet.a();
    par3Socket.setSoTimeout(i);
    return packet;
  }
  


  public static void a(ey par0Packet, DataOutput par1DataOutput)
    throws IOException
  {
    par1DataOutput.write(par0Packet.n());
    par0Packet.a(par1DataOutput);
    q += 1L;
    r += par0Packet.a();
  }
  


  public static void a(String par0Str, DataOutput par1DataOutput)
    throws IOException
  {
    if (par0Str.length() > 32767)
    {
      throw new IOException("String too big");
    }
    

    par1DataOutput.writeShort(par0Str.length());
    par1DataOutput.writeChars(par0Str);
  }
  



  public static String a(DataInput par0DataInput, int par1)
    throws IOException
  {
    short short1 = par0DataInput.readShort();
    
    if (short1 > par1)
    {
      throw new IOException("Received string length longer than maximum allowed (" + short1 + " > " + par1 + ")");
    }
    if (short1 < 0)
    {
      throw new IOException("Received string length is less than zero! Weird string!");
    }
    

    StringBuilder stringbuilder = new StringBuilder();
    
    for (int j = 0; j < short1; j++)
    {
      stringbuilder.append(par0DataInput.readChar());
    }
    
    return stringbuilder.toString();
  }
  



  public abstract void a(DataInput paramDataInput)
    throws IOException;
  



  public abstract void a(DataOutput paramDataOutput)
    throws IOException;
  



  public abstract void a(ez paramEz);
  



  public abstract int a();
  


  public boolean e()
  {
    return false;
  }
  




  public boolean a(ey par1Packet)
  {
    return false;
  }
  




  public boolean a_()
  {
    return false;
  }
  
  public String toString()
  {
    String s = getClass().getSimpleName();
    return s;
  }
  


  public static ye c(DataInput par0DataInput)
    throws IOException
  {
    ye itemstack = null;
    short short1 = par0DataInput.readShort();
    
    if (short1 >= 0)
    {
      byte b0 = par0DataInput.readByte();
      short short2 = par0DataInput.readShort();
      itemstack = new ye(short1, b0, short2);
      e = d(par0DataInput);
    }
    
    return itemstack;
  }
  


  public static void a(ye par0ItemStack, DataOutput par1DataOutput)
    throws IOException
  {
    if (par0ItemStack == null)
    {
      par1DataOutput.writeShort(-1);
    }
    else
    {
      par1DataOutput.writeShort(d);
      par1DataOutput.writeByte(b);
      par1DataOutput.writeShort(par0ItemStack.k());
      by nbttagcompound = null;
      
      if ((par0ItemStack.b().p()) || (par0ItemStack.b().s()))
      {
        nbttagcompound = e;
      }
      
      a(nbttagcompound, par1DataOutput);
    }
  }
  


  public static by d(DataInput par0DataInput)
    throws IOException
  {
    short short1 = par0DataInput.readShort();
    
    if (short1 < 0)
    {
      return null;
    }
    

    byte[] abyte = new byte[short1];
    par0DataInput.readFully(abyte);
    return ci.a(abyte);
  }
  



  protected static void a(by par0NBTTagCompound, DataOutput par1DataOutput)
    throws IOException
  {
    if (par0NBTTagCompound == null)
    {
      par1DataOutput.writeShort(-1);
    }
    else
    {
      byte[] abyte = ci.a(par0NBTTagCompound);
      par1DataOutput.writeShort((short)abyte.length);
      par1DataOutput.write(abyte);
    }
  }
  
  static
  {
    a(0, true, true, ei.class);
    a(1, true, true, ep.class);
    a(2, false, true, dq.class);
    a(3, true, true, dm.class);
    a(4, true, false, fx.class);
    a(5, true, false, fq.class);
    a(6, true, false, fw.class);
    a(7, false, true, eh.class);
    a(8, true, false, fs.class);
    a(9, true, true, fh.class);
    a(10, true, true, eu.class);
    a(11, true, true, ev.class);
    a(12, true, true, ex.class);
    a(13, true, true, ew.class);
    a(14, false, true, fb.class);
    a(15, false, true, gk.class);
    a(16, true, true, fk.class);
    a(17, true, false, ec.class);
    a(18, true, true, dj.class);
    a(19, false, true, fc.class);
    a(20, true, false, di.class);
    a(22, true, false, ga.class);
    a(23, true, false, dd.class);
    a(24, true, false, dg.class);
    a(25, true, false, dh.class);
    a(26, true, false, de.class);
    a(27, false, true, fe.class);
    a(28, true, false, fp.class);
    a(29, true, false, ff.class);
    a(30, true, false, eq.class);
    a(31, true, false, er.class);
    a(32, true, false, et.class);
    a(33, true, false, es.class);
    a(34, true, false, gb.class);
    a(35, true, false, fi.class);
    a(38, true, false, ed.class);
    a(39, true, false, fo.class);
    a(40, true, false, fn.class);
    a(41, true, false, gj.class);
    a(42, true, false, fg.class);
    a(43, true, false, fr.class);
    a(44, true, false, gh.class);
    a(51, true, false, ej.class);
    a(52, true, false, dn.class);
    a(53, true, false, gg.class);
    a(54, true, false, gf.class);
    a(55, true, false, gc.class);
    a(56, true, false, el.class);
    a(60, true, false, ee.class);
    a(61, true, false, em.class);
    a(62, true, false, eo.class);
    a(63, true, false, en.class);
    a(70, true, false, ef.class);
    a(71, true, false, df.class);
    a(100, true, false, dw.class);
    a(101, true, true, dv.class);
    a(102, false, true, du.class);
    a(103, true, false, dz.class);
    a(104, true, false, dx.class);
    a(105, true, false, dy.class);
    a(106, true, true, ds.class);
    a(107, true, true, fl.class);
    a(108, false, true, dt.class);
    a(130, true, true, fz.class);
    a(131, true, true, dr.class);
    a(132, true, false, ge.class);
    a(133, true, false, gd.class);
    a(171, true, false, Packet171EntitySize.class);
    a(172, true, false, Packet172AttachEntitySpecial.class);
    a(200, true, false, dk.class);
    a(201, true, false, fd.class);
    a(202, true, true, fa.class);
    a(203, true, true, dl.class);
    a(204, false, true, dp.class);
    a(205, false, true, do.class);
    a(206, true, false, ft.class);
    a(207, true, false, fv.class);
    a(208, true, false, fm.class);
    a(209, true, false, fu.class);
    a(250, true, true, ea.class);
    a(252, true, true, fy.class);
    a(253, true, false, fj.class);
    a(254, false, true, eg.class);
    a(255, true, true, eb.class);
  }
}
