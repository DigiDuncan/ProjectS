import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import org.lwjgl.opengl.GL11;












@SideOnly(Side.CLIENT)
public class bhv
  extends bhe
{
  private static final bjo a = new bjo("textures/entity/witch.png");
  private final bcj f;
  
  public bhv()
  {
    super(new bcj(0.0F), 0.5F);
    f = ((bcj)i);
  }
  
  public void a(tv par1EntityWitch, double par2, double par4, double par6, float par8, float par9)
  {
    ye itemstack = par1EntityWitch.aZ();
    f.g = (itemstack != null);
    super.a(par1EntityWitch, par2, par4, par6, par8, par9);
  }
  
  protected bjo a(tv par1EntityWitch)
  {
    return a;
  }
  
  protected void a(tv par1EntityWitch, float par2)
  {
    float f1 = 1.0F;
    GL11.glColor3f(f1, f1, f1);
    super.c(par1EntityWitch, par2);
    ye itemstack = par1EntityWitch.aZ();
    
    if (itemstack != null)
    {
      GL11.glPushMatrix();
      

      if (i.s)
      {
        float f2 = 0.5F;
        GL11.glTranslatef(0.0F, 0.625F, 0.0F);
        GL11.glRotatef(-20.0F, -1.0F, 0.0F, 0.0F);
        GL11.glScalef(f2, f2, f2);
      }
      
      f.f.c(0.0625F);
      GL11.glTranslatef(-0.0625F, 0.53125F, 0.21875F);
      
      if ((d < 256) && (bfr.a(aqz.s[d].d())))
      {
        float f2 = 0.5F;
        GL11.glTranslatef(0.0F, 0.1875F, -0.3125F);
        f2 *= 0.75F;
        GL11.glRotatef(20.0F, 1.0F, 0.0F, 0.0F);
        GL11.glRotatef(45.0F, 0.0F, 1.0F, 0.0F);
        GL11.glScalef(f2, -f2, f2);
      }
      else if (d == mcv)
      {
        float f2 = 0.625F;
        GL11.glTranslatef(0.0F, 0.125F, 0.3125F);
        GL11.glRotatef(-20.0F, 0.0F, 1.0F, 0.0F);
        GL11.glScalef(f2, -f2, f2);
        GL11.glRotatef(-100.0F, 1.0F, 0.0F, 0.0F);
        GL11.glRotatef(45.0F, 0.0F, 1.0F, 0.0F);
      }
      else if (yc.g[d].n_())
      {
        float f2 = 0.625F;
        
        if (yc.g[d].o_())
        {
          GL11.glRotatef(180.0F, 0.0F, 0.0F, 1.0F);
          GL11.glTranslatef(0.0F, -0.125F, 0.0F);
        }
        
        b();
        GL11.glScalef(f2, -f2, f2);
        GL11.glRotatef(-100.0F, 1.0F, 0.0F, 0.0F);
        GL11.glRotatef(45.0F, 0.0F, 1.0F, 0.0F);
      }
      else
      {
        float f2 = 0.375F;
        GL11.glTranslatef(0.25F, 0.1875F, -0.1875F);
        GL11.glScalef(f2, f2, f2);
        GL11.glRotatef(60.0F, 0.0F, 0.0F, 1.0F);
        GL11.glRotatef(-90.0F, 1.0F, 0.0F, 0.0F);
        GL11.glRotatef(20.0F, 0.0F, 0.0F, 1.0F);
      }
      
      GL11.glRotatef(-15.0F, 1.0F, 0.0F, 0.0F);
      GL11.glRotatef(40.0F, 0.0F, 0.0F, 1.0F);
      


      float mult = 1.0F / par1EntityWitch.getSizeMultiplierRoot();
      GL11.glScalef(mult, mult, mult);
      b.f.a(par1EntityWitch, itemstack, 0);
      
      if (itemstack.b().b())
      {
        b.f.a(par1EntityWitch, itemstack, 1);
      }
      
      GL11.glPopMatrix();
    }
  }
  
  protected void b()
  {
    GL11.glTranslatef(0.0F, 0.1875F, 0.0F);
  }
  
  protected void b(tv par1EntityWitch, float par2)
  {
    float f1 = 0.9375F;
    GL11.glScalef(f1, f1, f1);
  }
  
  public void a(og par1EntityLiving, double par2, double par4, double par6, float par8, float par9)
  {
    a((tv)par1EntityLiving, par2, par4, par6, par8, par9);
  }
  




  protected void a(of par1EntityLivingBase, float par2)
  {
    b((tv)par1EntityLivingBase, par2);
  }
  
  protected void c(of par1EntityLivingBase, float par2)
  {
    a((tv)par1EntityLivingBase, par2);
  }
  
  public void a(of par1EntityLivingBase, double par2, double par4, double par6, float par8, float par9)
  {
    a((tv)par1EntityLivingBase, par2, par4, par6, par8, par9);
  }
  



  protected bjo a(nn par1Entity)
  {
    return a((tv)par1Entity);
  }
  






  public void a(nn par1Entity, double par2, double par4, double par6, float par8, float par9)
  {
    a((tv)par1Entity, par2, par4, par6, par8, par9);
  }
}
