













public class alg
{
  private acf a;
  private ald b = new ald();
  

  private lm c = new lm();
  

  private ale[] d = new ale[32];
  

  private boolean e;
  

  private boolean f;
  

  private boolean g;
  
  private boolean h;
  

  public alg(acf par1IBlockAccess, boolean par2, boolean par3, boolean par4, boolean par5)
  {
    a = par1IBlockAccess;
    e = par2;
    f = par3;
    g = par4;
    h = par5;
  }
  



  public alf a(nn par1Entity, nn par2Entity, float par3)
  {
    return a(par1Entity, u, E.b, w, par3);
  }
  



  public alf a(nn par1Entity, int par2, int par3, int par4, float par5)
  {
    return a(par1Entity, par2 + 0.5F, par3 + 0.5F, par4 + 0.5F, par5);
  }
  



  private alf a(nn par1Entity, double par2, double par4, double par6, float par8)
  {
    b.a();
    c.c();
    boolean flag = g;
    int i = ls.c(E.b + 0.5D);
    
    if ((h) && (par1Entity.H()))
    {
      i = (int)E.b;
      
      for (int j = a.a(ls.c(u), i, ls.c(w)); (j == FcF) || (j == GcF); j = a.a(ls.c(u), i, ls.c(w)))
      {
        i++;
      }
      
      flag = g;
      g = false;
    }
    else
    {
      i = ls.c(E.b + 0.5D);
    }
    
    ale pathpoint = a(ls.c(E.a), i, ls.c(E.c));
    ale pathpoint1 = a(ls.c(par2 - O / 2.0F), ls.c(par4), ls.c(par6 - O / 2.0F));
    ale pathpoint2 = new ale(ls.d(O + 1.0F), ls.d(P + 1.0F), ls.d(O + 1.0F));
    alf pathentity = a(par1Entity, pathpoint, pathpoint1, pathpoint2, par8);
    g = flag;
    return pathentity;
  }
  



  private alf a(nn par1Entity, ale par2PathPoint, ale par3PathPoint, ale par4PathPoint, float par5)
  {
    e = 0.0F;
    f = par2PathPoint.b(par3PathPoint);
    g = f;
    b.a();
    b.a(par2PathPoint);
    ale pathpoint3 = par2PathPoint;
    
    while (!b.e())
    {
      ale pathpoint4 = b.c();
      
      if (pathpoint4.equals(par3PathPoint))
      {
        return a(par2PathPoint, par3PathPoint);
      }
      
      if (pathpoint4.b(par3PathPoint) < pathpoint3.b(par3PathPoint))
      {
        pathpoint3 = pathpoint4;
      }
      
      i = true;
      int i = b(par1Entity, pathpoint4, par4PathPoint, par3PathPoint, par5);
      
      for (int j = 0; j < i; j++)
      {
        ale pathpoint5 = d[j];
        float f1 = e + pathpoint4.b(pathpoint5);
        
        if ((!pathpoint5.a()) || (f1 < e))
        {
          h = pathpoint4;
          e = f1;
          f = pathpoint5.b(par3PathPoint);
          
          if (pathpoint5.a())
          {
            b.a(pathpoint5, e + f);
          }
          else
          {
            g = (e + f);
            b.a(pathpoint5);
          }
        }
      }
    }
    
    if (pathpoint3 == par2PathPoint)
    {
      return null;
    }
    

    return a(par2PathPoint, pathpoint3);
  }
  





  private int b(nn par1Entity, ale par2PathPoint, ale par3PathPoint, ale par4PathPoint, float par5)
  {
    int i = 0;
    byte b0 = 0;
    
    if (a(par1Entity, a, b + 1, c, par3PathPoint) == 1)
    {
      b0 = 1;
    }
    
    ale pathpoint3 = a(par1Entity, a, b, c + 1, par3PathPoint, b0);
    ale pathpoint4 = a(par1Entity, a - 1, b, c, par3PathPoint, b0);
    ale pathpoint5 = a(par1Entity, a + 1, b, c, par3PathPoint, b0);
    ale pathpoint6 = a(par1Entity, a, b, c - 1, par3PathPoint, b0);
    
    if ((pathpoint3 != null) && (!i) && (pathpoint3.a(par4PathPoint) < par5))
    {
      d[(i++)] = pathpoint3;
    }
    
    if ((pathpoint4 != null) && (!i) && (pathpoint4.a(par4PathPoint) < par5))
    {
      d[(i++)] = pathpoint4;
    }
    
    if ((pathpoint5 != null) && (!i) && (pathpoint5.a(par4PathPoint) < par5))
    {
      d[(i++)] = pathpoint5;
    }
    
    if ((pathpoint6 != null) && (!i) && (pathpoint6.a(par4PathPoint) < par5))
    {
      d[(i++)] = pathpoint6;
    }
    
    return i;
  }
  



  private ale a(nn par1Entity, int par2, int par3, int par4, ale par5PathPoint, int par6)
  {
    ale pathpoint1 = null;
    int i1 = a(par1Entity, par2, par3, par4, par5PathPoint);
    
    if ((i1 == 2) || (i1 == 3))
    {
      return a(par2, par3, par4);
    }
    

    if (i1 == 1)
    {
      pathpoint1 = a(par2, par3, par4);
    }
    
    if ((pathpoint1 == null) && (par6 > 0) && (i1 != -3) && (i1 != -4) && (a(par1Entity, par2, par3 + par6, par4, par5PathPoint) == 1))
    {
      pathpoint1 = a(par2, par3 + par6, par4);
      par3 += par6;
    }
    
    if (pathpoint1 != null)
    {
      int j1 = 0;
      int k1 = 0;
      
      while (par3 > 0)
      {
        k1 = a(par1Entity, par2, par3 - 1, par4, par5PathPoint);
        
        if ((g) && (k1 == -1))
        {
          return null;
        }
        
        if (k1 != 1) {
          break;
        }
        

        if (j1++ >= par1Entity.as())
        {
          return null;
        }
        
        par3--;
        
        if (par3 > 0)
        {
          pathpoint1 = a(par2, par3, par4);
        }
      }
      
      if (k1 == -2)
      {
        return null;
      }
    }
    
    return pathpoint1;
  }
  




  private final ale a(int par1, int par2, int par3)
  {
    int l = ale.a(par1, par2, par3);
    ale pathpoint = (ale)c.a(l);
    
    if (pathpoint == null)
    {
      pathpoint = new ale(par1, par2, par3);
      c.a(l, pathpoint);
    }
    
    return pathpoint;
  }
  





  public int a(nn par1Entity, int par2, int par3, int par4, ale par5PathPoint)
  {
    return a(par1Entity, par2, par3, par4, par5PathPoint, g, f, e);
  }
  
  public static int a(nn par0Entity, int par1, int par2, int par3, ale par4PathPoint, boolean par5, boolean par6, boolean par7)
  {
    boolean flag3 = false;
    
    for (int l = par1; l < par1 + a; l++)
    {
      for (int i1 = par2; i1 < par2 + b; i1++)
      {
        for (int j1 = par3; j1 < par3 + c; j1++)
        {
          int k1 = q.a(l, i1, j1);
          
          if (k1 > 0)
          {
            if (k1 == bpcF)
            {
              flag3 = true;
            }
            else if ((k1 != FcF) && (k1 != GcF))
            {
              if ((!par7) && (k1 == aJcF))
              {
                return 0;
              }
            }
            else
            {
              if (par5)
              {
                return -1;
              }
              
              flag3 = true;
            }
            
            aqz block = aqz.s[k1];
            int l1 = block.d();
            
            if (q.e(l, i1, j1) == 9)
            {
              int i2 = ls.c(u);
              int j2 = ls.c(v);
              int k2 = ls.c(w);
              
              if ((q.e(i2, j2, k2) != 9) && (q.e(i2, j2 - 1, k2) != 9))
              {
                return -3;
              }
            }
            else if ((!block.b(q, l, i1, j1)) && ((!par6) || (k1 != aJcF)))
            {
              if ((l1 == 11) || (l1 == 32))
              {
                if (par0Entity.isTiny())
                {
                  asx bb1 = aqz.be.b(q, l, i1, j1);
                  if ((d - a < 1.0D) || (f - c < 1.0D))
                  {
                    return 3;
                  }
                }
                
                return -3;
              }
              
              if (k1 == bAcF)
              {
                if (par0Entity.isTiny())
                {
                  return P < 0.3125F ? 2 : 3;
                }
                
                return -3;
              }
              
              if (k1 == bpcF)
              {
                return -4;
              }
              
              akc material = cU;
              
              if (material != akc.i)
              {
                if (block.c())
                {
                  return 0;
                }
                
                block.a(q, l, i1, j1);
                
                if ((block instanceof aqp))
                {

                  return P < 0.5F ? 3 : 0;
                }
                if ((k1 == bKcF) && (O < 0.4F))
                {
                  return 3;
                }
                if ((block.v() - block.u() >= 1.0D - O) && (block.z() - block.y() >= 1.0D - O) && (block.x() - block.w() >= 1.0D - P))
                {
                  return 0;
                }
                



                return 3;
              }
              

              if (!par0Entity.J())
              {
                return -2;
              }
            }
            else if ((par0Entity.isTiny()) && (!block.c()) && (block.b(q, l, i1, j1)))
            {
              block.a(q, l, i1, j1);
              if ((block.v() - block.u() >= 1.0D - O) && (block.z() - block.y() >= 1.0D - O) && (block.x() - block.w() >= 1.0D - P))
              {
                return 0;
              }
              
              return 3;
            }
          }
        }
      }
    }
    
    return flag3 ? 2 : 1;
  }
  



  private alf a(ale par1PathPoint, ale par2PathPoint)
  {
    int i = 1;
    

    for (ale pathpoint2 = par2PathPoint; h != null; pathpoint2 = h)
    {
      i++;
    }
    
    ale[] apathpoint = new ale[i];
    pathpoint2 = par2PathPoint;
    i--;
    
    for (apathpoint[i] = par2PathPoint; h != null; apathpoint[i] = pathpoint2)
    {
      pathpoint2 = h;
      i--;
    }
    
    return new alf(apathpoint);
  }
}
