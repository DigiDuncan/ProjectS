import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import java.util.Random;


















public abstract class rp
  extends nk
  implements nl
{
  public int bp;
  private int bq;
  
  public rp(abw par1World)
  {
    super(par1World);
  }
  



  protected void bk()
  {
    if (b() != 0)
    {
      bp = 0;
    }
    
    super.bk();
  }
  




  public void c()
  {
    super.c();
    
    if (b() != 0)
    {
      bp = 0;
    }
    
    if (bp > 0)
    {
      bp -= 1;
      String s = "heart";
      
      if (bp % 10 == 0)
      {
        double d0 = ab.nextGaussian() * 0.02D;
        double d1 = ab.nextGaussian() * 0.02D;
        double d2 = ab.nextGaussian() * 0.02D;
        q.a(s, u + ab.nextFloat() * O * 2.0F - O, v + 0.5D + ab.nextFloat() * P, w + ab.nextFloat() * O * 2.0F - O, d0, d1, d2);
      }
    }
    else
    {
      bq = 0;
    }
  }
  



  protected void a(nn par1Entity, float par2)
  {
    if ((par1Entity instanceof uf))
    {
      if (par2 < 3.0F)
      {
        double d0 = u - u;
        double d1 = w - w;
        A = ((float)(Math.atan2(d1, d0) * 180.0D / 3.141592653589793D) - 90.0F);
        bn = true;
      }
      
      uf entityplayer = (uf)par1Entity;
      
      if ((entityplayer.by() == null) || (!c(entityplayer.by())))
      {
        j = null;
      }
    }
    else if ((par1Entity instanceof rp))
    {
      rp entityanimal = (rp)par1Entity;
      
      if ((b() > 0) && (entityanimal.b() < 0))
      {
        if (par2 < 2.5D)
        {
          bn = true;
        }
      }
      else if ((bp > 0) && (bp > 0))
      {
        if (j == null)
        {
          j = this;
        }
        
        if ((j == this) && (par2 < 3.5D))
        {
          bp += 1;
          bp += 1;
          bq += 1;
          
          if (bq % 4 == 0)
          {
            q.a("heart", u + ab.nextFloat() * O * 2.0F - O, v + 0.5D + ab.nextFloat() * P, w + ab.nextFloat() * O * 2.0F - O, 0.0D, 0.0D, 0.0D);
          }
          
          if (bq == 60)
          {
            b((rp)par1Entity);
          }
        }
        else
        {
          bq = 0;
        }
      }
      else
      {
        bq = 0;
        j = null;
      }
    }
  }
  




  private void b(rp par1EntityAnimal)
  {
    nk entityageable = a(par1EntityAnimal);
    
    if (entityageable != null)
    {
      c(6000);
      par1EntityAnimal.c(6000);
      bp = 0;
      bq = 0;
      j = null;
      j = null;
      bq = 0;
      bp = 0;
      entityageable.c(41536);
      entityageable.b(u, v, w, A, B);
      
      for (int i = 0; i < 7; i++)
      {
        double d0 = ab.nextGaussian() * 0.02D;
        double d1 = ab.nextGaussian() * 0.02D;
        double d2 = ab.nextGaussian() * 0.02D;
        q.a("heart", u + ab.nextFloat() * O * 2.0F - O, v + 0.5D + ab.nextFloat() * P, w + ab.nextFloat() * O * 2.0F - O, d0, d1, d2);
      }
      
      q.d(entityageable);
    }
  }
  



  public boolean a(nb par1DamageSource, float par2)
  {
    if (ar())
    {
      return false;
    }
    

    bo = 60;
    
    if (!bf())
    {
      os attributeinstance = a(tp.d);
      
      if (attributeinstance.a(h) == null)
      {
        attributeinstance.a(i);
      }
    }
    
    j = null;
    bp = 0;
    return super.a(par1DamageSource, par2);
  }
  





  public float a(int par1, int par2, int par3)
  {
    return q.a(par1, par2 - 1, par3) == zcF ? 10.0F : q.q(par1, par2, par3) - 0.5F;
  }
  



  public void b(by par1NBTTagCompound)
  {
    super.b(par1NBTTagCompound);
    par1NBTTagCompound.a("InLove", bp);
  }
  



  public void a(by par1NBTTagCompound)
  {
    super.a(par1NBTTagCompound);
    bp = par1NBTTagCompound.e("InLove");
  }
  




  protected nn bL()
  {
    if (bo > 0)
    {
      return null;
    }
    

    float f = 8.0F * getSizeMultiplierRoot();
    



    if (bp > 0)
    {
      List list = q.a(getClass(), E.b(f, f, f));
      
      for (int i = 0; i < list.size(); i++)
      {
        rp entityanimal = (rp)list.get(i);
        
        if ((entityanimal != this) && (bp > 0))
        {
          return entityanimal;
        }
      }
    }
    if (b() == 0)
    {
      List list = q.a(uf.class, E.b(f, f, f));
      
      for (int i = 0; i < list.size(); i++)
      {
        uf entityplayer = (uf)list.get(i);
        
        if ((entityplayer.by() != null) && (c(entityplayer.by())))
        {
          return entityplayer;
        }
      }
    }
    if (b() > 0)
    {
      List list = q.a(getClass(), E.b(f, f, f));
      
      for (int i = 0; i < list.size(); i++)
      {
        rp entityanimal = (rp)list.get(i);
        
        if ((entityanimal != this) && (entityanimal.b() < 0))
        {
          return entityanimal;
        }
      }
    }
    
    return null;
  }
  




  public boolean bs()
  {
    int i = ls.c(u);
    int j = ls.c(E.b);
    int k = ls.c(w);
    return (q.a(i, j - 1, k) == zcF) && (q.m(i, j, k) > 8) && (super.bs());
  }
  



  public int o()
  {
    return 120;
  }
  



  protected boolean t()
  {
    return false;
  }
  




  protected int e(uf par1EntityPlayer)
  {
    return 1 + q.s.nextInt((int)(2.0F * getSizeMultiplier()) + 1);
  }
  




  public boolean c(ye par1ItemStack)
  {
    return d == Vcv;
  }
  



  public boolean a(uf par1EntityPlayer)
  {
    ye itemstack = bn.h();
    
    if ((itemstack != null) && (c(itemstack)) && (b() == 0) && (bp <= 0))
    {
      if (!bG.d)
      {
        b -= 1;
        
        if (b <= 0)
        {
          bn.a(bn.c, (ye)null);
        }
      }
      
      bX();
      return true;
    }
    

    return super.a(par1EntityPlayer);
  }
  

  public void bX()
  {
    bp = 600;
    j = null;
    q.a(this, (byte)18);
  }
  



  public double Y()
  {
    if (!g_())
    {
      return P * 0.75D;
    }
    

    return P * 0.52D;
  }
  




  public asx getEntityCollisionBox()
  {
    asx bb = E.c();
    b += P * 0.4D;
    return bb;
  }
  



  public asx getEntityHitBox()
  {
    asx bb = E.c();
    b += P * 0.4D;
    return bb;
  }
  



  public boolean bY()
  {
    return bp > 0;
  }
  
  public void bZ()
  {
    bp = 0;
  }
  



  public boolean a(rp par1EntityAnimal)
  {
    return par1EntityAnimal != this;
  }
  
  @SideOnly(Side.CLIENT)
  public void a(byte par1)
  {
    if (par1 == 18)
    {
      for (int i = 0; i < 7; i++)
      {
        double d0 = ab.nextGaussian() * 0.02D;
        double d1 = ab.nextGaussian() * 0.02D;
        double d2 = ab.nextGaussian() * 0.02D;
        q.a("heart", u + ab.nextFloat() * O * 2.0F - O, v + 0.5D + ab.nextFloat() * P, w + ab.nextFloat() * O * 2.0F - O, d0, d1, d2);
      }
      
    }
    else {
      super.a(par1);
    }
  }
}
