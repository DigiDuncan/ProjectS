import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import gulliver.common.GulliverOMHelper;
import java.util.Iterator;
import java.util.List;
import java.util.Random;



















public class anb
  extends anw
{
  public static final int[][] a = { { 0, 1 }, { -1, 0 }, { 0, -1 }, { 1, 0 } };
  @SideOnly(Side.CLIENT)
  private ms[] b;
  @SideOnly(Side.CLIENT)
  private ms[] c;
  @SideOnly(Side.CLIENT)
  private ms[] d;
  
  public anb(int par1)
  {
    super(par1, akc.n);
    q();
  }
  



  public boolean a(abw par1World, int par2, int par3, int par4, uf par5EntityPlayer, int par6, float par7, float par8, float par9)
  {
    if ((I) || (q.I))
    {
      return true;
    }
    

    int i1 = par1World.h(par2, par3, par4);
    int i2 = i1;
    
    if (!f_(i1))
    {
      int j1 = j(i1);
      par2 += a[j1][0];
      par4 += a[j1][1];
      
      if (par1World.a(par2, par3, par4) != cF)
      {
        return true;
      }
      
      i1 = par1World.h(par2, par3, par4);
    }
    else
    {
      int j = j(i1);
      i2 = par1World.h(par2 - a[j][0], par3, par4 - a[j][1]);
    }
    
    if ((t.e()) && (par1World.a(par2, par4) != acq.j))
    {
      if ((c(i1)) || (c(i2)))
      {
        int j2 = j(i2);
        uf entityplayer1 = null;
        uf entityplayer2 = null;
        Iterator iterator = h.iterator();
        
        while (iterator.hasNext())
        {
          uf entityplayer3 = (uf)iterator.next();
          
          if (entityplayer3.bh())
          {
            t chunkcoordinates = bD;
            
            if ((a == par2) && (b == par3) && (c == par4))
            {
              entityplayer1 = entityplayer3;
            }
            else if ((a == par2 - a[j2][0]) && (b == par3) && (c == par4 - a[j2][1]))
            {
              entityplayer2 = entityplayer3;
            }
          }
        }
        
        if (entityplayer1 == null)
        {
          a(par1World, par2, par3, par4, false);
          
          if ((entityplayer2 != null) && (par5EntityPlayer.getSizeMultiplier() > 0.5F))
          {
            entityplayer2.a(true, true, false);
          }
        }
        else
        {
          float sizemult = par5EntityPlayer.getSizeMultiplier();
          
          if ((sizemult <= 1.5F) && (sizemult > entityplayer1.getSizeMultiplier() * 2.0F))
          {

            entityplayer1.a(true, true, false);
            

            if ((entityplayer2 != null) && (sizemult > 0.5F))
            {
              entityplayer2.a(true, true, false);
            }
          }
          else {
            if ((entityplayer1.getSizeMultiplier() > 0.5F) || (sizemult > 0.5F))
            {
              par5EntityPlayer.a("tile.bed.occupied");
              return true;
            }
            

            if (entityplayer2 != null)
            {
              if (sizemult <= entityplayer2.getSizeMultiplier() * 2.0F)
              {
                par5EntityPlayer.a("tile.bed.occupied");
                return true;
              }
              

              entityplayer2.a(true, true, false);
            }
            



            par2 -= a[j2][0];
            par4 -= a[j2][1];
            
            if (par1World.a(par2, par3, par4) != cF)
            {
              par5EntityPlayer.a("tile.bed.occupied");
              return true;
            }
          }
        }
      }
      
      ug enumstatus = !GulliverOMHelper.isLittleBlocksWorld(par1World) ? par5EntityPlayer.a(par2, par3, par4) : par5EntityPlayer.sleepInSizedBedAt(par1World, par2, par3, par4);
      
      if (enumstatus == ug.a)
      {
        a(par1World, par2, par3, par4, true);
        return true;
      }
      

      if (enumstatus == ug.c)
      {
        par5EntityPlayer.a("tile.bed.noSleep");
      }
      else if (enumstatus == ug.f)
      {
        par5EntityPlayer.a("tile.bed.notSafe");
      }
      
      return true;
    }
    


    double d0 = par2 + 0.5D;
    double d1 = par3 + 0.5D;
    double d2 = par4 + 0.5D;
    par1World.i(par2, par3, par4);
    int k1 = j(i1);
    par2 += a[k1][0];
    par4 += a[k1][1];
    
    if (par1World.a(par2, par3, par4) == cF)
    {
      par1World.i(par2, par3, par4);
      d0 = (d0 + par2 + 0.5D) / 2.0D;
      d1 = (d1 + par3 + 0.5D) / 2.0D;
      d2 = (d2 + par4 + 0.5D) / 2.0D;
    }
    
    par1World.a((nn)null, par2 + 0.5F, par3 + 0.5F, par4 + 0.5F, 5.0F, true, true);
    return true;
  }
  






  @SideOnly(Side.CLIENT)
  public ms a(int par1, int par2)
  {
    if (par1 == 0)
    {
      return aqz.C.m(par1);
    }
    

    int k = j(par2);
    int l = r.i[k][par1];
    int i1 = f_(par2) ? 1 : 0;
    return ((i1 != 1) || (l != 2)) && ((i1 != 0) || (l != 3)) ? c[i1] : (l != 5) && (l != 4) ? d[i1] : b[i1];
  }
  






  @SideOnly(Side.CLIENT)
  public void a(mt par1IconRegister)
  {
    d = new ms[] { par1IconRegister.a(E() + "_feet_top"), par1IconRegister.a(E() + "_head_top") };
    b = new ms[] { par1IconRegister.a(E() + "_feet_end"), par1IconRegister.a(E() + "_head_end") };
    c = new ms[] { par1IconRegister.a(E() + "_feet_side"), par1IconRegister.a(E() + "_head_side") };
  }
  



  public int d()
  {
    return 14;
  }
  



  public boolean b()
  {
    return false;
  }
  




  public boolean c()
  {
    return false;
  }
  




  public ata a(abw par1World, int par2, int par3, int par4, atc par5Vec3, atc par6Vec3)
  {
    a(0.0F, 0.1875F, 0.0F, 1.0F, 0.5625F, 1.0F);
    ata var1 = super.a(par1World, par2, par3, par4, par5Vec3, par6Vec3);
    q();
    return var1;
  }
  




  public asx b(abw par1World, int par2, int par3, int par4)
  {
    return asx.a().a(par2, par3 + 0.1875F, par4, par2 + 1, par3 + 0.5625F, par4 + 1);
  }
  



  public void a(acf par1IBlockAccess, int par2, int par3, int par4)
  {
    q();
  }
  




  public void a(abw par1World, int par2, int par3, int par4, int par5)
  {
    int i1 = par1World.h(par2, par3, par4);
    int j1 = j(i1);
    
    if (f_(i1))
    {
      if (par1World.a(par2 - a[j1][0], par3, par4 - a[j1][1]) != cF)
      {
        par1World.i(par2, par3, par4);
      }
    }
    else if (par1World.a(par2 + a[j1][0], par3, par4 + a[j1][1]) != cF)
    {
      par1World.i(par2, par3, par4);
      
      if (!I)
      {
        c(par1World, par2, par3, par4, i1, 0);
      }
    }
  }
  



  public int a(int par1, Random par2Random, int par3)
  {
    return f_(par1) ? 0 : bccv;
  }
  



  private void q()
  {
    a(0.0F, 0.0F, 0.0F, 1.0F, 0.5625F, 1.0F);
  }
  



  public static boolean f_(int par0)
  {
    return (par0 & 0x8) != 0;
  }
  



  public static boolean c(int par0)
  {
    return (par0 & 0x4) != 0;
  }
  



  public static void a(abw par0World, int par1, int par2, int par3, boolean par4)
  {
    int l = par0World.h(par1, par2, par3);
    
    if (par4)
    {
      l |= 0x4;
    }
    else
    {
      l &= 0xFFFFFFFB;
    }
    
    par0World.b(par1, par2, par3, l, 4);
  }
  



  public static t b(abw par0World, int par1, int par2, int par3, int par4)
  {
    int i1 = par0World.h(par1, par2, par3);
    int j1 = anw.j(i1);
    
    for (int k1 = 0; k1 <= 1; k1++)
    {
      int l1 = par1 - a[j1][0] * k1 - 1;
      int i2 = par3 - a[j1][1] * k1 - 1;
      int j2 = l1 + 2;
      int k2 = i2 + 2;
      
      for (int l2 = l1; l2 <= j2; l2++)
      {
        for (int i3 = i2; i3 <= k2; i3++)
        {
          if ((par0World.w(l2, par2 - 1, i3)) && (!par0World.g(l2, par2, i3).k()) && (!par0World.g(l2, par2 + 1, i3).k()))
          {
            if (par4 <= 0)
            {
              return new t(l2, par2, i3);
            }
            
            par4--;
          }
        }
      }
    }
    
    return null;
  }
  



  public void a(abw par1World, int par2, int par3, int par4, int par5, float par6, int par7)
  {
    if (!f_(par5))
    {
      super.a(par1World, par2, par3, par4, par5, par6, 0);
    }
  }
  




  public int h()
  {
    return 1;
  }
  




  @SideOnly(Side.CLIENT)
  public int d(abw par1World, int par2, int par3, int par4)
  {
    return bccv;
  }
  



  public void a(abw par1World, int par2, int par3, int par4, int par5, uf par6EntityPlayer)
  {
    if ((bG.d) && (f_(par5)))
    {
      int i1 = j(par5);
      par2 -= a[i1][0];
      par4 -= a[i1][1];
      
      if (par1World.a(par2, par3, par4) == cF)
      {
        par1World.i(par2, par3, par4);
      }
    }
  }
}
