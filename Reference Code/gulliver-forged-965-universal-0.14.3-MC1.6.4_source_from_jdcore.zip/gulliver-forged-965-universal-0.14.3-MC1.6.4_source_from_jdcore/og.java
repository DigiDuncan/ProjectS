import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import gulliver.common.GulliverEnvoy;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.UUID;
import net.minecraftforge.common.ForgeHooks;
import net.minecraftforge.event.Event.Result;
import net.minecraftforge.event.ForgeEventFactory;







































public abstract class og
  extends of
{
  public int a_;
  public int b;
  private pe h;
  private pf i;
  private pd j;
  private pb bn;
  private rf bo;
  public final pt c;
  public final pt d;
  private of bp;
  private rg bq;
  private ye[] br = new ye[5];
  

  protected float[] e = new float[5];
  

  private boolean bs;
  
  private boolean bt;
  
  protected float f;
  
  private nn bu;
  
  protected int g;
  
  private boolean bv;
  
  private nn bw;
  
  private by bx;
  
  protected float minTargetSize;
  
  protected float maxTargetSize;
  
  public float minLookSize;
  
  public float maxLookSize;
  

  public float getMinTargetSize()
  {
    return minTargetSize;
  }
  
  public float getMaxTargetSize()
  {
    return maxTargetSize;
  }
  
  public og(abw par1World)
  {
    super(par1World);
    minLookSize = (this.minTargetSize = 0.3F);
    

    if (GulliverEnvoy.isArthropod(this))
    {
      minLookSize = (this.minTargetSize = 0.1F);
    }
    
    maxLookSize = (this.maxTargetSize = 20.0F);
    c = new pt((par1World != null) && (C != null) ? C : null);
    d = new pt((par1World != null) && (C != null) ? C : null);
    h = new pe(this);
    this.i = new pf(this);
    j = new pd(this);
    bn = new pb(this);
    bo = new rf(this, par1World);
    bq = new rg(this);
    
    for (int i = 0; i < e.length; i++)
    {
      e[i] = 0.085F;
    }
  }
  
  protected void az()
  {
    super.az();
    aX().b(tp.b).a(16.0D);
  }
  
  public pe h()
  {
    return h;
  }
  
  public pf i()
  {
    return i;
  }
  
  public pd j()
  {
    return j;
  }
  
  public rf k()
  {
    return bo;
  }
  



  public rg l()
  {
    return bq;
  }
  



  public of m()
  {
    return bp;
  }
  



  public void d(of par1EntityLivingBase)
  {
    bp = par1EntityLivingBase;
    ForgeHooks.onLivingSetAttackTarget(this, par1EntityLivingBase);
  }
  



  public boolean a(Class par1Class)
  {
    return (tf.class != par1Class) && (tj.class != par1Class);
  }
  


  public void n() {}
  


  protected void a()
  {
    super.a();
    ah.a(11, Byte.valueOf((byte)0));
    ah.a(10, "");
  }
  



  public int o()
  {
    return 80;
  }
  



  public void p()
  {
    String s = r();
    
    if (s != null)
    {
      a(s, ba(), bb());
    }
  }
  



  public void y()
  {
    super.y();
    q.C.a("mobBaseTick");
    
    if ((T()) && (ab.nextInt(1000) < a_++))
    {
      a_ = (-o());
      p();
    }
    
    q.C.b();
  }
  



  protected int e(uf par1EntityPlayer)
  {
    if (b > 0)
    {


      float f = par1EntityPlayer == null ? 1.0F : par1EntityPlayer.getSizeMultiplier();
      int i = b;
      ye[] aitemstack = ae();
      
      for (int j = 0; j < aitemstack.length; j++)
      {
        if ((aitemstack[j] != null) && (e[j] <= 1.0F))
        {
          i += 1 + ab.nextInt(3);
        }
      }
      
      return (int)(i * getSizeMultiplier() / f);
    }
    

    return b;
  }
  




  public void q()
  {
    int pcnt = (int)(20.0F * getSizeMultiplierRoot());
    for (int i = 0; i < pcnt; i++)
    {
      double d0 = ab.nextGaussian() * 0.02D;
      double d1 = ab.nextGaussian() * 0.02D;
      double d2 = ab.nextGaussian() * 0.02D;
      double d3 = 10.0D;
      q.a("explode", u + ab.nextFloat() * O * 2.0F - O - d0 * d3, v + ab.nextFloat() * P - d1 * d3, w + ab.nextFloat() * O * 2.0F - O - d2 * d3, d0, d1, d2);
    }
  }
  



  public void l_()
  {
    super.l_();
    
    if (!q.I)
    {
      bF();
    }
  }
  
  protected float f(float par1, float par2)
  {
    if (bf())
    {
      bn.a();
      return par2;
    }
    

    return super.f(par1, par2);
  }
  




  protected String r()
  {
    return null;
  }
  



  protected int s()
  {
    return 0;
  }
  



  protected int getMeatItemId()
  {
    return 0;
  }
  



  protected int getCookedMeatItemId()
  {
    return 0;
  }
  




  protected void b(boolean par1, int par2)
  {
    int id = s();
    dropItemSizedAmount(par2, id, 0, 3);
    id = (af()) && (getCookedMeatItemId() > 0) ? getCookedMeatItemId() : getMeatItemId();
    dropItemSizedAmount(par2, id, 1, 3);
  }
  
  protected void dropItemSizedAmount(int nloot, int id, int nmin, int nchance)
  {
    if (id > 0)
    {

      int k = 0;
      
      if (nloot > 0)
      {
        k += ab.nextInt(nloot + (int)getSizeMultiplierRoot());
      }
      
      if (nchance > 0)
      {
        float chance = nchance * getSizeMultiplierRoot();
        
        if (chance < 2.0F)
        {
          k += (ab.nextFloat() < chance / 2.0F ? 1 : 0);
        }
        else
        {
          k += ab.nextInt((int)chance);
        }
      }
      
      if (nmin < 0)
      {
        k += nmin;
      }
      else if ((nmin > 0) && (!isTiny()))
      {
        int n = (int)(nmin * getSizeMultiplierRoot());
        k += (n > 0 ? n : 1);
      }
      
      for (int l = 0; l < k; l++)
      {
        b(id, 1);
      }
    }
  }
  



  public void b(by par1NBTTagCompound)
  {
    super.b(par1NBTTagCompound);
    par1NBTTagCompound.a("CanPickUpLoot", bD());
    par1NBTTagCompound.a("PersistenceRequired", bt);
    cg nbttaglist = new cg();
    

    for (int i = 0; i < br.length; i++)
    {
      by nbttagcompound1 = new by();
      
      if (br[i] != null)
      {
        br[i].b(nbttagcompound1);
      }
      
      nbttaglist.a(nbttagcompound1);
    }
    
    par1NBTTagCompound.a("Equipment", nbttaglist);
    cg nbttaglist1 = new cg();
    
    for (int j = 0; j < e.length; j++)
    {
      nbttaglist1.a(new cd(j + "", e[j]));
    }
    
    par1NBTTagCompound.a("DropChances", nbttaglist1);
    par1NBTTagCompound.a("CustomName", bA());
    par1NBTTagCompound.a("CustomNameVisible", bC());
    par1NBTTagCompound.a("Leashed", bv);
    
    if (bw != null)
    {
      by nbttagcompound1 = new by("Leash");
      
      if ((bw instanceof of))
      {
        nbttagcompound1.a("UUIDMost", bw.aw().getMostSignificantBits());
        nbttagcompound1.a("UUIDLeast", bw.aw().getLeastSignificantBits());
      }
      else if ((bw instanceof oc))
      {
        oc entityhanging = (oc)bw;
        nbttagcompound1.a("X", b);
        nbttagcompound1.a("Y", c);
        nbttagcompound1.a("Z", d);
      }
      
      par1NBTTagCompound.a("Leash", nbttagcompound1);
    }
  }
  



  public void a(by par1NBTTagCompound)
  {
    super.a(par1NBTTagCompound);
    h(par1NBTTagCompound.n("CanPickUpLoot"));
    bt = par1NBTTagCompound.n("PersistenceRequired");
    
    if ((par1NBTTagCompound.b("CustomName")) && (par1NBTTagCompound.i("CustomName").length() > 0))
    {
      a(par1NBTTagCompound.i("CustomName"));
    }
    
    g(par1NBTTagCompound.n("CustomNameVisible"));
    


    if (par1NBTTagCompound.b("Equipment"))
    {
      cg nbttaglist = par1NBTTagCompound.m("Equipment");
      
      for (int i = 0; i < br.length; i++)
      {
        br[i] = ye.a((by)nbttaglist.b(i));
      }
    }
    
    if (par1NBTTagCompound.b("DropChances"))
    {
      cg nbttaglist = par1NBTTagCompound.m("DropChances");
      
      for (int i = 0; i < nbttaglist.c(); i++)
      {
        e[i] = ba;
      }
    }
    
    bv = par1NBTTagCompound.n("Leashed");
    
    if ((bv) && (par1NBTTagCompound.b("Leash")))
    {
      bx = par1NBTTagCompound.l("Leash");
    }
  }
  
  public void n(float par1)
  {
    bf = par1;
  }
  



  public void i(float par1)
  {
    super.i(par1);
    n(par1);
  }
  




  public void c()
  {
    super.c();
    q.C.a("looting");
    

    for (int j = 1; j < 5; j++)
    {
      if (cannotEquipItemOrArmor(j, n(j)))
      {
        ye stack = n(j);
        if (q.O().b("doMobLoot"))
        {
          if ((isHuge()) && ((stack.b() instanceof wh)))
          {
            stack.a(1, this);
          }
          dropItemAtRandom(stack);
        }
        c(j, null);
      }
    }
    
    if ((!q.I) && (bD()) && (!aU) && (q.O().b("mobGriefing")))
    {
      List list = q.a(ss.class, E.b(1.0D, 0.0D, 1.0D));
      Iterator iterator = list.iterator();
      
      while (iterator.hasNext())
      {
        ss entityitem = (ss)iterator.next();
        
        if ((!M) && (entityitem.d() != null))
        {
          ye itemstack = entityitem.d();
          int i = b(itemstack);
          
          if (i > -1)
          {
            boolean flag = true;
            ye itemstack1 = n(i);
            
            if (itemstack1 != null)
            {
              if (i == 0)
              {
                if (((itemstack.b() instanceof zl)) && (!(itemstack1.b() instanceof zl)))
                {
                  flag = true;
                }
                else if (((itemstack.b() instanceof zl)) && ((itemstack1.b() instanceof zl)))
                {
                  zl itemsword = (zl)itemstack.b();
                  zl itemsword1 = (zl)itemstack1.b();
                  
                  if (itemsword.g() == itemsword1.g())
                  {
                    flag = (itemstack.k() > itemstack1.k()) || ((itemstack.p()) && (!itemstack1.p()));
                  }
                  else
                  {
                    flag = itemsword.g() > itemsword1.g();
                  }
                }
                else
                {
                  flag = false;
                }
              }
              else if (((itemstack.b() instanceof wh)) && (!(itemstack1.b() instanceof wh)))
              {
                flag = true;
              }
              else if (((itemstack.b() instanceof wh)) && ((itemstack1.b() instanceof wh)))
              {
                wh itemarmor = (wh)itemstack.b();
                wh itemarmor1 = (wh)itemstack1.b();
                
                if (c == c)
                {
                  flag = (itemstack.k() > itemstack1.k()) || ((itemstack.p()) && (!itemstack1.p()));
                }
                else
                {
                  flag = c > c;
                }
              }
              else
              {
                flag = false;
              }
            }
            
            if ((flag) && ((i == 0) || (!cannotEquipItemOrArmor(i, itemstack))))
            {
              if ((itemstack1 != null) && (ab.nextFloat() - 0.1F < e[i]))
              {
                a(itemstack1, 0.0F);
              }
              
              c(i, itemstack);
              e[i] = 2.0F;
              bt = true;
              a(entityitem, 1);
              entityitem.x();
            }
          }
        }
      }
    }
    
    q.C.b();
  }
  



  protected boolean bf()
  {
    return false;
  }
  



  protected boolean t()
  {
    return true;
  }
  



  protected void u()
  {
    Event.Result result = null;
    if (bt)
    {
      aV = 0;
    }
    else if (((aV & 0x1F) == 31) && ((result = ForgeEventFactory.canEntityDespawn(this)) != Event.Result.DEFAULT))
    {
      if (result == Event.Result.DENY)
      {
        aV = 0;
      }
      else
      {
        x();
      }
    }
    else
    {
      uf entityplayer = q.a(this, -1.0D);
      
      if (entityplayer != null)
      {
        double d0 = u - u;
        double d1 = v - v;
        double d2 = w - w;
        double d3 = d0 * d0 + d1 * d1 + d2 * d2;
        
        if ((t()) && (d3 > 16384.0D * (getRangeMultiplier() * getRangeMultiplier())))
        {
          x();
        }
        double rangesq = 1024.0D * (getRangeMultiplier() * getRangeMultiplier());
        
        if ((aV > 600) && (ab.nextInt(800) == 0) && (d3 > rangesq) && (t()))
        {
          x();
        }
        else if (d3 < rangesq)
        {
          aV = 0;
        }
      }
    }
  }
  
  protected void bi()
  {
    aV += 1;
    q.C.a("checkDespawn");
    u();
    q.C.b();
    q.C.a("sensing");
    bq.a();
    q.C.b();
    q.C.a("targetSelector");
    d.a();
    q.C.b();
    q.C.a("goalSelector");
    c.a();
    q.C.b();
    q.C.a("navigation");
    bo.f();
    q.C.b();
    q.C.a("mob tick");
    bk();
    q.C.b();
    q.C.a("controls");
    q.C.a("move");
    i.c();
    q.C.c("look");
    h.a();
    q.C.c("jump");
    j.b();
    q.C.b();
    q.C.b();
  }
  
  protected void bl()
  {
    super.bl();
    be = 0.0F;
    bf = 0.0F;
    u();
    float f = 8.0F * getSizeMultiplier();
    
    if (ab.nextFloat() < 0.02F)
    {
      uf entityplayer = q.getClosestVisibleSizedPlayerToEntity(this, f, minLookSize, maxLookSize);
      
      if (entityplayer != null)
      {
        bu = entityplayer;
        g = (10 + ab.nextInt(20));
      }
      else
      {
        bg = ((ab.nextFloat() - 0.5F) * 20.0F);
      }
    }
    
    if (bu != null)
    {
      a(bu, 10.0F, bp());
      
      if ((g-- <= 0) || (bu.M) || (bu.e(this) > f * f))
      {
        bu = null;
      }
    }
    else
    {
      if (ab.nextFloat() < 0.05F)
      {
        bg = ((ab.nextFloat() - 0.5F) * 20.0F);
      }
      
      A += bg;
      B = this.f;
    }
    
    boolean flag = H();
    boolean flag1 = J();
    
    if ((flag) || (flag1))
    {
      bd = (ab.nextFloat() < 0.8F);
    }
  }
  




  public int bp()
  {
    return 40;
  }
  



  public void a(nn par1Entity, float par2, float par3)
  {
    double d0 = u - u;
    double d1 = w - w;
    double d2;
    double d2;
    if ((par1Entity instanceof of))
    {
      of entitylivingbase = (of)par1Entity;
      d2 = v + entitylivingbase.f() - (v + f());
    }
    else
    {
      d2 = (E.b + E.e) / 2.0D - (v + f());
    }
    
    double d3 = ls.a(d0 * d0 + d1 * d1);
    float f2 = (float)(Math.atan2(d1, d0) * 180.0D / 3.141592653589793D) - 90.0F;
    float f3 = (float)-(Math.atan2(d2, d3) * 180.0D / 3.141592653589793D);
    B = b(B, f3, par3);
    A = b(A, f2, par2);
  }
  



  private float b(float par1, float par2, float par3)
  {
    float f3 = ls.g(par2 - par1);
    
    if (f3 > par3)
    {
      f3 = par3;
    }
    
    if (f3 < -par3)
    {
      f3 = -par3;
    }
    
    return par1 + f3;
  }
  



  public boolean bs()
  {
    return (q.b(E)) && (q.a(this, E).isEmpty()) && (!q.d(E));
  }
  



  public float bt()
  {
    return 1.0F * getSizeMultiplier();
  }
  



  public int bv()
  {
    return 4;
  }
  



  public int as()
  {
    if (m() == null)
    {
      return 3;
    }
    

    int i = (int)(aN() - aT() * 0.33F);
    i -= (3 - q.r) * 4;
    
    if (i < 0)
    {
      i = 0;
    }
    
    return i + 3;
  }
  




  public ye aZ()
  {
    return br[0];
  }
  



  public ye n(int par1)
  {
    return br[par1];
  }
  
  public ye o(int par1)
  {
    return br[(par1 + 1)];
  }
  



  public void c(int par1, ye par2ItemStack)
  {
    br[par1] = par2ItemStack;
  }
  
  public ye[] ae()
  {
    return br;
  }
  



  protected void a(boolean par1, int par2)
  {
    for (int j = 0; j < ae().length; j++)
    {
      ye itemstack = n(j);
      boolean flag1 = e[j] > 1.0F;
      
      if ((itemstack != null) && ((par1) || (flag1)) && (ab.nextFloat() - par2 * 0.01F < e[j]))
      {
        if ((!flag1) && (itemstack.g()))
        {
          int k = Math.max(itemstack.l() - 25, 1);
          int l = itemstack.l() - ab.nextInt(ab.nextInt(k) + 1);
          
          if (l > k)
          {
            l = k;
          }
          
          if (l < 1)
          {
            l = 1;
          }
          
          itemstack.b(l);
        }
        
        a(itemstack, 0.0F);
      }
    }
  }
  

  public ss dropItemAtRandom(ye par1ItemStack)
  {
    if (par1ItemStack == null)
    {
      return null;
    }
    

    ss var3 = new ss(q, u, v - 0.30000001192092896D * getSizeMultiplier() + f(), w, par1ItemStack);
    var3.setSizeMultiplier(getSizeMultiplierRoot());
    var3.a(0.25F * var3.getSizeMultiplier(), 0.25F * var3.getSizeMultiplier());
    N = (P / 2.0F);
    b = 40;
    float var4 = 0.1F;
    


    float var5 = ab.nextFloat() * 0.5F * getSizeMultiplierRoot();
    float var6 = ab.nextFloat() * 3.1415927F * 2.0F;
    x = (-ls.a(var6) * var5);
    z = (ls.b(var6) * var5);
    y = (0.20000000298023224D * (getSizeMultiplier() >= 1.0F ? 1.0D : getSizeMultiplier()));
    
    q.d(var3);
    return var3;
  }
  




  protected void bw()
  {
    if (ab.nextFloat() < 0.15F * q.b(u, v, w))
    {
      int i = ab.nextInt(2);
      float f = q.r == 3 ? 0.1F : 0.25F;
      
      if (ab.nextFloat() < 0.095F)
      {
        i++;
      }
      
      if (ab.nextFloat() < 0.095F)
      {
        i++;
      }
      
      if (ab.nextFloat() < 0.095F)
      {
        i++;
      }
      
      for (int j = 3; j >= 0; j--)
      {
        ye itemstack = o(j);
        
        if ((j < 3) && (ab.nextFloat() < f)) {
          break;
        }
        

        if (itemstack == null)
        {
          yc item = a(j + 1, i);
          
          if (item != null)
          {
            c(j + 1, new ye(item));
          }
        }
      }
    }
  }
  
  public static int b(ye par0ItemStack)
  {
    if ((d != bfcF) && (d != bScv))
    {
      if ((par0ItemStack.b() instanceof wh))
      {
        switch (bb)
        {
        case 0: 
          return 4;
        case 1: 
          return 3;
        case 2: 
          return 2;
        case 3: 
          return 1;
        }
        
      }
      return 0;
    }
    

    return 4;
  }
  




  public static yc a(int par0, int par1)
  {
    switch (par0)
    {
    case 4: 
      if (par1 == 0)
      {
        return yc.X;
      }
      if (par1 == 1)
      {
        return yc.an;
      }
      if (par1 == 2)
      {
        return yc.ab;
      }
      if (par1 == 3)
      {
        return yc.af;
      }
      if (par1 == 4)
      {
        return yc.aj;
      }
    case 3: 
      if (par1 == 0)
      {
        return yc.Y;
      }
      if (par1 == 1)
      {
        return yc.ao;
      }
      if (par1 == 2)
      {
        return yc.ac;
      }
      if (par1 == 3)
      {
        return yc.ag;
      }
      if (par1 == 4)
      {
        return yc.ak;
      }
    case 2: 
      if (par1 == 0)
      {
        return yc.Z;
      }
      if (par1 == 1)
      {
        return yc.ap;
      }
      if (par1 == 2)
      {
        return yc.ad;
      }
      if (par1 == 3)
      {
        return yc.ah;
      }
      if (par1 == 4)
      {
        return yc.al;
      }
    case 1: 
      if (par1 == 0)
      {
        return yc.aa;
      }
      if (par1 == 1)
      {
        return yc.aq;
      }
      if (par1 == 2)
      {
        return yc.ae;
      }
      if (par1 == 3)
      {
        return yc.ai;
      }
      if (par1 == 4)
      {
        return yc.am; }
      break;
    }
    return null;
  }
  




  protected void bx()
  {
    float f = q.b(u, v, w);
    
    if ((aZ() != null) && (ab.nextFloat() < 0.25F * f))
    {
      aaw.a(ab, aZ(), (int)(5.0F + f * ab.nextInt(18)));
    }
    
    for (int i = 0; i < 4; i++)
    {
      ye itemstack = o(i);
      
      if ((itemstack != null) && (ab.nextFloat() < 0.5F * f))
      {
        aaw.a(ab, itemstack, (int)(5.0F + f * ab.nextInt(18)));
      }
    }
  }
  
  public oi a(oi par1EntityLivingData)
  {
    a(tp.b).a(new ot("Random spawn bonus", ab.nextGaussian() * 0.05D, 1));
    return par1EntityLivingData;
  }
  




  public boolean by()
  {
    return false;
  }
  



  public String an()
  {
    return bB() ? bA() : super.an();
  }
  
  public void bz()
  {
    bt = true;
  }
  
  public void a(String par1Str)
  {
    ah.b(10, par1Str);
  }
  
  public String bA()
  {
    return ah.e(10);
  }
  
  public boolean bB()
  {
    return ah.e(10).length() > 0;
  }
  
  public void g(boolean par1)
  {
    ah.b(11, Byte.valueOf((byte)(par1 ? 1 : 0)));
  }
  
  public boolean bC()
  {
    return ah.a(11) == 1;
  }
  
  @SideOnly(Side.CLIENT)
  public boolean bd()
  {
    return bC();
  }
  
  public void a(int par1, float par2)
  {
    e[par1] = par2;
  }
  
  public boolean bD()
  {
    return bs;
  }
  
  public void h(boolean par1)
  {
    bs = par1;
  }
  
  public boolean bE()
  {
    return bt;
  }
  



  public final boolean c(uf par1EntityPlayer)
  {
    if ((bH()) && (bI() == par1EntityPlayer))
    {
      a(true, !bG.d);
      return true;
    }
    

    ye itemstack = bn.h();
    
    if ((itemstack != null) && (d == chcv) && (bG()))
    {
      if ((!(this instanceof oq)) || (!((oq)this).bT()))
      {
        b(par1EntityPlayer, true);
        b -= 1;
        return true;
      }
      
      if (par1EntityPlayer.c_().equalsIgnoreCase(((oq)this).h_()))
      {
        b(par1EntityPlayer, true);
        b -= 1;
        return true;
      }
    }
    
    return a(par1EntityPlayer) ? true : super.c(par1EntityPlayer);
  }
  




  protected boolean a(uf par1EntityPlayer)
  {
    return false;
  }
  
  protected void bF()
  {
    if (bx != null)
    {
      bJ();
    }
    
    if (bv)
    {
      if ((bw == null) || (bw.M))
      {
        a(true, true);
      }
    }
  }
  



  public void a(boolean par1, boolean par2)
  {
    if (bv)
    {
      bv = false;
      bw = null;
      
      if ((!q.I) && (par2))
      {
        b(chcv, 1);
      }
      
      if ((!q.I) && (par1) && ((q instanceof js)))
      {
        ((js)q).q().a(this, new fo(1, this, (nn)null));
      }
    }
  }
  
  public boolean bG()
  {
    return (!bH()) && (!(this instanceof th));
  }
  
  public boolean bH()
  {
    return bv;
  }
  
  public nn bI()
  {
    return bw;
  }
  




  public void b(nn par1Entity, boolean par2)
  {
    bv = true;
    bw = par1Entity;
    
    if ((!q.I) && (par2) && ((q instanceof js)))
    {
      ((js)q).q().a(this, new fo(1, this, bw));
    }
  }
  
  private void bJ()
  {
    if ((bv) && (bx != null))
    {
      if ((bx.b("UUIDMost")) && (bx.b("UUIDLeast")))
      {
        UUID uuid = new UUID(bx.f("UUIDMost"), bx.f("UUIDLeast"));
        double range = 10.0D * getSizeMultiplierRoot();
        List list = q.a(of.class, E.b(range, range, range));
        Iterator iterator = list.iterator();
        
        while (iterator.hasNext())
        {
          of entitylivingbase = (of)iterator.next();
          
          if (entitylivingbase.aw().equals(uuid))
          {
            bw = entitylivingbase;
            break;
          }
        }
      }
      else if ((bx.b("X")) && (bx.b("Y")) && (bx.b("Z")))
      {
        int i = bx.e("X");
        int j = bx.e("Y");
        int k = bx.e("Z");
        oe entityleashknot = oe.b(q, i, j, k);
        
        if (entityleashknot == null)
        {
          entityleashknot = oe.a(q, i, j, k);
        }
        
        bw = entityleashknot;
      }
      else
      {
        a(false, true);
      }
    }
    
    bx = null;
  }
}
