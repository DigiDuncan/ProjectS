import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import java.util.Random;












public abstract class uq
  extends nn
  implements un
{
  private int c = -1;
  private int d = -1;
  private int e = -1;
  
  private int f;
  
  protected boolean a;
  
  public int b;
  
  private of g;
  private String h;
  private int i;
  private int j;
  
  public uq(abw par1World)
  {
    super(par1World);
    a(0.25F, 0.25F);
  }
  



  protected void a() {}
  


  @SideOnly(Side.CLIENT)
  public boolean a(double par1)
  {
    double d1 = E.b() * 4.0D;
    d1 *= 64.0D;
    return par1 < d1 * d1;
  }
  
  public uq(abw par1World, of par2EntityLivingBase)
  {
    super(par1World);
    g = par2EntityLivingBase;
    float psize = par2EntityLivingBase.getSizeMultiplier();
    setSizeMultiplier(par2EntityLivingBase.getSizeMultiplierRoot());
    a(0.25F, 0.25F);
    b(u, v + par2EntityLivingBase.f(), w, A, B);
    u -= ls.b(A / 180.0F * 3.1415927F) * 0.16F * psize;
    v -= 0.10000000149011612D * psize;
    w -= ls.a(A / 180.0F * 3.1415927F) * 0.16F * psize;
    b(u, v, w);
    N = 0.0F;
    float f = 0.4F;
    x = (-ls.a(A / 180.0F * 3.1415927F) * ls.b(B / 180.0F * 3.1415927F) * f);
    z = (ls.b(A / 180.0F * 3.1415927F) * ls.b(B / 180.0F * 3.1415927F) * f);
    y = (-ls.a((B + d()) / 180.0F * 3.1415927F) * f);
    c(x, y, z, c() * (getSizeMultiplier() <= 1.0F ? 1.0F : getSizeMultiplier()), 1.0F * psize);
  }
  
  public uq(abw par1World, double par2, double par4, double par6)
  {
    super(par1World);
    i = 0;
    a(0.25F, 0.25F);
    b(par2, par4, par6);
    N = 0.0F;
  }
  
  public boolean isResizable()
  {
    return true;
  }
  



  public void a(float par1, float par2)
  {
    super.a(par1 * getSizeMultiplier(), par2 * getSizeMultiplier());
  }
  
  protected float c()
  {
    return 1.5F;
  }
  
  protected float d()
  {
    return 0.0F;
  }
  



  public void c(double par1, double par3, double par5, float par7, float par8)
  {
    float f2 = ls.a(par1 * par1 + par3 * par3 + par5 * par5);
    par1 /= f2;
    par3 /= f2;
    par5 /= f2;
    par1 += ab.nextGaussian() * 0.007499999832361937D * par8;
    par3 += ab.nextGaussian() * 0.007499999832361937D * par8;
    par5 += ab.nextGaussian() * 0.007499999832361937D * par8;
    par1 *= par7;
    par3 *= par7;
    par5 *= par7;
    x = par1;
    y = par3;
    z = par5;
    float f3 = ls.a(par1 * par1 + par5 * par5);
    C = (this.A = (float)(Math.atan2(par1, par5) * 180.0D / 3.141592653589793D));
    D = (this.B = (float)(Math.atan2(par3, f3) * 180.0D / 3.141592653589793D));
    i = 0;
  }
  




  @SideOnly(Side.CLIENT)
  public void h(double par1, double par3, double par5)
  {
    x = par1;
    y = par3;
    z = par5;
    
    if ((D == 0.0F) && (C == 0.0F))
    {
      float f = ls.a(par1 * par1 + par5 * par5);
      C = (this.A = (float)(Math.atan2(par1, par5) * 180.0D / 3.141592653589793D));
      D = (this.B = (float)(Math.atan2(par3, f) * 180.0D / 3.141592653589793D));
    }
  }
  



  public void l_()
  {
    U = u;
    V = v;
    W = w;
    super.l_();
    
    if (b > 0)
    {
      b -= 1;
    }
    
    if (a)
    {
      int i = q.a(c, d, e);
      
      if (i == this.f)
      {
        this.i += 1;
        
        if (this.i == 1200)
        {
          x();
        }
        
        return;
      }
      
      a = false;
      x *= ab.nextFloat() * 0.2F;
      y *= ab.nextFloat() * 0.2F;
      z *= ab.nextFloat() * 0.2F;
      this.i = 0;
      this.j = 0;
    }
    else
    {
      this.j += 1;
    }
    
    atc vec3 = q.V().a(u, v, w);
    atc vec31 = q.V().a(u + x, v + y, w + z);
    ata movingobjectposition = q.a(vec3, vec31);
    vec3 = q.V().a(u, v, w);
    vec31 = q.V().a(u + x, v + y, w + z);
    
    if (movingobjectposition != null)
    {
      vec31 = q.V().a(f.c, f.d, f.e);
    }
    
    if (!q.I)
    {
      nn entity = null;
      List list = q.b(this, E.a(x, y, z).b(1.0D, 1.0D, 1.0D));
      double d0 = 0.0D;
      of entitylivingbase = h();
      
      for (int j = 0; j < list.size(); j++)
      {
        nn entity1 = (nn)list.get(j);
        
        if (entity1.L()) { if (entity1 == entitylivingbase) { if (this.j < (entitylivingbase.getSizeMultiplier() <= 1.0F ? 5 : (int)(5.0F * entitylivingbase.getSizeMultiplierRoot()))) {}
          } else {
            float f = 0.3F;
            asx axisalignedbb = E.b(f, f, f);
            ata movingobjectposition1 = axisalignedbb.a(vec3, vec31);
            
            if (movingobjectposition1 != null)
            {
              double d1 = vec3.d(f);
              
              if ((d1 < d0) || (d0 == 0.0D))
              {
                entity = entity1;
                d0 = d1;
              }
            }
          }
        }
      }
      if (entity != null)
      {
        movingobjectposition = new ata(entity);
      }
    }
    
    if (movingobjectposition != null)
    {
      if ((a == atb.a) && (q.a(b, c, d) == bjcF))
      {
        ab();
      }
      else
      {
        a(movingobjectposition);
      }
    }
    
    u += x;
    v += y;
    w += z;
    float f1 = ls.a(x * x + z * z);
    A = ((float)(Math.atan2(x, z) * 180.0D / 3.141592653589793D));
    
    for (B = ((float)(Math.atan2(y, f1) * 180.0D / 3.141592653589793D)); B - D < -180.0F; D -= 360.0F) {}
    



    while (B - D >= 180.0F)
    {
      D += 360.0F;
    }
    
    while (A - C < -180.0F)
    {
      C -= 360.0F;
    }
    
    while (A - C >= 180.0F)
    {
      C += 360.0F;
    }
    
    B = (D + (B - D) * 0.2F);
    A = (C + (A - C) * 0.2F);
    float f2 = 0.99F;
    float f3 = e();
    
    if (H())
    {
      for (int k = 0; k < 4; k++)
      {
        float f4 = 0.25F;
        q.a("bubble", u - x * f4, v - y * f4, w - z * f4, x, y, z);
      }
      
      f2 = 0.8F;
    }
    
    x *= f2;
    y *= f2;
    z *= f2;
    y -= f3;
    b(u, v, w);
  }
  



  protected float e()
  {
    return 0.03F;
  }
  



  protected abstract void a(ata paramAta);
  



  public void b(by par1NBTTagCompound)
  {
    par1NBTTagCompound.a("xTile", (short)c);
    par1NBTTagCompound.a("yTile", (short)d);
    par1NBTTagCompound.a("zTile", (short)e);
    par1NBTTagCompound.a("inTile", (byte)f);
    par1NBTTagCompound.a("shake", (byte)b);
    par1NBTTagCompound.a("inGround", (byte)(a ? 1 : 0));
    
    if (((h == null) || (h.length() == 0)) && (g != null) && ((g instanceof uf)))
    {
      h = g.an();
    }
    
    par1NBTTagCompound.a("ownerName", h == null ? "" : h);
  }
  



  public void a(by par1NBTTagCompound)
  {
    c = par1NBTTagCompound.d("xTile");
    d = par1NBTTagCompound.d("yTile");
    e = par1NBTTagCompound.d("zTile");
    f = (par1NBTTagCompound.c("inTile") & 0xFF);
    b = (par1NBTTagCompound.c("shake") & 0xFF);
    a = (par1NBTTagCompound.c("inGround") == 1);
    h = par1NBTTagCompound.i("ownerName");
    
    if ((h != null) && (h.length() == 0))
    {
      h = null;
    }
  }
  
  @SideOnly(Side.CLIENT)
  public float S()
  {
    return 0.0F;
  }
  
  public of h()
  {
    if ((g == null) && (h != null) && (h.length() > 0))
    {
      g = q.a(h);
    }
    
    return g;
  }
}
