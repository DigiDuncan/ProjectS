import java.util.Random;




public class qf
  extends ps
{
  abw a;
  og b;
  of c;
  int d;
  
  public qf(og par1EntityLiving)
  {
    b = par1EntityLiving;
    a = q;
    a(3);
  }
  



  public boolean a()
  {
    of entitylivingbase = b.m();
    
    if (entitylivingbase == null)
    {
      return false;
    }
    if ((P > b.P) || (b.aD().nextInt(200) == 0))
    {

      c = null;
      b.d(null);
      return false;
    }
    if (b.n == entitylivingbase)
    {
      return false;
    }
    

    c = entitylivingbase;
    return true;
  }
  




  public boolean b()
  {
    return c.T();
  }
  



  public void d()
  {
    c = null;
    b.k().h();
  }
  



  public void e()
  {
    b.h().a(c, 30.0F, 30.0F);
    float r = Math.min(b.O, c.O);
    double d0 = (b.O + r) * (b.O + r);
    double d1 = b.e(c.u, c.E.b, c.w);
    double d2 = 0.8D;
    
    if ((d1 > d0) && (d1 < 16.0D * b.getSizeMultiplier()))
    {
      d2 = 1.33D;
    }
    else if (d1 < 225.0D * b.getSizeMultiplier())
    {
      d2 = 0.6D;
    }
    
    b.k().a(c, d2);
    d = Math.max(d - 1, 0);
    
    if (d1 <= d0)
    {
      if ((d <= 0) && (b.o(c)))
      {
        d = 20;
        b.m(c);
      }
    }
  }
}
