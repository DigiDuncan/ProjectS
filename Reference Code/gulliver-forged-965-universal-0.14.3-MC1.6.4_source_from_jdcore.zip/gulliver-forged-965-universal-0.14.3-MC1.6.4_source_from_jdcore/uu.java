import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.Iterator;
import java.util.List;














public class uu
  extends uq
{
  private ye c;
  
  public uu(abw par1World)
  {
    super(par1World);
  }
  
  public uu(abw par1World, of par2EntityLivingBase, int par3)
  {
    this(par1World, par2EntityLivingBase, new ye(yc.bu, 1, par3));
  }
  
  public uu(abw par1World, of par2EntityLivingBase, ye par3ItemStack)
  {
    super(par1World, par2EntityLivingBase);
    c = par3ItemStack;
  }
  
  @SideOnly(Side.CLIENT)
  public uu(abw par1World, double par2, double par4, double par6, int par8)
  {
    this(par1World, par2, par4, par6, new ye(yc.bu, 1, par8));
  }
  
  public uu(abw par1World, double par2, double par4, double par6, ye par8ItemStack)
  {
    super(par1World, par2, par4, par6);
    c = par8ItemStack;
  }
  



  protected float e()
  {
    return 0.05F;
  }
  
  protected float c()
  {
    return 0.5F;
  }
  
  protected float d()
  {
    return -20.0F;
  }
  
  public void a(int par1)
  {
    if (c == null)
    {
      c = new ye(yc.bu, 1, 0);
    }
    
    c.b(par1);
  }
  



  public int i()
  {
    if (c == null)
    {
      c = new ye(yc.bu, 1, 0);
    }
    
    return c.k();
  }
  



  protected void a(ata par1MovingObjectPosition)
  {
    if (!q.I)
    {
      List list = yc.bu.g(c);
      
      if ((list != null) && (!list.isEmpty()))
      {
        asx axisalignedbb = E.b(4.0D, 2.0D, 4.0D);
        List list1 = q.a(of.class, axisalignedbb);
        
        if ((g != null) && ((g instanceof of)))
        {
          list1.add(g);
        }
        
        if ((list1 != null) && (!list1.isEmpty()))
        {
          boolean gotEntityHit = false;
          Iterator iterator = list1.iterator();
          
          while (iterator.hasNext())
          {
            of entitylivingbase = (of)iterator.next();
            double d0 = e(entitylivingbase);
            
            if ((d0 < 16.0D) || ((entitylivingbase == g) && (!gotEntityHit)))
            {
              double d1 = 1.0D - Math.sqrt(d0) / 4.0D;
              
              if (entitylivingbase == g)
              {
                d1 = 1.0D;
                gotEntityHit = true;
              }
              
              Iterator iterator1 = list.iterator();
              
              while (iterator1.hasNext())
              {
                nj potioneffect = (nj)iterator1.next();
                int i = potioneffect.a();
                
                if (ni.a[i].b())
                {
                  ni.a[i].a(h(), entitylivingbase, potioneffect.c(), d1);
                }
                else
                {
                  int j = (int)(d1 * potioneffect.b() + 0.5D);
                  
                  if (j > 20)
                  {
                    entitylivingbase.c(new nj(i, j, potioneffect.c()));
                  }
                }
              }
            }
          }
        }
      }
      
      q.e(2002, (int)Math.round(u), (int)Math.round(v), (int)Math.round(w), i());
      x();
    }
  }
  



  public void a(by par1NBTTagCompound)
  {
    super.a(par1NBTTagCompound);
    
    if (par1NBTTagCompound.b("Potion"))
    {
      c = ye.a(par1NBTTagCompound.l("Potion"));
    }
    else
    {
      a(par1NBTTagCompound.e("potionValue"));
    }
    
    if (c == null)
    {
      x();
    }
  }
  



  public void b(by par1NBTTagCompound)
  {
    super.b(par1NBTTagCompound);
    
    if (c != null)
    {
      par1NBTTagCompound.a("Potion", c.b(new by()));
    }
  }
}
