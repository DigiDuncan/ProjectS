import gulliver.common.GulliverEnvoy;
import java.util.Calendar;
import java.util.Random;


















public class ro
  extends rn
{
  private t h;
  
  public ro(abw par1World)
  {
    super(par1World);
    a(0.5F, 0.9F);
    a(true);
  }
  
  protected void a()
  {
    super.a();
    ah.a(16, new Byte((byte)0));
  }
  



  protected float ba()
  {
    return 0.1F;
  }
  



  protected float bb()
  {
    return super.bb() * 0.95F;
  }
  



  protected String r()
  {
    return (bJ()) && (ab.nextInt(4) != 0) ? null : "mob.bat.idle";
  }
  



  protected String aO()
  {
    return "mob.bat.hurt";
  }
  



  protected String aP()
  {
    return "mob.bat.death";
  }
  



  public boolean M()
  {
    return false;
  }
  
  protected void n(nn par1Entity) {}
  
  protected void bj() {}
  
  protected void az()
  {
    super.az();
    a(tp.a).a(6.0D);
  }
  
  public boolean bJ()
  {
    return (ah.a(16) & 0x1) != 0;
  }
  
  public void a(boolean par1)
  {
    byte b0 = ah.a(16);
    
    if (par1)
    {
      ah.b(16, Byte.valueOf((byte)(b0 | 0x1)));
    }
    else
    {
      ah.b(16, Byte.valueOf((byte)(b0 & 0xFFFFFFFE)));
    }
  }
  



  protected boolean bf()
  {
    return true;
  }
  
  public float maxRiderWidth(nn par1Entity)
  {
    return O * 0.65F;
  }
  



  public void l_()
  {
    super.l_();
    
    if (bJ())
    {
      x = (this.y = this.z = 0.0D);
      v = (ls.c(v) + 1.0D - P);
      

      if ((!q.I) && (n != null))
      {
        n.a(null);
      }
    }
    else
    {
      y *= 0.6000000238418579D;
    }
  }
  
  protected void bi()
  {
    super.bi();
    
    if (bJ())
    {
      if (!q.u(ls.c(u), (int)v + 1, ls.c(w)))
      {
        a(false);
        q.a((uf)null, 1015, (int)u, (int)v, (int)w, 0);
      }
      else
      {
        if (ab.nextInt(200) == 0)
        {
          aP = ab.nextInt(360);
        }
        
        uf closetiny = null;
        if (bB())
        {
          closetiny = q.getClosestVisibleSizedPlayerToEntity(this, 2.0D, 0.1F, 0.4F);
          if ((closetiny != null) && (!GulliverEnvoy.isHoldingStringOrLeash(closetiny)) && (!closetiny.isGliding()))
          {
            closetiny = null;
          }
        }
        if ((closetiny != null) || (q.getClosestSizedPlayerToEntity(this, 4.0D, 0.4F, 0.0F) != null))
        {
          a(false);
          q.a((uf)null, 1015, (int)u, (int)v, (int)w, 0);
        }
      }
    }
    else
    {
      float sizemult = getSizeMultiplier();
      float sizeroot = getSizeMultiplierRoot();
      boolean hasRider = (n != null) && ((n instanceof uf));
      

      boolean fullctrl = false;
      boolean hasreins = false;
      float fwd = 0.0F;
      if (hasRider)
      {
        fwd = n).bf;
        ye itemstack = n).bn.h();
        hasreins = (itemstack != null) && (n.isTiny() ? d == Mcv : d == chcv);
        fullctrl = (isEntityInRelativeSizeRange(n, 0.1F, 0.65F)) && ((hasreins) || (bB()));
      }
      float yawadj = 0.0F;
      
      if (!fullctrl)
      {
        uf closetiny = q.getClosestVisibleSizedPlayerToEntity(this, 6.0D, 0.1F, 0.3F);
        if ((closetiny != null) && (!GulliverEnvoy.isHoldingStringOrLeash(closetiny)) && (!closetiny.isGliding()))
        {
          closetiny = null;
        }
        
        if ((h != null) && ((!q.c(h.a, h.b, h.c)) || (h.b < 1)))
        {
          h = null;
        }
        
        if ((h == null) || (ab.nextInt(30) == 0) || (h.e((int)u, (int)v, (int)w) < 4.0F))
        {
          if ((bB()) && (closetiny != null) && (!(o instanceof ro)))
          {

            h = new t((int)u + ab.nextInt(3) - ab.nextInt(3), (int)v + ab.nextInt(2), (int)w + ab.nextInt(3) - ab.nextInt(3));
          }
          else
          {
            h = new t((int)u + ab.nextInt(7) - ab.nextInt(7), (int)v + ab.nextInt(6) - 2, (int)w + ab.nextInt(7) - ab.nextInt(7));
          }
        }
        
        double d0 = h.a + 0.5D - u;
        double d1 = h.b + 0.1D - v;
        double d2 = h.c + 0.5D - w;
        x += (Math.signum(d0) * 0.5D - x) * 0.10000000149011612D * sizeroot;
        y += (Math.signum(d1) * 0.699999988079071D - y) * 0.10000000149011612D * sizeroot;
        z += (Math.signum(d2) * 0.5D - z) * 0.10000000149011612D * sizeroot;
        float f = (float)(Math.atan2(z, x) * 180.0D / 3.141592653589793D) - 90.0F;
        yawadj = ls.g(f - A);
        bf = 0.5F;
        A = ls.g(A + yawadj);
      }
      
      if (fullctrl)
      {
        h = null;
        float riderYaw = n.A;
        float f4 = ls.a(riderYaw * 3.1415927F / 180.0F);
        float f5 = ls.b(riderYaw * 3.1415927F / 180.0F);
        float sizeratio = n.getSizeMultiplier() / sizemult;
        float sizerootratio = n.getSizeMultiplierRoot() / sizeroot;
        float pitchamt = n.B / 75.0F;
        
        if (pitchamt > 1.0F) pitchamt = 1.0F;
        if (pitchamt < -1.0F) pitchamt = -1.0F;
        if (Math.abs(pitchamt) < 0.2F) pitchamt = 0.0F;
        if (fwd > 0.0F)
        {

          y = (-pitchamt * sizerootratio * sizeroot * 0.699999988079071D);
          x = (-f4 * sizerootratio * sizeroot * 0.5D);
          z = (f5 * sizerootratio * sizeroot * 0.5D);
          bf = (0.5F * sizerootratio);

        }
        else
        {
          x = 0.0D;
          z = 0.0D;
          pitchamt = pitchamt < 0.0F ? -0.2F : 0.2F;
          
          if (fwd < 0.0F)
          {
            y = (-pitchamt * sizerootratio * sizeroot);
            bf = (0.1F * sizerootratio);
          }
          else
          {
            y = (0.1D * (ac % 2 * 2 - 1));
            bf = (hasreins ? 0.001F : 0.0F);
          }
        }
        yawadj = ls.g(riderYaw - A);
        if ((y > 0.0D) && (q.u(ls.c(u), (int)(E.e + y - 0.2D), ls.c(w))))
        {
          y = 0.0D;
        }
        if ((y < 0.0D) && (q.u(ls.c(u), (int)(E.b + y + 0.2D), ls.c(w))))
        {
          y = 0.0D;
        }
        if ((hasreins) || (fwd > 0.0F))
        {
          C = (this.A = ls.g(A + yawadj));
          aP = A;
          b(A, B);
        }
      }
      
      if ((!hasRider) || (!bB())) { if ((ab.nextInt(bB() ? 10 : 100) == 0) && (q.u(ls.c(u), (int)(E.e - P) + 1, ls.c(w))) && (getSizeMultiplier() <= 2.0F) && (!H))
        {
          a(true);
        }
      }
    }
  }
  



  protected boolean e_()
  {
    return false;
  }
  




  protected void b(float par1) {}
  



  protected void a(double par1, boolean par3) {}
  



  public boolean au()
  {
    return true;
  }
  



  public boolean a(nb par1DamageSource, float par2)
  {
    if (ar())
    {
      return false;
    }
    

    if ((!q.I) && (bJ()))
    {
      a(false);
    }
    
    return super.a(par1DamageSource, par2);
  }
  

  public void W()
  {
    double flapoff = ls.b(ac * 0.3F) * 0.2F * O;
    double d = Math.cos((aN - 90.0F) * 3.141592653589793D / 180.0D) * O * 0.4D;
    double d1 = Math.sin((aN - 90.0F) * 3.141592653589793D / 180.0D) * O * 0.4D;
    
    n.b(u + d, v + Y() + n.X() + flapoff, w + d1);
  }
  



  public double Y()
  {
    return P * 0.325D;
  }
  



  public asx getEntityCollisionBox()
  {
    return E.c();
  }
  



  public asx getEntityHitBox()
  {
    return E.c();
  }
  



  public void a(by par1NBTTagCompound)
  {
    super.a(par1NBTTagCompound);
    ah.b(16, Byte.valueOf(par1NBTTagCompound.c("BatFlags")));
  }
  



  public void b(by par1NBTTagCompound)
  {
    super.b(par1NBTTagCompound);
    par1NBTTagCompound.a("BatFlags", ah.a(16));
  }
  



  public boolean bs()
  {
    int i = ls.c(E.b);
    
    if (i >= 63)
    {
      return false;
    }
    

    int j = ls.c(u);
    int k = ls.c(w);
    int l = q.n(j, i, k);
    byte b0 = 4;
    Calendar calendar = q.W();
    
    if (((calendar.get(2) + 1 != 10) || (calendar.get(5) < 20)) && ((calendar.get(2) + 1 != 11) || (calendar.get(5) > 3)))
    {
      if (ab.nextBoolean())
      {
        return false;
      }
      
    }
    else {
      b0 = 7;
    }
    
    return l > ab.nextInt(b0) ? false : super.bs();
  }
}
