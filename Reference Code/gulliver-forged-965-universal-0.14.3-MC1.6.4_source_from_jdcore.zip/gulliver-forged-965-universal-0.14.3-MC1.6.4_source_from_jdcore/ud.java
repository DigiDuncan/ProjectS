import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;















public class ud
  implements mo
{
  public ye[] a = new ye[36];
  

  public ye[] b = new ye[4];
  

  public int c;
  

  @SideOnly(Side.CLIENT)
  private ye f;
  

  public uf d;
  

  private ye g;
  

  public boolean e;
  

  public ud(uf par1EntityPlayer)
  {
    d = par1EntityPlayer;
  }
  



  public ye h()
  {
    return (c < 9) && (c >= 0) ? a[c] : null;
  }
  



  public static int i()
  {
    return 9;
  }
  



  private int g(int par1)
  {
    for (int j = 0; j < a.length; j++)
    {
      if ((a[j] != null) && (a[j].d == par1))
      {
        return j;
      }
    }
    
    return -1;
  }
  
  @SideOnly(Side.CLIENT)
  private int d(int par1, int par2)
  {
    for (int k = 0; k < a.length; k++)
    {
      if ((a[k] != null) && (a[k].d == par1) && (a[k].k() == par2))
      {
        return k;
      }
    }
    
    return -1;
  }
  



  private int d(ye par1ItemStack)
  {
    for (int i = 0; i < a.length; i++)
    {
      if ((a[i] != null) && (a[i].d == d) && (a[i].f()) && (a[i].b < a[i].e()) && (a[i].b < d()) && ((!a[i].h()) || (a[i].k() == par1ItemStack.k())) && (ye.a(a[i], par1ItemStack)))
      {
        return i;
      }
    }
    
    return -1;
  }
  



  public int j()
  {
    for (int i = 0; i < a.length; i++)
    {
      if ((a[i] == null) && ((d.heldEntity == null) || (i != c)))
      {
        return i;
      }
    }
    
    return -1;
  }
  




  @SideOnly(Side.CLIENT)
  public void a(int par1, int par2, boolean par3, boolean par4)
  {
    boolean flag2 = true;
    f = h();
    int k;
    int k;
    if (par3)
    {
      k = d(par1, par2);
    }
    else
    {
      k = g(par1);
    }
    
    if ((k >= 0) && (k < 9))
    {
      c = k;


    }
    else if ((par4) && (par1 > 0))
    {
      int l = j();
      
      if ((l >= 0) && (l < 9))
      {
        c = l;
      }
      
      a(yc.g[par1], par2);
    }
  }
  





  @SideOnly(Side.CLIENT)
  public void c(int par1)
  {
    if (par1 > 0)
    {
      par1 = 1;
    }
    
    if (par1 < 0)
    {
      par1 = -1;
    }
    
    for (c -= par1; c < 0; c += 9) {}
    



    while (c >= 9)
    {
      c -= 9;
    }
  }
  



  public int b(int par1, int par2)
  {
    int k = 0;
    


    for (int l = 0; l < a.length; l++)
    {
      ye itemstack = a[l];
      
      if ((itemstack != null) && ((par1 <= -1) || (d == par1)) && ((par2 <= -1) || (itemstack.k() == par2)))
      {
        k += b;
        a[l] = null;
      }
    }
    
    for (l = 0; l < b.length; l++)
    {
      ye itemstack = b[l];
      
      if ((itemstack != null) && ((par1 <= -1) || (d == par1)) && ((par2 <= -1) || (itemstack.k() == par2)))
      {
        k += b;
        b[l] = null;
      }
    }
    
    if (g != null)
    {
      if ((par1 > -1) && (g.d != par1))
      {
        return k;
      }
      
      if ((par2 > -1) && (g.k() != par2))
      {
        return k;
      }
      
      k += g.b;
      b((ye)null);
    }
    
    return k;
  }
  
  @SideOnly(Side.CLIENT)
  public void a(yc par1Item, int par2)
  {
    if (par1Item != null)
    {
      if ((f != null) && (f.x()) && (d(f.d, f.j()) == c))
      {
        return;
      }
      
      int j = d(cv, par2);
      
      if (j >= 0)
      {
        int k = a[j].b;
        a[j] = a[c];
        a[c] = new ye(yc.g[cv], k, par2);
      }
      else
      {
        a[c] = new ye(yc.g[cv], 1, par2);
      }
    }
  }
  




  private int e(ye par1ItemStack)
  {
    int i = d;
    int j = b;
    

    if (par1ItemStack.e() == 1)
    {
      int k = j();
      
      if (k < 0)
      {
        return j;
      }
      

      if (a[k] == null)
      {
        a[k] = ye.b(par1ItemStack);
      }
      
      return 0;
    }
    


    int k = d(par1ItemStack);
    
    if (k < 0)
    {
      k = j();
    }
    
    if (k < 0)
    {
      return j;
    }
    

    if (a[k] == null)
    {
      a[k] = new ye(i, 0, par1ItemStack.k());
      
      if (par1ItemStack.p())
      {
        a[k].d((by)par1ItemStack.q().b());
      }
    }
    
    int l = j;
    
    if (j > a[k].e() - a[k].b)
    {
      l = a[k].e() - a[k].b;
    }
    
    if (l > d() - a[k].b)
    {
      l = d() - a[k].b;
    }
    
    if (l == 0)
    {
      return j;
    }
    

    j -= l;
    a[k].b += l;
    a[k].c = 5;
    return j;
  }
  







  public void k()
  {
    for (int i = 0; i < a.length; i++)
    {
      if (a[i] != null)
      {
        a[i].a(d.q, d, i, c == i);
      }
    }
    
    for (int i = 0; i < b.length; i++)
    {
      if (b[i] != null)
      {
        b[i].b().onArmorTickUpdate(d.q, d, b[i]);
      }
    }
  }
  



  public boolean d(int par1)
  {
    int j = g(par1);
    
    if (j < 0)
    {
      return false;
    }
    

    if (--a[j].b <= 0)
    {
      a[j] = null;
    }
    
    return true;
  }
  




  public boolean e(int par1)
  {
    int j = g(par1);
    return j >= 0;
  }
  



  public boolean a(ye par1ItemStack)
  {
    if (par1ItemStack == null)
    {
      return false;
    }
    if (b == 0)
    {
      return false;
    }
    



    try
    {
      if (par1ItemStack.i())
      {
        int i = j();
        
        if (i >= 0)
        {
          a[i] = ye.b(par1ItemStack);
          a[i].c = 5;
          b = 0;
          return true;
        }
        if (d.bG.d)
        {
          b = 0;
          return true;
        }
        

        return false;
      }
      
      int i;
      
      do
      {
        i = b;
        b = e(par1ItemStack);
      }
      while ((b > 0) && (b < i));
      
      if ((b == i) && (d.bG.d))
      {
        b = 0;
        return true;
      }
      

      return b < i;

    }
    catch (Throwable throwable)
    {

      b crashreport = b.a(throwable, "Adding item to inventory");
      m crashreportcategory = crashreport.a("Item being added");
      crashreportcategory.a("Item ID", Integer.valueOf(d));
      crashreportcategory.a("Item data", Integer.valueOf(par1ItemStack.k()));
      crashreportcategory.a("Item name", new ue(this, par1ItemStack));
      throw new u(crashreport);
    }
  }
  





  public ye a(int par1, int par2)
  {
    ye[] aitemstack = a;
    
    if (par1 >= a.length)
    {
      aitemstack = b;
      par1 -= a.length;
    }
    
    if (aitemstack[par1] != null)
    {


      if (b <= par2)
      {
        ye itemstack = aitemstack[par1];
        aitemstack[par1] = null;
        return itemstack;
      }
      

      ye itemstack = aitemstack[par1].a(par2);
      
      if (b == 0)
      {
        aitemstack[par1] = null;
      }
      
      return itemstack;
    }
    


    return null;
  }
  





  public ye a_(int par1)
  {
    ye[] aitemstack = a;
    
    if (par1 >= a.length)
    {
      aitemstack = b;
      par1 -= a.length;
    }
    
    if (aitemstack[par1] != null)
    {
      ye itemstack = aitemstack[par1];
      aitemstack[par1] = null;
      return itemstack;
    }
    

    return null;
  }
  




  public void a(int par1, ye par2ItemStack)
  {
    ye[] aitemstack = a;
    
    if (par1 >= aitemstack.length)
    {
      par1 -= aitemstack.length;
      aitemstack = b;
    }
    
    aitemstack[par1] = par2ItemStack;
  }
  



  public float a(aqz par1Block)
  {
    float f = 1.0F;
    
    if (a[c] != null)
    {
      f *= a[c].a(par1Block);
    }
    
    return f;
  }
  







  public cg a(cg par1NBTTagList)
  {
    for (int i = 0; i < a.length; i++)
    {
      if (a[i] != null)
      {
        by nbttagcompound = new by();
        nbttagcompound.a("Slot", (byte)i);
        a[i].b(nbttagcompound);
        par1NBTTagList.a(nbttagcompound);
      }
    }
    
    for (i = 0; i < b.length; i++)
    {
      if (b[i] != null)
      {
        by nbttagcompound = new by();
        nbttagcompound.a("Slot", (byte)(i + 100));
        b[i].b(nbttagcompound);
        par1NBTTagList.a(nbttagcompound);
      }
    }
    
    return par1NBTTagList;
  }
  



  public void b(cg par1NBTTagList)
  {
    a = new ye[36];
    b = new ye[4];
    
    for (int i = 0; i < par1NBTTagList.c(); i++)
    {
      by nbttagcompound = (by)par1NBTTagList.b(i);
      int j = nbttagcompound.c("Slot") & 0xFF;
      ye itemstack = ye.a(nbttagcompound);
      
      if (itemstack != null)
      {
        if ((j >= 0) && (j < a.length))
        {
          a[j] = itemstack;
        }
        
        if ((j >= 100) && (j < b.length + 100))
        {
          b[(j - 100)] = itemstack;
        }
      }
    }
  }
  



  public int j_()
  {
    return a.length + 4;
  }
  



  public ye a(int par1)
  {
    ye[] aitemstack = a;
    
    if (par1 >= aitemstack.length)
    {
      par1 -= aitemstack.length;
      aitemstack = b;
    }
    
    return aitemstack[par1];
  }
  



  public String b()
  {
    return "container.inventory";
  }
  




  public boolean c()
  {
    return false;
  }
  




  public int d()
  {
    return 64;
  }
  



  public boolean b(aqz par1Block)
  {
    if (cU.l())
    {
      return true;
    }
    

    ye itemstack = a(c);
    return itemstack != null ? itemstack.b(par1Block) : false;
  }
  




  public ye f(int par1)
  {
    return b[par1];
  }
  



  public int l()
  {
    int i = 0;
    
    for (int j = 0; j < b.length; j++)
    {
      if ((b[j] != null) && ((b[j].b() instanceof wh)))
      {
        int k = b[j].b()).c;
        i += k;
      }
    }
    
    return i;
  }
  



  public void a(float par1)
  {
    par1 /= 4.0F;
    
    if (par1 < 1.0F)
    {
      par1 = 1.0F;
    }
    
    for (int i = 0; i < b.length; i++)
    {
      if ((b[i] != null) && ((b[i].b() instanceof wh)))
      {
        b[i].a((int)par1, d);
        
        if (b[i].b == 0)
        {
          b[i] = null;
        }
      }
    }
  }
  





  public void m()
  {
    for (int i = 0; i < a.length; i++)
    {
      if (a[i] != null)
      {
        d.a(a[i], true);
        a[i] = null;
      }
    }
    
    for (i = 0; i < b.length; i++)
    {
      if (b[i] != null)
      {
        d.a(b[i], true);
        b[i] = null;
      }
    }
  }
  



  public void e()
  {
    e = true;
  }
  
  public void b(ye par1ItemStack)
  {
    g = par1ItemStack;
  }
  
  public ye o()
  {
    return g;
  }
  



  public boolean a(uf par1EntityPlayer)
  {
    return !d.M;
  }
  





  public boolean c(ye par1ItemStack)
  {
    for (int i = 0; i < b.length; i++)
    {
      if ((b[i] != null) && (b[i].a(par1ItemStack)))
      {
        return true;
      }
    }
    
    for (i = 0; i < a.length; i++)
    {
      if ((a[i] != null) && (a[i].a(par1ItemStack)))
      {
        return true;
      }
    }
    
    return false;
  }
  

  public void k_() {}
  

  public void g() {}
  

  public boolean b(int par1, ye par2ItemStack)
  {
    return true;
  }
  





  public void b(ud par1InventoryPlayer)
  {
    for (int i = 0; i < a.length; i++)
    {
      a[i] = ye.b(a[i]);
    }
    
    for (i = 0; i < b.length; i++)
    {
      b[i] = ye.b(b[i]);
    }
    
    c = c;
  }
}
