import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;











@SideOnly(Side.CLIENT)
public class bey
  extends beu
{
  private boolean a;
  private int c;
  private double d;
  private double e;
  private double f;
  private double g;
  private double h;
  
  public bey(abw par1World, String par2Str)
  {
    super(par1World, par2Str);
    N = 0.0F;
    Y = 0.0F;
    Z = true;
    cc = 0.25F;
    l = 10.0D;
  }
  



  protected void d_()
  {
    N = 0.0F;
  }
  



  public boolean a(nb par1DamageSource, float par2)
  {
    return true;
  }
  




  public void a(double par1, double par3, double par5, float par7, float par8, int par9)
  {
    d = par1;
    e = par3;
    f = par5;
    g = par7;
    h = par8;
    c = par9;
  }
  



  public void l_()
  {
    cc = 0.0F;
    super.l_();
    aF = aG;
    double d0 = u - r;
    double d1 = w - t;
    float f = ls.a(d0 * d0 + d1 * d1) * 4.0F / getSizeMovementMultiplier();
    
    if (f > 1.0F)
    {
      f = 1.0F;
    }
    
    aG += (f - aG) * 0.4F;
    aH += aG;
    
    if ((!a) && (ak()) && (bn.a[bn.c] != null))
    {
      ye itemstack = bn.a[bn.c];
      a(bn.a[bn.c], yc.g[d].d_(itemstack));
      a = true;
    }
    else if ((a) && (!ak()))
    {
      bu();
      a = false;
    }
  }
  
  public float S()
  {
    return 0.0F;
  }
  




  public void c()
  {
    super.bl();
    
    if (c > 0)
    {
      double d0 = u + (d - u) / c;
      double d1 = v + (e - v) / c;
      double d2 = w + (this.f - w) / c;
      

      for (double d3 = g - A; d3 < -180.0D; d3 += 360.0D) {}
      



      while (d3 >= 180.0D)
      {
        d3 -= 360.0D;
      }
      
      A = ((float)(A + d3 / c));
      B = ((float)(B + (h - B) / c));
      c -= 1;
      b(d0, d1, d2);
      b(A, B);
    }
    
    bs = bt;
    float f = ls.a(x * x + z * z);
    float f1 = (float)Math.atan(-y * 0.20000000298023224D) * 15.0F;
    
    if (f > 0.1F)
    {
      f = 0.1F;
    }
    
    if ((!F) || (aN() <= 0.0F))
    {
      f = 0.0F;
    }
    
    if ((F) || (aN() <= 0.0F))
    {
      f1 = 0.0F;
    }
    
    bt += (f - bt) * 0.4F;
    aK += (f1 - aK) * 0.8F;
  }
  

  public void updateResizingFlags()
  {
    boolean tmp = F;
    
    if ((isTiny()) && (!I))
    {
      double dsizemult = getSizeMultiplier();
      List blist = q.a(this, E.e(0.03125D * dsizemult, 0.0D, 0.03125D * dsizemult).c(0.0D, -0.2D * dsizemult, 0.0D));
      
      if (!blist.isEmpty())
      {
        F = true;
      }
    }
    
    super.updateResizingFlags();
    F = tmp;
  }
  



  public void c(int par1, ye par2ItemStack)
  {
    if (par1 == 0)
    {
      bn.a[bn.c] = par2ItemStack;
    }
    else
    {
      bn.b[(par1 - 1)] = par2ItemStack;
    }
  }
  


  public float getDefaultEyeHeight()
  {
    return 1.82F * getSizeMultiplier();
  }
  
  public void a(cv par1ChatMessageComponent)
  {
    wr.b().a(par1ChatMessageComponent.a(true));
  }
  



  public boolean a(int par1, String par2Str)
  {
    return false;
  }
  



  public t b()
  {
    return new t(ls.c(u + 0.5D), ls.c(v + 0.5D), ls.c(w + 0.5D));
  }
}
