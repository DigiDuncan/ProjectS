import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import java.util.Random;






























public class ul
  extends nn
{
  private int d;
  private int e;
  private int f;
  private int g;
  private boolean h;
  public int a;
  public uf b;
  private int i;
  private int j;
  private int au;
  public nn c;
  private int av;
  private double aw;
  private double ax;
  private double ay;
  private double az;
  private double aA;
  @SideOnly(Side.CLIENT)
  private double aB;
  @SideOnly(Side.CLIENT)
  private double aC;
  @SideOnly(Side.CLIENT)
  private double aD;
  
  public ul(abw par1World)
  {
    super(par1World);
    d = -1;
    e = -1;
    f = -1;
    a(0.25F, 0.25F);
    am = true;
  }
  
  @SideOnly(Side.CLIENT)
  public ul(abw par1World, double par2, double par4, double par6, uf par8EntityPlayer)
  {
    this(par1World);
    b(par2, par4, par6);
    am = true;
    b = par8EntityPlayer;
    bM = this;
  }
  
  public ul(abw par1World, uf par2EntityPlayer)
  {
    super(par1World);
    d = -1;
    e = -1;
    this.f = -1;
    am = true;
    b = par2EntityPlayer;
    b.bM = this;
    float asize = par2EntityPlayer.getSizeMultiplierRoot();
    setSizeMultiplier(asize);
    a(0.25F, 0.25F);
    b(u, v + 1.62D * par2EntityPlayer.getSizeMultiplier() - N, w, A, B);
    u -= ls.b(A / 180.0F * 3.1415927F) * 0.16F * asize;
    v -= 0.10000000149011612D * asize;
    w -= ls.a(A / 180.0F * 3.1415927F) * 0.16F * asize;
    b(u, v, w);
    N = 0.0F;
    float f = 0.4F;
    x = (-ls.a(A / 180.0F * 3.1415927F) * ls.b(B / 180.0F * 3.1415927F) * f);
    z = (ls.b(A / 180.0F * 3.1415927F) * ls.b(B / 180.0F * 3.1415927F) * f);
    y = (-ls.a(B / 180.0F * 3.1415927F) * f);
    
    c(x, y, z, 1.5F * ls.c(getSizeMultiplierRoot()), 1.0F * getSizeMultiplierRoot());
  }
  
  public boolean isResizable()
  {
    return true;
  }
  



  public void a(float par1, float par2)
  {
    super.a(par1 * getSizeMultiplier(), par2 * getSizeMultiplier());
  }
  



  protected void a() {}
  


  @SideOnly(Side.CLIENT)
  public boolean a(double par1)
  {
    double d1 = E.b() * 4.0D;
    d1 *= 64.0D;
    return par1 < d1 * d1;
  }
  
  public void c(double par1, double par3, double par5, float par7, float par8)
  {
    float f2 = ls.a(par1 * par1 + par3 * par3 + par5 * par5);
    par1 /= f2;
    par3 /= f2;
    par5 /= f2;
    par1 += ab.nextGaussian() * 0.007499999832361937D * par8;
    par3 += ab.nextGaussian() * 0.007499999832361937D * par8;
    par5 += ab.nextGaussian() * 0.007499999832361937D * par8;
    par1 *= par7;
    par3 *= par7;
    par5 *= par7;
    x = par1;
    y = par3;
    z = par5;
    float f3 = ls.a(par1 * par1 + par5 * par5);
    C = (this.A = (float)(Math.atan2(par1, par5) * 180.0D / 3.141592653589793D));
    D = (this.B = (float)(Math.atan2(par3, f3) * 180.0D / 3.141592653589793D));
    i = 0;
  }
  





  @SideOnly(Side.CLIENT)
  public void a(double par1, double par3, double par5, float par7, float par8, int par9)
  {
    aw = par1;
    ax = par3;
    ay = par5;
    az = par7;
    aA = par8;
    av = par9;
    x = aB;
    y = aC;
    z = aD;
  }
  




  @SideOnly(Side.CLIENT)
  public void h(double par1, double par3, double par5)
  {
    aB = (this.x = par1);
    aC = (this.y = par3);
    aD = (this.z = par5);
  }
  



  public void l_()
  {
    super.l_();
    
    if (av > 0)
    {
      double d0 = u + (aw - u) / av;
      double d1 = v + (ax - v) / av;
      double d2 = w + (ay - w) / av;
      double d3 = ls.g(az - A);
      A = ((float)(A + d3 / av));
      B = ((float)(B + (aA - B) / av));
      av -= 1;
      b(d0, d1, d2);
      b(A, B);
    }
    else
    {
      if (!q.I)
      {
        ye itemstack = b.by();
        
        if ((b.M) || (!b.T()) || (itemstack == null) || (itemstack.b() != yc.aT) || (e(b) > 1024.0D))
        {
          x();
          b.bM = null;
          return;
        }
        
        if (c != null)
        {
          if (!c.M)
          {
            u = c.u;
            v = (c.E.b + c.P * 0.8D);
            w = c.w;
            return;
          }
          
          c = null;
        }
      }
      
      if (a > 0)
      {
        a -= 1;
      }
      
      if (h)
      {
        int i = q.a(d, e, this.f);
        
        if (i == g)
        {
          this.i += 1;
          
          if (this.i == 1200)
          {
            x();
          }
          
          return;
        }
        
        h = false;
        x *= ab.nextFloat() * 0.2F;
        y *= ab.nextFloat() * 0.2F;
        z *= ab.nextFloat() * 0.2F;
        this.i = 0;
        this.j = 0;
      }
      else
      {
        this.j += 1;
      }
      
      atc vec3 = q.V().a(u, v, w);
      atc vec31 = q.V().a(u + x, v + y, w + z);
      ata movingobjectposition = q.a(vec3, vec31);
      vec3 = q.V().a(u, v, w);
      vec31 = q.V().a(u + x, v + y, w + z);
      
      if (movingobjectposition != null)
      {
        vec31 = q.V().a(f.c, f.d, f.e);
      }
      
      nn entity = null;
      double dexpand = 1.0D * getSizeMultiplierRoot();
      List list = q.b(this, E.a(x, y, z).b(dexpand, dexpand, dexpand));
      double d4 = 0.0D;
      

      for (int j = 0; j < list.size(); j++)
      {
        nn entity1 = (nn)list.get(j);
        
        if ((entity1.L()) && (((entity1 != b) && (entity1 != b.o)) || (this.j >= 5)))
        {
          float f = 0.3F * entity1.getSizeMultiplierRoot();
          asx axisalignedbb = E.b(f, f, f);
          ata movingobjectposition1 = axisalignedbb.a(vec3, vec31);
          
          if (movingobjectposition1 != null)
          {
            double d5 = vec3.d(f);
            
            if ((d5 < d4) || (d4 == 0.0D))
            {
              entity = entity1;
              d4 = d5;
            }
          }
        }
      }
      
      if (entity != null)
      {
        movingobjectposition = new ata(entity);
      }
      
      if (movingobjectposition != null)
      {
        if (g != null)
        {
          if (g.a(nb.a(this, b), 0.0F))
          {
            c = g;
          }
          
        }
        else {
          h = true;
        }
      }
      
      if (!h)
      {
        d(x, y, z);
        float f1 = ls.a(x * x + z * z);
        A = ((float)(Math.atan2(x, z) * 180.0D / 3.141592653589793D));
        
        for (B = ((float)(Math.atan2(y, f1) * 180.0D / 3.141592653589793D)); B - D < -180.0F; D -= 360.0F) {}
        



        while (B - D >= 180.0F)
        {
          D += 360.0F;
        }
        
        while (A - C < -180.0F)
        {
          C -= 360.0F;
        }
        
        while (A - C >= 180.0F)
        {
          C += 360.0F;
        }
        
        B = (D + (B - D) * 0.2F);
        A = (C + (A - C) * 0.2F);
        float f2 = 0.92F;
        
        if ((F) || (G))
        {
          f2 = 0.5F * getSizeMultiplierRoot();
        }
        
        byte b0 = 5;
        double d6 = 0.0D;
        
        for (int k = 0; k < b0; k++)
        {
          double d7 = E.b + (E.e - E.b) * (k + 0) / b0 - 0.125D + 0.125D;
          double d8 = E.b + (E.e - E.b) * (k + 1) / b0 - 0.125D + 0.125D;
          asx axisalignedbb1 = asx.a().a(E.a, d7, E.c, E.d, d8, E.f);
          
          if (q.b(axisalignedbb1, akc.h))
          {
            d6 += 1.0D / b0;
          }
        }
        
        if (d6 > 0.0D)
        {
          if (au > 0)
          {
            au -= 1;
          }
          else if (!q.I)
          {
            short short1 = 500;
            
            if (q.F(ls.c(u), ls.c(v) + 1, ls.c(w)))
            {
              short1 = 300;
            }
            
            if (ab.nextInt(short1) == 0)
            {
              au = (ab.nextInt(30) + 10);
              if ((b != null) && (b.isTiny()))
              {

                double dx = b.u - u;
                double dy = b.v - v;
                double dz = b.w - w;
                double dist = ls.a(dx * dx + dy * dy + dz * dz);
                b.x -= dx / dist / b.getSizeMultiplierRoot() / 60.0D;
                b.y -= dy / dist / b.getSizeMultiplierRoot() / 60.0D;
                b.z -= dz / dist / b.getSizeMultiplierRoot() / 60.0D;
                if ((b instanceof jv))
                {
                  jv toy = (jv)b;
                  a.b(new fp(k, x, y, z));
                }
              }
              
              y -= 0.20000000298023224D;
              a("random.splash", 0.25F, 1.0F + (ab.nextFloat() - ab.nextFloat()) * 0.4F);
              float f3 = ls.c(E.b);
              



              for (int l = 0; l < 1.0F + O * 20.0F; l++)
              {
                float f5 = (ab.nextFloat() * 2.0F - 1.0F) * O;
                float f4 = (ab.nextFloat() * 2.0F - 1.0F) * O;
                q.a("bubble", u + f5, f3 + 1.0F, w + f4, x, y - ab.nextFloat() * 0.2F, z);
              }
              
              for (l = 0; l < 1.0F + O * 20.0F; l++)
              {
                float f5 = (ab.nextFloat() * 2.0F - 1.0F) * O;
                float f4 = (ab.nextFloat() * 2.0F - 1.0F) * O;
                q.a("splash", u + f5, f3 + 1.0F, w + f4, x, y, z);
              }
            }
          }
        }
        
        if (au > 0)
        {
          y -= ab.nextFloat() * ab.nextFloat() * ab.nextFloat() * 0.2D;
        }
        
        double d5 = d6 * 2.0D - 1.0D;
        y += 0.03999999910593033D * d5;
        
        if (d6 > 0.0D)
        {
          f2 = (float)(f2 * 0.9D);
          y *= 0.8D;
        }
        
        x *= f2;
        y *= f2;
        z *= f2;
        b(u, v, w);
      }
    }
  }
  



  public void b(by par1NBTTagCompound)
  {
    par1NBTTagCompound.a("xTile", (short)d);
    par1NBTTagCompound.a("yTile", (short)e);
    par1NBTTagCompound.a("zTile", (short)f);
    par1NBTTagCompound.a("inTile", (byte)g);
    par1NBTTagCompound.a("shake", (byte)a);
    par1NBTTagCompound.a("inGround", (byte)(h ? 1 : 0));
  }
  



  public void a(by par1NBTTagCompound)
  {
    d = par1NBTTagCompound.d("xTile");
    e = par1NBTTagCompound.d("yTile");
    f = par1NBTTagCompound.d("zTile");
    g = (par1NBTTagCompound.c("inTile") & 0xFF);
    a = (par1NBTTagCompound.c("shake") & 0xFF);
    h = (par1NBTTagCompound.c("inGround") == 1);
  }
  
  @SideOnly(Side.CLIENT)
  public float S()
  {
    return 0.0F;
  }
  
  public int c()
  {
    byte var1 = 0;
    
    if (c != null)
    {
      float asize = b.getSizeMultiplierRoot();
      float bsize = c.getSizeMultiplierRoot();
      double var2 = b.u - u;
      double var4 = b.v + 1.62D * b.getSizeMultiplier() - b.N - v;
      double var6 = b.w - w;
      double var8 = ls.a(var2 * var2 + var4 * var4 + var6 * var6);
      double var10 = 0.1D;
      
      if ((asize >= bsize) && (!q.I))
      {

        c.x += var2 * var10 * asize / bsize;
        c.y += var4 * var10 * asize / bsize + ls.a(var8) * 0.08D;
        c.z += var6 * var10 * asize / bsize;
      }
      
      if (b.isTiny())
      {
        if (q.I)
        {

          b.x -= var2 * var10 / asize;
          double rise = ls.a(var8) * 0.08D - var4 * var10 / asize;
          
          if ((var4 < -0.25D) && (rise > 0.0D) && (rise < 0.8D))
          {
            rise = 0.8D;
          }
          
          b.y += rise;
          b.z -= var6 * var10 / asize;
        }
        
        var1 = 2;
      }
      else
      {
        var1 = 3;
      }
    }
    else if (au > 0)
    {
      double var3 = b.u - u;
      double var5 = b.v + 1.62D * b.getSizeMultiplier() - b.N - v;
      double var7 = b.w - w;
      double var9 = ls.a(var3 * var3 + var5 * var5 + var7 * var7);
      
      if (!q.I)
      {
        double var11 = 0.1D;
        ss var13 = new ss(q, u, v, w, new ye(yc.aW));
        x = (var3 * var11);
        y = (var5 * var11 + ls.a(var9) * 0.08D);
        z = (var7 * var11);
        q.d(var13);
        b.a(la.B, 1);
        b.q.d(new oa(b.q, b.u, b.v + 0.5D, b.w + 0.5D, ab.nextInt(6) + 1));
        var1 = 1;
      }
      else if (b.isTiny())
      {


        b.x -= var3 / var9 / b.getSizeMultiplier() / 30.0D;
        b.y -= var5 / var9 / b.getSizeMultiplier() / 30.0D;
        b.z -= var7 / var9 / b.getSizeMultiplier() / 30.0D;
      }
      
      var1 = 1;
    }
    
    boolean fling = false;
    
    if ((q.I) && (!h) && (b.isTiny()) && (var1 == 0))
    {

      List var5 = q.b(this, E);
      
      for (int var8 = 0; (var8 < var5.size()) && (!fling); var8++)
      {
        nn var9 = (nn)var5.get(var8);
        
        if ((var9.L()) && (var9 != b) && (var9 != b.o))
        {
          fling = true;
        }
      }
    }
    
    if ((h) || (fling))
    {
      if ((q.I) && (b.isTiny()) && (b.o == null))
      {

        float asize = b.getSizeMultiplierRoot();
        double d = b.u - u;
        double d2 = b.v + 1.62D * b.getSizeMultiplier() - b.N - v;
        double d4 = b.w - w;
        double d6 = ls.a(d * d + d2 * d2 + d4 * d4);
        double d8 = 0.1D;
        b.x -= d * d8 / asize;
        double rise = ls.a(d6) * 0.08D - d2 * d8 / asize;
        
        if ((d2 < -0.25D) && (rise > 0.0D) && (rise < 0.8D))
        {
          rise = 0.8D;
        }
        
        b.y += rise;
        b.z -= d4 * d8 / asize;
      }
      
      var1 = 2;
    }
    
    if (q.I)
    {
      var1 = 0;
    }
    
    x();
    b.bM = null;
    return var1;
  }
  



  public void x()
  {
    super.x();
    
    if (b != null)
    {
      b.bM = null;
    }
  }
}
