import java.util.Random;
















public class tq
  extends tm
{
  private int bp;
  
  public tq(abw par1World)
  {
    super(par1World);
    a(0.3F, 0.7F);
    
    maxTargetSize = 1.5F;
  }
  
  protected void az()
  {
    super.az();
    a(tp.a).a(8.0D);
    a(tp.d).a(0.6000000238418579D);
    a(tp.e).a(1.0D);
  }
  




  protected boolean e_()
  {
    return false;
  }
  




  protected nn bL()
  {
    double d0 = 8.0D;
    return q.b(this, d0);
  }
  



  protected String r()
  {
    return "mob.silverfish.say";
  }
  



  protected String aO()
  {
    return "mob.silverfish.hit";
  }
  



  protected String aP()
  {
    return "mob.silverfish.kill";
  }
  



  public boolean a(nb par1DamageSource, float par2)
  {
    if (ar())
    {
      return false;
    }
    

    if ((bp <= 0) && (((par1DamageSource instanceof nc)) || (par1DamageSource == nb.k)))
    {
      bp = 20;
    }
    
    return super.a(par1DamageSource, par2);
  }
  




  protected void a(nn par1Entity, float par2)
  {
    if ((aC <= 0) && (par2 < 1.2F) && (E.e > E.b) && (E.b < E.e))
    {
      aC = 20;
      m(par1Entity);
    }
  }
  



  public asx getEntityCollisionBox()
  {
    return E.c();
  }
  



  public asx getEntityHitBox()
  {
    return E.c();
  }
  



  protected void a(int par1, int par2, int par3, int par4)
  {
    a("mob.silverfish.step", 0.15F, 1.0F);
  }
  



  protected int s()
  {
    return 0;
  }
  



  public double Y()
  {
    return 0.25D * getSizeMultiplier();
  }
  



  public void l_()
  {
    aN = A;
    super.l_();
  }
  
  protected void bl()
  {
    super.bl();
    
    if (!q.I)
    {





      boolean sizeok = (getSizeMultiplier() <= 1.0F) && (getSizeMultiplier() > 0.4F);
      
      if (bp > 0)
      {
        bp -= 1;
        
        if ((bp == 0) && (sizeok))
        {
          int i = ls.c(u);
          int j = ls.c(v);
          int k = ls.c(w);
          boolean flag = false;
          
          for (int l = 0; (!flag) && (l <= 5) && (l >= -5); l = l <= 0 ? 1 - l : 0 - l)
          {
            for (int i1 = 0; (!flag) && (i1 <= 10) && (i1 >= -10); i1 = i1 <= 0 ? 1 - i1 : 0 - i1)
            {
              for (int j1 = 0; (!flag) && (j1 <= 10) && (j1 >= -10); j1 = j1 <= 0 ? 1 - j1 : 0 - j1)
              {
                int k1 = q.a(i + i1, j + l, k + j1);
                
                if (k1 == bqcF)
                {
                  if (!q.O().b("mobGriefing"))
                  {
                    int l1 = q.h(i + i1, j + l, k + j1);
                    aqz block = aqz.y;
                    
                    if (l1 == 1)
                    {
                      block = aqz.B;
                    }
                    
                    if (l1 == 2)
                    {
                      block = aqz.br;
                    }
                    
                    q.f(i + i1, j + l, k + j1, cF, 0, 3);
                  }
                  else
                  {
                    q.a(i + i1, j + l, k + j1, false);
                  }
                  
                  aqz.bq.g(q, i + i1, j + l, k + j1, 0);
                  
                  if (ab.nextBoolean())
                  {
                    flag = true;
                    break;
                  }
                }
              }
            }
          }
        }
      }
      
      if ((this.j == null) && (!bM()))
      {
        int i = ls.c(u);
        int j = ls.c(v + 0.5D);
        int k = ls.c(w);
        int i2 = ab.nextInt(6);
        int l = q.a(i + s.b[i2], j + s.c[i2], k + s.d[i2]);
        
        if ((sizeok) && (aqs.d(l)))
        {
          q.f(i + s.b[i2], j + s.c[i2], k + s.d[i2], bqcF, aqs.e(l), 3);
          q();
          x();
        }
        else
        {
          bK();
        }
      }
      else if ((this.j != null) && (!bM()))
      {
        this.j = null;
      }
    }
  }
  




  public float a(int par1, int par2, int par3)
  {
    return q.a(par1, par2 - 1, par3) == ycF ? 10.0F : super.a(par1, par2, par3);
  }
  



  protected boolean i_()
  {
    return true;
  }
  



  public boolean bs()
  {
    if (super.bs())
    {
      uf entityplayer = q.a(this, 5.0D);
      return entityplayer == null;
    }
    

    return false;
  }
  




  public oj aY()
  {
    return oj.c;
  }
}
