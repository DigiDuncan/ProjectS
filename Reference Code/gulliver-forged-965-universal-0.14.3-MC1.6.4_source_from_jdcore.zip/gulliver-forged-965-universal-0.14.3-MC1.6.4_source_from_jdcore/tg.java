import java.util.List;
import java.util.Random;
import java.util.UUID;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.EventBus;
import net.minecraftforge.event.entity.living.EnderTeleportEvent;















public class tg
  extends tm
{
  private static final UUID bp = UUID.fromString("020E0DFB-87AE-4653-9556-831010E291A0");
  private static final ot bq = new ot(bp, "Attacking speed boost", 6.199999809265137D, 0).a(false);
  public static boolean[] br = new boolean['Ā'];
  

  private int bs;
  

  private int bt;
  

  private nn bu;
  
  private boolean bv;
  

  protected boolean canPickupThisBlock(int i)
  {
    return (br[i] != 0) && ((!isTiny()) || (scU == akc.k));
  }
  
  public tg(abw par1World)
  {
    super(par1World);
    a(0.6F, 2.9F);
    Y = 1.0F;
  }
  
  protected void az()
  {
    super.az();
    a(tp.a).a(40.0D);
    a(tp.d).a(0.30000001192092896D);
    a(tp.e).a(7.0D);
  }
  
  protected void a()
  {
    super.a();
    ah.a(16, new Byte((byte)0));
    ah.a(17, new Byte((byte)0));
    ah.a(18, new Byte((byte)0));
  }
  



  public void b(by par1NBTTagCompound)
  {
    super.b(par1NBTTagCompound);
    par1NBTTagCompound.a("carried", (short)bV());
    par1NBTTagCompound.a("carriedData", (short)bW());
  }
  



  public void a(by par1NBTTagCompound)
  {
    super.a(par1NBTTagCompound);
    a(par1NBTTagCompound.d("carried"));
    c(par1NBTTagCompound.d("carriedData"));
  }
  




  protected nn bL()
  {
    uf entityplayer = q.b(this, 64.0D);
    
    if (entityplayer != null)
    {
      if (f(entityplayer))
      {
        bv = true;
        
        if (bt == 0)
        {
          q.a(entityplayer, "mob.endermen.stare", 1.0F, 1.0F);
        }
        
        if (bt++ == 5)
        {
          bt = 0;
          a(true);
          return entityplayer;
        }
      }
      else
      {
        bt = 0;
      }
    }
    
    return null;
  }
  



  private boolean f(uf par1EntityPlayer)
  {
    ye itemstack = bn.b[3];
    
    if ((itemstack != null) && (d == bfcF))
    {
      return false;
    }
    

    atc vec3 = par1EntityPlayer.j(1.0F).a();
    atc vec31 = q.V().a(u - u, E.b + P / 2.0F - (v + par1EntityPlayer.f()), w - w);
    double d0 = vec31.b();
    vec31 = vec31.a();
    double d1 = vec3.b(vec31);
    return d1 > 1.0D - 0.025D / d0 ? par1EntityPlayer.o(this) : false;
  }
  





  public void c()
  {
    if (G())
    {
      a(nb.e, 1.0F);
    }
    
    if (bu != this.j)
    {
      os attributeinstance = a(tp.d);
      attributeinstance.b(bq);
      
      if (this.j != null)
      {
        attributeinstance.a(bq);
      }
    }
    
    bu = this.j;
    
    double drange = getRangeMultiplier();
    
    if ((!q.I) && (q.O().b("mobGriefing")))
    {




      if (bV() == 0)
      {
        if (ab.nextInt(20) == 0)
        {
          int i = ls.c(u - 2.0D * drange + ab.nextDouble() * 4.0D * drange);
          int j = ls.c(v + ab.nextDouble() * 3.0D * drange);
          int k = ls.c(w - 2.0D * drange + ab.nextDouble() * 4.0D * drange);
          int l = q.a(i, j, k);
          
          if (canPickupThisBlock(l))
          {
            a(q.a(i, j, k));
            c(q.h(i, j, k));
            q.c(i, j, k, 0);
          }
        }
      }
      else if (ab.nextInt(2000) == 0)
      {
        int i = ls.c(u - 1.0D * drange + ab.nextDouble() * 2.0D * drange);
        int j = ls.c(v + ab.nextDouble() * 2.0D * drange);
        int k = ls.c(w - 1.0D * drange + ab.nextDouble() * 2.0D * drange);
        int l = q.a(i, j, k);
        int i1 = q.a(i, j - 1, k);
        
        if ((l == 0) && (i1 > 0) && (aqz.s[i1].b()))
        {
          q.f(i, j, k, bV(), bW(), 3);
          a(0);
        }
      }
    }
    
    for (int i = 0; i < 2; i++)
    {
      q.a("portal", u + (ab.nextDouble() - 0.5D) * O, v + ab.nextDouble() * P - 0.25D, w + (ab.nextDouble() - 0.5D) * O, (ab.nextDouble() - 0.5D) * 2.0D, -ab.nextDouble(), (ab.nextDouble() - 0.5D) * 2.0D);
    }
    
    if ((q.v()) && (!q.I))
    {
      float f = d(1.0F);
      
      if ((f > 0.5F) && (q.l(ls.c(u), ls.c(v), ls.c(w))) && (ab.nextFloat() * 30.0F < (f - 0.4F) * 2.0F))
      {
        this.j = null;
        a(false);
        bv = false;
        bT();
      }
    }
    
    if ((G()) || (af()))
    {
      this.j = null;
      a(false);
      bv = false;
      bT();
    }
    
    if ((bX()) && (!bv) && (ab.nextInt(100) == 0))
    {
      a(false);
    }
    
    bd = false;
    
    if (this.j != null)
    {
      a(this.j, 100.0F, 100.0F);
    }
    
    if ((!q.I) && (T()))
    {
      if (this.j != null)
      {
        if (((this.j instanceof uf)) && (f((uf)this.j)))
        {
          if (this.j.e(this) < 16.0D)
          {
            bT();
          }
          
          bs = 0;
        }
        else if ((this.j.e(this) > 256.0D) && (bs++ >= 30) && (c(this.j)))
        {
          bs = 0;
        }
      }
      else
      {
        a(false);
        bs = 0;
      }
    }
    
    super.c();
  }
  




  protected boolean bT()
  {
    if ((n != null) && (ab.nextInt(4) != 0)) {
      return false;
    }
    double d0 = u + (ab.nextDouble() - 0.5D) * 64.0D;
    double d1 = v + (ab.nextInt(64) - 32);
    double d2 = w + (ab.nextDouble() - 0.5D) * 64.0D;
    return j(d0, d1, d2);
  }
  



  protected boolean c(nn par1Entity)
  {
    atc vec3 = q.V().a(u - u, E.b + P / 2.0F - v + par1Entity.f(), w - w);
    vec3 = vec3.a();
    double d0 = 16.0D;
    double d1 = u + (ab.nextDouble() - 0.5D) * 8.0D - c * d0;
    double d2 = v + (ab.nextInt(16) - 8) - d * d0;
    double d3 = w + (ab.nextDouble() - 0.5D) * 8.0D - e * d0;
    return j(d1, d2, d3);
  }
  



  protected boolean j(double par1, double par3, double par5)
  {
    EnderTeleportEvent event = new EnderTeleportEvent(this, par1, par3, par5, 0.0F);
    if (MinecraftForge.EVENT_BUS.post(event)) {
      return false;
    }
    
    double d3 = u;
    double d4 = v;
    double d5 = w;
    u = targetX;
    v = targetY;
    w = targetZ;
    boolean flag = false;
    int i = ls.c(u);
    int j = ls.c(v);
    int k = ls.c(w);
    

    if (q.f(i, j, k))
    {
      boolean flag1 = false;
      
      while ((!flag1) && (j > 0))
      {
        int l = q.a(i, j - 1, k);
        
        if ((l != 0) && (scU.c()))
        {
          flag1 = true;
        }
        else
        {
          v -= 1.0D;
          j--;
        }
      }
      
      if (flag1)
      {
        if (holdingEntity != null)
        {
          holdingEntity.dropHeldEntity(this);
        }
        
        if (o != null)
        {
          a(null);
        }
        
        b(u, v, w);
        
        if ((q.a(this, E).isEmpty()) && (!q.d(E)))
        {
          flag = true;
        }
      }
    }
    
    if (!flag)
    {
      if (holdingEntity != null)
      {
        holdingEntity.dropHeldEntity(this);
      }
      
      if (o != null)
      {
        a(null);
      }
      
      b(d3, d4, d5);
      return false;
    }
    

    short short1 = 128;
    
    for (int l = 0; l < short1; l++)
    {
      double d6 = l / (short1 - 1.0D);
      float f = (ab.nextFloat() - 0.5F) * 0.2F;
      float f1 = (ab.nextFloat() - 0.5F) * 0.2F;
      float f2 = (ab.nextFloat() - 0.5F) * 0.2F;
      double d7 = d3 + (u - d3) * d6 + (ab.nextDouble() - 0.5D) * O * 2.0D;
      double d8 = d4 + (v - d4) * d6 + ab.nextDouble() * P;
      double d9 = d5 + (w - d5) * d6 + (ab.nextDouble() - 0.5D) * O * 2.0D;
      q.a("portal", d7, d8, d9, f, f1, f2);
    }
    
    q.a(d3, d4, d5, "mob.endermen.portal", 1.0F, 1.0F);
    a("mob.endermen.portal", 1.0F, 1.0F);
    return true;
  }
  




  protected String r()
  {
    return bX() ? "mob.endermen.scream" : "mob.endermen.idle";
  }
  



  protected String aO()
  {
    return "mob.endermen.hit";
  }
  



  protected String aP()
  {
    return "mob.endermen.death";
  }
  



  protected int s()
  {
    return bpcv;
  }
  




  protected void b(boolean par1, int par2)
  {
    dropItemSizedAmount(par2 + 1, s(), 0, 0);
  }
  



  public void a(int par1)
  {
    ah.b(16, Byte.valueOf((byte)(par1 & 0xFF)));
  }
  



  public int bV()
  {
    return ah.a(16);
  }
  



  public void c(int par1)
  {
    ah.b(17, Byte.valueOf((byte)(par1 & 0xFF)));
  }
  



  public int bW()
  {
    return ah.a(17);
  }
  



  public boolean a(nb par1DamageSource, float par2)
  {
    if (ar())
    {
      return false;
    }
    

    a(true);
    
    if (((par1DamageSource instanceof nc)) && ((par1DamageSource.i() instanceof uf)))
    {
      bv = true;
    }
    
    if ((par1DamageSource instanceof nd))
    {
      bv = false;
      
      for (int i = 0; i < 64; i++)
      {
        if (bT())
        {
          return true;
        }
      }
      
      return super.a(par1DamageSource, par2);
    }
    

    return super.a(par1DamageSource, par2);
  }
  


  public boolean bX()
  {
    return ah.a(18) > 0;
  }
  
  public void a(boolean par1)
  {
    ah.b(18, Byte.valueOf((byte)(par1 ? 1 : 0)));
  }
  



  protected boolean t()
  {
    return n == null;
  }
  
  static
  {
    br[zcF] = true;
    br[AcF] = true;
    br[JcF] = true;
    br[KcF] = true;
    br[aicF] = true;
    br[ajcF] = true;
    br[akcF] = true;
    br[alcF] = true;
    br[arcF] = true;
    br[bacF] = true;
    br[bbcF] = true;
    br[bfcF] = true;
    br[bwcF] = true;
    br[bDcF] = true;
  }
}
