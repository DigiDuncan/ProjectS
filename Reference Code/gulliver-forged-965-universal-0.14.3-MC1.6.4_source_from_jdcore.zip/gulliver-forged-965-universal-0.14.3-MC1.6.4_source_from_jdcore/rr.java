















public class rr
  extends rp
{
  public rr(abw par1World)
  {
    super(par1World);
    a(0.9F, 1.3F);
    k().a(true);
    c.a(0, new pp(this));
    c.a(1, new qj(this, 2.0D));
    c.a(2, new pk(this, 1.0D));
    c.a(3, new qu(this, 1.25D, Vcv, false));
    c.a(4, new pr(this, 1.25D));
    c.a(5, new qm(this, 1.0D));
    c.a(6, new px(this, uf.class, 6.0F));
    c.a(7, new ql(this));
  }
  



  public boolean bf()
  {
    return true;
  }
  
  protected void az()
  {
    super.az();
    a(tp.a).a(10.0D);
    a(tp.d).a(0.20000000298023224D);
  }
  



  protected String r()
  {
    return "mob.cow.say";
  }
  



  protected String aO()
  {
    return "mob.cow.hurt";
  }
  



  protected String aP()
  {
    return "mob.cow.hurt";
  }
  



  protected void a(int par1, int par2, int par3, int par4)
  {
    a("mob.cow.step", 0.15F, 1.0F);
  }
  



  protected float ba()
  {
    return 0.4F;
  }
  



  protected int s()
  {
    return aHcv;
  }
  



  protected int getMeatItemId()
  {
    return bkcv;
  }
  



  protected int getCookedMeatItemId()
  {
    return blcv;
  }
  



  public boolean a(uf par1EntityPlayer)
  {
    ye itemstack = bn.h();
    
    if ((itemstack != null) && (d == aycv) && (!bG.d))
    {
      if (b-- == 1)
      {
        bn.a(bn.c, new ye(yc.aI));
      }
      else if (!bn.a(new ye(yc.aI)))
      {
        par1EntityPlayer.b(new ye(aIcv, 1, 0));
      }
      
      return true;
    }
    

    return super.a(par1EntityPlayer);
  }
  




  public double Y()
  {
    if (!g_())
    {
      return P * 0.91D;
    }
    

    return P * 0.74D;
  }
  




  public rr b(nk par1EntityAgeable)
  {
    return new rr(q);
  }
  
  public nk a(nk par1EntityAgeable)
  {
    return b(par1EntityAgeable);
  }
}
