import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import gulliver.common.GulliverEnvoy;
import gulliver.common.GulliverOMHelper;
import java.util.Random;














public class anz
  extends aqz
{
  @SideOnly(Side.CLIENT)
  private ms[] a;
  @SideOnly(Side.CLIENT)
  private ms[] b;
  
  protected anz(int par1, akc par2Material)
  {
    super(par1, par2Material);
    float f = 0.5F;
    float f1 = 1.0F;
    a(0.5F - f, 0.0F, 0.5F - f, 0.5F + f, f1, 0.5F + f);
  }
  




  @SideOnly(Side.CLIENT)
  public ms a(int par1, int par2)
  {
    return b[0];
  }
  




  @SideOnly(Side.CLIENT)
  public ms b_(acf par1IBlockAccess, int par2, int par3, int par4, int par5)
  {
    if ((par5 != 1) && (par5 != 0))
    {
      int i1 = c_(par1IBlockAccess, par2, par3, par4);
      int j1 = i1 & 0x3;
      boolean flag = (i1 & 0x4) != 0;
      boolean flag1 = false;
      boolean flag2 = (i1 & 0x8) != 0;
      
      if (flag)
      {
        if ((j1 == 0) && (par5 == 2))
        {
          flag1 = !flag1;
        }
        else if ((j1 == 1) && (par5 == 5))
        {
          flag1 = !flag1;
        }
        else if ((j1 == 2) && (par5 == 3))
        {
          flag1 = !flag1;
        }
        else if ((j1 == 3) && (par5 == 4))
        {
          flag1 = !flag1;
        }
      }
      else
      {
        if ((j1 == 0) && (par5 == 5))
        {
          flag1 = !flag1;
        }
        else if ((j1 == 1) && (par5 == 3))
        {
          flag1 = !flag1;
        }
        else if ((j1 == 2) && (par5 == 4))
        {
          flag1 = !flag1;
        }
        else if ((j1 == 3) && (par5 == 2))
        {
          flag1 = !flag1;
        }
        
        if ((i1 & 0x10) != 0)
        {
          flag1 = !flag1;
        }
      }
      
      return flag2 ? a[0] : b[0];
    }
    

    return b[0];
  }
  






  @SideOnly(Side.CLIENT)
  public void a(mt par1IconRegister)
  {
    a = new ms[2];
    b = new ms[2];
    a[0] = par1IconRegister.a(E() + "_upper");
    b[0] = par1IconRegister.a(E() + "_lower");
    a[1] = new mr(a[0], true, false);
    b[1] = new mr(b[0], true, false);
  }
  




  public boolean c()
  {
    return false;
  }
  
  public boolean b(acf par1IBlockAccess, int par2, int par3, int par4)
  {
    int l = c_(par1IBlockAccess, par2, par3, par4);
    return (l & 0x4) != 0;
  }
  



  public boolean b()
  {
    return false;
  }
  



  public int d()
  {
    return 7;
  }
  




  @SideOnly(Side.CLIENT)
  public asx c_(abw par1World, int par2, int par3, int par4)
  {
    a(par1World, par2, par3, par4);
    return super.c_(par1World, par2, par3, par4);
  }
  




  public asx b(abw par1World, int par2, int par3, int par4)
  {
    a(par1World, par2, par3, par4);
    return super.b(par1World, par2, par3, par4);
  }
  



  public void a(acf par1IBlockAccess, int par2, int par3, int par4)
  {
    d(c_(par1IBlockAccess, par2, par3, par4));
  }
  



  public int d(acf par1IBlockAccess, int par2, int par3, int par4)
  {
    return c_(par1IBlockAccess, par2, par3, par4) & 0x3;
  }
  
  public boolean b_(acf par1IBlockAccess, int par2, int par3, int par4)
  {
    return (c_(par1IBlockAccess, par2, par3, par4) & 0x4) != 0;
  }
  
  private void d(int par1)
  {
    float f = 0.1875F;
    a(0.0F, 0.0F, 0.0F, 1.0F, 2.0F, 1.0F);
    int j = par1 & 0x3;
    boolean flag = (par1 & 0x4) != 0;
    boolean flag1 = (par1 & 0x10) != 0;
    
    if (j == 0)
    {
      if (flag)
      {
        if (!flag1)
        {
          a(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, f);
        }
        else
        {
          a(0.0F, 0.0F, 1.0F - f, 1.0F, 1.0F, 1.0F);
        }
        
      }
      else {
        a(0.0F, 0.0F, 0.0F, f, 1.0F, 1.0F);
      }
    }
    else if (j == 1)
    {
      if (flag)
      {
        if (!flag1)
        {
          a(1.0F - f, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
        }
        else
        {
          a(0.0F, 0.0F, 0.0F, f, 1.0F, 1.0F);
        }
        
      }
      else {
        a(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, f);
      }
    }
    else if (j == 2)
    {
      if (flag)
      {
        if (!flag1)
        {
          a(0.0F, 0.0F, 1.0F - f, 1.0F, 1.0F, 1.0F);
        }
        else
        {
          a(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, f);
        }
        
      }
      else {
        a(1.0F - f, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
      }
    }
    else if (j == 3)
    {
      if (flag)
      {
        if (!flag1)
        {
          a(0.0F, 0.0F, 0.0F, f, 1.0F, 1.0F);
        }
        else
        {
          a(1.0F - f, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
        }
        
      }
      else {
        a(0.0F, 0.0F, 1.0F - f, 1.0F, 1.0F, 1.0F);
      }
    }
  }
  



  public void a(abw par1World, int par2, int par3, int par4, uf par5EntityPlayer) {}
  



  public boolean a(abw par1World, int par2, int par3, int par4, uf par5EntityPlayer, int par6, float par7, float par8, float par9)
  {
    if (cU == akc.f)
    {
      return false;
    }
    

    int i1 = c_(par1World, par2, par3, par4);
    

    if ((!GulliverOMHelper.isLittleBlocksWorld(par1World)) && ((((i1 & 0x8) == 0) && (!GulliverEnvoy.canOpenDoubleBlock(par5EntityPlayer))) || (((i1 & 0x8) != 0) && (!GulliverEnvoy.canOpenSingleBlock(par5EntityPlayer)))))
    {
      return false;
    }
    
    int j1 = i1 & 0x7;
    j1 ^= 0x4;
    
    if ((i1 & 0x8) == 0)
    {
      par1World.b(par2, par3, par4, j1, 2);
      par1World.g(par2, par3, par4, par2, par3, par4);
    }
    else
    {
      par1World.b(par2, par3 - 1, par4, j1, 2);
      par1World.g(par2, par3 - 1, par4, par2, par3, par4);
    }
    
    par1World.a(par5EntityPlayer, 1003, par2, par3, par4, 0);
    return true;
  }
  




  public void a(abw par1World, int par2, int par3, int par4, boolean par5)
  {
    int l = c_(par1World, par2, par3, par4);
    boolean flag1 = (l & 0x4) != 0;
    
    if (flag1 != par5)
    {
      int i1 = l & 0x7;
      i1 ^= 0x4;
      
      if ((l & 0x8) == 0)
      {
        par1World.b(par2, par3, par4, i1, 2);
        par1World.g(par2, par3, par4, par2, par3, par4);
      }
      else
      {
        par1World.b(par2, par3 - 1, par4, i1, 2);
        par1World.g(par2, par3 - 1, par4, par2, par3, par4);
      }
      
      par1World.a((uf)null, 1003, par2, par3, par4, 0);
    }
  }
  




  public void a(abw par1World, int par2, int par3, int par4, int par5)
  {
    int i1 = par1World.h(par2, par3, par4);
    
    if ((i1 & 0x8) == 0)
    {
      boolean flag = false;
      
      if (par1World.a(par2, par3 + 1, par4) != cF)
      {
        par1World.i(par2, par3, par4);
        flag = true;
      }
      
      if (!par1World.w(par2, par3 - 1, par4))
      {
        par1World.i(par2, par3, par4);
        flag = true;
        
        if (par1World.a(par2, par3 + 1, par4) == cF)
        {
          par1World.i(par2, par3 + 1, par4);
        }
      }
      
      if (flag)
      {
        if (!I)
        {
          c(par1World, par2, par3, par4, i1, 0);
        }
      }
      else
      {
        boolean flag1 = (par1World.C(par2, par3, par4)) || (par1World.C(par2, par3 + 1, par4));
        
        if (((flag1) || ((par5 > 0) && (aqz.s[par5].f()))) && (par5 != cF))
        {
          a(par1World, par2, par3, par4, flag1);
        }
      }
    }
    else
    {
      if (par1World.a(par2, par3 - 1, par4) != cF)
      {
        par1World.i(par2, par3, par4);
      }
      
      if ((par5 > 0) && (par5 != cF))
      {
        a(par1World, par2, par3 - 1, par4, par5);
      }
    }
  }
  



  public int a(int par1, Random par2Random, int par3)
  {
    return cU == akc.f ? aDcv : (par1 & 0x8) != 0 ? 0 : axcv;
  }
  




  public ata a(abw par1World, int par2, int par3, int par4, atc par5Vec3, atc par6Vec3)
  {
    a(par1World, par2, par3, par4);
    return super.a(par1World, par2, par3, par4, par5Vec3, par6Vec3);
  }
  



  public boolean c(abw par1World, int par2, int par3, int par4)
  {
    return par3 < par1World.R() - 1;
  }
  




  public int h()
  {
    return 1;
  }
  



  public int c_(acf par1IBlockAccess, int par2, int par3, int par4)
  {
    int l = par1IBlockAccess.h(par2, par3, par4);
    boolean flag = (l & 0x8) != 0;
    int j1;
    int i1;
    int j1;
    if (flag)
    {
      int i1 = par1IBlockAccess.h(par2, par3 - 1, par4);
      j1 = l;
    }
    else
    {
      i1 = l;
      j1 = par1IBlockAccess.h(par2, par3 + 1, par4);
    }
    
    boolean flag1 = (j1 & 0x1) != 0;
    return i1 & 0x7 | (flag ? 8 : 0) | (flag1 ? 16 : 0);
  }
  




  @SideOnly(Side.CLIENT)
  public int d(abw par1World, int par2, int par3, int par4)
  {
    return cU == akc.f ? aDcv : axcv;
  }
  



  public void a(abw par1World, int par2, int par3, int par4, int par5, uf par6EntityPlayer)
  {
    if ((bG.d) && ((par5 & 0x8) != 0) && (par1World.a(par2, par3 - 1, par4) == cF))
    {
      par1World.i(par2, par3 - 1, par4);
    }
  }
}
