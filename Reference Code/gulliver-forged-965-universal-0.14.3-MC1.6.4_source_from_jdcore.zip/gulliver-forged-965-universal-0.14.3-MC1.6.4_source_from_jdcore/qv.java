




public class qv
  extends ps
{
  private ub a;
  
  public qv(ub par1EntityVillager)
  {
    a = par1EntityVillager;
    a(5);
  }
  



  public boolean a()
  {
    if (!a.T())
    {
      return false;
    }
    if (a.H())
    {
      return false;
    }
    if (!a.F)
    {
      return false;
    }
    if (a.J)
    {
      return false;
    }
    

    uf entityplayer = a.m_();
    
    if (entityplayer == null)
    {
      return false;
    }
    if (!a.couldTradeWith(entityplayer))
    {
      return false;
    }
    
    return a.e(entityplayer) > 16.0D * a.getSizeMultiplier() ? false : bp instanceof uy;
  }
  




  public void c()
  {
    a.k().h();
  }
  



  public void d()
  {
    a.a_((uf)null);
  }
}
