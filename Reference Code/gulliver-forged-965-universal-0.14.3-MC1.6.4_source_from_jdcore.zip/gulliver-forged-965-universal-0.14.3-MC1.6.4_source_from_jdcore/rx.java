import java.util.List;
import java.util.Random;




























public class rx
  extends oq
{
  private qu bq;
  
  public rx(abw par1World)
  {
    super(par1World);
    a(0.6F, 0.8F);
    minLookSize = (this.minTargetSize = 0.1F);
    maxTargetSize = 0.3F;
    maxLookSize = 10.0F;
    k().a(true);
    c.a(1, new pp(this));
    c.a(2, bp.setTargetSizeRange(0.3F, 0.0F));
    c.a(3, this.bq = new qu(this, 0.6000000238418579D, aWcv, true));
    
    c.a(4, new pg(this, uf.class, 16.0F, 0.8D, 1.33D).setTargetSizeRange(maxTargetSize, maxLookSize));
    c.a(5, new pq(this, 1.0D, 10.0F, 5.0F).setTargetSizeRange(0.3F, 0.0F));
    c.a(6, new pw(this, 0.3F));
    c.a(7, new qf(this));
    c.a(8, new qg(this, 1.3300000429153442D));
    c.a(9, new pk(this, 0.8D));
    c.a(10, new qm(this, 0.8D));
    c.a(11, new px(this, uf.class, 10.0F));
    
    d.a(1, new rb(this, rq.class, 750, false).setTargetSizeRange(maxTargetSize, 1.0F));
    
    d.a(2, new qy(this, on.class, 400, false).setCanTargetOwner(true));
    d.a(3, new qy(this, uf.class, 400, false).setCanTargetOwner(true));
  }
  
  protected void a()
  {
    super.a();
    ah.a(18, Byte.valueOf((byte)0));
  }
  



  public void bk()
  {
    if (i().a())
    {
      double d0 = i().b();
      
      if (d0 == 0.6D)
      {
        b(true);
        c(false);
      }
      else if (d0 == 1.33D)
      {
        b(false);
        c(true);
      }
      else
      {
        b(false);
        c(false);
      }
    }
    else
    {
      b(false);
      c(false);
    }
  }
  



  protected boolean t()
  {
    return (!bT()) && (ac > 2400);
  }
  



  public boolean bf()
  {
    return true;
  }
  
  protected void az()
  {
    super.az();
    a(tp.a).a(10.0D);
    a(tp.d).a(0.30000001192092896D);
  }
  



  protected void b(float par1)
  {
    if ((n != null) && ((n instanceof uf)) && (par1 > n.P * 6.0F))
    {
      ((uf)n).maybeKnockoff();
    }
  }
  



  public void b(by par1NBTTagCompound)
  {
    super.b(par1NBTTagCompound);
    par1NBTTagCompound.a("CatType", ca());
  }
  



  public void a(by par1NBTTagCompound)
  {
    super.a(par1NBTTagCompound);
    p(par1NBTTagCompound.e("CatType"));
  }
  



  protected String r()
  {
    return bT() ? "mob.cat.meow" : ab.nextInt(4) == 0 ? "mob.cat.purreow" : bY() ? "mob.cat.purr" : "";
  }
  



  protected String aO()
  {
    return "mob.cat.hitt";
  }
  



  protected String aP()
  {
    return "mob.cat.hitt";
  }
  



  protected float ba()
  {
    return 0.4F;
  }
  



  protected int s()
  {
    return aHcv;
  }
  

  public boolean m(nn par1Entity)
  {
    float var2 = (bT()) && (isEntityInRelativeSizeRange(par1Entity, minTargetSize, maxTargetSize)) ? 1.0F : 3.0F;
    return par1Entity.a(nb.a(this), var2);
  }
  



  public boolean a(nb par1DamageSource, float par2)
  {
    if (ar())
    {
      return false;
    }
    

    bp.a(false);
    return super.a(par1DamageSource, par2);
  }
  




  protected void b(boolean par1, int par2) {}
  




  public boolean a(uf par1EntityPlayer)
  {
    ye itemstack = bn.h();
    
    if (bT())
    {
      if ((holdingEntity == null) && (bn.h() == null) && (!par1EntityPlayer.ah()) && (itemstack == null) && (n == null) && (bU()) && (isEntityInRelativeSizeRange(par1EntityPlayer, 0.0F, 0.65F)) && (o == null) && (getEyeDistanceToEntityLiving(par1EntityPlayer) <= O * 1.5F) && ((n == null) || (n.isTinierThan(par1EntityPlayer))))
      {

        if (!q.I)
        {
          par1EntityPlayer.a(this);
        }
        
        return true;
      }
      if ((par1EntityPlayer.c_().equalsIgnoreCase(h_())) && (isEntityInRelativeSizeRange(par1EntityPlayer, 0.3F, 0.0F)) && (!q.I) && (!c(itemstack)))
      {
        bp.a(!bU());
      }
      

    }
    else if ((itemstack != null) && (d == aWcv))
    {
      if ((bq.f()) && (itemstack != null) && (par1EntityPlayer.e(this) < 9.0D * getRangeMultiplier()))
      {
        b -= 1;
        
        if (b <= 0)
        {
          bn.a(bn.c, (ye)null);
        }
        
        if (!q.I)
        {
          if (ab.nextInt(3) == 0)
          {
            j(true);
            p(1 + q.s.nextInt(3));
            b(par1EntityPlayer.c_());
            i(true);
            bp.a(true);
            q.a(this, (byte)7);
          }
          else
          {
            i(false);
            q.a(this, (byte)6);
          }
        }
      }
      
      return true;
    }
    

    return super.a(par1EntityPlayer);
  }
  



  public double Y()
  {
    double offset = P * 0.5D;
    
    if (ah())
    {
      offset *= 0.8D;
    }
    
    if (g_())
    {
      offset *= 0.35D;
    }
    
    if (bT())
    {
      offset *= 0.7D;
    }
    
    return offset;
  }
  



  public rx b(nk par1EntityAgeable)
  {
    rx entityocelot = new rx(q);
    
    if (bT())
    {
      entityocelot.b(h_());
      entityocelot.j(true);
      entityocelot.p(ca());
    }
    
    return entityocelot;
  }
  




  public boolean c(ye par1ItemStack)
  {
    return (par1ItemStack != null) && (d == aWcv);
  }
  



  public boolean a(rp par1EntityAnimal)
  {
    if (par1EntityAnimal == this)
    {
      return false;
    }
    if (!bT())
    {
      return false;
    }
    if (!(par1EntityAnimal instanceof rx))
    {
      return false;
    }
    

    rx entityocelot = (rx)par1EntityAnimal;
    return entityocelot.bT();
  }
  

  public int ca()
  {
    return ah.a(18);
  }
  
  public void p(int par1)
  {
    ah.b(18, Byte.valueOf((byte)par1));
  }
  



  public boolean bs()
  {
    if (q.s.nextInt(3) == 0)
    {
      return false;
    }
    

    if ((q.b(E)) && (q.a(this, E).isEmpty()) && (!q.d(E)))
    {
      int i = ls.c(u);
      int j = ls.c(E.b);
      int k = ls.c(w);
      
      if (j < 63)
      {
        return false;
      }
      
      int l = q.a(i, j - 1, k);
      aqz block = aqz.s[l];
      
      if ((l == zcF) || ((block != null) && (block.isLeaves(q, i, j - 1, k))))
      {
        return true;
      }
    }
    
    return false;
  }
  




  public String an()
  {
    return bT() ? "entity.Cat.name" : bB() ? bA() : super.an();
  }
  
  public oi a(oi par1EntityLivingData)
  {
    par1EntityLivingData = super.a(par1EntityLivingData);
    
    if (q.s.nextInt(7) == 0)
    {
      for (int i = 0; i < 2; i++)
      {
        rx entityocelot = new rx(q);
        entityocelot.b(u, v, w, A, 0.0F);
        entityocelot.c(41536);
        q.d(entityocelot);
      }
    }
    
    return par1EntityLivingData;
  }
  
  public nk a(nk par1EntityAgeable)
  {
    return b(par1EntityAgeable);
  }
}
