




























public class qu
  extends ps
{
  private on a;
  private double b;
  private double c;
  private double d;
  private double e;
  private double f;
  private double g;
  private uf h;
  private int i;
  private boolean j;
  private int k;
  private boolean l;
  private boolean m;
  
  public qu(on par1EntityCreature, double par2, int par4, boolean par5)
  {
    a = par1EntityCreature;
    b = par2;
    k = par4;
    l = par5;
    
    minTargetSize = 0.2F;
    maxTargetSize = 5.0F;
    a(3);
  }
  



  public boolean a()
  {
    if (i > 0)
    {
      i -= 1;
      return false;
    }
    

    h = a.q.getClosestVisibleSizedPlayerToEntity(a, 2.0D + 8.0D * a.getRangeMultiplier(), minTargetSize, maxTargetSize);
    
    if (h == null)
    {
      return false;
    }
    

    ye itemstack = h.by();
    return itemstack != null;
  }
  





  public boolean b()
  {
    if (l)
    {
      float rangefactor = (a.getRangeMultiplier() + h.getRangeMultiplier()) / 2.0F;
      
      if (a.e(h) < 36.0D * rangefactor * rangefactor)
      {
        if (h.e(c, d, e) > 0.010000000000000002D * h.getRangeMultiplier())
        {
          return false;
        }
        
        if ((Math.abs(h.B - f) > 5.0D) || (Math.abs(h.A - g) > 5.0D))
        {
          return false;
        }
      }
      else
      {
        c = h.u;
        d = h.v;
        e = h.w;
      }
      
      f = h.B;
      g = h.A;
    }
    
    return a();
  }
  



  public void c()
  {
    c = h.u;
    d = h.v;
    e = h.w;
    j = true;
    m = a.k().a();
    a.k().a(false);
  }
  



  public void d()
  {
    h = null;
    a.k().h();
    i = 100;
    j = false;
    a.k().a(m);
  }
  



  public void e()
  {
    a.h().a(h, 30.0F, a.bp());
    
    float rangefactor = (a.getRangeMultiplier() + h.getRangeMultiplier()) / 2.0F;
    
    if ((a.e(h) < 6.25D * rangefactor * rangefactor) && ((!a.isTiny()) || (a.o(h))))
    {
      a.k().h();
    }
    else
    {
      a.k().a(h, b);
    }
  }
  



  public boolean f()
  {
    return j;
  }
}
