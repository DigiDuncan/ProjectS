import com.google.common.collect.Maps;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.UUID;












public class ni
{
  public static final ni[] a = new ni[32];
  public static final ni b = null;
  public static final ni c = new ni(1, false, 8171462).b("potion.moveSpeed").b(0, 0).a(tp.d, "91AEAA56-376B-4498-935B-2F7F68070635", 0.20000000298023224D, 2);
  public static final ni d = new ni(2, true, 5926017).b("potion.moveSlowdown").b(1, 0).a(tp.d, "7107DE5E-7CE8-4030-940E-514C1F160890", -0.15000000596046448D, 2);
  public static final ni e = new ni(3, false, 14270531).b("potion.digSpeed").b(2, 0).a(1.5D);
  public static final ni f = new ni(4, true, 4866583).b("potion.digSlowDown").b(3, 0);
  public static final ni g = new nf(5, false, 9643043).b("potion.damageBoost").b(4, 0).a(tp.e, "648D7064-6A60-4F59-8ABE-C2C23A6DD7A9", 3.0D, 2);
  public static final ni h = new nh(6, false, 16262179).b("potion.heal");
  public static final ni i = new nh(7, true, 4393481).b("potion.harm");
  public static final ni j = new ni(8, false, 7889559).b("potion.jump").b(2, 1);
  public static final ni k = new ni(9, true, 5578058).b("potion.confusion").b(3, 1).a(0.25D);
  

  public static final ni l = new ni(10, false, 13458603).b("potion.regeneration").b(7, 0).a(0.25D);
  public static final ni m = new ni(11, false, 10044730).b("potion.resistance").b(6, 1);
  

  public static final ni n = new ni(12, false, 14981690).b("potion.fireResistance").b(7, 1);
  

  public static final ni o = new ni(13, false, 3035801).b("potion.waterBreathing").b(0, 2);
  

  public static final ni p = new ni(14, false, 8356754).b("potion.invisibility").b(0, 1);
  

  public static final ni q = new ni(15, true, 2039587).b("potion.blindness").b(5, 1).a(0.25D);
  

  public static final ni r = new ni(16, false, 2039713).b("potion.nightVision").b(4, 1);
  

  public static final ni s = new ni(17, true, 5797459).b("potion.hunger").b(1, 1);
  

  public static final ni t = new nf(18, true, 4738376).b("potion.weakness").b(5, 0).a(tp.e, "22653B89-116E-49DC-9B6B-9971489B5BE5", 2.0D, 0);
  

  public static final ni u = new ni(19, true, 5149489).b("potion.poison").b(6, 0).a(0.25D);
  

  public static final ni v = new ni(20, true, 3484199).b("potion.wither").b(1, 2).a(0.25D);
  public static final ni w = new ng(21, false, 16284963).b("potion.healthBoost").b(2, 2).a(tp.a, "5D6F0BA2-1186-46AC-B896-C61C5CEE99CC", 4.0D, 0);
  public static final ni x = new ne(22, false, 2445989).b("potion.absorption").b(2, 2);
  public static final ni y = new nh(23, false, 16262179).b("potion.saturation");
  public static final ni z = null;
  public static final ni A = null;
  public static final ni B = null;
  public static final ni C = null;
  public static final ni D = null;
  public static final ni E = null;
  public static final ni F = null;
  public static final ni G = null;
  
  public final int H;
  
  private final Map I = Maps.newHashMap();
  


  private final boolean J;
  


  private final int K;
  

  private String L = "";
  

  private int M = -1;
  private double N;
  private boolean O;
  
  protected ni(int par1, boolean par2, int par3)
  {
    H = par1;
    a[par1] = this;
    J = par2;
    
    if (par2)
    {
      N = 0.5D;
    }
    else
    {
      N = 1.0D;
    }
    
    K = par3;
  }
  



  public ni b(int par1, int par2)
  {
    M = (par1 + par2 * 8);
    return this;
  }
  



  public int c()
  {
    return H;
  }
  
  public void a(of par1EntityLivingBase, int par2)
  {
    if (H == lH)
    {
      if (par1EntityLivingBase.aN() < par1EntityLivingBase.aT())
      {
        par1EntityLivingBase.f(1.0F);
      }
    }
    else if (H == uH)
    {
      if (par1EntityLivingBase.aN() > 1.0F)
      {
        par1EntityLivingBase.a(nb.k, 1.0F);
      }
    }
    else if (H == vH)
    {
      par1EntityLivingBase.a(nb.l, 1.0F);
    }
    else if ((H == sH) && ((par1EntityLivingBase instanceof uf)))
    {
      ((uf)par1EntityLivingBase).a(0.025F * (par2 + 1));
    }
    else if ((H == yH) && ((par1EntityLivingBase instanceof uf)))
    {
      if (!q.I)
      {
        ((uf)par1EntityLivingBase).bI().a(par2 + 1, 1.0F);
      }
    }
    else if (((H != hH) || (par1EntityLivingBase.aM())) && ((H != iH) || (!par1EntityLivingBase.aM())))
    {
      if (((H == iH) && (!par1EntityLivingBase.aM())) || ((H == hH) && (par1EntityLivingBase.aM())))
      {
        par1EntityLivingBase.a(nb.k, 6 << par2);
      }
      
    }
    else {
      par1EntityLivingBase.f(Math.max(4 << par2, 0));
    }
  }
  





  public void a(of par1EntityLivingBase, of par2EntityLivingBase, int par3, double par4)
  {
    if (((H != hH) || (par2EntityLivingBase.aM())) && ((H != iH) || (!par2EntityLivingBase.aM())))
    {
      if (((H == iH) && (!par2EntityLivingBase.aM())) || ((H == hH) && (par2EntityLivingBase.aM())))
      {
        int j = (int)(par4 * (6 << par3) + 0.5D);
        
        if (par1EntityLivingBase == null)
        {
          par2EntityLivingBase.a(nb.k, j);
        }
        else
        {
          par2EntityLivingBase.a(nb.b(par2EntityLivingBase, par1EntityLivingBase), j);
        }
      }
    }
    else
    {
      int j = (int)(par4 * (4 << par3) + 0.5D);
      par2EntityLivingBase.f(j);
    }
  }
  



  public boolean b()
  {
    return false;
  }
  





  public boolean a(int par1, int par2)
  {
    if (H == lH)
    {
      int k = par2 >= 0 ? 50 >> par2 : 50 << -par2;
      return par1 % k == 0;
    }
    if (H == uH)
    {
      int k = par2 >= 0 ? 25 >> par2 : 25 << -par2;
      return par1 % k == 0;
    }
    if (H == vH)
    {
      int k = par2 >= 0 ? 40 >> par2 : 40 << -par2;
      return par1 % k == 0;
    }
    

    return H == sH;
  }
  


  public void finishEffect(of par1EntityLivingBase) {}
  


  public ni b(String par1Str)
  {
    L = par1Str;
    return this;
  }
  



  public String a()
  {
    return L;
  }
  
  protected ni a(double par1)
  {
    N = par1;
    return this;
  }
  




  @SideOnly(Side.CLIENT)
  public boolean d()
  {
    return M >= 0;
  }
  




  @SideOnly(Side.CLIENT)
  public int e()
  {
    return M;
  }
  




  @SideOnly(Side.CLIENT)
  public boolean f()
  {
    return J;
  }
  
  @SideOnly(Side.CLIENT)
  public static String a(nj par0PotionEffect)
  {
    if (par0PotionEffect.g())
    {
      return "**:**";
    }
    

    int i = par0PotionEffect.b();
    return ma.a(i);
  }
  

  public double g()
  {
    return N;
  }
  
  public boolean i()
  {
    return O;
  }
  



  public int j()
  {
    return K;
  }
  
  public ni a(or par1Attribute, String par2Str, double par3, int par5)
  {
    ot attributemodifier = new ot(UUID.fromString(par2Str), a(), par3, par5);
    I.put(par1Attribute, attributemodifier);
    return this;
  }
  
  public void a(of par1EntityLivingBase, ov par2BaseAttributeMap, int par3)
  {
    Iterator iterator = I.entrySet().iterator();
    
    while (iterator.hasNext())
    {
      Map.Entry entry = (Map.Entry)iterator.next();
      os attributeinstance = par2BaseAttributeMap.a((or)entry.getKey());
      
      if (attributeinstance != null)
      {
        attributeinstance.b((ot)entry.getValue());
      }
    }
  }
  
  @SideOnly(Side.CLIENT)
  public Map k()
  {
    return I;
  }
  
  public void b(of par1EntityLivingBase, ov par2BaseAttributeMap, int par3)
  {
    Iterator iterator = I.entrySet().iterator();
    
    while (iterator.hasNext())
    {
      Map.Entry entry = (Map.Entry)iterator.next();
      os attributeinstance = par2BaseAttributeMap.a((or)entry.getKey());
      
      if (attributeinstance != null)
      {
        ot attributemodifier = (ot)entry.getValue();
        attributeinstance.b(attributemodifier);
        attributeinstance.a(new ot(attributemodifier.a(), a() + " " + par3, a(par3, attributemodifier), attributemodifier.c()));
      }
    }
  }
  
  public double a(int par1, ot par2AttributeModifier)
  {
    return par2AttributeModifier.d() * (par1 + 1);
  }
}
