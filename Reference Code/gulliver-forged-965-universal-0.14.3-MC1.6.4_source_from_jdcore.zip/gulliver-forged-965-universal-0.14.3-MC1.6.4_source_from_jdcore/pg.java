import gulliver.common.GulliverEnvoy;
import java.util.List;











public class pg
  extends ps
{
  public final nw a = new ph(this);
  
  private on b;
  
  private double c;
  
  private double d;
  
  private nn e;
  
  private float f;
  
  private alf g;
  
  private rf h;
  
  private Class i;
  
  public pg(on par1EntityCreature, Class par2Class, float par3, double par4, double par6)
  {
    b = par1EntityCreature;
    i = par2Class;
    f = par3;
    c = par4;
    d = par6;
    h = par1EntityCreature.k();
    minTargetSize = b.minLookSize;
    maxTargetSize = b.maxLookSize;
    a(1);
  }
  



  public boolean a()
  {
    float rangefactor = b.getRangeMultiplier();
    
    if (i == uf.class)
    {
      if (((b instanceof oq)) && (((oq)b).bT()))
      {
        return false;
      }
      
      e = b.q.getClosestSizedPlayerToEntity(b, f * rangefactor, minTargetSize, maxTargetSize);
      
      if (e == null)
      {
        return false;
      }
    }
    else
    {
      double ycheck = 3.0D;
      
      if (minTargetSize > 1.0F)
      {
        ycheck *= minTargetSize;
      }
      
      List list = b.q.a(i, b.E.b(f * rangefactor, ycheck, f * rangefactor), a);
      GulliverEnvoy.pruneSmallerEntities(minTargetSize * b.getSizeMultiplier(), list);
      GulliverEnvoy.pruneLargerEntities(maxTargetSize * b.getSizeMultiplier(), list);
      
      if (list.isEmpty())
      {
        return false;
      }
      
      e = ((nn)list.get(0));
    }
    
    atc vec3 = rh.b(b, 16, 7, b.q.V().a(e.u, e.v, e.w));
    
    if (vec3 == null)
    {
      return false;
    }
    if (e.e(c, d, e) < e.e(b))
    {
      return false;
    }
    

    g = h.a(c, d, e);
    return g == null ? false : g.b(vec3);
  }
  




  public boolean b()
  {
    return !h.g();
  }
  



  public void c()
  {
    h.a(g, c);
  }
  



  public void d()
  {
    e = null;
  }
  



  public void e()
  {
    float rangefactor = (b.getRangeMultiplier() + e.getRangeMultiplier()) / 2.0F;
    
    if (b.e(e) < 49.0D * (rangefactor * rangefactor))
    {
      b.k().a(d);
    }
    else
    {
      b.k().a(c);
    }
  }
  
  static on a(pg par0EntityAIAvoidEntity)
  {
    return b;
  }
}
