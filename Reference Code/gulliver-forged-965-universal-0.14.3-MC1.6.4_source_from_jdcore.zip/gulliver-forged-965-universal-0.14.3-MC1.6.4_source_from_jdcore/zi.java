






public class zi
  extends yc
{
  private int a;
  
  public zi(int par1, aqz par2Block)
  {
    super(par1);
    a = cF;
  }
  




  public boolean a(ye par1ItemStack, uf par2EntityPlayer, abw par3World, int par4, int par5, int par6, int par7, float par8, float par9, float par10)
  {
    int i1 = par3World.a(par4, par5, par6);
    
    if ((i1 == aXcF) && ((par3World.h(par4, par5, par6) & 0x7) < 1))
    {
      par7 = 1;
    }
    else if ((i1 != bzcF) && (i1 != accF) && (i1 != adcF))
    {
      if (par7 == 0)
      {
        par5--;
      }
      
      if (par7 == 1)
      {
        par5++;
      }
      
      if (par7 == 2)
      {
        par6--;
      }
      
      if (par7 == 3)
      {
        par6++;
      }
      
      if (par7 == 4)
      {
        par4--;
      }
      
      if (par7 == 5)
      {
        par4++;
      }
    }
    
    if (!par2EntityPlayer.a(par4, par5, par6, par7, par1ItemStack))
    {
      return false;
    }
    if (b == 0)
    {
      return false;
    }
    

    if ((par2EntityPlayer.isTiny()) && (a == bZcF) && (i1 != bZcF) && (i1 != bYcF))
    {
      return false;
    }
    
    if (par3World.a(a, par4, par5, par6, false, par7, (nn)null, par1ItemStack))
    {
      aqz block = aqz.s[a];
      int j1 = block.a(par3World, par4, par5, par6, par7, par8, par9, par10, 0);
      
      if (par3World.f(par4, par5, par6, a, j1, 3))
      {
        if (par3World.a(par4, par5, par6) == a)
        {
          aqz.s[a].a(par3World, par4, par5, par6, par2EntityPlayer, par1ItemStack);
          aqz.s[a].k(par3World, par4, par5, par6, j1);
        }
        
        par3World.a(par4 + 0.5F, par5 + 0.5F, par6 + 0.5F, cS.b(), (cS.c() + 1.0F) / 2.0F, cS.d() * 0.8F);
        b -= 1;
      }
    }
    
    return true;
  }
}
