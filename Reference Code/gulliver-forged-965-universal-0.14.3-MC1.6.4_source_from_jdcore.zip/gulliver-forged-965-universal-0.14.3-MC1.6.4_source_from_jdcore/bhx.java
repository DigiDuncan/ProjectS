import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import org.lwjgl.opengl.GL11;








@SideOnly(Side.CLIENT)
public class bhx
  extends bgm
{
  private static final bjo a = new bjo("textures/entity/wither/wither_invulnerable.png");
  private static final bjo f = new bjo("textures/entity/wither/wither.png");
  

  private final bby g = new bby();
  
  public bhx() {}
  
  private float a(float par1, float par2, float par3)
  {
    for (float f3 = par2 - par1; f3 < -180.0F; f3 += 360.0F) {}
    



    while (f3 >= 180.0F)
    {
      f3 -= 360.0F;
    }
    
    return par1 + par3 * f3;
  }
  
  public void a(uv par1EntityWitherSkull, double par2, double par4, double par6, float par8, float par9)
  {
    GL11.glPushMatrix();
    GL11.glDisable(2884);
    float f2 = a(C, A, par9);
    float f3 = D + (B - D) * par9;
    GL11.glTranslatef((float)par2, (float)par4, (float)par6);
    float f4 = 0.0625F;
    GL11.glEnable(32826);
    float scale = par1EntityWitherSkull.getSizeMultiplier();
    GL11.glScalef(-scale, -scale, scale);
    GL11.glEnable(3008);
    b(par1EntityWitherSkull);
    g.a(par1EntityWitherSkull, 0.0F, 0.0F, 0.0F, f2, f3, f4);
    GL11.glPopMatrix();
  }
  
  protected bjo a(uv par1EntityWitherSkull)
  {
    return par1EntityWitherSkull.d() ? a : f;
  }
  



  protected bjo a(nn par1Entity)
  {
    return a((uv)par1Entity);
  }
  






  public void a(nn par1Entity, double par2, double par4, double par6, float par8, float par9)
  {
    a((uv)par1Entity, par2, par4, par6, par8, par9);
  }
}
