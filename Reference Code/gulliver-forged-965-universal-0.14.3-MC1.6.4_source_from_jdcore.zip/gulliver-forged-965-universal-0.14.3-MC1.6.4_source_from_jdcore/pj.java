import java.util.Random;


public class pj
  extends pm
{
  private int i;
  private int j = -1;
  
  public pj(og par1EntityLiving)
  {
    super(par1EntityLiving);
    minTargetSize = 0.3F;
    maxTargetSize = 4.8F;
  }
  



  public boolean a()
  {
    return (super.a()) && (a.q.O().b("mobGriefing"));
  }
  



  public void c()
  {
    super.c();
    i = 0;
  }
  



  public boolean b()
  {
    double d0 = a.e(b, c, d);
    
    if (a.getSizeMultiplier() < 1.0F)
    {
      d0 *= a.getSizeMultiplier();
    }
    
    return (i <= 480) && ((minTargetSize <= 0.0F) || (a.getSizeMultiplier() >= minTargetSize)) && ((maxTargetSize <= 0.0F) || (a.getSizeMultiplier() <= maxTargetSize)) && (!e.b_(a.q, b, c, d)) && (d0 < 4.0D);
  }
  



  public void d()
  {
    super.d();
    a.q.f(a.k, b, c, d, -1);
  }
  



  public void e()
  {
    super.e();
    
    if (a.aD().nextInt(20) == 0)
    {
      a.q.e(1010, b, c, d, 0);
    }
    
    this.i += (int)(2.0F * a.getSizeMultiplierRoot() + 0.5F);
    int i = (int)(this.i / 480.0F * 10.0F);
    
    if (i != j)
    {
      a.q.f(a.k, b, c, d, i);
      j = i;
    }
    
    if ((this.i == 480) && (a.q.r == 3))
    {
      a.q.i(b, c, d);
      a.q.e(1012, b, c, d, 0);
      a.q.e(2001, b, c, d, e.cF);
    }
  }
}
