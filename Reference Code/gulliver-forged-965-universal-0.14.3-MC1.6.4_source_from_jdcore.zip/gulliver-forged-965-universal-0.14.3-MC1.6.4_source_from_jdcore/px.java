import java.util.Random;
import org.apache.commons.lang3.StringUtils;









public class px
  extends ps
{
  private og b;
  protected nn a;
  private float c;
  private int d;
  private float e;
  private Class f;
  
  public px(og par1EntityLiving, Class par2Class, float par3)
  {
    b = par1EntityLiving;
    f = par2Class;
    c = par3;
    e = 0.02F;
    minTargetSize = minLookSize;
    maxTargetSize = maxLookSize;
    a(2);
  }
  
  public px(og par1EntityLiving, Class par2Class, float par3, float par4)
  {
    b = par1EntityLiving;
    f = par2Class;
    c = par3;
    e = par4;
    minTargetSize = minLookSize;
    maxTargetSize = maxLookSize;
    a(2);
  }
  



  public boolean a()
  {
    if (b.aD().nextFloat() >= e)
    {
      return false;
    }
    

    if (b.m() != null)
    {
      a = b.m();
    }
    
    double range = c * b.getRangeMultiplier();
    
    if (f == uf.class)
    {
      a = b.q.getClosestVisibleSizedPlayerToEntity(b, range, minTargetSize, maxTargetSize);
      
      if ((a == null) && ((b instanceof ok)) && (StringUtils.isNotEmpty(((ok)b).h_())))
      {
        nn owner = ((ok)b).d();
        if ((owner != null) && ((owner instanceof uf)) && (o != b) && (b.e(owner) < range * range))
        {

          a = ((ok)b).d();
        }
      }
    }
    else
    {
      a = b.q.findNearestSizedEntityWithinAABB(f, b.E.b(range, 3.0D * b.getRangeMultiplier(), range), b, minTargetSize, maxTargetSize);
    }
    
    return a != null;
  }
  




  public boolean b()
  {
    if (!a.T())
    {
      return false;
    }
    
    if (a.o == b)
    {
      return false;
    }
    
    float rangefactor = (b.getRangeMultiplier() + a.getRangeMultiplier()) / 2.0F;
    
    if (b.e(a) > c * c * rangefactor * rangefactor)
    {
      return false;
    }
    

    return d > 0;
  }
  




  public void c()
  {
    d = (40 + b.aD().nextInt(40));
  }
  



  public void d()
  {
    a = null;
  }
  



  public void e()
  {
    b.h().a(a.u, a.v + a.f(), a.w, 10.0F, b.bp());
    d -= 1;
  }
}
