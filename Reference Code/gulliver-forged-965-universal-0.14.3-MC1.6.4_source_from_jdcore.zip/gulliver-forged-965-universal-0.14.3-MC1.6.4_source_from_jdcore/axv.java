import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import org.lwjgl.opengl.GL11;




















@SideOnly(Side.CLIENT)
public class axv
  extends axp
{
  private float t;
  private float u;
  
  public axv(uf par1EntityPlayer)
  {
    super(bo);
    j = true;
    par1EntityPlayer.a(kp.f, 1);
  }
  



  public void c()
  {
    if (f.c.h())
    {
      f.a(new axm(f.h));
    }
  }
  



  public void A_()
  {
    i.clear();
    
    if (f.c.h())
    {
      f.a(new axm(f.h));
    }
    else
    {
      super.A_();
    }
  }
  



  protected void b(int par1, int par2)
  {
    o.b(bkb.a("container.crafting"), 86, 16, 4210752);
  }
  



  public void a(int par1, int par2, float par3)
  {
    super.a(par1, par2, par3);
    t = par1;
    u = par2;
  }
  



  protected void a(float par1, int par2, int par3)
  {
    GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
    f.J().a(a);
    int k = p;
    int l = q;
    b(k, l, 0, 0, c, d);
    a(k + 51, l + 75, 30, k + 51 - t, l + 75 - 50 - u, f.h);
  }
  
  public static void a(int par0, int par1, int par2, float par3, float par4, of par5EntityLivingBase)
  {
    GL11.glEnable(2903);
    GL11.glPushMatrix();
    float f = par2 / par5EntityLivingBase.getSizeMultiplier();
    GL11.glTranslatef(par0, par1, 50.0F);
    GL11.glScalef(-f, f, f);
    GL11.glRotatef(180.0F, 0.0F, 0.0F, 1.0F);
    float f2 = aN;
    float f3 = A;
    float f4 = B;
    float f5 = aQ;
    float f6 = aP;
    GL11.glRotatef(135.0F, 0.0F, 1.0F, 0.0F);
    att.b();
    GL11.glRotatef(-135.0F, 0.0F, 1.0F, 0.0F);
    GL11.glRotatef(-(float)Math.atan(par4 / 40.0F) * 20.0F, 1.0F, 0.0F, 0.0F);
    aN = ((float)Math.atan(par3 / 40.0F) * 20.0F);
    A = ((float)Math.atan(par3 / 40.0F) * 40.0F);
    B = (-(float)Math.atan(par4 / 40.0F) * 20.0F);
    aP = A;
    aQ = A;
    GL11.glTranslatef(0.0F, N, 0.0F);
    aj = 180.0F;
    bgl.a.a(par5EntityLivingBase, 0.0D, 0.0D, 0.0D, 0.0F, 1.0F);
    aN = f2;
    A = f3;
    B = f4;
    aQ = f5;
    aP = f6;
    GL11.glPopMatrix();
    att.a();
    GL11.glDisable(32826);
    bma.a(bma.b);
    GL11.glDisable(3553);
    bma.a(bma.a);
  }
  



  protected void a(aut par1GuiButton)
  {
    if (g == 0)
    {
      f.a(new awq(f.y));
    }
    
    if (g == 1)
    {
      f.a(new awr(this, f.y));
    }
  }
}
