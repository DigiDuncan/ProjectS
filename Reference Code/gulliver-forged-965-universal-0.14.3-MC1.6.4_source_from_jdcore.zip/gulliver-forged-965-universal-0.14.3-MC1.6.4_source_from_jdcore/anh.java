import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import gulliver.common.GulliverEnvoy;
import gulliver.potion.PotionResizing;
import java.util.Random;













public class anh
  extends aqz
{
  @SideOnly(Side.CLIENT)
  private ms a;
  @SideOnly(Side.CLIENT)
  private ms b;
  @SideOnly(Side.CLIENT)
  private ms c;
  
  protected anh(int par1)
  {
    super(par1, akc.E);
    b(true);
  }
  



  public void a(acf par1IBlockAccess, int par2, int par3, int par4)
  {
    int l = par1IBlockAccess.h(par2, par3, par4);
    float f = 0.0625F;
    float f1 = (1 + l * 2) / 16.0F;
    float f2 = 0.5F;
    a(f1, 0.0F, f, 1.0F - f, f2, 1.0F - f);
  }
  



  public void g()
  {
    float f = 0.0625F;
    float f1 = 0.5F;
    a(f, 0.0F, f, 1.0F - f, f1, 1.0F - f);
  }
  




  public asx b(abw par1World, int par2, int par3, int par4)
  {
    int l = par1World.h(par2, par3, par4);
    float f = 0.0625F;
    float f1 = (1 + l * 2) / 16.0F;
    float f2 = 0.5F;
    return asx.a().a(par2 + f1, par3, par4 + f, par2 + 1 - f, par3 + f2 - f, par4 + 1 - f);
  }
  



  public boolean b()
  {
    return false;
  }
  




  @SideOnly(Side.CLIENT)
  public asx c_(abw par1World, int par2, int par3, int par4)
  {
    int l = par1World.h(par2, par3, par4);
    float f = 0.0625F;
    float f1 = (1 + l * 2) / 16.0F;
    float f2 = 0.5F;
    return asx.a().a(par2 + f1, par3, par4 + f, par2 + 1 - f, par3 + f2, par4 + 1 - f);
  }
  




  @SideOnly(Side.CLIENT)
  public ms a(int par1, int par2)
  {
    return (par2 > 0) && (par1 == 4) ? c : par1 == 0 ? b : par1 == 1 ? a : cW;
  }
  





  @SideOnly(Side.CLIENT)
  public void a(mt par1IconRegister)
  {
    cW = par1IconRegister.a(E() + "_side");
    c = par1IconRegister.a(E() + "_inner");
    a = par1IconRegister.a(E() + "_top");
    b = par1IconRegister.a(E() + "_bottom");
  }
  




  public boolean c()
  {
    return false;
  }
  



  public boolean a(abw par1World, int par2, int par3, int par4, uf par5EntityPlayer, int par6, float par7, float par8, float par9)
  {
    b(par1World, par2, par3, par4, par5EntityPlayer);
    return true;
  }
  



  public void a(abw par1World, int par2, int par3, int par4, uf par5EntityPlayer)
  {
    b(par1World, par2, par3, par4, par5EntityPlayer);
  }
  



  private void b(abw par1World, int par2, int par3, int par4, uf par5EntityPlayer)
  {
    if ((!par5EntityPlayer.isTiny()) || (par5EntityPlayer.holdingPointyItem()))
    {
      if (par5EntityPlayer.g(false))
      {
        int l = par1World.h(par2, par3, par4) + 1;
        
        if ((par5EntityPlayer.isHuge()) && (l < 6))
        {

          par5EntityPlayer.bI().a(4, 0.2F);
          l++;
        }
        else
        {
          par5EntityPlayer.bI().a(2, 0.1F);
        }
        
        if ((!I) && ((!par5EntityPlayer.isTiny()) || (!par5EntityPlayer.smallerAndNotUseBlock())))
        {
          if (l >= 6)
          {
            par1World.i(par2, par3, par4);
          }
          else
          {
            par1World.b(par2, par3, par4, l, 2);
          }
        }
      }
      
      if ((!I) && (shouldEmbiggen(par1World, par2, par3, par4)))
      {

        par5EntityPlayer.c(new nj(hugeH, 1200, 0));
        par5EntityPlayer.a(GulliverEnvoy.eatMe, 1);
      }
    }
  }
  
  protected boolean shouldEmbiggen(abw par1World, int par2, int par3, int par4)
  {
    return (par1World.a(par2, par3, par4) == blcF) && (s.nextInt(111) == 0);
  }
  



  public boolean c(abw par1World, int par2, int par3, int par4)
  {
    return !super.c(par1World, par2, par3, par4) ? false : f(par1World, par2, par3, par4);
  }
  




  public void a(abw par1World, int par2, int par3, int par4, int par5)
  {
    if (!f(par1World, par2, par3, par4))
    {
      par1World.i(par2, par3, par4);
    }
  }
  



  public boolean f(abw par1World, int par2, int par3, int par4)
  {
    return par1World.g(par2, par3 - 1, par4).a();
  }
  



  public int a(Random par1Random)
  {
    return 0;
  }
  



  public int a(int par1, Random par2Random, int par3)
  {
    return 0;
  }
  




  @SideOnly(Side.CLIENT)
  public int d(abw par1World, int par2, int par3, int par4)
  {
    return bbcv;
  }
}
