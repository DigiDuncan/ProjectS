



public class py
  extends px
{
  private final ub b;
  
  public py(ub par1EntityVillager)
  {
    super(par1EntityVillager, uf.class, 8.0F);
    b = par1EntityVillager;
  }
  



  public boolean a()
  {
    if (b.bW())
    {
      a = b.m_();
      return (a != null) && (a.o != b);
    }
    

    return false;
  }
}
