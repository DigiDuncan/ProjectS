import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import java.util.Random;

















public class anj
  extends aqz
{
  @SideOnly(Side.CLIENT)
  private ms a;
  @SideOnly(Side.CLIENT)
  private ms b;
  @SideOnly(Side.CLIENT)
  private ms c;
  
  public anj(int par1)
  {
    super(par1, akc.f);
  }
  




  @SideOnly(Side.CLIENT)
  public ms a(int par1, int par2)
  {
    return par1 == 0 ? c : par1 == 1 ? b : cW;
  }
  





  @SideOnly(Side.CLIENT)
  public void a(mt par1IconRegister)
  {
    a = par1IconRegister.a(E() + "_" + "inner");
    b = par1IconRegister.a(E() + "_top");
    c = par1IconRegister.a(E() + "_" + "bottom");
    cW = par1IconRegister.a(E() + "_side");
  }
  




  public void a(abw par1World, int par2, int par3, int par4, asx par5AxisAlignedBB, List par6List, nn par7Entity)
  {
    a(0.0F, 0.0F, 0.0F, 1.0F, 0.3125F, 1.0F);
    super.a(par1World, par2, par3, par4, par5AxisAlignedBB, par6List, par7Entity);
    float f = 0.125F;
    a(0.0F, 0.0F, 0.0F, f, 1.0F, 1.0F);
    super.a(par1World, par2, par3, par4, par5AxisAlignedBB, par6List, par7Entity);
    a(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, f);
    super.a(par1World, par2, par3, par4, par5AxisAlignedBB, par6List, par7Entity);
    a(1.0F - f, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
    super.a(par1World, par2, par3, par4, par5AxisAlignedBB, par6List, par7Entity);
    a(0.0F, 0.0F, 1.0F - f, 1.0F, 1.0F, 1.0F);
    super.a(par1World, par2, par3, par4, par5AxisAlignedBB, par6List, par7Entity);
    g();
  }
  
  @SideOnly(Side.CLIENT)
  public static ms b(String par0Str)
  {
    return par0Str.equals("bottom") ? bLc : par0Str.equals("inner") ? bLa : null;
  }
  




  public ata a(abw par1World, int par2, int par3, int par4, atc par5Vec3, atc par6Vec3)
  {
    ata[] hits = new ata[5];
    a(0.0F, 0.0F, 0.0F, 1.0F, 0.3125F, 1.0F);
    hits[0] = super.a(par1World, par2, par3, par4, par5Vec3, par6Vec3);
    float var8 = 0.125F;
    a(0.0F, 0.0F, 0.0F, var8, 1.0F, 1.0F);
    hits[1] = super.a(par1World, par2, par3, par4, par5Vec3, par6Vec3);
    a(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, var8);
    hits[2] = super.a(par1World, par2, par3, par4, par5Vec3, par6Vec3);
    a(1.0F - var8, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
    hits[3] = super.a(par1World, par2, par3, par4, par5Vec3, par6Vec3);
    a(0.0F, 0.0F, 1.0F - var8, 1.0F, 1.0F, 1.0F);
    hits[4] = super.a(par1World, par2, par3, par4, par5Vec3, par6Vec3);
    double mlen = 0.0D;
    ata ray = null;
    int var16 = hits.length;
    
    for (int var17 = 0; var17 < var16; var17++)
    {
      ata var18 = hits[var17];
      
      if (var18 != null)
      {
        double var19 = f.e(par6Vec3);
        
        if (var19 > mlen)
        {
          ray = var18;
          mlen = var19;
        }
      }
    }
    
    g();
    return ray;
  }
  



  public void g()
  {
    a(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
  }
  




  public boolean c()
  {
    return false;
  }
  



  public int d()
  {
    return 24;
  }
  



  public boolean b()
  {
    return false;
  }
  




  public boolean a(abw par1World, int par2, int par3, int par4, uf par5EntityPlayer, int par6, float par7, float par8, float par9)
  {
    ye itemstack = bn.h();
    
    if (itemstack == null)
    {
      return true;
    }
    

    int i1 = par1World.h(par2, par3, par4);
    int j1 = h_(i1);
    
    if (d == azcv)
    {
      if (j1 < 3)
      {
        if (!I)
        {
          if (!bG.d)
          {
            bn.a(bn.c, new ye(yc.ay));
          }
          
          par1World.b(par2, par3, par4, 3, 2);
          par1World.m(par2, par3, par4, cF);
        }
        
        return true;
      }
      
      return false;
    }
    

    if (d == bvcv)
    {
      if (!I)
      {
        if (j1 > 0)
        {
          ye itemstack1 = new ye(yc.bu, 1, 0);
          
          if (!bn.a(itemstack1))
          {
            par1World.d(new ss(par1World, par2 + 0.5D, par3 + 1.5D, par4 + 0.5D, itemstack1));
          }
          else if ((par5EntityPlayer instanceof jv))
          {
            ((jv)par5EntityPlayer).a(bo);
          }
          
          b -= 1;
          
          if (b <= 0)
          {
            bn.a(bn.c, (ye)null);
          }
          
          par1World.b(par2, par3, par4, j1 - 1, 2);
          par1World.m(par2, par3, par4, cF);
        }
        
        return true;
      }
    }
    else if ((j1 > 0) && ((itemstack.b() instanceof wh)) && (((wh)itemstack.b()).d() == wj.a))
    {
      if (!I)
      {
        wh itemarmor = (wh)itemstack.b();
        itemarmor.c(itemstack);
        par1World.b(par2, par3, par4, j1 - 1, 2);
        par1World.m(par2, par3, par4, cF);
        return true;
      }
      
      return true;
    }
    
    return false;
  }
  





  public void g(abw par1World, int par2, int par3, int par4)
  {
    if (s.nextInt(20) == 1)
    {
      int l = par1World.h(par2, par3, par4);
      
      if (l < 3)
      {
        par1World.b(par2, par3, par4, l + 1, 2);
      }
    }
  }
  



  public int a(int par1, Random par2Random, int par3)
  {
    return bBcv;
  }
  




  @SideOnly(Side.CLIENT)
  public int d(abw par1World, int par2, int par3, int par4)
  {
    return bBcv;
  }
  




  public boolean q_()
  {
    return true;
  }
  




  public int b_(abw par1World, int par2, int par3, int par4, int par5)
  {
    int i1 = par1World.h(par2, par3, par4);
    return h_(i1);
  }
  
  public static int h_(int par0)
  {
    return par0;
  }
}
