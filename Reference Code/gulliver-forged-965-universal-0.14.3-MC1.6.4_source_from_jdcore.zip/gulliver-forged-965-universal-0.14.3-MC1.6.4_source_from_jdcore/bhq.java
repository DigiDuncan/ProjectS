import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import org.lwjgl.opengl.GL11;








@SideOnly(Side.CLIENT)
public class bhq
  extends bhe
{
  private static final bjo a = new bjo("textures/entity/squid.png");
  
  public bhq(bbo par1ModelBase, float par2)
  {
    super(par1ModelBase, par2);
  }
  



  public void a(sc par1EntitySquid, double par2, double par4, double par6, float par8, float par9)
  {
    super.a(par1EntitySquid, par2, par4, par6, par8, par9);
  }
  
  protected bjo a(sc par1EntitySquid)
  {
    return a;
  }
  



  protected void a(sc par1EntitySquid, float par2, float par3, float par4)
  {
    float f3 = bq + (bp - bq) * par4;
    float f4 = bs + (br - bs) * par4;
    GL11.glTranslatef(0.0F, 0.5F * par1EntitySquid.getSizeMultiplier(), 0.0F);
    GL11.glRotatef(180.0F - par3, 0.0F, 1.0F, 0.0F);
    GL11.glRotatef(f3, 1.0F, 0.0F, 0.0F);
    GL11.glRotatef(f4, 0.0F, 1.0F, 0.0F);
    GL11.glTranslatef(0.0F, -1.2F * par1EntitySquid.getSizeMultiplier(), 0.0F);
  }
  
  protected float a(sc par1EntitySquid, float par2)
  {
    return bw + (bv - bw) * par2;
  }
  
  public void a(og par1EntityLiving, double par2, double par4, double par6, float par8, float par9)
  {
    a((sc)par1EntityLiving, par2, par4, par6, par8, par9);
  }
  



  protected float b(of par1EntityLivingBase, float par2)
  {
    return a((sc)par1EntityLivingBase, par2);
  }
  
  protected void a(of par1EntityLivingBase, float par2, float par3, float par4)
  {
    a((sc)par1EntityLivingBase, par2, par3, par4);
  }
  
  public void a(of par1EntityLivingBase, double par2, double par4, double par6, float par8, float par9)
  {
    a((sc)par1EntityLivingBase, par2, par4, par6, par8, par9);
  }
  



  protected bjo a(nn par1Entity)
  {
    return a((sc)par1Entity);
  }
  






  public void a(nn par1Entity, double par2, double par4, double par6, float par8, float par9)
  {
    a((sc)par1Entity, par2, par4, par6, par8, par9);
  }
}
