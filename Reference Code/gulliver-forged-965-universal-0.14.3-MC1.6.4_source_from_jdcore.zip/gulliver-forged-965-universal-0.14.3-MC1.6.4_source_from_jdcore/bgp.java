import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import org.lwjgl.opengl.GL11;










@SideOnly(Side.CLIENT)
public class bgp
  extends bgm
{
  private float a;
  
  public bgp(float par1)
  {
    a = par1;
  }
  
  public void a(uj par1EntityFireball, double par2, double par4, double par6, float par8, float par9)
  {
    GL11.glPushMatrix();
    b(par1EntityFireball);
    GL11.glTranslatef((float)par2, (float)par4, (float)par6);
    GL11.glEnable(32826);
    float f2 = a * par1EntityFireball.getSizeMultiplier();
    GL11.glScalef(f2 / 1.0F, f2 / 1.0F, f2 / 1.0F);
    ms icon = yc.bG.b_(0);
    bfq tessellator = bfq.a;
    float f3 = icon.c();
    float f4 = icon.d();
    float f5 = icon.e();
    float f6 = icon.f();
    float f7 = 1.0F;
    float f8 = 0.5F;
    float f9 = 0.25F;
    GL11.glRotatef(180.0F - b.j, 0.0F, 1.0F, 0.0F);
    GL11.glRotatef(-b.k, 1.0F, 0.0F, 0.0F);
    tessellator.b();
    tessellator.b(0.0F, 1.0F, 0.0F);
    tessellator.a(0.0F - f8, 0.0F - f9, 0.0D, f3, f6);
    tessellator.a(f7 - f8, 0.0F - f9, 0.0D, f4, f6);
    tessellator.a(f7 - f8, 1.0F - f9, 0.0D, f4, f5);
    tessellator.a(0.0F - f8, 1.0F - f9, 0.0D, f3, f5);
    tessellator.a();
    GL11.glDisable(32826);
    GL11.glPopMatrix();
  }
  
  protected bjo a(uj par1EntityFireball)
  {
    return bik.c;
  }
  



  protected bjo a(nn par1Entity)
  {
    return a((uj)par1Entity);
  }
  






  public void a(nn par1Entity, double par2, double par4, double par6, float par8, float par9)
  {
    a((uj)par1Entity, par2, par4, par6, par8, par9);
  }
}
