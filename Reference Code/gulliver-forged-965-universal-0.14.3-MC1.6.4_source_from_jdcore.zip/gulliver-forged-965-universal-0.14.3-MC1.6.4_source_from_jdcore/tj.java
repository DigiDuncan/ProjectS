import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import java.util.Random;
















public class tj
  extends ob
  implements th
{
  public int h;
  public double i;
  public double j;
  public double bn;
  private nn bq;
  private int br;
  public int bo;
  public int bp;
  private int bs = 1;
  
  public tj(abw par1World)
  {
    super(par1World);
    a(4.0F, 4.0F);
    ag = true;
    b = 5;
  }
  
  @SideOnly(Side.CLIENT)
  public boolean bJ()
  {
    return ah.a(16) != 0;
  }
  



  public boolean a(nb par1DamageSource, float par2)
  {
    if (ar())
    {
      return false;
    }
    if (("fireball".equals(par1DamageSource.n())) && ((par1DamageSource.i() instanceof uf)))
    {
      super.a(par1DamageSource, 1000.0F);
      ((uf)par1DamageSource.i()).a(kp.y);
      return true;
    }
    

    return super.a(par1DamageSource, par2);
  }
  

  protected void a()
  {
    super.a();
    ah.a(16, Byte.valueOf((byte)0));
  }
  
  protected void az()
  {
    super.az();
    a(tp.a).a(10.0D);
  }
  
  protected void bl()
  {
    if ((!q.I) && (q.r == 0))
    {
      x();
    }
    
    u();
    bo = bp;
    double d0 = i - u;
    double d1 = j - v;
    double d2 = bn - w;
    double d3 = d0 * d0 + d1 * d1 + d2 * d2;
    
    if ((d3 < 1.0D * getSizeMultiplier() * getSizeMultiplier()) || (d3 > 3600.0D * getSizeMultiplier() * getSizeMultiplier()))
    {
      i = (u + (ab.nextFloat() * 2.0F - 1.0F) * 16.0F * getSizeMultiplier());
      j = (v + (ab.nextFloat() * 2.0F - 1.0F) * 16.0F * getSizeMultiplier());
      bn = (w + (ab.nextFloat() * 2.0F - 1.0F) * 16.0F * getSizeMultiplier());
    }
    
    if (h-- <= 0)
    {
      h += ab.nextInt(5) + 2;
      d3 = ls.a(d3);
      
      if (a(i, j, bn, d3))
      {
        x += d0 / d3 * 0.1D * getSizeMultiplierRoot();
        y += d1 / d3 * 0.1D * getSizeMultiplierRoot();
        z += d2 / d3 * 0.1D * getSizeMultiplierRoot();
      }
      else
      {
        i = u;
        j = v;
        bn = w;
      }
    }
    
    if ((bq != null) && (bq.M))
    {
      bq = null;
    }
    
    if ((bq == null) || (br-- <= 0))
    {

      bq = q.getClosestSizedVulnerablePlayerToEntity(this, 100.0D * getSizeMultiplierRoot(), minTargetSize, maxTargetSize);
      
      if (bq != null)
      {
        br = 20;
      }
    }
    
    double d4 = 64.0D * getRangeMultiplier();
    
    if ((bq != null) && (bq.e(this) < d4 * d4))
    {
      double d5 = bq.u - u;
      double d6 = bq.E.b + bq.P / 2.0F - (v + P / 2.0F);
      double d7 = bq.w - w;
      aN = (this.A = -(float)Math.atan2(d5, d7) * 180.0F / 3.1415927F);
      
      if (o(bq))
      {
        if (bp == 10)
        {
          q.a((uf)null, 1007, (int)u, (int)v, (int)w, 0);
        }
        
        bp += 1;
        
        if (bp == 20)
        {
          q.a((uf)null, 1008, (int)u, (int)v, (int)w, 0);
          um entitylargefireball = new um(q, this, d5, d6, d7);
          e = bs;
          double d8 = 4.0D * getSizeMultiplier();
          atc vec3 = j(1.0F);
          u = (u + c * d8);
          v = (v + P / 2.0F + 0.5D * bq.getSizeMultiplier());
          w = (w + e * d8);
          q.d(entitylargefireball);
          bp = -40;
        }
      }
      else if (bp > 0)
      {
        bp -= 1;
      }
    }
    else
    {
      aN = (this.A = -(float)Math.atan2(x, z) * 180.0F / 3.1415927F);
      
      if (bp > 0)
      {
        bp -= 1;
      }
    }
    
    if (!q.I)
    {
      byte b0 = ah.a(16);
      byte b1 = (byte)(bp > 10 ? 1 : 0);
      
      if (b0 != b1)
      {
        ah.b(16, Byte.valueOf(b1));
      }
    }
  }
  



  private boolean a(double par1, double par3, double par5, double par7)
  {
    double d4 = (this.i - u) / par7;
    double d5 = (j - v) / par7;
    double d6 = (bn - w) / par7;
    asx axisalignedbb = E.c();
    
    for (int i = 1; i < par7; i++)
    {
      axisalignedbb.d(d4, d5, d6);
      
      if (!q.a(this, axisalignedbb).isEmpty())
      {
        return false;
      }
    }
    
    return true;
  }
  



  protected String r()
  {
    return "mob.ghast.moan";
  }
  



  protected String aO()
  {
    return "mob.ghast.scream";
  }
  



  protected String aP()
  {
    return "mob.ghast.death";
  }
  



  protected int s()
  {
    return Ocv;
  }
  




  protected void b(boolean par1, int par2)
  {
    dropItemSizedAmount(par2 + 1, brcv, 0, 2);
    dropItemSizedAmount(par2 + 1, Ocv, 0, 3);
  }
  



  protected float ba()
  {
    return 10.0F;
  }
  



  public boolean bs()
  {
    return (ab.nextInt(20) == 0) && (super.bs()) && (q.r > 0);
  }
  



  public int bv()
  {
    return 1;
  }
  



  public void b(by par1NBTTagCompound)
  {
    super.b(par1NBTTagCompound);
    par1NBTTagCompound.a("ExplosionPower", bs);
  }
  



  public void a(by par1NBTTagCompound)
  {
    super.a(par1NBTTagCompound);
    
    if (par1NBTTagCompound.b("ExplosionPower"))
    {
      bs = par1NBTTagCompound.e("ExplosionPower");
    }
  }
}
