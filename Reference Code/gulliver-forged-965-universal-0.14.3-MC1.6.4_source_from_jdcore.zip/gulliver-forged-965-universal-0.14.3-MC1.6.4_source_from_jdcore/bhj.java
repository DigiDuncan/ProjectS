import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraftforge.client.ForgeHooksClient;
import net.minecraftforge.client.IItemRenderer;
import net.minecraftforge.client.IItemRenderer.ItemRenderType;
import net.minecraftforge.client.IItemRenderer.ItemRendererHelper;
import net.minecraftforge.client.MinecraftForgeClient;
import net.minecraftforge.client.event.RenderPlayerEvent.Post;
import net.minecraftforge.client.event.RenderPlayerEvent.Pre;
import net.minecraftforge.client.event.RenderPlayerEvent.SetArmorModel;
import net.minecraftforge.client.event.RenderPlayerEvent.Specials.Post;
import net.minecraftforge.client.event.RenderPlayerEvent.Specials.Pre;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.EventBus;
import org.lwjgl.opengl.GL11;




















@SideOnly(Side.CLIENT)
public class bhj
  extends bhb
{
  private static final bjo a = new bjo("textures/entity/steve.png");
  private bbj f;
  private bbj g;
  private bbj h;
  
  public bhj()
  {
    super(new bbj(0.0F), 0.5F);
    f = ((bbj)i);
    g = new bbj(1.0F);
    h = new bbj(0.5F);
  }
  



  protected int a(beu par1AbstractClientPlayer, int par2, float par3)
  {
    ye itemstack = bn.f(3 - par2);
    
    RenderPlayerEvent.SetArmorModel event = new RenderPlayerEvent.SetArmorModel(par1AbstractClientPlayer, this, 3 - par2, par3, itemstack);
    MinecraftForge.EVENT_BUS.post(event);
    if (result != -1)
    {
      return result;
    }
    
    if (itemstack != null)
    {
      yc item = itemstack.b();
      
      if ((item instanceof wh))
      {
        wh itemarmor = (wh)item;
        a(bgu.getArmorResource(par1AbstractClientPlayer, itemstack, par2, null));
        bbj modelbiped = par2 == 2 ? h : g;
        c.j = (par2 == 0);
        d.j = (par2 == 0);
        e.j = ((par2 == 1) || (par2 == 2));
        f.j = (par2 == 1);
        g.j = (par2 == 1);
        h.j = ((par2 == 2) || (par2 == 3));
        i.j = ((par2 == 2) || (par2 == 3));
        modelbiped = ForgeHooksClient.getArmorModel(par1AbstractClientPlayer, itemstack, par2, modelbiped);
        a(modelbiped);
        p = i.p;
        q = i.q;
        s = i.s;
        float f1 = 1.0F;
        

        int j = itemarmor.b(itemstack);
        if (j != -1)
        {
          float f2 = (j >> 16 & 0xFF) / 255.0F;
          float f3 = (j >> 8 & 0xFF) / 255.0F;
          float f4 = (j & 0xFF) / 255.0F;
          GL11.glColor3f(f1 * f2, f1 * f3, f1 * f4);
          
          if (itemstack.y())
          {
            return 31;
          }
          
          return 16;
        }
        
        GL11.glColor3f(f1, f1, f1);
        
        if (itemstack.y())
        {
          return 15;
        }
        
        return 1;
      }
    }
    
    return -1;
  }
  
  protected void b(beu par1AbstractClientPlayer, int par2, float par3)
  {
    ye itemstack = bn.f(3 - par2);
    
    if (itemstack != null)
    {
      yc item = itemstack.b();
      
      if ((item instanceof wh))
      {
        a(bgu.getArmorResource(par1AbstractClientPlayer, itemstack, par2, "overlay"));
        float f1 = 1.0F;
        GL11.glColor3f(f1, f1, f1);
      }
    }
  }
  
  public void a(beu par1AbstractClientPlayer, double par2, double par4, double par6, float par8, float par9)
  {
    if (MinecraftForge.EVENT_BUS.post(new RenderPlayerEvent.Pre(par1AbstractClientPlayer, this, par9))) return;
    float sizemult = par1AbstractClientPlayer.getSizeMultiplier();
    
    float f2 = 1.0F;
    GL11.glColor3f(f2, f2, f2);
    ye itemstack = bn.h();
    g.m = (h.m = f.m = heldEntity != null ? 4 : itemstack != null ? 1 : 0);
    
    if ((itemstack != null) && (par1AbstractClientPlayer.bq() > 0))
    {
      zj enumaction = itemstack.o();
      
      if (enumaction == zj.d)
      {
        g.m = (h.m = f.m = 3);
      }
      else if (enumaction == zj.e)
      {
        g.o = (h.o = f.o = 1);
      }
    }
    
    g.n = (h.n = f.n = par1AbstractClientPlayer.ah());
    g.isGliding = (h.isGliding = f.isGliding = par1AbstractClientPlayer.isGliding());
    g.isRafting = (h.isRafting = f.isRafting = par1AbstractClientPlayer.isRafting());
    g.doesUmbrella = (h.doesUmbrella = f.doesUmbrella = par1AbstractClientPlayer.doesUmbrella());
    double d3 = par4 - N;
    
    if ((par1AbstractClientPlayer.ah()) && (!(par1AbstractClientPlayer instanceof bex)))
    {
      d3 -= 0.125D * sizemult;
    }
    
    super.a(par1AbstractClientPlayer, par2, d3, par6, par8, par9);
    g.o = (h.o = f.o = 0);
    g.n = (h.n = f.n = 0);
    g.isGliding = (h.isGliding = f.isGliding = 0);
    g.isRafting = (h.isRafting = f.isRafting = 0);
    g.doesUmbrella = (h.doesUmbrella = f.doesUmbrella = 0);
    g.m = (h.m = f.m = 0);
    MinecraftForge.EVENT_BUS.post(new RenderPlayerEvent.Post(par1AbstractClientPlayer, this, par9));
  }
  
  protected bjo a(beu par1AbstractClientPlayer)
  {
    return par1AbstractClientPlayer.r();
  }
  



  protected void a(beu par1AbstractClientPlayer, float par2)
  {
    RenderPlayerEvent.Specials.Pre event = new RenderPlayerEvent.Specials.Pre(par1AbstractClientPlayer, this, par2);
    if (MinecraftForge.EVENT_BUS.post(event))
    {
      return;
    }
    
    float f1 = 1.0F;
    GL11.glColor3f(f1, f1, f1);
    super.c(par1AbstractClientPlayer, par2);
    super.e(par1AbstractClientPlayer, par2);
    ye itemstack = bn.f(3);
    
    if ((itemstack != null) && (renderHelmet))
    {
      GL11.glPushMatrix();
      f.c.c(0.0625F);
      

      if ((itemstack != null) && ((itemstack.b() instanceof zh)))
      {
        IItemRenderer customRenderer = MinecraftForgeClient.getItemRenderer(itemstack, IItemRenderer.ItemRenderType.EQUIPPED);
        boolean is3D = (customRenderer != null) && (customRenderer.shouldUseRenderHelper(IItemRenderer.ItemRenderType.EQUIPPED, itemstack, IItemRenderer.ItemRendererHelper.BLOCK_3D));
        
        if ((is3D) || (bfr.a(aqz.s[d].d())))
        {
          float f2 = 0.625F;
          GL11.glTranslatef(0.0F, -0.25F, 0.0F);
          GL11.glRotatef(90.0F, 0.0F, 1.0F, 0.0F);
          GL11.glScalef(f2, -f2, -f2);
        }
        
        b.f.a(par1AbstractClientPlayer, itemstack, 0);
      }
      else if (bcv == bScv)
      {
        float f2 = 1.0625F;
        GL11.glScalef(f2, -f2, -f2);
        String s = "";
        
        if ((itemstack.p()) && (itemstack.q().b("SkullOwner")))
        {
          s = itemstack.q().i("SkullOwner");
        }
        
        bjb.a.a(-0.5F, 0.0F, -0.5F, 1, 180.0F, itemstack.k(), s);
      }
      
      GL11.glPopMatrix();
    }
    
    if ((par1AbstractClientPlayer.c_().equals("deadmau5")) && (par1AbstractClientPlayer.p().a()))
    {
      a(par1AbstractClientPlayer.r());
      
      for (int i = 0; i < 2; i++)
      {
        float f3 = C + (A - C) * par2 - (aO + (aN - aO) * par2);
        float f4 = D + (B - D) * par2;
        GL11.glPushMatrix();
        GL11.glRotatef(f3, 0.0F, 1.0F, 0.0F);
        GL11.glRotatef(f4, 1.0F, 0.0F, 0.0F);
        GL11.glTranslatef(0.375F * (i * 2 - 1), 0.0F, 0.0F);
        GL11.glTranslatef(0.0F, -0.375F, 0.0F);
        GL11.glRotatef(-f4, 1.0F, 0.0F, 0.0F);
        GL11.glRotatef(-f3, 0.0F, 1.0F, 0.0F);
        float f5 = 1.3333334F;
        GL11.glScalef(f5, f5, f5);
        f.b(0.0625F);
        GL11.glPopMatrix();
      }
    }
    
    boolean flag = par1AbstractClientPlayer.q().a();
    boolean flag1 = !par1AbstractClientPlayer.aj();
    boolean flag2 = !par1AbstractClientPlayer.bL();
    flag = (renderCape) && (flag);
    

    if ((flag) && (flag1) && (flag2))
    {
      a(par1AbstractClientPlayer.s());
      GL11.glPushMatrix();
      GL11.glTranslatef(0.0F, 0.0F, 0.125F);
      double d0 = bw + (bz - bw) * par2 - (r + (u - r) * par2);
      double d1 = bx + (bA - bx) * par2 - (s + (v - s) * par2);
      double d2 = by + (bB - by) * par2 - (t + (w - t) * par2);
      float f6 = aO + (aN - aO) * par2;
      double d3 = ls.a(f6 * 3.1415927F / 180.0F);
      double d4 = -ls.b(f6 * 3.1415927F / 180.0F);
      float f7 = (float)d1 * 10.0F;
      
      if (f7 < -6.0F)
      {
        f7 = -6.0F;
      }
      
      if (f7 > 32.0F)
      {
        f7 = 32.0F;
      }
      
      float f8 = (float)(d0 * d3 + d2 * d4) * 100.0F;
      float f9 = (float)(d0 * d4 - d2 * d3) * 100.0F;
      
      if (f8 < 0.0F)
      {
        f8 = 0.0F;
      }
      
      float f10 = bs + (bt - bs) * par2;
      f7 += ls.a((Q + (R - Q) * par2) * 6.0F) * 32.0F * f10;
      
      if (par1AbstractClientPlayer.ah())
      {
        f7 += 25.0F;
      }
      
      GL11.glRotatef(6.0F + f8 / 2.0F + f7, 1.0F, 0.0F, 0.0F);
      GL11.glRotatef(f9 / 2.0F, 0.0F, 0.0F, 1.0F);
      GL11.glRotatef(-f9 / 2.0F, 0.0F, 1.0F, 0.0F);
      GL11.glRotatef(180.0F, 0.0F, 1.0F, 0.0F);
      f.c(0.0625F);
      GL11.glPopMatrix();
    }
    
    ye itemstack1 = bn.h();
    
    if ((itemstack1 != null) && (renderItem))
    {
      GL11.glPushMatrix();
      f.f.c(0.0625F);
      
      GL11.glTranslatef(-0.0625F, 0.4375F, 0.0625F);
      

      if (bM != null)
      {
        itemstack1 = new ye(yc.F);
      }
      
      zj enumaction = null;
      
      if (par1AbstractClientPlayer.bq() > 0)
      {
        enumaction = itemstack1.o();
      }
      

      float sizeroot = par1AbstractClientPlayer.getSizeMultiplierRoot();
      float sizerootdiv = 1.0F / sizeroot;
      

      IItemRenderer customRenderer = MinecraftForgeClient.getItemRenderer(itemstack1, IItemRenderer.ItemRenderType.EQUIPPED);
      boolean is3D = (customRenderer != null) && (customRenderer.shouldUseRenderHelper(IItemRenderer.ItemRenderType.EQUIPPED, itemstack1, IItemRenderer.ItemRendererHelper.BLOCK_3D));
      boolean isBlock = (d < aqz.s.length) && (itemstack1.d() == 0);
      
      if ((is3D) || ((isBlock) && (bfr.a(aqz.s[d].d()))))
      {
        float f11 = 0.5F * sizerootdiv;
        GL11.glTranslatef(0.0F, 0.1875F, -0.3125F);
        f11 *= 0.75F;
        GL11.glRotatef(20.0F, 1.0F, 0.0F, 0.0F);
        GL11.glRotatef(45.0F, 0.0F, 1.0F, 0.0F);
        GL11.glScalef(-f11, -f11, f11);
      }
      else if (d == mcv)
      {
        float f11 = 0.625F * sizerootdiv;
        GL11.glTranslatef(0.0F, 0.125F, 0.3125F);
        
        GL11.glRotatef(-20.0F, 0.0F, 1.0F, 0.0F);
        GL11.glScalef(f11, -f11, f11);
        GL11.glRotatef(-100.0F, 1.0F, 0.0F, 0.0F);
        GL11.glRotatef(45.0F, 0.0F, 1.0F, 0.0F);
      }
      else if (yc.g[d].n_())
      {
        float f11 = 0.625F * sizerootdiv;
        
        if (yc.g[d].o_())
        {
          GL11.glRotatef(180.0F, 0.0F, 0.0F, 1.0F);
          GL11.glTranslatef(0.0F, -0.125F, 0.0F);
        }
        
        if ((par1AbstractClientPlayer.bq() > 0) && (enumaction == zj.d))
        {
          GL11.glTranslatef(0.05F, 0.0F, -0.1F);
          GL11.glRotatef(-50.0F, 0.0F, 1.0F, 0.0F);
          GL11.glRotatef(-10.0F, 1.0F, 0.0F, 0.0F);
          GL11.glRotatef(-60.0F, 0.0F, 0.0F, 1.0F);
          GL11.glTranslatef(0.0F, 0.1875F, 0.0F);
        }
        else
        {
          GL11.glTranslatef(-0.0625F + 0.0625F * sizerootdiv, 0.1875F, 0.0625F - 0.0625F * sizeroot);
        }
        
        GL11.glScalef(f11, -f11, f11);
        GL11.glRotatef(-100.0F, 1.0F, 0.0F, 0.0F);
        GL11.glRotatef(45.0F, 0.0F, 1.0F, 0.0F);
      }
      else
      {
        float f11 = 0.375F * sizerootdiv;
        if ((f.isGliding) || (f.doesUmbrella))
        {
          GL11.glScalef(f11, f11, f11);
          GL11.glTranslatef(-0.25F * sizeroot, 0.1875F * sizerootdiv, -0.1875F);
          GL11.glRotatef(-90.0F, 0.0F, 0.0F, 1.0F);
          GL11.glRotatef(50.0F, 0.0F, 1.0F, 0.0F);
        }
        else if (f.isRafting)
        {
          GL11.glRotatef(180.0F, 0.0F, 1.0F, 0.0F);
          GL11.glScalef(f11, f11, f11);
          GL11.glTranslatef(-0.125F, 0.375F, -0.1875F);
          GL11.glRotatef(90.0F, 0.0F, 0.0F, 1.0F);
          GL11.glRotatef(70.0F, 0.0F, 1.0F, 0.0F);
        }
        else
        {
          GL11.glTranslatef(0.25F, 0.1875F, -0.1875F);
          GL11.glScalef(f11, f11, f11);
          GL11.glRotatef(60.0F, 0.0F, 0.0F, 1.0F);
          GL11.glRotatef(-90.0F, 1.0F, 0.0F, 0.0F);
          GL11.glRotatef(20.0F, 0.0F, 0.0F, 1.0F);
        }
      }
      




      if (itemstack1.b().b())
      {
        for (int j = 0; j < itemstack1.b().getRenderPasses(itemstack1.k()); j++)
        {
          int k = itemstack1.b().a(itemstack1, j);
          float f13 = (k >> 16 & 0xFF) / 255.0F;
          float f12 = (k >> 8 & 0xFF) / 255.0F;
          float f6 = (k & 0xFF) / 255.0F;
          GL11.glColor4f(f13, f12, f6, 1.0F);
          b.f.a(par1AbstractClientPlayer, itemstack1, j);
        }
      }
      

      int j = itemstack1.b().a(itemstack1, 0);
      float f14 = (j >> 16 & 0xFF) / 255.0F;
      float f13 = (j >> 8 & 0xFF) / 255.0F;
      float f12 = (j & 0xFF) / 255.0F;
      GL11.glColor4f(f14, f13, f12, 1.0F);
      b.f.a(par1AbstractClientPlayer, itemstack1, 0);
      

      GL11.glPopMatrix();
    }
    MinecraftForge.EVENT_BUS.post(new RenderPlayerEvent.Specials.Post(par1AbstractClientPlayer, this, par2));
  }
  
  protected void b(beu par1AbstractClientPlayer, float par2)
  {
    float f1 = 0.9375F;
    GL11.glScalef(f1, f1, f1);
  }
  
  protected void a(beu par1AbstractClientPlayer, double par2, double par4, double par6, String par8Str, float par9, double par10)
  {
    if (par10 < 100.0D)
    {
      atj scoreboard = par1AbstractClientPlayer.bM();
      ate scoreobjective = scoreboard.a(2);
      
      if (scoreobjective != null)
      {
        atg score = scoreboard.a(par1AbstractClientPlayer.an(), scoreobjective);
        
        if (par1AbstractClientPlayer.bh())
        {
          a(par1AbstractClientPlayer, score.c() + " " + scoreobjective.d(), par2, par4 - 1.5D * par1AbstractClientPlayer.getSizeMultiplier(), par6, 64);
        }
        else
        {
          a(par1AbstractClientPlayer, score.c() + " " + scoreobjective.d(), par2, par4, par6, 64);
        }
        
        par4 += aa * 1.15F * par9;
      }
    }
    
    super.a(par1AbstractClientPlayer, par2, par4, par6, par8Str, par9, par10);
  }
  
  public void a(uf par1EntityPlayer)
  {
    float f = 1.0F;
    GL11.glColor3f(f, f, f);
    fp = 0.0F;
    this.f.a(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0625F, par1EntityPlayer);
    ff.a(0.0625F);
  }
  



  protected void a(beu par1AbstractClientPlayer, double par2, double par4, double par6)
  {
    if ((par1AbstractClientPlayer.T()) && (par1AbstractClientPlayer.bh()))
    {

      float sizemult = par1AbstractClientPlayer.getSizeMultiplier();
      double yoff = (par1AbstractClientPlayer instanceof bey) ? (sizemult - 1.0F) * 0.375D : 0.0D;
      super.a(par1AbstractClientPlayer, par2 + bE * sizemult, par4 + yoff, par6 + bF * sizemult);
    }
    else
    {
      super.a(par1AbstractClientPlayer, par2, par4, par6);
    }
  }
  



  protected void a(beu par1AbstractClientPlayer, float par2, float par3, float par4)
  {
    if ((par1AbstractClientPlayer.T()) && (par1AbstractClientPlayer.bh()))
    {
      GL11.glRotatef(par1AbstractClientPlayer.bC(), 0.0F, 1.0F, 0.0F);
      GL11.glRotatef(a(par1AbstractClientPlayer), 0.0F, 0.0F, 1.0F);
      GL11.glRotatef(270.0F, 0.0F, 1.0F, 0.0F);
    }
    else
    {
      super.a(par1AbstractClientPlayer, par2, par3, par4);
    }
  }
  
  protected void a(of par1EntityLivingBase, double par2, double par4, double par6, String par8Str, float par9, double par10)
  {
    a((beu)par1EntityLivingBase, par2, par4, par6, par8Str, par9, par10);
  }
  




  protected void a(of par1EntityLivingBase, float par2)
  {
    b((beu)par1EntityLivingBase, par2);
  }
  
  protected void c(of par1EntityLivingBase, int par2, float par3)
  {
    b((beu)par1EntityLivingBase, par2, par3);
  }
  



  protected int a(of par1EntityLivingBase, int par2, float par3)
  {
    return a((beu)par1EntityLivingBase, par2, par3);
  }
  
  protected void c(of par1EntityLivingBase, float par2)
  {
    a((beu)par1EntityLivingBase, par2);
  }
  
  protected void a(of par1EntityLivingBase, float par2, float par3, float par4)
  {
    a((beu)par1EntityLivingBase, par2, par3, par4);
  }
  



  protected void a(of par1EntityLivingBase, double par2, double par4, double par6)
  {
    a((beu)par1EntityLivingBase, par2, par4, par6);
  }
  
  public void a(of par1EntityLivingBase, double par2, double par4, double par6, float par8, float par9)
  {
    a((beu)par1EntityLivingBase, par2, par4, par6, par8, par9);
  }
  



  protected bjo a(nn par1Entity)
  {
    return a((beu)par1Entity);
  }
  




  public void b(nn par1Entity, double par2, double par4, double par6, float par8, float par9)
  {
    float tmp = d;
    if (!(par1Entity instanceof og))
    {
      d *= par1Entity.getSizeMultiplier();
    }
    super.b(par1Entity, par2, par4, par6, par8, par9);
    d = tmp;
  }
  






  public void a(nn par1Entity, double par2, double par4, double par6, float par8, float par9)
  {
    a((beu)par1Entity, par2, par4, par6, par8, par9);
  }
}
