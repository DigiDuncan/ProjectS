import cpw.mods.fml.common.registry.VillagerRegistry;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;



























































public class ub
  extends nk
  implements abk, ua
{
  private int bq;
  private boolean br;
  private boolean bs;
  rj bp;
  private uf bt;
  private abm bu;
  private int bv;
  private boolean bw;
  private int bx;
  private String by;
  private boolean bz;
  private float bA;
  public static final Map bB = new HashMap();
  




  public static final Map bC = new HashMap();
  
  public ub(abw par1World)
  {
    this(par1World, 0);
  }
  
  public ub(abw par1World, int par2)
  {
    super(par1World);
    p(par2);
    a(0.6F, 1.8F);
    minLookSize = 0.1F;
    maxLookSize = 0.0F;
    minTargetSize = 0.3F;
    maxTargetSize = 4.5F;
    k().b(true);
    k().a(true);
    c.a(0, new pp(this));
    c.a(1, new pg(this, tw.class, 8.0F, 0.6D, 0.6D));
    c.a(1, new pg(this, of.class, 12.0F, 0.6000000238418579D, 0.6000000238418579D).setTargetSizeRange(2.5F, maxLookSize));
    c.a(1, new qv(this).setTargetSizeRange(minTargetSize, maxTargetSize));
    c.a(1, new py(this).setTargetSizeRange(minTargetSize, maxTargetSize));
    c.a(2, new qb(this));
    c.a(3, new qo(this));
    c.a(4, new qi(this, true));
    c.a(5, new qd(this, 0.6D));
    c.a(6, new pz(this));
    c.a(7, new qt(this));
    c.a(8, new qk(this, 0.32D));
    c.a(9, new pv(this, uf.class, 3.0F, 1.0F));
    c.a(9, new pv(this, ub.class, 5.0F, 0.02F));
    c.a(9, new qm(this, 0.6D));
    c.a(10, new px(this, og.class, 8.0F));
  }
  
  protected void az()
  {
    super.az();
    a(tp.d).a(0.5D);
  }
  



  public boolean bf()
  {
    return true;
  }
  



  protected void bk()
  {
    if (--bq <= 0)
    {
      q.A.a(ls.c(u), ls.c(v), ls.c(w));
      bq = (70 + ab.nextInt(50));
      bp = q.A.a(ls.c(u), ls.c(v), ls.c(w), 32);
      
      if (bp == null)
      {
        bR();
      }
      else
      {
        t chunkcoordinates = bp.a();
        b(a, b, c, (int)(bp.b() * 0.6F));
        
        if (bz)
        {
          bz = false;
          bp.b(5);
        }
      }
    }
    
    if ((!bW()) && (bv > 0))
    {
      bv -= 1;
      
      if (bv <= 0)
      {
        if (bw)
        {
          if (bu.size() > 1)
          {
            Iterator iterator = bu.iterator();
            
            while (iterator.hasNext())
            {
              abl merchantrecipe = (abl)iterator.next();
              
              if (merchantrecipe.g())
              {
                merchantrecipe.a(ab.nextInt(6) + ab.nextInt(6) + 2);
              }
            }
          }
          
          q(1);
          bw = false;
          
          if ((bp != null) && (by != null))
          {
            q.a(this, (byte)14);
            bp.a(by, 1);
          }
        }
        
        c(new nj(lH, 200, 0));
      }
    }
    
    super.bk();
  }
  

  public boolean couldTradeWith(uf par1EntityPlayer)
  {
    return (isEntityInRelativeSizeRange(par1EntityPlayer, minTargetSize, maxTargetSize)) || ((o(par1EntityPlayer)) && (isEntityInRelativeSizeRange(par1EntityPlayer, minLookSize, minTargetSize)) && (getEyeDistanceToEntityLiving(par1EntityPlayer) <= O * 3.0F) && (E.b - E.b > P * 0.5F));
  }
  



  public boolean a(uf par1EntityPlayer)
  {
    ye itemstack = bn.h();
    boolean flag = (itemstack != null) && (d == bEcv);
    
    if ((!flag) && (T()) && (!bW()) && (!g_()) && (!par1EntityPlayer.ah()) && (n != par1EntityPlayer) && (couldTradeWith(par1EntityPlayer)) && ((!isQuiteSmallerThan(par1EntityPlayer)) || (par1EntityPlayer.by() != null)) && ((!par1EntityPlayer.isTiny()) || (itemstack == null) || (itemstack.b() != yc.M)) && ((itemstack == null) || ((!(itemstack.b() instanceof yp)) && (!(itemstack.b() instanceof zd)))))
    {
      if (!q.I)
      {
        a_(par1EntityPlayer);
        par1EntityPlayer.a(this, bA());
      }
      
      return true;
    }
    

    return super.a(par1EntityPlayer);
  }
  

  protected void a()
  {
    super.a();
    ah.a(16, Integer.valueOf(0));
  }
  



  public double Y()
  {
    if (!g_())
    {
      return P * 0.675D;
    }
    

    return P * 0.54D;
  }
  




  public void b(by par1NBTTagCompound)
  {
    super.b(par1NBTTagCompound);
    par1NBTTagCompound.a("Profession", bT());
    par1NBTTagCompound.a("Riches", bx);
    
    if (bu != null)
    {
      par1NBTTagCompound.a("Offers", bu.a());
    }
  }
  



  public void a(by par1NBTTagCompound)
  {
    super.a(par1NBTTagCompound);
    p(par1NBTTagCompound.e("Profession"));
    bx = par1NBTTagCompound.e("Riches");
    
    if (par1NBTTagCompound.b("Offers"))
    {
      by nbttagcompound1 = par1NBTTagCompound.l("Offers");
      bu = new abm(nbttagcompound1);
    }
  }
  



  protected boolean t()
  {
    return false;
  }
  



  protected String r()
  {
    return bW() ? "mob.villager.haggle" : "mob.villager.idle";
  }
  



  protected String aO()
  {
    return "mob.villager.hit";
  }
  



  protected String aP()
  {
    return "mob.villager.death";
  }
  
  public void p(int par1)
  {
    ah.b(16, Integer.valueOf(par1));
  }
  
  public int bT()
  {
    return ah.c(16);
  }
  
  public boolean bU()
  {
    return br;
  }
  
  public void i(boolean par1)
  {
    br = par1;
  }
  
  public void j(boolean par1)
  {
    bs = par1;
  }
  
  public boolean bV()
  {
    return bs;
  }
  
  public void b(of par1EntityLivingBase)
  {
    super.b(par1EntityLivingBase);
    
    if ((bp != null) && (par1EntityLivingBase != null))
    {
      bp.a(par1EntityLivingBase);
      
      if ((par1EntityLivingBase instanceof uf))
      {
        byte b0 = -1;
        
        if (g_())
        {
          b0 = -3;
        }
        
        bp.a(((uf)par1EntityLivingBase).c_(), b0);
        
        if (T())
        {
          q.a(this, (byte)13);
        }
      }
    }
  }
  



  public void a(nb par1DamageSource)
  {
    if (bp != null)
    {
      nn entity = par1DamageSource.i();
      
      if (entity != null)
      {
        if ((entity instanceof uf))
        {
          bp.a(((uf)entity).c_(), -2);
        }
        else if ((entity instanceof th))
        {
          bp.h();
        }
      }
      else if (entity == null)
      {
        uf entityplayer = q.a(this, 16.0D);
        
        if (entityplayer != null)
        {
          bp.h();
        }
      }
    }
    
    super.a(par1DamageSource);
  }
  
  public void a_(uf par1EntityPlayer)
  {
    bt = par1EntityPlayer;
  }
  
  public uf m_()
  {
    return bt;
  }
  
  public boolean bW()
  {
    return bt != null;
  }
  
  public void a(abl par1MerchantRecipe)
  {
    par1MerchantRecipe.f();
    a_ = (-o());
    a("mob.villager.yes", ba(), bb());
    
    if (par1MerchantRecipe.a((abl)bu.get(bu.size() - 1)))
    {
      bv = 40;
      bw = true;
      
      if (bt != null)
      {
        by = bt.c_();
      }
      else
      {
        by = null;
      }
    }
    
    if (ad == bJcv)
    {
      bx += ab;
    }
  }
  
  public void a_(ye par1ItemStack)
  {
    if ((!q.I) && (a_ > -o() + 20))
    {
      a_ = (-o());
      
      if (par1ItemStack != null)
      {
        a("mob.villager.yes", ba(), bb());
      }
      else
      {
        a("mob.villager.no", ba(), bb());
      }
    }
  }
  
  public abm b(uf par1EntityPlayer)
  {
    if (bu == null)
    {
      q(1);
    }
    
    return bu;
  }
  



  private float p(float par1)
  {
    float f1 = par1 + bA;
    return f1 > 0.9F ? 0.9F - (f1 - 0.9F) : f1;
  }
  




  private void q(int par1)
  {
    if (bu != null)
    {
      bA = (ls.c(bu.size()) * 0.2F);
    }
    else
    {
      bA = 0.0F;
    }
    

    abm merchantrecipelist = new abm();
    VillagerRegistry.manageVillagerTrades(merchantrecipelist, this, bT(), ab);
    int j;
    int[] aint1;
    int l;
    switch (bT())
    {
    case 0: 
      a(merchantrecipelist, Vcv, ab, p(0.9F));
      a(merchantrecipelist, agcF, ab, p(0.5F));
      a(merchantrecipelist, bmcv, ab, p(0.5F));
      a(merchantrecipelist, aXcv, ab, p(0.4F));
      b(merchantrecipelist, Wcv, ab, p(0.9F));
      b(merchantrecipelist, bhcv, ab, p(0.3F));
      b(merchantrecipelist, lcv, ab, p(0.3F));
      b(merchantrecipelist, becv, ab, p(0.3F));
      b(merchantrecipelist, bgcv, ab, p(0.3F));
      b(merchantrecipelist, kcv, ab, p(0.3F));
      b(merchantrecipelist, bncv, ab, p(0.3F));
      b(merchantrecipelist, ncv, ab, p(0.5F));
      
      if (ab.nextFloat() < p(0.5F))
      {
        merchantrecipelist.add(new abl(new ye(aqz.K, 10), new ye(yc.bJ), new ye(arcv, 4 + ab.nextInt(2), 0)));
      }
      
      break;
    case 1: 
      a(merchantrecipelist, aMcv, ab, p(0.8F));
      a(merchantrecipelist, aNcv, ab, p(0.8F));
      a(merchantrecipelist, bIcv, ab, p(0.3F));
      b(merchantrecipelist, ascF, ab, p(0.8F));
      b(merchantrecipelist, RcF, ab, p(0.2F));
      b(merchantrecipelist, aScv, ab, p(0.2F));
      b(merchantrecipelist, aUcv, ab, p(0.2F));
      
      if (ab.nextFloat() < p(0.07F))
      {
        aau enchantment = aau.c[ab.nextInt(aau.c.length)];
        int k = ls.a(ab, enchantment.d(), enchantment.b());
        ye itemstack = yc.bY.a(new abb(enchantment, k));
        j = 2 + ab.nextInt(5 + k * 10) + 3 * k;
        merchantrecipelist.add(new abl(new ye(yc.aN), new ye(yc.bJ, j), itemstack)); }
      break;
    

    case 2: 
      b(merchantrecipelist, bCcv, ab, p(0.3F));
      b(merchantrecipelist, bFcv, ab, p(0.2F));
      b(merchantrecipelist, aEcv, ab, p(0.4F));
      b(merchantrecipelist, bicF, ab, p(0.3F));
      int[] aint = { scv, Bcv, agcv, akcv, jcv, Ecv, icv, Dcv };
      aint1 = aint;
      l = aint.length;
      j = 0;
    
    case 3: 
    case 4: 
      while (j < l)
      {



        int i1 = aint1[j];
        
        if (ab.nextFloat() < p(0.05F))
        {
          merchantrecipelist.add(new abl(new ye(i1, 1, 0), new ye(yc.bJ, 2 + ab.nextInt(3), 0), aaw.a(ab, new ye(i1, 1, 0), 5 + ab.nextInt(15))));
        }
        
        j++;
        continue;
        
        a(merchantrecipelist, ocv, ab, p(0.7F));
        a(merchantrecipelist, qcv, ab, p(0.5F));
        a(merchantrecipelist, rcv, ab, p(0.5F));
        a(merchantrecipelist, pcv, ab, p(0.5F));
        b(merchantrecipelist, scv, ab, p(0.5F));
        b(merchantrecipelist, Bcv, ab, p(0.5F));
        b(merchantrecipelist, jcv, ab, p(0.3F));
        b(merchantrecipelist, Ecv, ab, p(0.3F));
        b(merchantrecipelist, icv, ab, p(0.5F));
        b(merchantrecipelist, Dcv, ab, p(0.5F));
        b(merchantrecipelist, hcv, ab, p(0.2F));
        b(merchantrecipelist, Ccv, ab, p(0.2F));
        b(merchantrecipelist, Rcv, ab, p(0.2F));
        b(merchantrecipelist, Scv, ab, p(0.2F));
        b(merchantrecipelist, aicv, ab, p(0.2F));
        b(merchantrecipelist, amcv, ab, p(0.2F));
        b(merchantrecipelist, afcv, ab, p(0.2F));
        b(merchantrecipelist, ajcv, ab, p(0.2F));
        b(merchantrecipelist, agcv, ab, p(0.2F));
        b(merchantrecipelist, akcv, ab, p(0.2F));
        b(merchantrecipelist, ahcv, ab, p(0.2F));
        b(merchantrecipelist, alcv, ab, p(0.2F));
        b(merchantrecipelist, aecv, ab, p(0.1F));
        b(merchantrecipelist, abcv, ab, p(0.1F));
        b(merchantrecipelist, accv, ab, p(0.1F));
        b(merchantrecipelist, adcv, ab, p(0.1F));
        break;
        
        a(merchantrecipelist, ocv, ab, p(0.7F));
        a(merchantrecipelist, ascv, ab, p(0.5F));
        a(merchantrecipelist, bkcv, ab, p(0.5F));
        b(merchantrecipelist, aCcv, ab, p(0.1F));
        b(merchantrecipelist, Ycv, ab, p(0.3F));
        b(merchantrecipelist, aacv, ab, p(0.3F));
        b(merchantrecipelist, Xcv, ab, p(0.3F));
        b(merchantrecipelist, Zcv, ab, p(0.3F));
        b(merchantrecipelist, atcv, ab, p(0.3F));
        b(merchantrecipelist, blcv, ab, p(0.3F));
      }
    }
    if (merchantrecipelist.isEmpty())
    {
      a(merchantrecipelist, rcv, ab, 1.0F);
    }
    
    Collections.shuffle(merchantrecipelist);
    
    if (bu == null)
    {
      bu = new abm();
    }
    
    for (int j1 = 0; (j1 < par1) && (j1 < merchantrecipelist.size()); j1++)
    {
      bu.a((abl)merchantrecipelist.get(j1));
    }
  }
  


  @SideOnly(Side.CLIENT)
  public void a(abm par1MerchantRecipeList) {}
  

  public static void a(abm par0MerchantRecipeList, int par1, Random par2Random, float par3)
  {
    if (par2Random.nextFloat() < par3)
    {
      par0MerchantRecipeList.add(new abl(a(par1, par2Random), yc.bJ));
    }
  }
  
  private static ye a(int par0, Random par1Random)
  {
    return new ye(par0, b(par0, par1Random), 0);
  }
  



  private static int b(int par0, Random par1Random)
  {
    mh tuple = (mh)bB.get(Integer.valueOf(par0));
    return ((Integer)tuple.a()).intValue() >= ((Integer)tuple.b()).intValue() ? ((Integer)tuple.a()).intValue() : tuple == null ? 1 : ((Integer)tuple.a()).intValue() + par1Random.nextInt(((Integer)tuple.b()).intValue() - ((Integer)tuple.a()).intValue());
  }
  
  public static void b(abm par0MerchantRecipeList, int par1, Random par2Random, float par3)
  {
    if (par2Random.nextFloat() < par3)
    {
      int j = c(par1, par2Random);
      ye itemstack1;
      ye itemstack;
      ye itemstack1;
      if (j < 0)
      {
        ye itemstack = new ye(bJcv, 1, 0);
        itemstack1 = new ye(par1, -j, 0);
      }
      else
      {
        itemstack = new ye(bJcv, j, 0);
        itemstack1 = new ye(par1, 1, 0);
      }
      
      par0MerchantRecipeList.add(new abl(itemstack, itemstack1));
    }
  }
  
  private static int c(int par0, Random par1Random)
  {
    mh tuple = (mh)bC.get(Integer.valueOf(par0));
    return ((Integer)tuple.a()).intValue() >= ((Integer)tuple.b()).intValue() ? ((Integer)tuple.a()).intValue() : tuple == null ? 1 : ((Integer)tuple.a()).intValue() + par1Random.nextInt(((Integer)tuple.b()).intValue() - ((Integer)tuple.a()).intValue());
  }
  
  @SideOnly(Side.CLIENT)
  public void a(byte par1)
  {
    if (par1 == 12)
    {
      b("heart");
    }
    else if (par1 == 13)
    {
      b("angryVillager");
    }
    else if (par1 == 14)
    {
      b("happyVillager");
    }
    else
    {
      super.a(par1);
    }
  }
  
  public oi a(oi par1EntityLivingData)
  {
    par1EntityLivingData = super.a(par1EntityLivingData);
    VillagerRegistry.applyRandomTrade(this, q.s);
    return par1EntityLivingData;
  }
  




  @SideOnly(Side.CLIENT)
  private void b(String par1Str)
  {
    for (int i = 0; i < 5; i++)
    {
      double d0 = ab.nextGaussian() * 0.02D;
      double d1 = ab.nextGaussian() * 0.02D;
      double d2 = ab.nextGaussian() * 0.02D;
      q.a(par1Str, u + ab.nextFloat() * O * 2.0F - O, v + 1.0D + ab.nextFloat() * P, w + ab.nextFloat() * O * 2.0F - O, d0, d1, d2);
    }
  }
  
  public void bX()
  {
    bz = true;
  }
  
  public ub b(nk par1EntityAgeable)
  {
    ub entityvillager = new ub(q);
    entityvillager.a((oi)null);
    return entityvillager;
  }
  
  public boolean bG()
  {
    return false;
  }
  
  public nk a(nk par1EntityAgeable)
  {
    return b(par1EntityAgeable);
  }
  
  static
  {
    bB.put(Integer.valueOf(ocv), new mh(Integer.valueOf(16), Integer.valueOf(24)));
    bB.put(Integer.valueOf(qcv), new mh(Integer.valueOf(8), Integer.valueOf(10)));
    bB.put(Integer.valueOf(rcv), new mh(Integer.valueOf(8), Integer.valueOf(10)));
    bB.put(Integer.valueOf(pcv), new mh(Integer.valueOf(4), Integer.valueOf(6)));
    bB.put(Integer.valueOf(aMcv), new mh(Integer.valueOf(24), Integer.valueOf(36)));
    bB.put(Integer.valueOf(aNcv), new mh(Integer.valueOf(11), Integer.valueOf(13)));
    bB.put(Integer.valueOf(bIcv), new mh(Integer.valueOf(1), Integer.valueOf(1)));
    bB.put(Integer.valueOf(bpcv), new mh(Integer.valueOf(3), Integer.valueOf(4)));
    bB.put(Integer.valueOf(bCcv), new mh(Integer.valueOf(2), Integer.valueOf(3)));
    bB.put(Integer.valueOf(ascv), new mh(Integer.valueOf(14), Integer.valueOf(18)));
    bB.put(Integer.valueOf(bkcv), new mh(Integer.valueOf(14), Integer.valueOf(18)));
    bB.put(Integer.valueOf(bmcv), new mh(Integer.valueOf(14), Integer.valueOf(18)));
    bB.put(Integer.valueOf(aXcv), new mh(Integer.valueOf(9), Integer.valueOf(13)));
    bB.put(Integer.valueOf(Ucv), new mh(Integer.valueOf(34), Integer.valueOf(48)));
    bB.put(Integer.valueOf(bjcv), new mh(Integer.valueOf(30), Integer.valueOf(38)));
    bB.put(Integer.valueOf(bicv), new mh(Integer.valueOf(30), Integer.valueOf(38)));
    bB.put(Integer.valueOf(Vcv), new mh(Integer.valueOf(18), Integer.valueOf(22)));
    bB.put(Integer.valueOf(agcF), new mh(Integer.valueOf(14), Integer.valueOf(22)));
    bB.put(Integer.valueOf(bocv), new mh(Integer.valueOf(36), Integer.valueOf(64)));
    bC.put(Integer.valueOf(kcv), new mh(Integer.valueOf(3), Integer.valueOf(4)));
    bC.put(Integer.valueOf(bgcv), new mh(Integer.valueOf(3), Integer.valueOf(4)));
    bC.put(Integer.valueOf(scv), new mh(Integer.valueOf(7), Integer.valueOf(11)));
    bC.put(Integer.valueOf(Bcv), new mh(Integer.valueOf(12), Integer.valueOf(14)));
    bC.put(Integer.valueOf(jcv), new mh(Integer.valueOf(6), Integer.valueOf(8)));
    bC.put(Integer.valueOf(Ecv), new mh(Integer.valueOf(9), Integer.valueOf(12)));
    bC.put(Integer.valueOf(icv), new mh(Integer.valueOf(7), Integer.valueOf(9)));
    bC.put(Integer.valueOf(Dcv), new mh(Integer.valueOf(10), Integer.valueOf(12)));
    bC.put(Integer.valueOf(hcv), new mh(Integer.valueOf(4), Integer.valueOf(6)));
    bC.put(Integer.valueOf(Ccv), new mh(Integer.valueOf(7), Integer.valueOf(8)));
    bC.put(Integer.valueOf(Rcv), new mh(Integer.valueOf(4), Integer.valueOf(6)));
    bC.put(Integer.valueOf(Scv), new mh(Integer.valueOf(7), Integer.valueOf(8)));
    bC.put(Integer.valueOf(aicv), new mh(Integer.valueOf(4), Integer.valueOf(6)));
    bC.put(Integer.valueOf(amcv), new mh(Integer.valueOf(7), Integer.valueOf(8)));
    bC.put(Integer.valueOf(afcv), new mh(Integer.valueOf(4), Integer.valueOf(6)));
    bC.put(Integer.valueOf(ajcv), new mh(Integer.valueOf(7), Integer.valueOf(8)));
    bC.put(Integer.valueOf(agcv), new mh(Integer.valueOf(10), Integer.valueOf(14)));
    bC.put(Integer.valueOf(akcv), new mh(Integer.valueOf(16), Integer.valueOf(19)));
    bC.put(Integer.valueOf(ahcv), new mh(Integer.valueOf(8), Integer.valueOf(10)));
    bC.put(Integer.valueOf(alcv), new mh(Integer.valueOf(11), Integer.valueOf(14)));
    bC.put(Integer.valueOf(aecv), new mh(Integer.valueOf(5), Integer.valueOf(7)));
    bC.put(Integer.valueOf(abcv), new mh(Integer.valueOf(5), Integer.valueOf(7)));
    bC.put(Integer.valueOf(accv), new mh(Integer.valueOf(11), Integer.valueOf(15)));
    bC.put(Integer.valueOf(adcv), new mh(Integer.valueOf(9), Integer.valueOf(11)));
    bC.put(Integer.valueOf(Wcv), new mh(Integer.valueOf(-4), Integer.valueOf(-2)));
    bC.put(Integer.valueOf(bhcv), new mh(Integer.valueOf(-8), Integer.valueOf(-4)));
    bC.put(Integer.valueOf(lcv), new mh(Integer.valueOf(-8), Integer.valueOf(-4)));
    bC.put(Integer.valueOf(becv), new mh(Integer.valueOf(-10), Integer.valueOf(-7)));
    bC.put(Integer.valueOf(RcF), new mh(Integer.valueOf(-5), Integer.valueOf(-3)));
    bC.put(Integer.valueOf(ascF), new mh(Integer.valueOf(3), Integer.valueOf(4)));
    bC.put(Integer.valueOf(Ycv), new mh(Integer.valueOf(4), Integer.valueOf(5)));
    bC.put(Integer.valueOf(aacv), new mh(Integer.valueOf(2), Integer.valueOf(4)));
    bC.put(Integer.valueOf(Xcv), new mh(Integer.valueOf(2), Integer.valueOf(4)));
    bC.put(Integer.valueOf(Zcv), new mh(Integer.valueOf(2), Integer.valueOf(4)));
    bC.put(Integer.valueOf(aCcv), new mh(Integer.valueOf(6), Integer.valueOf(8)));
    bC.put(Integer.valueOf(bFcv), new mh(Integer.valueOf(-4), Integer.valueOf(-1)));
    bC.put(Integer.valueOf(aEcv), new mh(Integer.valueOf(-4), Integer.valueOf(-1)));
    bC.put(Integer.valueOf(aScv), new mh(Integer.valueOf(10), Integer.valueOf(12)));
    bC.put(Integer.valueOf(aUcv), new mh(Integer.valueOf(10), Integer.valueOf(12)));
    bC.put(Integer.valueOf(bicF), new mh(Integer.valueOf(-3), Integer.valueOf(-1)));
    bC.put(Integer.valueOf(atcv), new mh(Integer.valueOf(-7), Integer.valueOf(-5)));
    bC.put(Integer.valueOf(blcv), new mh(Integer.valueOf(-7), Integer.valueOf(-5)));
    bC.put(Integer.valueOf(bncv), new mh(Integer.valueOf(-8), Integer.valueOf(-6)));
    bC.put(Integer.valueOf(bCcv), new mh(Integer.valueOf(7), Integer.valueOf(11)));
    bC.put(Integer.valueOf(ncv), new mh(Integer.valueOf(-12), Integer.valueOf(-8)));
  }
}
