package gulliver.client;

import abw;
import aqz;
import asx;
import atv;
import aus;
import bcw;
import bdi;
import bev;
import ls;







public class EntityResizeableClientPlayerMP
  extends bdi
{
  public float ySizeOld;
  
  public EntityResizeableClientPlayerMP(atv par1Minecraft, abw par2World, aus par3Session, bcw par4NetClientHandler)
  {
    super(par1Minecraft, par2World, par3Session, par4NetClientHandler);
    ySizeOld = X;
  }
  





  public void c()
  {
    ySizeOld = X;
    super.c();
  }
  
  private boolean shouldPushOutOfBlock(int par1, int par2, int par3)
  {
    if (!q.u(par1, par2, par3))
    {
      return false;
    }
    
    if (isTiny())
    {
      aqz b = aqz.s[q.a(par1, par2, par3)];
      asx bb = b.b(q, par1, par2, par3);
      
      if ((bb == null) || (E.b >= e))
      {
        return false;
      }
    }
    
    return true;
  }
  





  protected boolean i(double par1, double par3, double par5)
  {
    if ((c.d) && (ySizeOld < 0.2F * getSizeMultiplier()))
    {
      X = (0.2F * getSizeMultiplier());
    }
    
    if (Z)
    {
      return false;
    }
    
    double low = getSizeMultiplier() < 0.25F ? 0.125D : getSizeMultiplier() >= 1.0F ? 0.5D : 0.5D * getSizeMultiplier();
    int i = ls.c(par1);
    int j = ls.c(par3 + low - 0.5D);
    int k = ls.c(par5);
    double d = par1 - i;
    double d1 = par5 - k;
    
    int hb = (int)P;
    boolean stuck = false;
    for (int n = 0; n <= hb; n++)
    {
      stuck |= shouldPushOutOfBlock(i, j + n, k);
    }
    if (stuck)
    {
      boolean flag = true;
      boolean flag1 = true;
      boolean flag2 = true;
      boolean flag3 = true;
      for (int n = 0; n <= hb; n++)
      {
        flag &= !shouldPushOutOfBlock(i - 1, j + n, k);
        flag1 &= !shouldPushOutOfBlock(i + 1, j + n, k);
        flag2 &= !shouldPushOutOfBlock(i, j + n, k - 1);
        flag3 &= !shouldPushOutOfBlock(i, j + n, k + 1);
      }
      byte byte0 = -1;
      double d2 = 9999.0D;
      
      if ((flag) && (d < d2))
      {
        d2 = d;
        byte0 = 0;
      }
      
      if ((flag1) && (1.0D - d < d2))
      {
        d2 = 1.0D - d;
        byte0 = 1;
      }
      
      if ((flag2) && (d1 < d2))
      {
        d2 = d1;
        byte0 = 4;
      }
      
      if ((flag3) && (1.0D - d1 < d2))
      {
        double d3 = 1.0D - d1;
        byte0 = 5;
      }
      
      float f = 0.1F * getSizeMultiplier();
      
      if (byte0 == 0)
      {
        x = (-f);
      }
      
      if (byte0 == 1)
      {
        x = f;
      }
      
      if (byte0 == 4)
      {
        z = (-f);
      }
      
      if (byte0 == 5)
      {
        z = f;
      }
    }
    
    return false;
  }
  

  public void a(String par1Str, float par2, float par3)
  {
    super.a(par1Str, par2 * getSizeMultiplierRoot(), par3);
  }
}
