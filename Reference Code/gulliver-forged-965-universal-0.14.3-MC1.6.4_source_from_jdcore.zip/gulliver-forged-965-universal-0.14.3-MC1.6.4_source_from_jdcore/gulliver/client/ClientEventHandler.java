package gulliver.client;

import atv;
import awf;
import bdi;
import ls;
import lv;
import net.minecraftforge.client.event.RenderGameOverlayEvent.Pre;

@cpw.mods.fml.relauncher.SideOnly(cpw.mods.fml.relauncher.Side.CLIENT)
public class ClientEventHandler
{
  atv mc;
  
  public ClientEventHandler()
  {
    mc = atv.w();
  }
  
  @net.minecraftforge.event.ForgeSubscribe
  public void handleAirGUI(RenderGameOverlayEvent.Pre event)
  {
    if (type == net.minecraftforge.client.event.RenderGameOverlayEvent.ElementType.AIR)
    {
      if ((!event.isCanceled()) && (event.isCancelable()))
      {
        int width = resolution.a();
        int height = resolution.b();
        
        mc.C.a("air");
        int left = width / 2 + 91;
        int top = height - 49;
        
        if (mc.h.al() < 300)
        {
          int air = mc.h.al();
          int full = ls.f((air - 2) * 10.0D / 300.0D);
          int partial = ls.f(air * 10.0D / 300.0D) - full;
          
          for (int i = 0; i < full + partial; i++)
          {
            mc.r.b(left - i * 8 - 9, top, i < full ? 16 : 25, 18, 9, 9);
          }
        }
        
        event.setCanceled(true);
      }
    }
  }
}
