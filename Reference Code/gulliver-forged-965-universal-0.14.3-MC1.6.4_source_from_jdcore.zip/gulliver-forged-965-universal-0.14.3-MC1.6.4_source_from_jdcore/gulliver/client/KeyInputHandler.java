package gulliver.client;

import ata;
import atb;
import ats;
import atv;
import bdc;
import bdi;
import cpw.mods.fml.client.registry.KeyBindingRegistry.KeyHandler;
import cpw.mods.fml.common.TickType;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.EnumSet;
import nn;
import ud;
import yc;
import ye;

@SideOnly(cpw.mods.fml.relauncher.Side.CLIENT)
public class KeyInputHandler extends KeyBindingRegistry.KeyHandler
{
  protected static ats keyUpsize = new ats("key.UPSIZE", 19);
  protected static ats keyDownsize = new ats("key.DOWNSIZE", 33);
  protected static ats keyShoulder = new ats("key.SHOULDER", 47);
  
  atv mc;
  
  public KeyInputHandler()
  {
    super(new ats[] { keyUpsize, keyDownsize, keyShoulder }, new boolean[] { false, false, false });
    mc = atv.w();
  }
  

  public String getLabel()
  {
    return "Gulliver Resizing Key Handler";
  }
  


  public void keyDown(EnumSet<TickType> types, ats kb, boolean tickEnd, boolean isRepeat)
  {
    if ((mc.n != null) || (tickEnd)) {
      return;
    }
    abw world = mc.f;
    
    if ((kb == keyUpsize) && (mc.c.h()))
    {

      ye itemstack = mc.h.bn.h();
      if ((itemstack != null) && (d == Fcv))
      {
        if ((mc.t != null) && (mc.t.a == atb.b))
        {
          mc.h.b("/entitydoublesize " + mc.t.g.k);
        }
        
      }
      else {
        mc.h.b("/doublesize");
      }
    }
    else if ((kb == keyDownsize) && (mc.c.h()))
    {

      ye itemstack = mc.h.bn.h();
      if ((itemstack != null) && (d == Fcv))
      {
        if ((mc.t != null) && (mc.t.a == atb.b))
        {
          mc.h.b("/entityhalfsize " + mc.t.g.k);
        }
        
      }
      else {
        mc.h.b("/halfsize");
      }
    }
    else if (kb == keyShoulder)
    {

      mc.h.b("/shoulderentity");
    }
  }
  

  public void keyUp(EnumSet<TickType> types, ats kb, boolean tickEnd)
  {
    if (tickEnd) {
      return;
    }
    for (ats key : mc.u.W)
    {
      if ((d == d) && (key != kb)) {
        e = false;
      }
    }
  }
  
  public EnumSet<TickType> ticks()
  {
    return EnumSet.of(TickType.CLIENT);
  }
}
