package gulliver.client;

import abw;
import acd;
import acf;
import amc;
import atc;
import ats;
import atv;
import aul;
import beg;
import bev;
import bex;
import gulliver.GulliverForged;
import gulliver.common.CommonProxy;
import gulliver.common.GulliverOMHelper;
import gulliver.common.InteractEventHandler;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.logging.Logger;
import js;
import lp;
import lv;
import net.minecraft.server.MinecraftServer;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.EventBus;
import nn;
import uf;

public class ClientProxy extends CommonProxy
{
  atv mc;
  static Class cfg = null;
  static Class ccolorizer = null;
  
  public ClientProxy()
  {
    mc = atv.w();
  }
  

  public String getCurrentLanguage()
  {
    return wu.an;
  }
  

  public void load()
  {
    MinecraftForge.EVENT_BUS.register(new ClientEventHandler());
    MinecraftForge.EVENT_BUS.register(new InteractEventHandler());
  }
  

  public void loadKeyBindings()
  {
    cpw.mods.fml.client.registry.KeyBindingRegistry.registerKeyBinding(new KeyInputHandler());
  }
  


  public void checkOtherMods()
  {
    GulliverOMHelper.hasOptifine = false;
    
    try
    {
      cfg = Class.forName("Config");
      cfg.getDeclaredField("OF_RELEASE");
      ccolorizer = Class.forName("CustomColorizer");
      GulliverOMHelper.hasOptifine = true;
    }
    catch (ClassNotFoundException e) {}catch (NoSuchFieldException e) {}
    


    GulliverOMHelper.hasTMI = false;
    
    try
    {
      getClass().getClassLoader().loadClass("TMIItemInfo");
      GulliverOMHelper.hasTMI = true;
    }
    catch (ClassNotFoundException e) {}
    
    super.checkOtherMods();
  }
  

  public void checkOtherModsInit()
  {
    super.checkOtherModsInit();
    
    if (GulliverOMHelper.hasOptifine)
    {
      GulliverForged.logger.info("Optifine found");
    }
    else
    {
      GulliverForged.logger.info("Optifine not found");
    }
    
    if (GulliverOMHelper.hasTMI)
    {
      GulliverForged.logger.info("Too Many Items found");
      try
      {
        Field modifiersField = Field.class.getDeclaredField("modifiers");
        modifiersField.setAccessible(true);
        
        Field field_potionValues = Class.forName("TMIItemInfo").getDeclaredField("potionValues");
        

        ArrayList poVal = (ArrayList)ArrayList.class.cast(field_potionValues.get(null));
        for (int d = 0; d < 2; d++)
        {
          poVal.add(Integer.valueOf(7 + d * 8 + 8192));
          poVal.add(Integer.valueOf(7 + d * 8 + 32 + 8192));
          poVal.add(Integer.valueOf(7 + d * 8 + 64 + 8192));
          poVal.add(Integer.valueOf(7 + d * 8 + 32 + 64 + 8192));
          poVal.add(Integer.valueOf(7 + d * 8 + 16384));
          poVal.add(Integer.valueOf(7 + d * 8 + 32 + 16384));
          poVal.add(Integer.valueOf(7 + d * 8 + 64 + 16384));
          poVal.add(Integer.valueOf(7 + d * 8 + 32 + 64 + 16384));
        }
        java.util.Collections.sort(poVal);
        field_potionValues.set(null, poVal);
        GulliverForged.logger.info("added resizing Potions to TMI menu");
      }
      catch (ClassNotFoundException e)
      {
        e.printStackTrace();
      }
      catch (NoSuchFieldException e)
      {
        e.printStackTrace();
      }
      catch (IllegalAccessException e)
      {
        e.printStackTrace();
      }
    }
    else
    {
      GulliverForged.logger.info("Too Many Items not found");
    }
  }
  

  public boolean isClientPlayerEntity(nn par1Entity)
  {
    return par1Entity instanceof bdi;
  }
  

  public boolean isClientsideEntity(nn par1Entity)
  {
    return par1Entity instanceof beg;
  }
  

  public void clearClientMouseover()
  {
    wt = null;
  }
  

  public boolean isClientAttacking()
  {
    return wu.R.c();
  }
  

  public boolean getClientPlayerMovementSneak(uf par1EntityPlayer)
  {
    return (par1EntityPlayer instanceof bex) ? c.d : false;
  }
  

  public boolean getClientPlayerMovementJump(uf par1EntityPlayer)
  {
    return (par1EntityPlayer instanceof bex) ? c.c : false;
  }
  

  public boolean setOptifineZoom(boolean par1)
  {
    if (!GulliverOMHelper.hasOptifine())
    {
      return false;
    }
    try
    {
      Field field_ofZoomMode = cfg.getDeclaredField("zoomMode");
      field_ofZoomMode.set(null, Boolean.valueOf(par1));
      return true;
    }
    catch (NoSuchFieldException e)
    {
      e.printStackTrace();
    }
    catch (IllegalAccessException e)
    {
      e.printStackTrace();
    }
    
    return false;
  }
  

  public boolean getOptifineZoom()
  {
    if (!GulliverOMHelper.hasOptifine())
    {
      return false;
    }
    try
    {
      return Boolean.valueOf(cfg.getDeclaredField("zoomMode").getBoolean(null)).booleanValue();

    }
    catch (NoSuchFieldException e)
    {
      e.printStackTrace();
    }
    catch (IllegalAccessException e)
    {
      e.printStackTrace();
    }
    
    return false;
  }
  

  public boolean checkOptifineSettings()
  {
    if (!GulliverOMHelper.hasOptifine())
    {
      return false;
    }
    
    boolean optifine_ok = false;
    
    try
    {
      GulliverOMHelper.ofFancyFog = ((Boolean)cfg.getDeclaredMethod("isFogFancy", new Class[0]).invoke(null, new Object[0])).booleanValue();
      GulliverOMHelper.ofFastFog = ((Boolean)cfg.getDeclaredMethod("isFogFast", new Class[0]).invoke(null, new Object[0])).booleanValue();
      GulliverOMHelper.ofDepthFog = ((Boolean)cfg.getDeclaredMethod("isDepthFog", new Class[0]).invoke(null, new Object[0])).booleanValue();
      GulliverOMHelper.ofFancyWater = ((Boolean)cfg.getDeclaredMethod("isWaterFancy", new Class[0]).invoke(null, new Object[0])).booleanValue();
      GulliverOMHelper.ofClearWater = ((Boolean)cfg.getDeclaredMethod("isClearWater", new Class[0]).invoke(null, new Object[0])).booleanValue();
      GulliverOMHelper.ofRainFancy = ((Boolean)cfg.getDeclaredMethod("isRainFancy", new Class[0]).invoke(null, new Object[0])).booleanValue();
      GulliverOMHelper.ofRainSplash = ((Boolean)cfg.getDeclaredMethod("isRainSplash", new Class[0]).invoke(null, new Object[0])).booleanValue();
      GulliverOMHelper.ofRainOff = ((Boolean)cfg.getDeclaredMethod("isRainOff", new Class[0]).invoke(null, new Object[0])).booleanValue();
      GulliverOMHelper.ofSkyEnabled = ((Boolean)cfg.getDeclaredMethod("isSkyEnabled", new Class[0]).invoke(null, new Object[0])).booleanValue();
      GulliverOMHelper.ofPlanetsEnabled = ((Boolean)cfg.getDeclaredMethod("isSunMoonEnabled", new Class[0]).invoke(null, new Object[0])).booleanValue();
      GulliverOMHelper.ofStarsEnabled = ((Boolean)cfg.getDeclaredMethod("isStarsEnabled", new Class[0]).invoke(null, new Object[0])).booleanValue();
      GulliverOMHelper.ofFogStart = ((Float)cfg.getDeclaredMethod("getFogStart", new Class[0]).invoke(null, new Object[0])).floatValue();
      GulliverOMHelper.ofFancyTrees = ((Boolean)cfg.getDeclaredMethod("isTreesFancy", new Class[0]).invoke(null, new Object[0])).booleanValue();
      GulliverOMHelper.ofFancyGrass = ((Boolean)cfg.getDeclaredMethod("isGrassFancy", new Class[0]).invoke(null, new Object[0])).booleanValue();
      GulliverOMHelper.ofFancyBetterGrass = ((Boolean)cfg.getDeclaredMethod("isBetterGrassFancy", new Class[0]).invoke(null, new Object[0])).booleanValue();
      GulliverOMHelper.ofFancyDrops = ((Boolean)cfg.getDeclaredMethod("isDroppedItemsFancy", new Class[0]).invoke(null, new Object[0])).booleanValue();
      aul gs = wu;
      GulliverOMHelper.ofRenderDistanceFine = Integer.valueOf(gs.getClass().getDeclaredField("ofRenderDistanceFine").getInt(gs)).intValue();
      GulliverOMHelper.ofZoomKeyCode = castgetClassgetDeclaredField"ofKeyBindZoom"getd;
      
      optifine_ok = true;
    }
    catch (NoSuchMethodException e)
    {
      e.printStackTrace();
    }
    catch (NoSuchFieldException e)
    {
      e.printStackTrace();
    }
    catch (InvocationTargetException e)
    {
      e.printStackTrace();
    }
    catch (IllegalAccessException e)
    {
      e.printStackTrace();
    }
    
    return optifine_ok;
  }
  

  public js getOptifineWorldServer(MinecraftServer par1MinecraftServer, amc par2ISaveHandler, String par3Str, int par4, acd par5WorldSettings, lv par6Profiler, lp par7ILogAgent)
  {
    if (GulliverOMHelper.hasOptifine()) {
      try
      {
        return (js)Class.forName("WorldServerOF").getDeclaredConstructor(new Class[] { MinecraftServer.class, amc.class, String.class, Integer.TYPE, acd.class, lv.class, lp.class }).newInstance(new Object[] { par1MinecraftServer, par2ISaveHandler, par3Str, Integer.valueOf(par4), par5WorldSettings, par6Profiler, par7ILogAgent });
      }
      catch (ClassNotFoundException e)
      {
        e.printStackTrace();
      }
      catch (NoSuchMethodException e)
      {
        e.printStackTrace();
      }
      catch (InvocationTargetException e)
      {
        e.printStackTrace();
      }
      catch (IllegalAccessException e)
      {
        e.printStackTrace();
      }
      catch (IllegalArgumentException e)
      {
        e.printStackTrace();
      }
      catch (SecurityException e)
      {
        e.printStackTrace();
      }
      catch (InstantiationException e)
      {
        e.printStackTrace();
      }
    }
    
    return new js(par1MinecraftServer, par2ISaveHandler, par3Str, par4, par5WorldSettings, par6Profiler, par7ILogAgent);
  }
  

  public void optifineRegisterTextureUtilsListener()
  {
    if (!GulliverOMHelper.hasOptifine())
    {
      return;
    }
    try
    {
      Class.forName("TextureUtils").getDeclaredMethod("registerResourceListener", new Class[0]).invoke(null, new Object[0]);
    }
    catch (ClassNotFoundException e)
    {
      e.printStackTrace();
    }
    catch (NoSuchMethodException e)
    {
      e.printStackTrace();
    }
    catch (InvocationTargetException e)
    {
      e.printStackTrace();
    }
    catch (IllegalAccessException e)
    {
      e.printStackTrace();
    }
  }
  

  public void optifineCheckDisplayMode()
  {
    if (!GulliverOMHelper.hasOptifine())
    {
      return;
    }
    try
    {
      cfg.getDeclaredMethod("checkDisplayMode", new Class[0]).invoke(null, new Object[0]);
    }
    catch (NoSuchMethodException e)
    {
      e.printStackTrace();
    }
    catch (InvocationTargetException e)
    {
      e.printStackTrace();
    }
    catch (IllegalAccessException e)
    {
      e.printStackTrace();
    }
  }
  

  public void updateOptifineWorldStuff(abw world0, abw world1)
  {
    if ((!GulliverOMHelper.hasOptifine()) || (world0 == world1))
    {
      return;
    }
    try
    {
      Class.forName("RandomMobs").getDeclaredMethod("worldChanged", new Class[] { abw.class, abw.class }).invoke(null, new Object[] { world0, world1 });
      cfg.getDeclaredMethod("updateThreadPriorities", new Class[0]).invoke(null, new Object[0]);
    }
    catch (ClassNotFoundException e)
    {
      e.printStackTrace();
    }
    catch (NoSuchMethodException e)
    {
      e.printStackTrace();
    }
    catch (InvocationTargetException e)
    {
      e.printStackTrace();
    }
    catch (IllegalAccessException e)
    {
      e.printStackTrace();
    }
  }
  

  public boolean updateOptifineCustomLightmap(abw world, float flickerX, int[] lmapColors, boolean nightvision)
  {
    if (GulliverOMHelper.hasOptifine()) {
      try
      {
        return ((Boolean)ccolorizer.getDeclaredMethod("updateLightmap", new Class[] { abw.class, Float.TYPE, [I.class, Boolean.TYPE }).invoke(null, new Object[] { world, Float.valueOf(flickerX), lmapColors, Boolean.valueOf(nightvision) })).booleanValue();
      }
      catch (NoSuchMethodException e)
      {
        e.printStackTrace();
      }
      catch (InvocationTargetException e)
      {
        e.printStackTrace();
      }
      catch (IllegalAccessException e)
      {
        e.printStackTrace();
      }
    }
    
    return false;
  }
  

  public boolean updateOptifineCustomWaterFX(beg waterFX, acf world)
  {
    if (GulliverOMHelper.hasOptifine()) {
      try
      {
        ccolorizer.getDeclaredMethod("updateWaterFX", new Class[] { beg.class, acf.class }).invoke(null, new Object[] { waterFX, world });
      }
      catch (NoSuchMethodException e)
      {
        e.printStackTrace();
      }
      catch (InvocationTargetException e)
      {
        e.printStackTrace();
      }
      catch (IllegalAccessException e)
      {
        e.printStackTrace();
      }
    }
    
    return false;
  }
  

  public atc getOptifineCustomColor(String method, atc cvec)
  {
    if (GulliverOMHelper.hasOptifine()) {
      try
      {
        cvec = (atc)ccolorizer.getDeclaredMethod(method, new Class[] { atc.class }).invoke(null, new Object[] { cvec });
      }
      catch (NoSuchMethodException e)
      {
        e.printStackTrace();
      }
      catch (InvocationTargetException e)
      {
        e.printStackTrace();
      }
      catch (IllegalAccessException e)
      {
        e.printStackTrace();
      }
    }
    
    return cvec;
  }
  

  public atc getOptifineCustomPosColor(String method, atc cvec, acf world, double x, double y, double z)
  {
    if (GulliverOMHelper.hasOptifine()) {
      try
      {
        cvec = (atc)ccolorizer.getDeclaredMethod(method, new Class[] { atc.class, acf.class, Double.TYPE, Double.TYPE, Double.TYPE }).invoke(null, new Object[] { cvec, world, Double.valueOf(x), Double.valueOf(y), Double.valueOf(z) });
      }
      catch (NoSuchMethodException e)
      {
        e.printStackTrace();
      }
      catch (InvocationTargetException e)
      {
        e.printStackTrace();
      }
      catch (IllegalAccessException e)
      {
        e.printStackTrace();
      }
    }
    
    return cvec;
  }
  

  public atc getOptifineCustomUnderwaterColor(acf world, double x, double y, double z)
  {
    if (GulliverOMHelper.hasOptifine()) {
      try
      {
        return (atc)ccolorizer.getDeclaredMethod("getUnderwaterColor", new Class[] { acf.class, Double.TYPE, Double.TYPE, Double.TYPE }).invoke(null, new Object[] { world, Double.valueOf(x), Double.valueOf(y), Double.valueOf(z) });
      }
      catch (NoSuchMethodException e)
      {
        e.printStackTrace();
      }
      catch (InvocationTargetException e)
      {
        e.printStackTrace();
      }
      catch (IllegalAccessException e)
      {
        e.printStackTrace();
      }
    }
    
    return null;
  }
  

  public void resumeOptifineBackgroundUpdates()
  {
    if (!GulliverOMHelper.hasOptifine())
    {
      return;
    }
    try
    {
      Class.forName("WrUpdates").getDeclaredMethod("resumeBackgroundUpdates", new Class[0]).invoke(null, new Object[0]);
    }
    catch (ClassNotFoundException e)
    {
      e.printStackTrace();
    }
    catch (NoSuchMethodException e)
    {
      e.printStackTrace();
    }
    catch (InvocationTargetException e)
    {
      e.printStackTrace();
    }
    catch (IllegalAccessException e)
    {
      e.printStackTrace();
    }
  }
  

  public void pauseOptifineBackgroundUpdates()
  {
    if (!GulliverOMHelper.hasOptifine())
    {
      return;
    }
    try
    {
      Class.forName("WrUpdates").getDeclaredMethod("pauseBackgroundUpdates", new Class[0]).invoke(null, new Object[0]);
    }
    catch (ClassNotFoundException e)
    {
      e.printStackTrace();
    }
    catch (NoSuchMethodException e)
    {
      e.printStackTrace();
    }
    catch (InvocationTargetException e)
    {
      e.printStackTrace();
    }
    catch (IllegalAccessException e)
    {
      e.printStackTrace();
    }
  }
}
