package gulliver;

import abw;
import ec;
import gulliver.network.packet.Packet172AttachEntitySpecial;
import jm;
import js;
import jv;
import jw;
import ka;
import net.minecraft.server.MinecraftServer;
import nn;
import ug;

public class EntityResizeablePlayerMP
  extends jv
{
  public EntityResizeablePlayerMP(MinecraftServer par1MinecraftServer, abw par2World, String par3Str, jw par4ItemInWorldManager)
  {
    super(par1MinecraftServer, par2World, par3Str, par4ItemInWorldManager);
  }
  


  public float f()
  {
    return 1.62F * getSizeMultiplier();
  }
  




  public void a(double par1, double par3, double par5)
  {
    if (holdingEntity != null)
    {
      nn holder = holdingEntity;
      holder.dropHeldEntity(this);
      Packet172AttachEntitySpecial var5 = new Packet172AttachEntitySpecial(this, holder, (byte)0);
      p().q().a(this, var5);
    }
    a.a(par1, par3, par5, A, B);
  }
  




  public ug a(int par1, int par2, int par3)
  {
    return sleepInSizedBedAt(q, par1, par2, par3);
  }
  




  public ug sleepInSizedBedAt(abw par0World, int par1, int par2, int par3)
  {
    ug enumstatus = super.sleepInSizedBedAt(par0World, par1, par2, par3);
    
    if (enumstatus == ug.a)
    {
      ec packet17sleep = new ec(this, 0, par1, par2, par3);
      p().q().a(this, packet17sleep);
      a.a(u, v, w, A, B);
      a.b(packet17sleep);
    }
    
    return enumstatus;
  }
}
