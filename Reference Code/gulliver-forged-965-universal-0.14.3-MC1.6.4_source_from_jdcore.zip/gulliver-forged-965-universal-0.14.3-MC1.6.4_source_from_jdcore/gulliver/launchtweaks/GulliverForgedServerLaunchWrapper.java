package gulliver.launchtweaks;

import cpw.mods.fml.relauncher.ServerLaunchWrapper;

public class GulliverForgedServerLaunchWrapper {
  public GulliverForgedServerLaunchWrapper() {}
  
  public static void main(String[] args) {
    System.setProperty("fml.ignorePatchDiscrepancies", "true");
    ServerLaunchWrapper.main(args);
  }
}
