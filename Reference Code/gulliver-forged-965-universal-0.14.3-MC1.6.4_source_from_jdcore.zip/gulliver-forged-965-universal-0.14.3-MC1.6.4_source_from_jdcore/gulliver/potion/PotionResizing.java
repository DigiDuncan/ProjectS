package gulliver.potion;

import java.util.HashMap;
import ni;
import nj;
import of;
import zp;




public class PotionResizing
  extends ni
{
  public static ni tiny;
  public static ni huge;
  public static final String mushroomRedEffect = "+0+1+2-3&4-4+13";
  public static final String mushroomBrownEffect = "+0+1+2+3&4-4+13";
  
  public PotionResizing(int par1, boolean par2, int par3)
  {
    super(par1, par2, par3);
  }
  
  public static void initResizingPotions(int tinyid, int hugeid)
  {
    tiny = new PotionResizing(tinyid, false, 8190976).b("potion.tiny");
    huge = new PotionResizing(hugeid, false, 9662683).b("potion.huge");
    




    zp.m.put(Integer.valueOf(huge.c()), "0 & 1 & 2 & !3 & 2+6");
    zp.m.put(Integer.valueOf(tiny.c()), "0 & 1 & 2 & 3 & 2+6");
    
    zp.n.put(Integer.valueOf(huge.c()), "5");
    zp.n.put(Integer.valueOf(tiny.c()), "5");
  }
  

  public void a(of par1EntityLivingBase, int par2)
  {
    if (H == hugeH)
    {

      int amp = par1EntityLivingBase.b(huge).c();
      amp = amp > 8 ? 8 : amp >= 255 ? -1 : amp;
      sizePotionMultiplier = Math.scalb(4.0F, amp);
    }
    else if (H == tinyH)
    {

      int amp = par1EntityLivingBase.b(tiny).c();
      amp = amp > 8 ? 8 : amp >= 255 ? -1 : amp;
      sizePotionMultiplier = Math.scalb(0.25F, -amp);
    }
    else
    {
      super.a(par1EntityLivingBase, par2);
    }
  }
  




  public boolean a(int par1, int par2)
  {
    return true;
  }
  

  public void finishEffect(of par1EntityLivingBase)
  {
    sizePotionMultiplier = 1.0F;
  }
}
