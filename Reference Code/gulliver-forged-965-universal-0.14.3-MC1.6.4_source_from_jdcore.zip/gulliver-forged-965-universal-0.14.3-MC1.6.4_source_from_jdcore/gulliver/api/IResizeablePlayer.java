package gulliver.api;

public abstract interface IResizeablePlayer
  extends IResizeableLiving
{}
