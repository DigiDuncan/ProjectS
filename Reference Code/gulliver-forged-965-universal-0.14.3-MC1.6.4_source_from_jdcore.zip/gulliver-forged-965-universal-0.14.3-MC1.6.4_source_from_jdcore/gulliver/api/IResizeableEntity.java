package gulliver.api;

public abstract interface IResizeableEntity
{
  public abstract float getSizeMultiplier();
  
  public abstract float getSizeMultiplierRoot();
  
  public abstract void halveSize();
  
  public abstract void doubleSize();
  
  public abstract boolean isTiny();
  
  public abstract boolean isExtraTiny();
  
  public abstract boolean isHuge();
  
  public abstract float getStepHeight();
}
