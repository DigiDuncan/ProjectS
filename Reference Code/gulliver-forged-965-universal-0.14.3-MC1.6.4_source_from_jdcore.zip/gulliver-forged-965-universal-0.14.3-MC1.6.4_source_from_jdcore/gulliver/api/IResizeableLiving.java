package gulliver.api;

public abstract interface IResizeableLiving
  extends IResizeableEntity
{
  public abstract float getSizePotionMultiplier();
  
  public abstract float getSizeItemMultiplier();
  
  public abstract void setBaseSize(float paramFloat);
  
  public abstract void adjustBaseSize(float paramFloat);
}
