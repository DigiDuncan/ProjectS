package gulliver;

import aa;
import abt;
import cpw.mods.fml.common.FMLCommonHandler;
import cpw.mods.fml.common.FMLLog;
import cpw.mods.fml.common.IFMLSidedHandler;
import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.Mod.EventHandler;
import cpw.mods.fml.common.Mod.Instance;
import cpw.mods.fml.common.SidedProxy;
import cpw.mods.fml.common.event.FMLInitializationEvent;
import cpw.mods.fml.common.event.FMLPostInitializationEvent;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import cpw.mods.fml.common.event.FMLServerStartedEvent;
import cpw.mods.fml.common.network.NetworkMod;
import gulliver.command.CommandBaseSizeAdjust;
import gulliver.command.CommandDoubleSize;
import gulliver.command.CommandEntityBaseSizeAdjust;
import gulliver.command.CommandEntityDoubleSize;
import gulliver.command.CommandEntityShowSize;
import gulliver.command.CommandInstantKarma;
import gulliver.command.CommandShoulderEntity;
import gulliver.command.CommandShowMySize;
import gulliver.common.CommonProxy;
import gulliver.common.GulliverBlockReplacer;
import gulliver.common.GulliverEnvoy;
import java.util.Random;
import java.util.logging.Logger;
import js;
import net.minecraft.server.MinecraftServer;

@Mod(modid="GulliverForged", name="Gulliver Forged", version="0.14.3", dependencies="required-after:Forge@[9.11.1.953,9.11.1.965]")
@NetworkMod(clientSideRequired=true, serverSideRequired=false)
public class GulliverForged
{
  public static final String ID = "GulliverForged";
  public static final String VERSION = "0.14.3";
  @Mod.Instance("GulliverForged")
  public static GulliverForged instance;
  @SidedProxy(clientSide="gulliver.client.ClientProxy", serverSide="gulliver.common.CommonProxy")
  public static CommonProxy proxy;
  public static Logger logger;
  public static Random rand = new Random();
  

  public static boolean modIsInit = false;
  public static boolean modIsLoaded = false;
  
  public GulliverForged() {}
  
  @Mod.EventHandler
  public void preInit(FMLPreInitializationEvent event) { logger = Logger.getLogger("GulliverForged");
    logger.setParent(FMLLog.getLogger());
    gulliver.common.GulliverConfigHelper.initConfiguration(event.getSuggestedConfigurationFile());
    GulliverEnvoy.registerAchievements();
    GulliverEnvoy.initResizingEffects();
    GulliverBlockReplacer.registerReplacementBlocks();
  }
  
  @Mod.EventHandler
  public void load(FMLInitializationEvent event)
  {
    if (modIsLoaded)
    {
      logger.warning("Already loaded Gulliver!");
      return;
    }
    
    proxy.checkOtherMods();
    proxy.load();
    proxy.loadKeyBindings();
    
    modIsLoaded = true;
  }
  
  @Mod.EventHandler
  public void modsLoaded(FMLPostInitializationEvent event)
  {
    if (modIsInit)
    {
      logger.warning("Already initialized Gulliver!");
      return;
    }
    
    proxy.checkOtherModsInit();
    modIsInit = true;
  }
  

  @Mod.EventHandler
  public void registerCommandsAndRules(FMLServerStartedEvent e)
  {
    aa handler = (aa)FMLCommonHandler.instance().getSidedDelegate().getServer().G();
    handler.a(new gulliver.command.CommandBaseSize());
    handler.a(new CommandBaseSizeAdjust());
    handler.a(new gulliver.command.CommandHalfSize());
    handler.a(new CommandDoubleSize());
    handler.a(new gulliver.command.CommandShowSize());
    handler.a(new CommandShowMySize());
    handler.a(new gulliver.command.CommandEntityHalfSize());
    handler.a(new CommandEntityDoubleSize());
    handler.a(new gulliver.command.CommandEntityBaseSize());
    handler.a(new CommandEntityBaseSizeAdjust());
    handler.a(new CommandEntityShowSize());
    handler.a(new CommandInstantKarma());
    handler.a(new CommandShoulderEntity());
    handler.a(new gulliver.command.CommandServerReloadGulliver());
    

    abt gamerules = FMLCommonHandler.instance().getSidedDelegate().getServer().a(0).O();
    if (!gamerules.e("sizeGriefing"))
    {
      gamerules.a("sizeGriefing", "true");
    }
  }
}
