package gulliver.network.packet;

import ey;
import ez;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import nn;



public class Packet171EntitySize
  extends ey
{
  public int entityId;
  public float sizeMult;
  
  public Packet171EntitySize() {}
  
  public Packet171EntitySize(nn par1Entity, float par2)
  {
    entityId = k;
    sizeMult = par2;
  }
  


  public void a(DataInput par1DataInput)
    throws IOException
  {
    entityId = par1DataInput.readInt();
    sizeMult = par1DataInput.readFloat();
  }
  



  public void a(DataOutput par1DataOutput)
    throws IOException
  {
    par1DataOutput.writeInt(entityId);
    par1DataOutput.writeFloat(sizeMult);
  }
  



  public void a(ez par1NetHandler)
  {
    par1NetHandler.handleEntitySize(this);
  }
  



  public int a()
  {
    return 6;
  }
  



  public boolean e()
  {
    return true;
  }
}
