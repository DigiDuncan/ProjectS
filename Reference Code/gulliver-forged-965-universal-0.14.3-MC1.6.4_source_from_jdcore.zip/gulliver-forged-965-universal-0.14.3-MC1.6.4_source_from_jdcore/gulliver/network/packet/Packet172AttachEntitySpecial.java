package gulliver.network.packet;

import ez;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import nn;

public class Packet172AttachEntitySpecial extends ey
{
  public int entityId;
  public int vehicleEntityId;
  public byte attachmentType;
  
  public Packet172AttachEntitySpecial() {}
  
  public Packet172AttachEntitySpecial(nn par1Entity, nn par2Entity, byte par3)
  {
    entityId = (par1Entity != null ? k : -1);
    vehicleEntityId = (par2Entity != null ? k : -1);
    attachmentType = par3;
  }
  



  public int a()
  {
    return 9;
  }
  


  public void a(DataInput par1DataInput)
    throws IOException
  {
    entityId = par1DataInput.readInt();
    vehicleEntityId = par1DataInput.readInt();
    attachmentType = par1DataInput.readByte();
  }
  


  public void a(DataOutput par1DataOutput)
    throws IOException
  {
    par1DataOutput.writeInt(entityId);
    par1DataOutput.writeInt(vehicleEntityId);
    par1DataOutput.writeByte(attachmentType);
  }
  



  public void a(ez par1NetHandler)
  {
    par1NetHandler.handleAttachEntitySpecial(this);
  }
  



  public boolean e()
  {
    return true;
  }
}
