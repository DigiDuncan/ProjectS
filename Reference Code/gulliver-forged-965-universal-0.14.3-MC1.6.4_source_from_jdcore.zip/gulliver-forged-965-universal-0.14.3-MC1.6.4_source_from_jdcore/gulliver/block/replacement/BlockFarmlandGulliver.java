package gulliver.block.replacement;

import abt;
import abw;
import aqz;
import nn;
import uf;

public class BlockFarmlandGulliver extends aof
{
  public BlockFarmlandGulliver(int par1)
  {
    super(par1);
  }
  




  public void b(abw par1World, int par2, int par3, int par4, nn par5Entity)
  {
    if ((!I) && (par5Entity.isHuge()) && (!par5Entity.ah()) && (s.nextInt(2) == 0))
    {
      if ((!(par5Entity instanceof uf)) && (!par1World.O().b("mobGriefing")))
      {
        return;
      }
      
      par1World.c(par2, par3, par4, AcF);
    }
  }
  




  public void a(abw par1World, int par2, int par3, int par4, nn par5Entity, float par6)
  {
    if ((!I) && (!par5Entity.isTiny()) && ((par5Entity.isHuge()) || (s.nextFloat() < par6 - 0.5F)))
    {
      if ((!(par5Entity instanceof uf)) && (!par1World.O().b("mobGriefing")))
      {
        return;
      }
      
      par1World.c(par2, par3, par4, AcF);
    }
  }
}
