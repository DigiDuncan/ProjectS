package gulliver.block.replacement;

import abw;
import aru;
import asx;
import asz;
import gulliver.common.GulliverOMHelper;
import java.util.List;
import nn;
import of;

public class BlockCarpetGulliver
  extends aru
{
  public BlockCarpetGulliver(int par1)
  {
    super(par1);
  }
  



  public void a(abw par1World, int par2, int par3, int par4, asx par5AxisAlignedBB, List par6List, nn par7Entity)
  {
    int var5 = 0;
    float var6 = 0.03125F;
    
    if ((par7Entity != null) && ((par7Entity instanceof of)))
    {
      asx var8 = null;
      
      if ((!par7Entity.ah()) && (par7Entity.isTiny()) && (!GulliverOMHelper.isLittleBlocksWorld(par1World)))
      {
        if (par7Entity.isExtraTiny())
        {
          var5 = 1;
        }
        else
        {
          var5 = 2;
        }
      }
      
      var8 = var5 > 0 ? asx.a().a(par2 + cM, par3 + cN, par4 + cO, par2 + cP, par3 + var5 * var6, par4 + cR) : null;
      
      if ((var8 != null) && (par5AxisAlignedBB.b(var8)))
      {
        par6List.add(var8);
      }
    }
  }
}
