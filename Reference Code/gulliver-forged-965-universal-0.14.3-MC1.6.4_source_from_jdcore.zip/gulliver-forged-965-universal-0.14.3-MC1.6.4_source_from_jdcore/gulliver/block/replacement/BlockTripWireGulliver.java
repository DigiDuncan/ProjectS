package gulliver.block.replacement;

import abw;
import acf;
import aqz;
import ark;
import arl;
import asx;
import asz;
import gulliver.common.GulliverOMHelper;
import java.util.List;
import nn;
import of;

public class BlockTripWireGulliver
  extends arl
{
  public BlockTripWireGulliver(int par1)
  {
    super(par1);
  }
  



  public void a(abw par1World, int par2, int par3, int par4, asx par5AxisAlignedBB, List par6List, nn par7Entity)
  {
    int var5 = par1World.h(par2, par3, par4);
    
    if ((par7Entity != null) && ((par7Entity instanceof of)) && (par7Entity.isTiny()) && (!GulliverOMHelper.isLittleBlocksWorld(par1World)))
    {
      asx var8 = null;
      boolean var6 = (var5 & 0x4) == 4;
      boolean var7 = (var5 & 0x2) == 2;
      boolean var4 = (a(par1World, par2, par3, par4, var5, 1)) || (a(par1World, par2, par3, par4, var5, 3));
      float xMin = var4 ? 0.0F : 0.375F;
      float xMax = var4 ? 1.0F : 0.625F;
      float zMin = var4 ? 0.375F : 0.0F;
      float zMax = var4 ? 0.625F : 1.0F;
      






      if (!var6)
      {

        var8 = asx.a().a(par2 + xMin, par3 + 0.1875D, par4 + zMin, par2 + xMax, par3 + 0.25D, par4 + zMax);
      }
      

      if ((var8 != null) && (par5AxisAlignedBB.b(var8)))
      {
        par6List.add(var8);
      }
    }
  }
  




  public void a(abw par1World, int par2, int par3, int par4, nn par5Entity)
  {
    if ((!(par5Entity instanceof of)) || (!par5Entity.isTiny()) || (GulliverOMHelper.isLittleBlocksWorld(par1World)))
    {
      super.a(par1World, par2, par3, par4, par5Entity);
    }
  }
  
  public static boolean a(acf par0IBlockAccess, int par1, int par2, int par3, int par4, int par5)
  {
    int j1 = par1 + r.a[par5];
    int k1 = par3 + r.b[par5];
    int l1 = par0IBlockAccess.a(j1, par2, k1);
    boolean flag = (par4 & 0x2) == 2;
    

    if (l1 == bYcF)
    {
      int i2 = par0IBlockAccess.h(j1, par2, k1);
      int j2 = i2 & 0x3;
      return j2 == r.f[par5];
    }
    if (l1 == bZcF)
    {
      int i2 = par0IBlockAccess.h(j1, par2, k1);
      boolean flag1 = (i2 & 0x2) == 2;
      return flag == flag1;
    }
    

    return false;
  }
}
