package gulliver.block.replacement;

import abw;
import ang;
import ata;
import atc;
import nb;
import nn;
import of;
import ud;
import uf;

public class BlockCactusGulliver
  extends ang
{
  public BlockCactusGulliver(int par1)
  {
    super(par1);
  }
  




  public ata a(abw par1World, int par2, int par3, int par4, atc par5Vec3, atc par6Vec3)
  {
    a(0.0625F, 0.0F, 0.0625F, 0.9375F, 0.9375F, 0.9375F);
    ata var1 = super.a(par1World, par2, par3, par4, par5Vec3, par6Vec3);
    a(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
    return var1;
  }
  




  public void a(abw par1World, int par2, int par3, int par4, uf par5EntityPlayer)
  {
    if ((!I) && (par5EntityPlayer.isTiny()) && (bn.h() == null))
    {
      par5EntityPlayer.a(nb.g, 1.0F);
    }
  }
  




  public void a(abw par1World, int par2, int par3, int par4, nn par5Entity)
  {
    if ((!(par5Entity instanceof of)) || (!par5Entity.isTiny()))
    {
      par5Entity.a(nb.g, 1.0F);
    }
  }
}
