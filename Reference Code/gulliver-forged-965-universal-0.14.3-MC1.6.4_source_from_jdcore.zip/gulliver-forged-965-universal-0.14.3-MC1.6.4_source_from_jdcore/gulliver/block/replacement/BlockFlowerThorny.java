package gulliver.block.replacement;

import abw;
import ane;
import asx;
import asz;
import gulliver.common.GulliverOMHelper;
import nb;
import nn;
import of;
import ud;
import uf;

public class BlockFlowerThorny extends ane
{
  public BlockFlowerThorny(int par1)
  {
    super(par1);
  }
  




  public void a(abw par1World, int par2, int par3, int par4, uf par5EntityPlayer)
  {
    if ((!I) && (par5EntityPlayer.isTiny()) && (bn.h() == null))
    {
      par5EntityPlayer.a(nb.g, 1.0F);
    }
  }
  




  public void a(abw par1World, int par2, int par3, int par4, nn par5Entity)
  {
    if (((par5Entity instanceof of)) && (par5Entity.isTiny()) && (!GulliverOMHelper.isLittleBlocksWorld(par1World)))
    {
      asx bb = asx.a().a(par2 + cM, par3 + cN, par4 + cO, par2 + cP, par3 + cQ, par4 + cR);
      
      if ((bb != null) && (E.b(bb)))
      {
        par5Entity.a(nb.g, 1.0F);
      }
    }
  }
}
