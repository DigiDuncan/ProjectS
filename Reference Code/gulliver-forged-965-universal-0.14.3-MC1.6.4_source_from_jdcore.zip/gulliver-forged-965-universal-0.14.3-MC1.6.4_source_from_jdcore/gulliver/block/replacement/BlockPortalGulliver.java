package gulliver.block.replacement;

import abw;
import aps;
import asx;
import asz;
import nn;

public class BlockPortalGulliver extends aps
{
  public BlockPortalGulliver(int par1)
  {
    super(par1);
  }
  




  public void a(abw par1World, int par2, int par3, int par4, nn par5Entity)
  {
    if ((o == null) && (n == null))
    {
      asx bb = asx.a().a(par2 + cM, par3 + cN, par4 + cO, par2 + cP, par3 + cQ, par4 + cR);
      
      if ((bb != null) && (E.b(bb)))
      {
        par5Entity.ab();
      }
    }
  }
}
