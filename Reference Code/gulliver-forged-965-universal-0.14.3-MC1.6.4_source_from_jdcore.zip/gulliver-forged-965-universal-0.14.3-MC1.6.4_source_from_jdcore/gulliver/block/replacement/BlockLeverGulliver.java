package gulliver.block.replacement;

import abw;
import apb;
import asx;
import asz;
import gulliver.common.GulliverOMHelper;
import java.util.List;
import nn;
import of;





public class BlockLeverGulliver
  extends apb
{
  public BlockLeverGulliver(int par1)
  {
    super(par1);
  }
  



  public void a(abw par1World, int par2, int par3, int par4, asx par5AxisAlignedBB, List par6List, nn par7Entity)
  {
    if ((par7Entity != null) && ((par7Entity instanceof of)) && (par7Entity.isTiny()) && (!GulliverOMHelper.isLittleBlocksWorld(par1World)))
    {
      int var5 = par1World.h(par2, par3, par4) & 0x7;
      float var6 = 0.1875F;
      float pix = 0.0625F;
      

      if (var5 == 1)
      {
        a(0.0F, 0.25F, 0.5F - var6, var6, 0.75F, 0.5F + var6);
      }
      else if (var5 == 2)
      {
        a(1.0F - var6, 0.25F, 0.5F - var6, 1.0F, 0.75F, 0.5F + var6);
      }
      else if (var5 == 3)
      {
        a(0.5F - var6, 0.25F, 0.0F, 0.5F + var6, 0.75F, var6);
      }
      else if (var5 == 4)
      {
        a(0.5F - var6, 0.25F, 1.0F - var6, 0.5F + var6, 0.75F, 1.0F);
      }
      else if (var5 == 5)
      {
        a(0.5F - var6, 0.0F, 0.25F, 0.5F + var6, var6, 0.75F);
      }
      else if (var5 == 6)
      {
        a(0.25F, 0.0F, 0.5F - var6, 0.75F, var6, 0.5F + var6);
      }
      else if (var5 == 7)
      {
        a(0.5F - var6, 1.0F - var6, 0.25F, 0.5F + var6, 1.0F, 0.75F);
      }
      else if (var5 == 0)
      {
        a(0.25F, 1.0F - var6, 0.5F - var6, 0.75F, 1.0F, 0.5F + var6);
      }
      
      asx var8 = asx.a().a(par2 + cM, par3 + cN, par4 + cO, par2 + cP, par3 + cQ, par4 + cR);
      
      if ((var8 != null) && (par5AxisAlignedBB.b(var8)))
      {
        par6List.add(var8);
      }
    }
  }
}
