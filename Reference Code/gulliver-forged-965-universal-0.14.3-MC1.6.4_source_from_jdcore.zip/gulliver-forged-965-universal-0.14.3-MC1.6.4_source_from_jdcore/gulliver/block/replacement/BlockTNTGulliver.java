package gulliver.block.replacement;

import abw;
import are;
import tc;
import uf;



public class BlockTNTGulliver
  extends are
{
  public BlockTNTGulliver(int par1)
  {
    super(par1);
  }
  




  public boolean a(abw par1World, int par2, int par3, int par4, uf par5EntityPlayer, int par6, float par7, float par8, float par9)
  {
    if ((par5EntityPlayer.by() == null) && (par5EntityPlayer.isHuge()))
    {
      if (!I)
      {
        tc entitytntprimed = new tc(par1World, par2 + 0.5F, par3 + 0.5F, par4 + 0.5F, par5EntityPlayer);
        a = 0;
        par1World.d(entitytntprimed);
      }
      
      par1World.i(par2, par3, par4);
      return true;
    }
    

    return super.a(par1World, par2, par3, par4, par5EntityPlayer, par6, par7, par8, par9);
  }
}
