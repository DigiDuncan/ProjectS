package gulliver.block.replacement;

import abw;
import aqz;
import ark;
import asx;
import asz;
import gulliver.common.GulliverEnvoy;
import gulliver.common.GulliverOMHelper;
import java.util.List;
import java.util.Random;
import nn;
import of;
import uf;


public class BlockTripWireSourceGulliver
  extends ark
{
  public BlockTripWireSourceGulliver(int par1)
  {
    super(par1);
  }
  



  public void a(abw par1World, int par2, int par3, int par4, asx par5AxisAlignedBB, List par6List, nn par7Entity)
  {
    int var5 = par1World.h(par2, par3, par4);
    
    if ((par7Entity != null) && ((par7Entity instanceof of)) && (par7Entity.isTiny()) && (!GulliverOMHelper.isLittleBlocksWorld(par1World)))
    {
      asx var8 = asx.a().a(par2 + cM, par3 + cN, par4 + cO, par2 + cP, par3 + cQ, par4 + cR);
      
      if ((var8 != null) && (par5AxisAlignedBB.b(var8)))
      {
        par6List.add(var8);
      }
      
      var8 = null;
      boolean var6 = (var5 & 0x8) == 8;
      boolean var7 = (var5 & 0x4) == 4;
      boolean var4 = (var5 & 0x1) == 1;
      float xMin = var4 ? 0.0F : 0.375F;
      float xMax = var4 ? 1.0F : 0.625F;
      float zMin = var4 ? 0.375F : 0.0F;
      float zMax = var4 ? 0.625F : 1.0F;
      
      if (!var7)
      {
        var8 = asx.a().a(par2 + xMin, par3 + 0.1D, par4 + zMin, par2 + xMax, par3 + 0.3D, par4 + zMax);

      }
      else if (!var6)
      {
        var8 = asx.a().a(par2 + xMin, par3 + cN, par4 + zMin, par2 + xMax, par3 + 0.125D, par4 + zMax);
      }
      

      if ((var8 != null) && (par5AxisAlignedBB.b(var8)))
      {
        par6List.add(var8);
      }
    }
  }
  




  public void a(abw par1World, int par2, int par3, int par4, nn par5Entity)
  {
    if ((!I) && (par5Entity.isHuge()) && (!par5Entity.ah()) && (GulliverEnvoy.canSizeGrief(par5Entity)) && ((!(par5Entity instanceof uf)) || (par1World.a((uf)par5Entity, par2, par3, par4))) && (s.nextInt(50) == 0))
    {
      int i = par1World.a(par2, par3, par4);
      aqz.s[i].c(par1World, par2, par3, par4, par1World.h(par2, par3, par4), 0);
      par1World.i(par2, par3, par4);
    }
  }
}
