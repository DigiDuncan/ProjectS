package gulliver.block.replacement;

import abw;
import aqn;
import nn;


public class BlockSoulSandGulliver
  extends aqn
{
  public BlockSoulSandGulliver(int par1)
  {
    super(par1);
  }
  




  public void a(abw par1World, int par2, int par3, int par4, nn par5Entity)
  {
    if (par5Entity.isTiny())
    {
      x *= 0.2D;
      z *= 0.2D;
    }
    else if (!par5Entity.isHuge())
    {
      x *= 0.4D;
      z *= 0.4D;
    }
  }
}
