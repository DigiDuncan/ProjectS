package gulliver.block.replacement;

import abw;
import arf;
import asx;
import asz;
import java.util.List;
import java.util.Random;
import nn;
import of;
import sb;
import uf;

public class BlockSnowGulliver
  extends arf
{
  public BlockSnowGulliver(int par1)
  {
    super(par1);
  }
  



  public void a(abw par1World, int par2, int par3, int par4, asx par5AxisAlignedBB, List par6List, nn par7Entity)
  {
    int var5 = par1World.h(par2, par3, par4) * 2;
    float var6 = 0.0625F;
    
    if ((par7Entity != null) && ((par7Entity instanceof of)))
    {
      asx var8 = null;
      
      if (par7Entity.isExtraTiny())
      {
        var5++;
      }
      else if (par7Entity.isHuge())
      {
        var5 -= (int)(par7Entity.getSizeMultiplier() * 1.25F);
      }
      
      var8 = var5 > 0 ? asx.a().a(par2 + cM, par3 + cN, par4 + cO, par2 + cP, par3 + var5 * var6, par4 + cR) : null;
      
      if ((var8 != null) && (par5AxisAlignedBB.b(var8)))
      {
        par6List.add(var8);
      }
    }
  }
  




  public asx b(abw par1World, int par2, int par3, int par4)
  {
    int l = par1World.h(par2, par3, par4) & 0x7;
    float f = 0.125F;
    return l > 0 ? asx.a().a(par2 + cM, par3 + cN, par4 + cO, par2 + cP, par3 + l * f, par4 + cR) : null;
  }
  




  public void a(abw par1World, int par2, int par3, int par4, nn par5Entity)
  {
    if ((!I) && (par5Entity.isHuge()) && (!(par5Entity instanceof sb)) && ((!(par5Entity instanceof uf)) || (par1World.a((uf)par5Entity, par2, par3, par4))) && (par3 > (int)(E.b + P * 0.25F)) && (!par5Entity.ah()) && (s.nextInt(50) == 0))
    {
      int i = par1World.a(par2, par3, par4);
      int d = (par1World.h(par2, par3, par4) & 0x7) - 1;
      
      if (d < 0)
      {
        par1World.i(par2, par3, par4);
      }
      else
      {
        par1World.f(par2, par3, par4, i, d, 3);
      }
    }
  }
}
