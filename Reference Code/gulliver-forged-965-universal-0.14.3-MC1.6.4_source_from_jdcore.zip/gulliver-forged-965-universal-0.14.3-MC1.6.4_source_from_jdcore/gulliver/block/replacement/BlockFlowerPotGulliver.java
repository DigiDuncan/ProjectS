package gulliver.block.replacement;

import abw;
import ane;
import aoj;
import aqz;
import asx;
import asz;
import ata;
import atc;
import gulliver.common.GulliverOMHelper;
import java.util.List;
import nb;
import nn;
import of;
import ye;






public class BlockFlowerPotGulliver
  extends aoj
{
  public BlockFlowerPotGulliver(int par1)
  {
    super(par1);
  }
  




  public void a(abw par1World, int par2, int par3, int par4, asx par5AxisAlignedBB, List par6List, nn par7Entity)
  {
    float var8 = 0.375F;
    float var9 = var8 / 2.0F;
    a(0.5F - var9, 0.0F, 0.5F - var9, 0.5F + var9, var9, 0.5F + var9);
    super.a(par1World, par2, par3, par4, par5AxisAlignedBB, par6List, par7Entity);
    float var10 = 0.0625F;
    a(0.5F - var9, var9, 0.5F - var9, 0.5F - var9 + var10, var8, 0.5F + var9);
    super.a(par1World, par2, par3, par4, par5AxisAlignedBB, par6List, par7Entity);
    a(0.5F - var9, var9, 0.5F - var9, 0.5F + var9, var8, 0.5F - var9 + var10);
    super.a(par1World, par2, par3, par4, par5AxisAlignedBB, par6List, par7Entity);
    a(0.5F + var9 - var10, var9, 0.5F - var9, 0.5F + var9, var8, 0.5F + var9);
    super.a(par1World, par2, par3, par4, par5AxisAlignedBB, par6List, par7Entity);
    a(0.5F - var9, var9, 0.5F + var9 - var10, 0.5F + var9, var8, 0.5F + var9);
    super.a(par1World, par2, par3, par4, par5AxisAlignedBB, par6List, par7Entity);
    g();
  }
  




  public ata a(abw par1World, int par2, int par3, int par4, atc par5Vec3, atc par6Vec3)
  {
    float var8 = 0.375F;
    float var9 = var8 / 2.0F;
    float var10 = 0.0625F;
    ata[] hits = new ata[5];
    a(0.5F - var9, 0.0F, 0.5F - var9, 0.5F + var9, var9, 0.5F + var9);
    hits[0] = super.a(par1World, par2, par3, par4, par5Vec3, par6Vec3);
    a(0.5F - var9, var9, 0.5F - var9, 0.5F - var9 + var10, var8, 0.5F + var9);
    hits[1] = super.a(par1World, par2, par3, par4, par5Vec3, par6Vec3);
    a(0.5F - var9, var9, 0.5F - var9, 0.5F + var9, var8, 0.5F - var9 + var10);
    hits[2] = super.a(par1World, par2, par3, par4, par5Vec3, par6Vec3);
    a(0.5F + var9 - var10, var9, 0.5F - var9, 0.5F + var9, var8, 0.5F + var9);
    hits[3] = super.a(par1World, par2, par3, par4, par5Vec3, par6Vec3);
    a(0.5F - var9, var9, 0.5F + var9 - var10, 0.5F + var9, var8, 0.5F + var9);
    hits[4] = super.a(par1World, par2, par3, par4, par5Vec3, par6Vec3);
    double mlen = 0.0D;
    ata ray = null;
    int var16 = hits.length;
    
    for (int var17 = 0; var17 < var16; var17++)
    {
      ata var18 = hits[var17];
      
      if (var18 != null)
      {
        double var19 = f.e(par6Vec3);
        
        if (var19 > mlen)
        {
          ray = var18;
          mlen = var19;
        }
      }
    }
    
    g();
    return ray;
  }
  



  public void a(abw par1World, int par2, int par3, int par4, nn par5Entity)
  {
    ye var5 = p_(par1World.h(par2, par3, par4));
    
    if ((var5 != null) && ((d == ajcF) || (d == bacF)) && ((par5Entity instanceof of)) && (par5Entity.isTiny()) && (!GulliverOMHelper.isLittleBlocksWorld(par1World)))
    {

      asx bb = asx.a().a(par2 + cM, par3 + 0.3125D, par4 + cO, par2 + cP, par3 + (d == bacF ? 1.0D : 0.85D), par4 + cR);
      
      if ((bb != null) && (E.b(bb)))
      {
        par5Entity.a(nb.g, 1.0F);
      }
    }
  }
}
