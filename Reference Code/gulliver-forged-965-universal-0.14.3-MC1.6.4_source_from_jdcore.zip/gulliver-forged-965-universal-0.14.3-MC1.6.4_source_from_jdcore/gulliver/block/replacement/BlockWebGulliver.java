package gulliver.block.replacement;

import abw;
import arp;
import gulliver.common.GulliverEnvoy;
import java.util.Random;
import nn;
import uf;

public class BlockWebGulliver extends arp
{
  public BlockWebGulliver(int par1)
  {
    super(par1);
  }
  




  public void a(abw par1World, int par2, int par3, int par4, nn par5Entity)
  {
    if ((!I) && (par5Entity.isHuge()) && (!par5Entity.ah()) && (GulliverEnvoy.canSizeGrief(par5Entity)) && ((!(par5Entity instanceof uf)) || (par1World.a((uf)par5Entity, par2, par3, par4))) && (s.nextInt(50) == 0))
    {
      int i = par1World.a(par2, par3, par4);
      aqz.s[i].c(par1World, par2, par3, par4, par1World.h(par2, par3, par4), 0);
      par1World.i(par2, par3, par4);
    }
    else
    {
      super.a(par1World, par2, par3, par4, par5Entity);
    }
  }
}
