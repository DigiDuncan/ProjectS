package gulliver.block.replacement;

import abw;
import acf;
import amv;
import asx;
import ata;
import atc;
import java.util.List;
import nn;


public class BlockAnvilGulliver
  extends amv
{
  private boolean doingRaytrace = false;
  
  public BlockAnvilGulliver(int par1)
  {
    super(par1);
    doingRaytrace = false;
  }
  



  public void a(acf par1IBlockAccess, int par2, int par3, int par4)
  {
    if (!doingRaytrace)
    {
      int var5 = par1IBlockAccess.h(par2, par3, par4) & 0x3;
      
      if ((var5 != 3) && (var5 != 1))
      {
        a(0.125F, 0.0F, 0.0F, 0.875F, 1.0F, 1.0F);
      }
      else
      {
        a(0.0F, 0.0F, 0.125F, 1.0F, 1.0F, 0.875F);
      }
    }
  }
  



  public void a(abw par1World, int par2, int par3, int par4, asx par5AxisAlignedBB, List par6List, nn par7Entity)
  {
    int var5 = par1World.h(par2, par3, par4) & 0x3;
    a(0.125F, 0.0F, 0.125F, 0.875F, 0.25F, 0.875F);
    super.a(par1World, par2, par3, par4, par5AxisAlignedBB, par6List, par7Entity);
    
    if ((var5 != 3) && (var5 != 1))
    {
      a(0.25F, 0.25F, 0.1875F, 0.75F, 0.3125F, 0.8125F);
      super.a(par1World, par2, par3, par4, par5AxisAlignedBB, par6List, par7Entity);
      a(0.375F, 0.3125F, 0.25F, 0.625F, 0.625F, 0.75F);
      super.a(par1World, par2, par3, par4, par5AxisAlignedBB, par6List, par7Entity);
      a(0.1875F, 0.625F, 0.0F, 0.8125F, 1.0F, 1.0F);
      super.a(par1World, par2, par3, par4, par5AxisAlignedBB, par6List, par7Entity);
    }
    else
    {
      a(0.1875F, 0.25F, 0.25F, 0.8125F, 0.3125F, 0.75F);
      super.a(par1World, par2, par3, par4, par5AxisAlignedBB, par6List, par7Entity);
      a(0.25F, 0.3125F, 0.375F, 0.75F, 0.625F, 0.625F);
      super.a(par1World, par2, par3, par4, par5AxisAlignedBB, par6List, par7Entity);
      a(0.0F, 0.625F, 0.1875F, 1.0F, 1.0F, 0.8125F);
      super.a(par1World, par2, par3, par4, par5AxisAlignedBB, par6List, par7Entity);
    }
    
    a(par1World, par2, par3, par4);
  }
  




  public ata a(abw par1World, int par2, int par3, int par4, atc par5Vec3, atc par6Vec3)
  {
    int var5 = par1World.h(par2, par3, par4) & 0x3;
    doingRaytrace = true;
    ata[] hits = new ata[3];
    a(0.125F, 0.0F, 0.125F, 0.875F, 0.3125F, 0.875F);
    hits[0] = super.a(par1World, par2, par3, par4, par5Vec3, par6Vec3);
    
    if ((var5 != 3) && (var5 != 1))
    {
      a(0.375F, 0.3125F, 0.25F, 0.625F, 0.625F, 0.75F);
      hits[1] = super.a(par1World, par2, par3, par4, par5Vec3, par6Vec3);
      a(0.1875F, 0.625F, 0.0F, 0.8125F, 1.0F, 1.0F);
      hits[2] = super.a(par1World, par2, par3, par4, par5Vec3, par6Vec3);
    }
    else
    {
      a(0.25F, 0.3125F, 0.375F, 0.75F, 0.625F, 0.625F);
      hits[1] = super.a(par1World, par2, par3, par4, par5Vec3, par6Vec3);
      a(0.0F, 0.625F, 0.1875F, 1.0F, 1.0F, 0.8125F);
      hits[2] = super.a(par1World, par2, par3, par4, par5Vec3, par6Vec3);
    }
    
    double mlen = 0.0D;
    ata ray = null;
    int var16 = hits.length;
    
    for (int var17 = 0; var17 < var16; var17++)
    {
      ata var18 = hits[var17];
      
      if (var18 != null)
      {
        double var19 = f.e(par6Vec3);
        
        if (var19 > mlen)
        {
          ray = var18;
          mlen = var19;
        }
      }
    }
    
    doingRaytrace = false;
    a(par1World, par2, par3, par4);
    return ray;
  }
}
