package gulliver.common;

import aqz;
import gulliver.block.replacement.BlockFarmlandGulliver;
import gulliver.block.replacement.BlockSnowGulliver;
import java.lang.reflect.Field;

public class GulliverBlockReplacer
{
  public GulliverBlockReplacer() {}
  
  public static void registerReplacementBlocks()
  {
    aqz instance = aqz.A;
    
    Field[] fieldList = aqz.class.getFields();
    
    for (Field bfld : fieldList)
    {
      try
      {
        Object bobj = bfld.get(instance);
        
        if ((bobj instanceof aqz))
        {
          int id = cF;
          try
          {
            if (id == cmcF)
            {
              String basename = aqz.cm.getTextureBaseName();
              String ulname = clearStaticBlockAndReturnName(bfld, aqz.cm);
              setFinalStatic(bfld, new gulliver.block.replacement.BlockAnvilGulliver(id).c(5.0F).a(aqz.r).b(2000.0F).c(ulname).d(basename));
            }
            else if (id == bacF)
            {
              String basename = aqz.ba.getTextureBaseName();
              String ulname = clearStaticBlockAndReturnName(bfld, aqz.ba);
              setFinalStatic(bfld, new gulliver.block.replacement.BlockCactusGulliver(id).c(0.4F).a(aqz.n).c(ulname).d(basename));
            }
            else if (id == chcF)
            {
              String basename = aqz.ch.getTextureBaseName();
              String ulname = clearStaticBlockAndReturnName(bfld, aqz.ch);
              setFinalStatic(bfld, new gulliver.block.replacement.BlockFlowerPotGulliver(id).c(0.0F).a(aqz.g).c(ulname).d(basename));
            }
            else if (id == aOcF)
            {
              String basename = aqz.aO.getTextureBaseName();
              String ulname = clearStaticBlockAndReturnName(bfld, aqz.aO);
              setFinalStatic(bfld, new gulliver.block.replacement.BlockLeverGulliver(id).c(0.5F).a(aqz.h).c(ulname).d(basename));
            }
            else if (id == ajcF)
            {
              String basename = aqz.aj.getTextureBaseName();
              String ulname = clearStaticBlockAndReturnName(bfld, aqz.aj);
              setFinalStatic(bfld, new gulliver.block.replacement.BlockFlowerThorny(id).c(0.0F).a(aqz.j).c(ulname).d(basename));
            }
            else if (id == bjcF)
            {
              String basename = aqz.bj.getTextureBaseName();
              String ulname = clearStaticBlockAndReturnName(bfld, aqz.bj);
              setFinalStatic(bfld, new gulliver.block.replacement.BlockPortalGulliver(id).c(-1.0F).a(aqz.m).a(0.75F).c(ulname).d(basename));
            }
            else if (id == aXcF)
            {
              String basename = aqz.aX.getTextureBaseName();
              String ulname = clearStaticBlockAndReturnName(bfld, aqz.aX);
              setFinalStatic(bfld, new BlockSnowGulliver(id).c(0.1F).a(aqz.p).c(ulname).d(basename).k(0));
            }
            else if (id == bhcF)
            {
              String basename = aqz.bh.getTextureBaseName();
              String ulname = clearStaticBlockAndReturnName(bfld, aqz.bh);
              setFinalStatic(bfld, new gulliver.block.replacement.BlockSoulSandGulliver(id).c(0.5F).a(aqz.o).c(ulname).d(basename));
            }
            else if (id == aFcF)
            {
              String basename = aqz.aF.getTextureBaseName();
              String ulname = clearStaticBlockAndReturnName(bfld, aqz.aF);
              setFinalStatic(bfld, new BlockFarmlandGulliver(id).c(0.6F).a(aqz.i).c(ulname).d(basename));
            }
            else if (id == arcF)
            {
              String basename = aqz.ar.getTextureBaseName();
              String ulname = clearStaticBlockAndReturnName(bfld, aqz.ar);
              setFinalStatic(bfld, new gulliver.block.replacement.BlockTNTGulliver(id).c(0.0F).a(aqz.j).c(ulname).d(basename));
            }
            else if (id == bZcF)
            {
              String basename = aqz.bp.getTextureBaseName();
              String ulname = clearStaticBlockAndReturnName(bfld, aqz.bZ);
              setFinalStatic(bfld, new gulliver.block.replacement.BlockTripWireGulliver(id).c(ulname).d(basename));
            }
            else if (id == bYcF)
            {
              String basename = aqz.bY.getTextureBaseName();
              String ulname = clearStaticBlockAndReturnName(bfld, aqz.bY);
              setFinalStatic(bfld, new gulliver.block.replacement.BlockTripWireSourceGulliver(id).c(ulname).d(basename));
            }
            else if (id == abcF)
            {
              String basename = aqz.ab.getTextureBaseName();
              String ulname = clearStaticBlockAndReturnName(bfld, aqz.ab);
              setFinalStatic(bfld, new gulliver.block.replacement.BlockWebGulliver(id).k(1).c(4.0F).c(ulname).d(basename));
            }
            else if (id == cCcF)
            {
              String basename = aqz.cC.getTextureBaseName();
              String ulname = clearStaticBlockAndReturnName(bfld, aqz.cC);
              setFinalStatic(bfld, new gulliver.block.replacement.BlockCarpetGulliver(id).c(0.1F).a(aqz.n).c(ulname).d(basename).k(0));
            }
          }
          catch (Exception e)
          {
            e.printStackTrace();
          }
        }
      }
      catch (IllegalArgumentException e)
      {
        e.printStackTrace();
      }
      catch (IllegalAccessException e)
      {
        e.printStackTrace();
      }
    }
  }
  
  private static String clearStaticBlockAndReturnName(Field par1Field, aqz par2Block) throws Exception
  {
    int id = cF;
    String name = par2Block.a().replaceFirst("tile.", "");
    setFinalStatic(par1Field, null);
    aqz.s[id] = null;
    return name;
  }
  
  private static void setFinalStatic(Field field, Object newValue)
    throws Exception
  {
    field.setAccessible(true);
    

    Field modifiersField = Field.class.getDeclaredField("modifiers");
    modifiersField.setAccessible(true);
    modifiersField.setInt(field, field.getModifiers() & 0xFFFFFFEF);
    
    field.set(null, newValue);
  }
}
