package gulliver.common;

import abw;
import acd;
import acf;
import amc;
import atc;
import beg;
import gulliver.GulliverForged;
import java.util.logging.Logger;
import js;
import lp;
import lv;
import net.minecraft.server.MinecraftServer;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.EventBus;
import nn;
import oa;
import oc;
import si;
import sk;
import ss;
import uf;
import xn;
import yc;
import ye;
import yh;


public class CommonProxy
{
  protected boolean hasLittleBlocks = false;
  
  public CommonProxy() {}
  
  public String getCurrentLanguage() { return "en_US"; }
  

  public void load()
  {
    MinecraftForge.EVENT_BUS.register(new InteractEventHandler());
  }
  

  public void loadKeyBindings() {}
  
  public void checkOtherMods()
  {
    hasLittleBlocks = false;
    
    try
    {
      GulliverOMHelper.lbWorldI = getClass().getClassLoader().loadClass("com.slimevoid.littleblocks.api.ILittleWorld");
      hasLittleBlocks = true;
    }
    catch (ClassNotFoundException classnotfoundexception) {}
  }
  


  public void checkOtherModsInit()
  {
    if (hasLittleBlocks)
    {
      GulliverForged.logger.info("Little Blocks found");
    }
    else
    {
      GulliverForged.logger.info("Little Blocks not found");
    }
  }
  
  public boolean hasLittleBlocks()
  {
    return hasLittleBlocks;
  }
  
  public boolean isClientPlayerEntity(nn par1Entity)
  {
    return false;
  }
  
  public boolean isClientsideEntity(nn par1Entity)
  {
    return false;
  }
  

  public boolean isUnrideableEntity(nn par1Entity)
  {
    return (isClientsideEntity(par1Entity)) || ((par1Entity instanceof ss)) || ((par1Entity instanceof oa)) || ((par1Entity instanceof oc)) || ((par1Entity instanceof sk)) || ((par1Entity instanceof si));
  }
  

  public boolean isUnholdableEntity(nn par1Entity)
  {
    return (isClientsideEntity(par1Entity)) || ((par1Entity instanceof ss)) || ((par1Entity instanceof oa)) || ((par1Entity instanceof oc)) || ((par1Entity instanceof sk)) || ((par1Entity instanceof si));
  }
  
  public boolean isGlideableItem(ye stack)
  {
    return (stack != null) && ((d == aMcv) || ((stack.b() instanceof xn)) || ((stack.b() instanceof yh)));
  }
  
  public void clearClientMouseover() {}
  
  public boolean isClientAttacking()
  {
    return false;
  }
  
  public boolean getClientPlayerMovementSneak(uf par1EntityPlayer)
  {
    return false;
  }
  
  public boolean getClientPlayerMovementJump(uf par1EntityPlayer)
  {
    return false;
  }
  
  public boolean setOptifineZoom(boolean par1)
  {
    return false;
  }
  
  public boolean getOptifineZoom()
  {
    return false;
  }
  
  public boolean checkOptifineSettings()
  {
    return false;
  }
  
  public js getOptifineWorldServer(MinecraftServer par1MinecraftServer, amc par2ISaveHandler, String par3Str, int par4, acd par5WorldSettings, lv par6Profiler, lp par7ILogAgent)
  {
    return new js(par1MinecraftServer, par2ISaveHandler, par3Str, par4, par5WorldSettings, par6Profiler, par7ILogAgent);
  }
  
  public void optifineRegisterTextureUtilsListener() {}
  
  public void optifineCheckDisplayMode() {}
  
  public void updateOptifineWorldStuff(abw world0, abw world1) {}
  
  public boolean updateOptifineCustomLightmap(abw world, float flickerX, int[] lmapColors, boolean nightvision)
  {
    return false;
  }
  
  public boolean updateOptifineCustomWaterFX(beg waterFX, acf world)
  {
    return false;
  }
  
  public atc getOptifineCustomColor(String method, atc cvec)
  {
    return cvec;
  }
  
  public atc getOptifineCustomPosColor(String method, atc cvec, acf world, double x, double y, double z)
  {
    return cvec;
  }
  
  public atc getOptifineCustomUnderwaterColor(acf world, double x, double y, double z)
  {
    return null;
  }
  
  public void resumeOptifineBackgroundUpdates() {}
  
  public void pauseOptifineBackgroundUpdates() {}
}
