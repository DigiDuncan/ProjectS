package gulliver.common;

import abw;
import aqz;
import ary;
import asf;
import asp;
import asx;
import java.lang.reflect.Field;
import mo;
import net.minecraftforge.event.Event.Result;
import net.minecraftforge.event.ForgeSubscribe;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.entity.player.PlayerOpenContainerEvent;
import nn;
import uf;
import uy;
import vj;

public class InteractEventHandler
{
  public InteractEventHandler() {}
  
  @ForgeSubscribe
  public void handleInteractEvent(PlayerInteractEvent event)
  {
    if ((action == net.minecraftforge.event.entity.player.PlayerInteractEvent.Action.RIGHT_CLICK_BLOCK) && (entityPlayer != null) && ((entityPlayer.isTiny()) || (entityPlayer.isHuge())))
    {
      int i = entityPlayer.q.a(x, y, z);
      aqz b = aqz.s[i];
      if ((b != null) && (!b.isBlockNormalCube(entityPlayer.q, x, y, z)))
      {
        String name = b.getClass().getName();
        
        if ((entityPlayer.isHuge()) && (name.endsWith("BlockLittleChunk")) && ((entityPlayer.aZ() == null) || ((!entityPlayer.holdingPointyItem()) && (!entityPlayer.ah()))))
        {
          useBlock = Event.Result.DENY;
          event.setCanceled(true);
        }
        else if ((!GulliverEnvoy.canOpenSingleBlock(entityPlayer)) && ((name.contains("Door")) || (name.contains("Lever")) || (name.contains("Button")) || (name.contains("Gate")) || (name.contains("Hatch")) || (name.contains("Cabinet")) || (name.contains("Safe"))))
        {
          useBlock = Event.Result.DENY;
          event.setCanceled(true);
        }
      }
    }
  }
  
  @ForgeSubscribe
  public void handleContainerInteractEvent(PlayerOpenContainerEvent event)
  {
    if ((entityPlayer != null) && ((entityPlayer.getSizeMultiplier() != 1.0F) || (GulliverOMHelper.hasLittleBlocks())))
    {
      adjustCanInteractWith(event);
    }
  }
  
  private void adjustCanInteractWith(PlayerOpenContainerEvent event)
  {
    if (entityPlayer.bp == entityPlayer.bo)
    {
      return;
    }
    
    uy vessel = entityPlayer.bp;
    Field[] fields = vessel.getClass().getDeclaredFields();
    int firstTE = -1;int firstWorld = -1;int firstEntityInv = -1;int firstInv = -1;
    for (int i = 0; i < fields.length; i++)
    {
      try
      {
        fields[i].setAccessible(true);
        if ((fields[i].get(vessel) instanceof asp))
        {
          firstTE = i;
          break;
        }
        if ((fields[i].get(vessel) instanceof abw))
        {
          firstWorld = i;
          break;
        }
        if (((fields[i].get(vessel) instanceof mo)) && ((fields[i].get(vessel) instanceof nn)))
        {

          firstEntityInv = i;
          break;
        }
        if (((fields[i].get(vessel) instanceof mo)) && (firstInv < 0))
        {
          firstInv = i;
        }
      } catch (IllegalArgumentException e) {
        e.printStackTrace();
      } catch (IllegalAccessException e) {
        e.printStackTrace();
      }
    }
    try
    {
      if (firstTE >= 0)
      {
        fields[firstTE].setAccessible(true);
        asp tile = (asp)fields[firstTE].get(vessel);
        if (tile.o())
        {
          event.setResult(canInteractWithTileEntity(event, tile) ? Event.Result.ALLOW : Event.Result.DENY);
        }
      }
      else if (firstWorld >= 0)
      {
        abw world = (abw)fields[firstWorld].get(vessel);
        
        if (fields.length > firstWorld + 3)
        {
          fields[(firstWorld + 1)].setAccessible(true);
          fields[(firstWorld + 2)].setAccessible(true);
          fields[(firstWorld + 3)].setAccessible(true);
          if (((fields[(firstWorld + 1)].get(vessel) instanceof Integer)) && ((fields[(firstWorld + 2)].get(vessel) instanceof Integer)) && ((fields[(firstWorld + 3)].get(vessel) instanceof Integer)))
          {
            boolean result = canInteractWithLocatedContainer(entityPlayer, world, fields[(firstWorld + 1)].getInt(vessel), fields[(firstWorld + 2)].getInt(vessel), fields[(firstWorld + 3)].getInt(vessel));
            event.setResult(result ? Event.Result.ALLOW : Event.Result.DENY);
          }
        }
      }
      else if (firstEntityInv >= 0)
      {
        nn entity = (nn)fields[firstEntityInv].get(vessel);
        event.setResult(canInteractWithContainerEntity(event, entity) ? Event.Result.ALLOW : Event.Result.DENY);
      }
      else if (firstInv >= 0)
      {
        mo innerinv = (mo)fields[firstInv].get(vessel);
        Field[] fields2 = innerinv.getClass().getDeclaredFields();
        for (int j = 0; j < fields2.length; j++)
        {
          fields2[j].setAccessible(true);
          if ((fields2[j].get(innerinv) instanceof asp))
          {
            asp tile = (asp)fields2[j].get(innerinv);
            if (tile.o())
            {
              event.setResult(canInteractWithTileEntity(event, tile) ? Event.Result.ALLOW : Event.Result.DENY);
            }
          }
        }
      }
    } catch (IllegalArgumentException e) {
      e.printStackTrace();
    } catch (IllegalAccessException e) {
      e.printStackTrace();
    }
  }
  
  private boolean canInteractWithLocatedContainer(uf player, abw worldObj, int x, int y, int z)
  {
    if ((player == null) || (worldObj == null))
    {
      return false;
    }
    
    double worldScale = GulliverOMHelper.isLittleBlocksWorld(worldObj) ? 8.0D : 1.0D;
    
    if (worldScale == 1.0D)
    {

      return getPlayerDistanceSq(player, x + 0.5D, y + 0.5D, z + 0.5D) <= 64.0D * player.getRangeMultiplier();
    }
    if (!player.isHuge())
    {

      return getPlayerDistanceSq(player, (x + 0.5D) / worldScale, (y + 0.5D) / worldScale, (z + 0.5D) / worldScale) <= 16.0D * player.getSizeMultiplier();
    }
    

    return false;
  }
  

  private boolean canInteractWithTileEntity(PlayerOpenContainerEvent event, asp tile)
  {
    boolean canAccessSpot = canInteractWithLocatedContainer(entityPlayer, k, l, m, n);
    
    if ((canAccessSpot) && (!GulliverOMHelper.isLittleBlocksWorld(k)))
    {

      int n = 0;
      boolean isChestOpen = false;
      
      if ((tile instanceof asf))
      {
        n = 1;
        isChestOpen = a > 0.5F;
      }
      else if ((tile instanceof ary))
      {
        ary tc = (ary)tile;
        isChestOpen = f > 0.5F;
        tc.j();
        n = (d != null) || (c != null) || (b != null) || (e != null) ? 2 : 1;
      }
      
      if (n > 0)
      {
        return (isChestOpen) || (n == 1 ? GulliverEnvoy.canOpenSingleBlock(entityPlayer) : GulliverEnvoy.canOpenDoubleBlock(entityPlayer));
      }
    }
    
    return canAccessSpot;
  }
  
  private boolean canInteractWithContainerEntity(PlayerOpenContainerEvent event, nn entity)
  {
    boolean couldAccess = (!M) && (entityPlayer.e(entity) <= 64.0D * entityPlayer.getRangeMultiplier());
    
    if ((couldAccess) && ((entityPlayer.bp instanceof vj)))
    {
      couldAccess = GulliverEnvoy.canOpenSingleBlock(entityPlayer);
    }
    
    return couldAccess;
  }
  

  private double getPlayerDistanceSq(uf player, double x, double y, double z)
  {
    double xdist = u - x;
    double ydist = E.b + P * 0.9D - y;
    double zdist = w - z;
    return xdist * xdist + ydist * ydist + zdist * zdist;
  }
}
