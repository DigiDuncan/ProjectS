package gulliver.common;

import net.minecraftforge.common.Configuration;

public class GulliverConfigHelper
{
  public static Configuration config;
  
  public GulliverConfigHelper() {}
  
  public static void initConfiguration(java.io.File cfgfile)
  {
    config = new Configuration(cfgfile);
    loadConfiguration(config);
  }
  
  public static void loadConfiguration(Configuration cfg)
  {
    cfg.load();
    
    cfg.get("potion", "potion-tiny-id", 26, GulliverEnvoy.getTinyEffectComment());
    cfg.get("potion", "potion-huge-id", 27, GulliverEnvoy.getHugeEffectComment());
    GulliverEnvoy.setDyeResizingEnabled(cfg.get("general", "enable-dye-resizing", true, "Whether or not resizing with Cyan & Purple Dye is enabled.").getBoolean(true));
    GulliverEnvoy.setKarmaModeEnabled(cfg.get("general", "enable-karma-mode", false, "Whether to reset the player's base size to base-player-size on death.").getBoolean(false));
    GulliverEnvoy.setMinEntitySize(cfg.get("general", "min-entity-size", 0.125D, "The smallest allowed size multiplier for entities. Subject to hard minimum of 0.125 (default).").getDouble(0.125D));
    GulliverEnvoy.setMaxEntitySize(cfg.get("general", "max-entity-size", 8.0D, "The largest allowed size multiplier for entities. Subject to hard maximum of 8.0 (default).").getDouble(8.0D));
    GulliverEnvoy.setMinEntityBaseSize(cfg.get("general", "min-base-size", 0.125D, "The smallest allowed base size for entities. Subject to hard minimum of 0.125 (default).").getDouble(0.125D));
    GulliverEnvoy.setMaxEntityBaseSize(cfg.get("general", "max-base-size", 8.0D, "The largest allowed base size for entities. Subject to hard maximum of 8.0 (default).").getDouble(8.0D));
    GulliverEnvoy.basePlayerSize = cfg.get("spawn-size", "base-player-size", "1.0", "The default spawn base size for players. 1.0 is normal size.").getString();
    GulliverEnvoy.baseAnimalSize = cfg.get("spawn-size", "base-animal-size", "1.0", "The default spawn base size for animals. 1.0 is normal size.").getString();
    GulliverEnvoy.baseMonsterSize = cfg.get("spawn-size", "base-monster-size", "1.0", "The default spawn base size for monsters. 1.0 is normal size.").getString();
    GulliverEnvoy.baseNPCSize = cfg.get("spawn-size", "base-npc-size", "1.0", "The default spawn base size for NPCs. 1.0 is normal size.").getString();
    cfg.get("spawn-size", "base-size-spider", "", "A default spawn base size for Spider; ignored if empty. Add other 'base-size-<entityname>' properties if you like!");
    cfg.get("spawn-size", "base-size-entity90", "", "A default spawn base size for the entity with EntityList ID 90 (Pig); ignored if empty. Add other 'base-size-entity<id>' properties if you like!");
    
    cfg.get("size-limit", "min-player-size", 0.125D, "A minimum sizemultiplier for players; ignored if 0. Subject to hard minimum of 0.125 (default).");
    cfg.get("size-limit", "max-player-size", 8.0D, "A maximum sizemultiplier for players; ignored if 0. Subject to hard maximum of 8.0 (default).");
    cfg.get("size-limit", "min-animal-size", 0.125D, "A minimum sizemultiplier for animals; ignored if 0. Subject to hard minimum of 0.125 (default).");
    cfg.get("size-limit", "max-animal-size", 8.0D, "A maximum sizemultiplier for animals; ignored if 0. Subject to hard maximum of 8.0 (default).");
    cfg.get("size-limit", "min-monster-size", 0.125D, "A minimum sizemultiplier for monsters; ignored if 0. Subject to hard minimum of 0.125 (default).");
    cfg.get("size-limit", "max-monster-size", 8.0D, "A maximum sizemultiplier for monsters; ignored if 0. Subject to hard maximum of 8.0 (default).");
    cfg.get("size-limit", "min-npc-size", 0.125D, "A minimum sizemultiplier for NPCs; ignored if 0. Subject to hard minimum of 0.125 (default).");
    cfg.get("size-limit", "max-npc-size", 8.0D, "A maximum sizemultiplier for NPCs; ignored if 0. Subject to hard maximum of 8.0 (default).");
    
    cfg.get("size-limit", "min-size-chicken", 0.0D, "A minimum sizemult for Chicken; ignored if 0. Subject to hard minimum of 0.125 (default). Add other 'min-size-<entityname>' properties if you like!");
    cfg.get("size-limit", "max-size-ghast", 0.0D, "A maximum sizemult for Ghast; ignored if 0. Subject to hard maximum of 8.0 (default). Add other 'max-size-<entityname>' properties if you like!");
    cfg.get("size-limit", "max-size-giant", 0.0D, "A maximum sizemult for Giant Zombie; ignored if 0. Subject to hard maximum of 8.0 (default). Add other 'max-size-<entityname>' properties if you like!");
    
    if (cfg.hasChanged())
    {
      cfg.save();
    }
  }
}
