package gulliver.common;

import abw;
import acd;
import acf;
import amc;
import atc;
import beg;
import gulliver.GulliverForged;
import js;
import lp;
import lv;
import net.minecraft.server.MinecraftServer;

public class GulliverOMHelper
{
  public static boolean hasOptifine = false;
  public static boolean hasTMI = false;
  
  protected static Class lbWorldI = null;
  

  public static boolean ofFancyDrops = false;
  public static boolean ofFancyGrass = false;
  public static boolean ofFancyBetterGrass = false;
  public static boolean ofFancyTrees = false;
  public static boolean ofFancyFog = false;
  public static boolean ofFastFog = false;
  public static boolean ofDepthFog = false;
  public static boolean ofFancyWater = false;
  public static boolean ofClearWater = false;
  public static boolean ofRainFancy = false;
  public static boolean ofRainSplash = false;
  public static boolean ofRainOff = false;
  public static boolean ofSkyEnabled = false;
  public static boolean ofPlanetsEnabled = false;
  public static boolean ofStarsEnabled = false;
  public static float ofFogStart = 0.0F;
  public static int ofRenderDistanceFine = 0;
  public static int ofZoomKeyCode = 0;
  
  public GulliverOMHelper() {}
  
  public static boolean hasOptifine() { return hasOptifine; }
  

  public static boolean hasTMI()
  {
    return hasTMI;
  }
  
  public static boolean hasLittleBlocks()
  {
    return GulliverForged.proxy.hasLittleBlocks();
  }
  
  public static boolean isLittleBlocksWorld(abw world)
  {
    return (hasLittleBlocks()) && (lbWorldI.isInstance(world));
  }
  
  public static boolean setOptifineZoom(boolean par1)
  {
    return GulliverForged.proxy.setOptifineZoom(par1);
  }
  
  public static boolean getOptifineZoom()
  {
    return GulliverForged.proxy.getOptifineZoom();
  }
  
  public static boolean checkOptifineSettings()
  {
    return GulliverForged.proxy.checkOptifineSettings();
  }
  
  public static js getOptifineWorldServer(MinecraftServer par1MinecraftServer, amc par2ISaveHandler, String par3Str, int par4, acd par5WorldSettings, lv par6Profiler, lp par7ILogAgent)
  {
    return GulliverForged.proxy.getOptifineWorldServer(par1MinecraftServer, par2ISaveHandler, par3Str, par4, par5WorldSettings, par6Profiler, par7ILogAgent);
  }
  
  public static void optifineRegisterTextureUtilsListener()
  {
    GulliverForged.proxy.optifineRegisterTextureUtilsListener();
  }
  
  public static void optifineCheckDisplayMode()
  {
    GulliverForged.proxy.optifineCheckDisplayMode();
  }
  
  public static void updateOptifineWorldStuff(abw world0, abw world1)
  {
    GulliverForged.proxy.updateOptifineWorldStuff(world0, world1);
  }
  
  public static boolean updateOptifineCustomLightmap(abw world, float flickerX, int[] lmapColors, boolean nightvision)
  {
    return GulliverForged.proxy.updateOptifineCustomLightmap(world, flickerX, lmapColors, nightvision);
  }
  
  public static void updateOptifineCustomWaterFX(beg waterFX, acf world)
  {
    GulliverForged.proxy.updateOptifineCustomWaterFX(waterFX, world);
  }
  
  public static atc getOptifineCustomColor(String method, atc cvec)
  {
    return GulliverForged.proxy.getOptifineCustomColor(method, cvec);
  }
  
  public static atc getOptifineCustomPosColor(String method, atc cvec, acf world, double x, double y, double z)
  {
    return GulliverForged.proxy.getOptifineCustomPosColor(method, cvec, world, x, y, z);
  }
  
  public static atc getOptifineCustomUnderwaterColor(acf world, double x, double y, double z)
  {
    return GulliverForged.proxy.getOptifineCustomUnderwaterColor(world, x, y, z);
  }
  
  public static void resumeOptifineBackgroundUpdates()
  {
    GulliverForged.proxy.resumeOptifineBackgroundUpdates();
  }
  
  public static void pauseOptifineBackgroundUpdates()
  {
    GulliverForged.proxy.pauseOptifineBackgroundUpdates();
  }
}
