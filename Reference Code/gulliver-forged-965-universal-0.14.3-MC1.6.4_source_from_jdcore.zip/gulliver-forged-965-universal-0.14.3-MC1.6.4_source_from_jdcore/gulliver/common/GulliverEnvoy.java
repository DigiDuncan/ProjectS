package gulliver.common;

import abt;
import abw;
import acq;
import acw;
import akc;
import ane;
import anm;
import aof;
import aoi;
import aoj;
import apc;
import apn;
import aqe;
import aqi;
import aqv;
import aqz;
import ark;
import aro;
import ast;
import asu;
import asx;
import asz;
import atd;
import gulliver.EntityDamageSourcePassive;
import gulliver.GulliverForged;
import gulliver.potion.PotionResizing;
import java.util.IllegalFormatException;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.logging.Logger;
import ko;
import ls;
import net.minecraftforge.common.Configuration;
import net.minecraftforge.common.Property;
import ni;
import nj;
import nn;
import nt;
import of;
import og;
import oj;
import si;
import sk;
import th;
import ua;
import uc;
import uf;
import ws;
import xj;
import yb;
import yc;
import ye;
import zh;
import zl;

public class GulliverEnvoy
{
  public static ko drinkMe;
  public static ko eatMe;
  public static final int highestUsedEffectNum = 23;
  public static final int defaultTinyID = 26;
  public static final int defaultHugeID = 27;
  private static boolean dyeResizingEnabled = true;
  private static boolean karmaModeEnabled = false;
  private static double minEntitySize = 0.125D;
  private static double maxEntitySize = 8.0D;
  private static double minEntityBaseSize = 0.125D;
  private static double maxEntityBaseSize = 8.0D;
  public static String basePlayerSize = "1.0";
  public static String baseAnimalSize = "1.0";
  public static String baseMonsterSize = "1.0";
  public static String baseNPCSize = "1.0";
  
  public GulliverEnvoy() {}
  
  public static Random getRand() { return GulliverForged.rand; }
  

  public static Logger getLogger()
  {
    return GulliverForged.logger;
  }
  
  public static void registerAchievements()
  {
    drinkMe = new ko(42780, "drinkMe", 10, 15, yc.bv, null).c();
    eatMe = new ko(42781, "eatMe", 11, 15, yc.bb, null).c();
  }
  
  public static String getTinyEffectComment()
  {
    return "Potion effect ID for Ensmallening (default " + String.valueOf(26) + "). DO NOT CHANGE UNLESS NECESSARY, IT MAY CRASH EXISTING WORLDS!";
  }
  
  public static String getHugeEffectComment()
  {
    return "Potion effect ID for Embiggening (default " + String.valueOf(27) + "). DO NOT CHANGE UNLESS NECESSARY, IT MAY CRASH EXISTING WORLDS!";
  }
  
  public static void initResizingEffects()
  {
    Configuration config = GulliverConfigHelper.config;
    

    if (((config.hasKey("potion", "potion-tiny-id")) && (config.get("potion", "potion-tiny-id", 26).getInt() <= 23)) || ((config.hasKey("potion", "potion-huge-id")) && (config.get("potion", "potion-huge-id", 27).getInt() <= 23)))
    {
      Property p = config.get("potion", "potion-tiny-id", 26);
      p.set(26);
      comment = getTinyEffectComment();
      p = config.get("potion", "potion-huge-id", 27);
      p.set(27);
      comment = getHugeEffectComment();
      config.save();
    }
    PotionResizing.initResizingPotions(config.get("potion", "potion-tiny-id", 26).getInt(), config.get("potion", "potion-huge-id", 27).getInt());
  }
  
  public static void reloadConfiguration()
  {
    GulliverConfigHelper.loadConfiguration(GulliverConfigHelper.config);
  }
  
  public static void setBasePlayerSize(String size)
  {
    basePlayerSize = size;
  }
  
  public static void setKarmaModeEnabled(boolean enabled)
  {
    karmaModeEnabled = enabled;
  }
  
  public static boolean isKarmaModeEnabled()
  {
    return karmaModeEnabled;
  }
  
  public static void setDyeResizingEnabled(boolean enabled)
  {
    dyeResizingEnabled = enabled;
  }
  
  public static boolean isDyeResizingEnabled()
  {
    return dyeResizingEnabled;
  }
  
  public static double getMinEntitySize()
  {
    return minEntitySize;
  }
  
  public static void setMinEntitySize(double size)
  {
    minEntitySize = size;
  }
  
  public static double getMaxEntitySize()
  {
    return maxEntitySize;
  }
  
  public static void setMaxEntitySize(double size)
  {
    maxEntitySize = size;
  }
  
  public static double getMinEntityBaseSize()
  {
    return minEntityBaseSize;
  }
  
  public static void setMinEntityBaseSize(double size)
  {
    minEntityBaseSize = size;
  }
  
  public static double getMaxEntityBaseSize()
  {
    return maxEntityBaseSize;
  }
  
  public static void setMaxEntityBaseSize(double size)
  {
    maxEntityBaseSize = size;
  }
  
  public static float parseFloatString(String s1, float defv)
  {
    try
    {
      return Float.parseFloat(s1);
    }
    catch (NumberFormatException numberformatexception) {}
    


    return defv;
  }
  

  public static String getBasePlayerSize()
  {
    return basePlayerSize;
  }
  
  public static String getBaseAnimalSize()
  {
    return baseAnimalSize;
  }
  
  public static String getBaseMonsterSize()
  {
    return baseMonsterSize;
  }
  
  public static String getBaseNPCSize()
  {
    return baseNPCSize;
  }
  
  public static float getNewBasePlayerSize()
  {
    return getSizeFromRangeString(getBasePlayerSize(), true);
  }
  
  public static boolean isNPC(of par1Entity)
  {
    return par1Entity instanceof ua;
  }
  
  public static boolean isMonster(of par1Entity)
  {
    return par1Entity instanceof th;
  }
  
  public static boolean isAnimal(of par1Entity)
  {
    return (!isNPC(par1Entity)) && (!isMonster(par1Entity)) && (!(par1Entity instanceof uf));
  }
  
  public static boolean isArthropod(of par1Entity)
  {
    boolean flag = false;
    
    if (isMonster(par1Entity))
    {
      try
      {
        if (par1Entity.aY() == oj.c)
        {
          flag = true;
        }
      }
      catch (Exception exception) {}
    }
    
    return flag;
  }
  
  public static double getMaxSizeForEntity(of par1Entity)
  {
    if ((q == null) || (q.I))
    {
      return maxEntitySize;
    }
    
    Configuration config = GulliverConfigHelper.config;
    
    if (nt.b(par1Entity) != null)
    {
      String key = "max-size-".concat(nt.b(par1Entity).toLowerCase());
      

      if ((config.hasKey("size-limit", key)) && (config.get("size-limit", key, 0.0D).getDouble(0.0D) != 0.0D))
      {
        return config.get("size-limit", key, 0.0D).getDouble(0.0D);
      }
    }
    
    if ((par1Entity instanceof uf))
    {
      if ((config.hasKey("size-limit", "max-player-size")) && (config.get("size-limit", "max-player-size", 0.0D).getDouble(0.0D) != 0.0D))
      {
        return config.get("size-limit", "max-player-size", 0.0D).getDouble(0.0D);
      }
    }
    else if (isNPC(par1Entity))
    {
      if ((config.hasKey("size-limit", "max-npc-size")) && (config.get("size-limit", "max-npc-size", 0.0D).getDouble(0.0D) != 0.0D))
      {
        return config.get("size-limit", "max-npc-size", 0.0D).getDouble(0.0D);
      }
    }
    else if (isMonster(par1Entity))
    {
      if ((config.hasKey("size-limit", "max-monster-size")) && (config.get("size-limit", "max-monster-size", 0.0D).getDouble(0.0D) != 0.0D))
      {
        return config.get("size-limit", "max-monster-size", 0.0D).getDouble(0.0D);
      }
      

    }
    else if ((config.hasKey("size-limit", "max-animal-size")) && (config.get("size-limit", "max-animal-size", 0.0D).getDouble(0.0D) != 0.0D))
    {
      return config.get("size-limit", "max-animal-size", 0.0D).getDouble(0.0D);
    }
    

    return maxEntitySize;
  }
  
  public static double getMinSizeForEntity(of par1Entity)
  {
    if ((q == null) || (q.I))
    {
      return minEntitySize;
    }
    
    Configuration config = GulliverConfigHelper.config;
    
    if (nt.b(par1Entity) != null)
    {
      String key = "min-size-".concat(nt.b(par1Entity).toLowerCase());
      

      if ((config.hasKey("size-limit", key)) && (config.get("size-limit", key, 0.0D).getDouble(0.0D) != 0.0D))
      {
        return config.get("size-limit", key, 0.0D).getDouble(0.0D);
      }
    }
    
    if ((par1Entity instanceof uf))
    {
      if ((config.hasKey("size-limit", "min-player-size")) && (config.get("size-limit", "min-player-size", 0.0D).getDouble(0.0D) != 0.0D))
      {
        return config.get("size-limit", "min-player-size", 0.0D).getDouble(0.0D);
      }
    }
    else if (isNPC(par1Entity))
    {
      if ((config.hasKey("size-limit", "min-npc-size")) && (config.get("size-limit", "min-npc-size", 0.0D).getDouble(0.0D) != 0.0D))
      {
        return config.get("size-limit", "min-npc-size", 0.0D).getDouble(0.0D);
      }
    }
    else if (isMonster(par1Entity))
    {
      if ((config.hasKey("size-limit", "min-monster-size")) && (config.get("size-limit", "min-monster-size", 0.0D).getDouble(0.0D) != 0.0D))
      {
        return config.get("size-limit", "min-monster-size", 0.0D).getDouble(0.0D);
      }
      

    }
    else if ((config.hasKey("size-limit", "min-animal-size")) && (config.get("size-limit", "min-animal-size", 0.0D).getDouble(0.0D) != 0.0D))
    {
      return config.get("size-limit", "min-animal-size", 0.0D).getDouble(0.0D);
    }
    

    return minEntitySize;
  }
  
  public static float getNewBaseEntitySize(of par1Entity)
  {
    if ((q == null) || (q.I))
    {
      return 1.0F;
    }
    
    Configuration config = GulliverConfigHelper.config;
    
    if (nt.b(par1Entity) != null)
    {
      String key = "base-size-".concat(nt.b(par1Entity).toLowerCase());
      String keyn = "base-size-entity" + nt.a(par1Entity);
      

      if ((config.hasKey("spawn-size", keyn)) && (!config.get("spawn-size", keyn, "").getString().isEmpty()))
      {
        return getSizeFromRangeString(config.get("spawn-size", keyn, "").getString(), false);
      }
      
      if ((config.hasKey("spawn-size", key)) && (!config.get("spawn-size", key, "").getString().isEmpty()))
      {
        return getSizeFromRangeString(config.get("spawn-size", key, "").getString(), false);
      }
    }
    
    if (isNPC(par1Entity))
    {
      return getSizeFromRangeString(getBaseNPCSize(), false);
    }
    if (isMonster(par1Entity))
    {
      return getSizeFromRangeString(getBaseMonsterSize(), false);
    }
    

    return getSizeFromRangeString(getBaseAnimalSize(), false);
  }
  

  public static boolean isInvalidSize(float f)
  {
    return (f <= 0.0F) || (Float.isInfinite(f)) || (Float.isNaN(f));
  }
  
  public static float getSizeFromRangeString(String sizes, boolean allowHeights)
  {
    float f1 = 1.0F;
    float f2 = 1.0F;
    String[] sets = sizes.split(",");
    
    int r = getRand().nextInt(sets.length);
    String[] range = sets[r].split("-");
    String s1 = range[0];
    String s2 = "";
    if (range.length > 1)
    {
      s2 = range[1];
    }
    
    try
    {
      f1 = allowHeights ? parsePlayerHeight(s1) : Float.parseFloat(s1);

    }
    catch (NumberFormatException numberformatexception)
    {
      return 1.0F;
    }
    if (range.length == 1)
    {

      return f1;
    }
    try
    {
      f2 = allowHeights ? parsePlayerHeight(s2) : Float.parseFloat(s2);

    }
    catch (NumberFormatException numberformatexception)
    {
      return f1;
    }
    if (f1 > f2)
    {

      return f1;
    }
    




    f1 += (f2 - f1) * getRand().nextInt(9) / 8.0F;
    
    return f1;
  }
  

  public static float parsePlayerHeight(String s)
  {
    float sm = 1.0F;
    boolean isInches = s.endsWith("in");
    boolean isFeet = s.endsWith("ft");
    boolean isMetric = s.endsWith("m");
    boolean isCentimeters = s.endsWith("cm");
    
    if (((isInches) || (isFeet) || (isCentimeters)) && (s.length() > 2))
    {
      s = s.substring(0, s.length() - 2);
    }
    else if ((isMetric) && (s.length() > 1))
    {
      s = s.substring(0, s.length() - 1);
    }
    else if ((s.endsWith("\"")) && (s.length() > 1))
    {
      s = s.substring(0, s.length() - 1);
      isInches = true;
    }
    else if ((s.endsWith("'")) && (s.length() > 1))
    {
      s = s.substring(0, s.length() - 1);
      isFeet = true;
    }
    
    if (isInches)
    {

      String[] parts = s.split("'|ft");
      
      if (parts.length == 2)
      {
        sm = Float.parseFloat(parts[0]) * 12.0F + Float.parseFloat(parts[(parts.length - 1)]);
      }
      else
      {
        sm = Float.parseFloat(s);
      }
    }
    else
    {
      sm = Float.parseFloat(s);
    }
    
    if ((isInches) || (isFeet) || (isMetric))
    {
      sm /= 1.8F;
      
      if (isCentimeters)
      {
        sm *= 0.01F;
      }
      else if (isInches)
      {
        sm *= 0.0254F;
      }
      else if (isFeet)
      {
        sm *= 0.3048F;
      }
    }
    
    return sm;
  }
  
  public static String getPlayerHeightStringFromSizeMult(float sm)
  {
    try
    {
      float h = sm * 1.8F;
      float hf = h / 0.3048F;
      boolean useMeters = h >= 1.0F;
      boolean useFeet = hf >= 1.0F;
      String s = "";
      
      if (useMeters)
      {
        s = "%.2fm";
      }
      else
      {
        s = "%.2fcm";
        h *= 100.0F;
      }
      
      if (useFeet)
      {
        return String.format(s + " (%dft%.2fin)", new Object[] { Float.valueOf(h), Integer.valueOf((int)hf), Float.valueOf(hf * 12.0F % 12.0F) });
      }
      

      return String.format(s + " (%.2fin)", new Object[] { Float.valueOf(h), Float.valueOf(hf * 12.0F) });
    }
    catch (IllegalFormatException var5) {}
    

    return "";
  }
  

  public static boolean isDragonEntity(nn par1Entity)
  {
    return ((par1Entity instanceof sk)) || ((par1Entity instanceof si));
  }
  
  public static boolean canOpenSingleBlock(of par1EntityLiving)
  {
    return smallBlockOpeningStrength(par1EntityLiving) >= 1;
  }
  
  public static boolean canOpenDoubleBlock(of par1EntityLiving)
  {
    return smallBlockOpeningStrength(par1EntityLiving) >= 2;
  }
  
  private static int smallBlockOpeningStrength(of par1EntityLiving)
  {
    float mult = par1EntityLiving.getSizeMultiplier();
    int strengthadj = 3;
    

    if (mult >= 0.6F)
    {
      return strengthadj;
    }
    while (mult < 0.6F)
    {
      strengthadj--;
      mult *= 2.0F;
    }
    if (par1EntityLiving.holdingPointyItem())
    {
      strengthadj++;
    }
    if (par1EntityLiving.a(ni.t))
    {
      strengthadj -= par1EntityLiving.b(ni.t).c() + 1;
    }
    if (par1EntityLiving.a(ni.g))
    {
      strengthadj += par1EntityLiving.b(ni.g).c() + 1;
    }
    
    return strengthadj;
  }
  

  public static boolean canPressPlateLikeButton(of par1EntityLiving)
  {
    return par1EntityLiving.isHuge();
  }
  
  public static boolean canSizeGrief(nn par1Entity)
  {
    abt gr = q.O();
    if ((par1Entity instanceof uf))
    {
      return (!bG.d) && ((!gr.e("sizeGriefing")) || (gr.b("sizeGriefing")));
    }
    

    return ((par1Entity instanceof og)) && (gr.b("mobGriefing")) && ((!gr.e("sizeGriefing")) || (gr.b("sizeGriefing")));
  }
  

  public static boolean isHoldingStringOrLeash(of par1Entity)
  {
    return (par1Entity.aZ() != null) && (((par1Entity.isTiny()) && (aZd == Mcv)) || ((!par1Entity.isTiny()) && (!par1Entity.isHuge()) && (aZd == chcv)));
  }
  
  public static boolean isItemPointy(ye par1ItemStack)
  {
    yc var3 = par1ItemStack.b();
    

    if ((var3 instanceof zh))
    {
      int id = ((zh)var3).g();
      return ((aqz.s[id] instanceof aqi)) || ((aqz.s[id] instanceof apn)) || (id == avcF) || (id == aOcF) || (d == bYcF);
    }
    

    return ((var3 instanceof xj)) || ((var3 instanceof yb)) || ((var3 instanceof zl)) || ((var3 instanceof xv)) || ((var3 instanceof ws)) || (d == Fcv) || (d == aZcv) || (d == ncv) || (d == aWcv) || (d == bMcv) || (d == bRcv);
  }
  


  public static void checkSupportingBlocksForHuge(nn entity, Random rand)
  {
    int k = ls.c(v - 0.20000000298023224D - N);
    int sx1 = ls.c(E.a + 0.001D);
    int sy1 = ls.c(E.b + 0.001D);
    int sz1 = ls.c(E.c + 0.001D);
    int sx2 = ls.c(E.d - 0.001D);
    int sy2 = ls.c(E.e - 0.001D);
    int sz2 = ls.c(E.f - 0.001D);
    
    boolean supported = false;
    int bcnt = 0;
    for (int hx = sx1; hx <= sx2; hx++)
    {
      for (int hz = sz1; hz <= sz2; hz++)
      {
        int id = q.a(hx, k, hz);
        akc m = q.g(hx, k, hz);
        if (aqz.s[id] != null)
        {
          boolean isBrittle = (m == akc.s) || (m == akc.w);
          boolean isFlimsy = (!m.a()) || (m == akc.j);
          if ((!isBrittle) && (!isFlimsy))
          {
            supported = true;
            break;
          }
          if (!isFlimsy)
          {
            bcnt++;
          }
        }
      }
    }
    if (!supported)
    {
      int edgew = ls.d(O / 3.0F);
      
      for (int hx = sx1; hx <= sx2; hx++)
      {
        for (int hz = sz1; hz <= sz2; hz++)
        {
          int id = q.a(hx, k, hz);
          akc m = q.g(hx, k, hz);
          if ((aqz.s[id] != null) && ((m == akc.s) || (m == akc.w)) && ((!(entity instanceof uf)) || (q.a((uf)entity, hx, k, hz))))
          {

            boolean beneath = (hx >= sx1 + edgew) && (hx <= sx2 - edgew) && (hz >= sz1 + edgew) && (hz <= sz2 - edgew);
            if (((beneath) && (rand.nextInt(10) == 0)) || ((!beneath) && (rand.nextInt(bcnt * 10) == 0)))
            {
              aqz.s[id].c(q, hx, k, hz, q.h(hx, k, hz), 0);
              q.c(hx, k, hz, m == akc.w ? FcF : 0);
              q.e(2001, hx, k, hz, scF + (q.h(hx, k, hz) << 12));
            }
          }
        }
      }
    }
  }
  

  public static void leaveHugeFootprints(nn entity)
  {
    int k = ls.c(v - 0.20000000298023224D - N);
    int sx1 = ls.c(E.a + 0.001D);
    int sz1 = ls.c(E.c + 0.001D);
    int sx2 = ls.c(E.d - 0.001D);
    int sz2 = ls.c(E.f - 0.001D);
    
    if (entity.getStepSide() > 0)
    {
      int j1 = q.a(sx1, k, sz1);
      
      if (j1 > 0)
      {
        aqz.s[j1].b(q, sx1, k, sz1, entity);
      }
      
      j1 = q.a(sx2, k, sz2);
      
      if (j1 > 0)
      {
        aqz.s[j1].b(q, sx2, k, sz2, entity);
      }
    }
    else if (entity.getStepSide() < 0)
    {
      int j1 = q.a(sx1, k, sz2);
      
      if (j1 > 0)
      {
        aqz.s[j1].b(q, sx1, k, sz2, entity);
      }
      
      j1 = q.a(sx2, k, sz1);
      
      if (j1 > 0)
      {
        aqz.s[j1].b(q, sx2, k, sz1, entity);
      }
    }
  }
  
  public static void stepOnSmallerEntities(nn entity)
  {
    List var2 = q.b(entity, E.b(0.20000000298023224D, 0.0D, 0.20000000298023224D));
    
    if ((var2 != null) && (!var2.isEmpty()))
    {
      for (int i = 0; i < var2.size(); i++)
      {
        nn var4 = (nn)var2.get(i);
        
        if ((entity.collideableRideEntity(var4)) && (entity.canSquish(var4)))
        {
          if ((E.e >= E.b) && (E.b <= E.b + P * 0.0625F))
          {


            var4.a(new EntityDamageSourcePassive("step", entity), ls.d(2.0F * entity.getSizeMultiplierRoot() / var4.getSizeMultiplierRoot()));
          }
        }
      }
    }
  }
  
  public static boolean resizeCollision(of entity, float oldwidth, float newwidth)
  {
    if ((q.I) && (!(entity instanceof uf))) {
      return false;
    }
    if (oldwidth > newwidth) {
      return false;
    }
    asx bbox = E.e(0.03125D * entity.getSizeMultiplier(), 0.0D, 0.03125D * entity.getSizeMultiplier());
    List list1 = q.a(entity, bbox);
    
    if (!list1.isEmpty())
    {
      int xpos = 0;
      int xneg = 0;
      int zpos = 0;
      int zneg = 0;
      
      for (int j = 0; j < list1.size(); j++)
      {
        asx axisalignedbb = (asx)list1.get(j);
        
        if ((a > a) && (a < d))
        {
          xneg = 1;
        }
        
        if ((c > c) && (c < f))
        {
          zneg = 1;
        }
        
        if ((d < d) && (d > a))
        {
          xpos = 1;
        }
        
        if ((f < f) && (f > c))
        {
          zpos = 1;
        }
      }
      
      if ((xpos != 0) || (xneg != 0) || (zpos != 0) || (zneg != 0))
      {
        float offset = newwidth - oldwidth;
        
        entity.g((xpos - xneg) * offset, 0.0D, (zpos - zneg) * offset);
        return true;
      }
    }
    
    return false;
  }
  
  public static void breakBlocksViaGrowth(of entity, asx oldbb, double diffh, double diffw, Random rand)
  {
    if (!q.a(entity, oldbb.e(diffw, diffh, diffw)).isEmpty())
    {
      float sizemult = entity.getSizeMultiplier();
      oldbb = E.c();
      
      if (sizemult > 1.0F)
      {
        b = (e - P / 4.0D);
        
        if (q.a(entity, oldbb.e(diffw * 4.0D, 0.0D, diffw * 4.0D)).isEmpty())
        {
          b = E.b;
        }
        else
        {
          b = (E.b - 0.5D);
        }
      }
      
      diffh = (diffh > 0.5D ? 0.5D : diffh) * 0.5D;
      diffw = (diffw > 0.5D ? 0.5D : diffw) * 0.5D;
      List list1 = q.a(entity, oldbb.e(diffw, diffh, diffw));
      
      for (int j = 0; j < list1.size(); j++)
      {
        asx tmpbb = (asx)list1.get(j);
        int var1 = ls.c((a + d) / 2.0D);
        int var2 = ls.c((b + e) / 2.0D);
        int var3 = ls.c((c + f) / 2.0D);
        
        if ((!(entity instanceof uf)) || (q.a((uf)entity, var1, var2, var3)))
        {

          aqz block = aqz.s[q.a(var1, var2, var3)];
          float h = block != null ? block.l(q, var1, var2, var3) : 0.0F;
          asp te = q.r(var1, var2, var3);
          
          if ((block != null) && (((h <= 1.0F) && (h >= 0.0F) && (h < sizemult)) || ((cU == akc.d) && (entity.isHuge()))))
          {
            block.a(q, var1, var2, var3);
            asx bb3 = asx.a(var1 + block.u(), var2 + block.w(), var3 + block.y(), var1 + block.v(), var2 + block.x(), var3 + block.z());
            
            if (oldbb.b(0.25D, 0.25D, 0.25D).a(q.V().a(var1 + (block.u() + block.v()) * 0.5D, var2 + (block.w() + block.x()) * 0.5D, var3 + (block.y() + block.z()) * 0.5D)))
            {
              int md = q.h(var1, var2, var3);
              
              if ((cU.d()) || (block == aqz.aY))
              {
                if (block == aqz.aY)
                {
                  akc var8 = q.g(var1, var2 - 1, var3);
                  
                  if ((var8.c()) || (var8.d()))
                  {
                    q.c(var1, var2, var3, FcF);
                  }
                  else
                  {
                    q.i(var1, var2, var3);
                  }
                }
                else if (cU == akc.h)
                {
                  q.c(var1, var2, var3, FcF);
                }
                
              }
              else
              {
                block.c(q, var1, var2, var3, md, 0);
                q.i(var1, var2, var3);
              }
              
              if (rand.nextInt(2) == 0)
              {
                q.e(2001, var1, var2, var3, cF + (md << 12));
              }
            }
          }
        }
      }
    }
  }
  
  public static float blockClimbingRateForTiny(abw world, int par1, int par2, int par3)
  {
    aqz b = aqz.s[world.a(par1, par2, par3)];
    akc m = world.g(par1, par2, par3);
    
    if (b == null)
    {
      return 0.0F;
    }
    if (cF == bhcF)
    {
      return 0.3F;
    }
    if ((m == akc.b) || (m == akc.j) || (m == akc.m))
    {
      return 0.7F;
    }
    if ((m == akc.e) && (world.r(par1, par2, par3) == null))
    {
      ye stack = new ye(cF, 1, world.h(par1, par2, par3));
      String name = (stack != null) && (stack.b() != null) ? stack.b().d(stack) : "";
      return (stack != null) && (name != null) && (name.toLowerCase().contains("moss")) ? 0.7F : 0.0F;
    }
    if ((m == akc.p) || (m == akc.A) || (m == akc.y) || ((b instanceof aof)))
    {
      return 0.6F;
    }
    if ((m == akc.n) || (b.isBed(world, par1, par2, par3, null)) || (m == akc.r) || (cF == bEcF) || (cF == bUcF) || (m == akc.z) || (m == akc.B))
    {
      return 0.5F;
    }
    if (m == akc.x)
    {
      return 0.4F;
    }
    if (m == akc.E)
    {
      return 0.3F;
    }
    if (cF == bZcF)
    {
      return 0.5F;
    }
    

    return 0.0F;
  }
  


  public static boolean isEntityIntersectingPlant(nn entity)
  {
    int x = ls.c(u);
    int y = ls.c(E.b);
    int z = ls.c(w);
    int bid = q.a(x, y, z);
    
    if ((q.g(x, y, z) == akc.k) || (q.g(x, y, z) == akc.l))
    {
      aqz b = aqz.s[bid];
      b.a(q, x, y, z);
      if (b.b(q, x, y, z) == null)
      {
        asx bb = asx.a().a(x + b.u(), y + b.w(), z + b.y(), x + b.v(), y + b.x(), z + b.z());
        if ((bb != null) && (E.b(bb)))
        {
          return true;
        }
      }
    }
    else if ((bid > 0) && ((aqz.s[bid] instanceof aoj)))
    {
      aqz b = aqz.s[bid];
      b.g();
      ye ps = aoj.p_(q.h(x, y, z));
      aqz pb = ps == null ? null : aqz.s[d];
      double pmaxy = pb == null ? 0.25D : pb.x() + 0.25D;
      if (pmaxy > 1.0D) pmaxy = 1.0D;
      asx potbb = b.b(q, x, y, z);
      asx pbb = asx.a().a(x + b.u(), y + 0.1875D, z + b.y(), x + b.v(), y + pmaxy, z + b.z());
      if ((pbb != null) && (E.b(pbb)))
      {
        return true;
      }
    }
    
    return false;
  }
  
  public static boolean tinyCaughtInRain(of entity)
  {
    return ((entity instanceof uf)) && (entity.isExtraTiny()) && (P < 1.0F) && (!entity.doesUmbrella()) && (!isShelteredFromRain(entity));
  }
  
  public static boolean couldBeRainedOn(of entity)
  {
    if (!q.Q())
    {
      return false;
    }
    
    double var1 = v + entity.f();
    int var4 = ls.c(u);
    int var5 = ls.c(var1);
    int var6 = ls.c(w);
    
    acq gb = q.a(var4, var6);
    if (!gb.d())
    {
      return false;
    }
    
    if (q.F(var4, var5, var6))
    {
      return true;
    }
    
    if (!q.F(var4, var5 + 4, var6))
    {

      return false;
    }
    
    asx bb = E.c();
    e = (var5 + 1);
    int var7 = var5;
    while (!q.F(var4, var7, var6))
    {
      if ((q.w(var4, var7, var6)) || (q.g(var4, var7 + 1, var6) == akc.r))
      {

        return false;
      }
      
      List l = q.a(bb);
      if ((l != null) && (!l.isEmpty()))
      {
        return false;
      }
      var7++;
      b = var7;
      e = (var7 + 1);
    }
    
    return true;
  }
  
  public static boolean isShelteredFromRain(of entity)
  {
    if (!couldBeRainedOn(entity))
    {
      return true;
    }
    
    double var1 = v + entity.f();
    int var4 = ls.c(u);
    int var5 = ls.c(var1);
    int var6 = ls.c(w);
    int var7 = q.a(var4, var5, var6);
    aqz b = aqz.s[var7];
    

    if ((var7 != 0) && (b != null) && (((b instanceof ane)) || (cU == akc.k)))
    {
      if ((!(b instanceof aqv)) && (!(b instanceof aro)) && (!(b instanceof aqe)))
      {
        b.a(q, var4, var5, var6);
        asx bb = asx.a().a(var4 + b.u(), var5, var6 + b.y(), var4 + b.v(), var5 + b.x(), var6 + b.z());
        if ((bb != null) && (e > var1) && (E.b(bb)))
        {
          return true;
        }
      }
    }
    

    var7 = q.a(var4, var5 + 1, var6);
    b = aqz.s[var7];
    
    if ((var7 != 0) && (b != null) && ((b instanceof anm)))
    {
      b.a(q, var4, var5 + 1, var6);
      asx bb = asx.a().a(var4 + b.u(), E.b, var6 + b.y(), var4 + b.v(), var5 + 1.0D + b.x(), var6 + b.z());
      if ((bb != null) && (E.b(bb)))
      {
        return true;
      }
    }
    
    asx bb = E.c();
    e += 3.0D;
    List var2 = q.b(entity, bb);
    
    if ((var2 != null) && (!var2.isEmpty()))
    {
      Iterator var10 = var2.iterator();
      
      while (var10.hasNext())
      {
        nn var11 = (nn)var10.next();
        
        if ((var11.collideableRideEntity(entity)) && (var11.canSquish(entity)))
        {
          return true;
        }
        if (((var11 instanceof of)) && (((of)var11).doesUmbrella()))
        {
          return true;
        }
      }
    }
    
    return false;
  }
  
  public static boolean alongStickySurface(of entity)
  {
    if (!entity.isTiny())
    {
      return false;
    }
    

    List list1 = q.a(entity, E.b(entity.Z(), entity.Z(), entity.Z()));
    
    if (list1.isEmpty())
    {
      return false;
    }
    
    int x1 = ls.c(u);
    int y1 = ls.c(E.b);
    int y2 = ls.c(E.e);
    int z1 = ls.c(w);
    
    for (int j = 0; j < list1.size(); j++)
    {
      asx tmpbb = (asx)list1.get(j);
      int var1 = ls.c((a + d) / 2.0D);
      int var2 = ls.c((b + e) / 2.0D);
      int var3 = ls.c((c + f) / 2.0D);
      int b = q.a(var1, var2, var3);
      int md = q.h(var1, var2, var3);
      aqz block = aqz.s[q.a(var1, var2, var3)];
      
      if ((b == aacF) && (!ast.e(md)))
      {
        int var7 = s.a[ast.d(md)];
        var1 -= s.b[var7];
        var2 -= s.c[var7];
        var3 -= s.d[var7];
        
        if ((x1 == var1) && ((y1 == var2) || (y2 == var2)) && (z1 == var3))
        {
          return true;
        }
      }
      else if (b == afcF)
      {
        int var7 = s.a[asu.d(md)];
        var1 += s.b[var7];
        var2 += s.c[var7];
        var3 += s.d[var7];
        int b2 = q.a(var1, var2, var3);
        
        if (b2 == aacF)
        {
          var1 -= 2 * s.b[var7];
          var2 -= 2 * s.c[var7];
          var3 -= 2 * s.d[var7];
          
          if ((x1 == var1) && ((y1 == var2) || (y2 == var2)) && (z1 == var3))
          {
            return true;
          }
        }
      }
    }
    
    return false;
  }
  
  public static double getRisingUpdraft(of entity)
  {
    double ypos = v + entity.f();
    double ret = 0.0D;
    int l = ls.c(u);
    int m = ls.c(ypos);
    int n = ls.c(w);
    int h = m;
    

    while ((h > 0) && (entity.q.a(l, h, n) == 0))
    {
      h--;
    }
    
    double alt = ypos - h;
    
    if (alt <= 8.0D)
    {
      double heat = getBlockHeatValue(entity.q, l, h, n);
      double intensity = -0.04D * (ypos - h) + 0.2D * heat;
      
      if (intensity < 0.0D)
      {
        intensity = 0.0D;
      }
      
      ret += intensity;
    }
    

    for (int i = 0; i < 4; i++)
    {
      int p = l - (i >> 1) % 2 * (i % 2 * 2 - 1);
      int q = n - ((i >> 1) + 1) % 2 * (i % 2 * 2 - 1);
      int r = m;
      

      while ((r > 0) && (entity.q.a(p, r, q) == 0))
      {
        r--;
      }
      
      alt = ypos - r;
      
      if (alt <= 8.0D)
      {
        double heat = getBlockHeatValue(entity.q, p, r, q);
        double intensity = -0.04D * (ypos - r) + 0.2D * heat;
        
        if (intensity < 0.0D)
        {
          intensity = 0.0D;
        }
        else if (entity.q.a(p, r, q) == aHcF)
        {
          int side = entity.q.h(p, r, q);
          intensity *= (i + 2 == side ? 0.75D : 0.25D);
        }
        else
        {
          intensity *= 0.25D;
        }
        
        ret += intensity;
      }
    }
    
    if (ret > 0.0D)
    {
      ret += ret * 0.05D * getRand().nextGaussian();
    }
    
    return ret > 0.0D ? ret * entity.getSizeMultiplierRoot() : 0.0D;
  }
  
  public static double getBlockHeatValue(abw world, int par1, int par2, int par3)
  {
    int b = world.a(par1, par2, par3);
    
    if (b == awcF)
    {
      return 1.0D;
    }
    if ((b == HcF) || (b == IcF))
    {
      return 1.5D;
    }
    if (b == aHcF)
    {
      return 0.75D;
    }
    if (((b == JcF) || (b == VcF)) && ((world.a(par1, par3) instanceof acw)) && (world.v()) && (world.J() % 24000L > 2000L) && (world.J() % 24000L < 10000L) && (world.l(par1, par2 + 1, par3)))
    {
      return 0.4D;
    }
    

    return 0.0D;
  }
  


  public static void pruneSmallerEntities(float minSize, List list)
  {
    if (minSize == 0.0F) {
      return;
    }
    Iterator iterator = list.iterator();
    

    while (iterator.hasNext())
    {



      nn entity = (nn)iterator.next();
      if (entity.getSizeMultiplier() < minSize)
      {
        iterator.remove();
      }
    }
  }
  

  public static void pruneLargerEntities(float maxSize, List list)
  {
    if (maxSize == 0.0F) {
      return;
    }
    Iterator iterator = list.iterator();
    

    while (iterator.hasNext())
    {



      nn entity = (nn)iterator.next();
      if (entity.getSizeMultiplier() > maxSize)
      {
        iterator.remove();
      }
    }
  }
  






  public static boolean isClientPlayerEntity(nn par1Entity)
  {
    return GulliverForged.proxy.isClientPlayerEntity(par1Entity);
  }
  
  public static boolean isClientsideEntity(nn par1Entity)
  {
    return GulliverForged.proxy.isClientsideEntity(par1Entity);
  }
  


  public static boolean isUnrideableEntity(nn par1Entity)
  {
    return GulliverForged.proxy.isUnrideableEntity(par1Entity);
  }
  

  public static boolean isUnholdableEntity(nn par1Entity)
  {
    return GulliverForged.proxy.isUnholdableEntity(par1Entity);
  }
  
  public static boolean isGlideableItem(ye stack)
  {
    return GulliverForged.proxy.isGlideableItem(stack);
  }
  
  public static void clearClientMouseover()
  {
    GulliverForged.proxy.clearClientMouseover();
  }
  
  public static boolean isClientAttacking()
  {
    return GulliverForged.proxy.isClientAttacking();
  }
  
  public static boolean getClientPlayerMovementSneak(uf par1EntityPlayer)
  {
    return GulliverForged.proxy.getClientPlayerMovementSneak(par1EntityPlayer);
  }
  
  public static boolean getClientPlayerMovementJump(uf par1EntityPlayer)
  {
    return GulliverForged.proxy.getClientPlayerMovementJump(par1EntityPlayer);
  }
}
