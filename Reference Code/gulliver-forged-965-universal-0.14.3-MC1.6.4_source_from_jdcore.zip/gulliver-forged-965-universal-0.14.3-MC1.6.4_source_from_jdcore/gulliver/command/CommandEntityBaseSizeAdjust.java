package gulliver.command;

import abw;
import ad;
import asp;
import az;
import bd;
import cv;
import gulliver.common.GulliverEnvoy;
import net.minecraft.server.MinecraftServer;
import nn;
import of;
import uf;
import z;

public class CommandEntityBaseSizeAdjust
  extends z
{
  public CommandEntityBaseSizeAdjust() {}
  
  public String c()
  {
    return "entitybasesizeadjust";
  }
  



  public int a()
  {
    return 2;
  }
  

  public String c(ad par1ICommandSender)
  {
    return "commands.entitybasesizeadjust.usage";
  }
  



  public static float parseFloat(ad par0ICommandSender, String par1Str)
  {
    try
    {
      return Float.parseFloat(par1Str);
    }
    catch (NumberFormatException var3)
    {
      throw new az("commands.generic.num.invalid", new Object[] { par1Str });
    }
  }
  
  public void b(ad par1ICommandSender, String[] par2ArrayOfStr)
  {
    if (par2ArrayOfStr.length == 2)
    {
      int var3 = a(par1ICommandSender, par2ArrayOfStr[0], 1);
      abw wc;
      abw wc;
      if ((par1ICommandSender instanceof asp))
      {
        wc = k;
      }
      else
      {
        uf var4 = b(par1ICommandSender);
        wc = MinecraftServer.F().a(ar);
      }
      nn var5 = wc.a(var3);
      
      if ((var5 != null) && (GulliverEnvoy.isDragonEntity(var5)))
      {
        par1ICommandSender.a(cv.e("commands.entitybasesize.failure.dragon"));
      }
      else if ((var5 != null) && ((var5 instanceof of)))
      {
        float basize = parseFloat(par1ICommandSender, par2ArrayOfStr[1]);
        if (GulliverEnvoy.isInvalidSize(basize))
        {
          throw new az("commands.basesize.num.invalid", new Object[] { Float.valueOf(basize) });
        }
        ((of)var5).adjustBaseSize(basize);
        
        a(par1ICommandSender, "commands.entitybasesize.success", new Object[] { Integer.valueOf(k), Float.valueOf(sizeBaseMultiplier), Float.valueOf(((of)var5).getNewSizeDestMultiplier()) });

      }
      else
      {
        par1ICommandSender.a(cv.b("commands.entitybasesize.failure.noEntity", new Object[] { Integer.valueOf(var3) }));
      }
      
    }
    else
    {
      throw new bd(c(par1ICommandSender), new Object[0]);
    }
  }
}
