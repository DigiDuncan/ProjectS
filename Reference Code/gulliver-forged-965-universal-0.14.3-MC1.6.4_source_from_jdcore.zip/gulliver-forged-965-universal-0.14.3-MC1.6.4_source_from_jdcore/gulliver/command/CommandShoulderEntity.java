package gulliver.command;

import ad;
import dj;
import jm;
import js;
import jv;
import nn;
import uf;
import z;







public class CommandShoulderEntity
  extends z
{
  public CommandShoulderEntity() {}
  
  public boolean a(ad par1ICommandSender)
  {
    return par1ICommandSender instanceof jv;
  }
  
  public String c()
  {
    return "shoulderentity";
  }
  



  public int a()
  {
    return 0;
  }
  
  public String c(ad par1ICommandSender)
  {
    return "/shoulderentity";
  }
  
  public void b(ad par1ICommandSender, String[] par2ArrayOfStr)
  {
    jv entityplayermp = b(par1ICommandSender);
    if ((entityplayermp.by() == null) && (heldEntity == null) && (n != null))
    {

      entityplayermp.p().q().a(entityplayermp, new dj(entityplayermp, 1));
      
      nn rider = n;
      rider.a((rider instanceof uf) ? entityplayermp : null);
      
      if (entityplayermp.maxHeldWidth(rider) >= O)
      {
        entityplayermp.pickUpEntity(rider);
      }
    }
    else if ((entityplayermp.by() == null) && (heldEntity != null) && (n == null))
    {

      nn held = heldEntity;
      held.getDroppedByEntity(holdingEntity);
      
      entityplayermp.p().q().b(entityplayermp, new dj(entityplayermp, 1));
      held.a(entityplayermp);
    }
  }
}
