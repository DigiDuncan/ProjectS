package gulliver.command;

import abw;
import ad;
import asp;
import bd;
import cv;
import gulliver.common.GulliverEnvoy;
import net.minecraft.server.MinecraftServer;
import nn;
import of;
import uf;
import z;

public class CommandEntityHalfSize
  extends z
{
  public CommandEntityHalfSize() {}
  
  public String c()
  {
    return "entityhalfsize";
  }
  



  public int a()
  {
    return 2;
  }
  

  public String c(ad par1ICommandSender)
  {
    return "commands.entityhalfsize.usage";
  }
  
  public void b(ad par1ICommandSender, String[] par2ArrayOfStr)
  {
    if (par2ArrayOfStr.length > 0)
    {
      int var3 = a(par1ICommandSender, par2ArrayOfStr[0], 1);
      abw wc;
      abw wc;
      if ((par1ICommandSender instanceof asp))
      {
        wc = k;
      }
      else
      {
        uf var4 = b(par1ICommandSender);
        wc = MinecraftServer.F().a(ar);
      }
      nn var5 = wc.a(var3);
      
      if ((var5 != null) && (GulliverEnvoy.isDragonEntity(var5)))
      {
        par1ICommandSender.a(cv.e("commands.entitybasesize.failure.dragon"));
      }
      else if ((var5 != null) && ((var5 instanceof of)))
      {
        var5.halveSize();
        
        a(par1ICommandSender, "commands.entitybasesize.success", new Object[] { Integer.valueOf(k), Float.valueOf(sizeBaseMultiplier), Float.valueOf(sizeDestMultiplier) });




      }
      else
      {



        par1ICommandSender.a(cv.b("commands.entitybasesize.failure.noEntity", new Object[] { Integer.valueOf(var3) }));
      }
      
    }
    else
    {
      throw new bd(c(par1ICommandSender), new Object[0]);
    }
  }
}
