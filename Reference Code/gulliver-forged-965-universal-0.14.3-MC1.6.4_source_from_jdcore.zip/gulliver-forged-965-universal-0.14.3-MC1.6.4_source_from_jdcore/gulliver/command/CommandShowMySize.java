package gulliver.command;

import ad;
import cv;
import gulliver.common.GulliverEnvoy;
import jv;
import z;

public class CommandShowMySize
  extends z
{
  public CommandShowMySize() {}
  
  public boolean a(ad par1ICommandSender)
  {
    return par1ICommandSender instanceof jv;
  }
  
  public String c()
  {
    return "showmysize";
  }
  



  public int a()
  {
    return 0;
  }
  
  public String c(ad par1ICommandSender)
  {
    return "/showmysize";
  }
  
  public void b(ad par1ICommandSender, String[] par2ArrayOfStr)
  {
    jv var4 = b(par1ICommandSender);
    String hs = GulliverEnvoy.getPlayerHeightStringFromSizeMult(var4.getSizeMultiplier());
    
    if (hs.length() > 0)
    {
      par1ICommandSender.a(cv.b("commands.showmysize.height", new Object[] { Float.valueOf(sizeBaseMultiplier), Float.valueOf(var4.getSizeMultiplier()), hs }));
    }
    else
    {
      par1ICommandSender.a(cv.b("commands.showmysize", new Object[] { Float.valueOf(sizeBaseMultiplier), Float.valueOf(var4.getSizeMultiplier()) }));
    }
  }
}
