package gulliver.command;

import ad;
import cv;
import gulliver.common.GulliverEnvoy;
import java.util.List;
import jv;
import net.minecraft.server.MinecraftServer;
import z;

public class CommandInstantKarma extends z
{
  public CommandInstantKarma() {}
  
  public String c()
  {
    return "instantkarma";
  }
  



  public int a()
  {
    return 2;
  }
  

  public String c(ad par1ICommandSender)
  {
    return "commands.instantkarma.usage";
  }
  
  public void b(ad par1ICommandSender, String[] par2ArrayOfStr)
  {
    jv var4 = par2ArrayOfStr.length >= 1 ? d(par1ICommandSender, par2ArrayOfStr[0]) : b(par1ICommandSender);
    if (GulliverEnvoy.isKarmaModeEnabled())
    {
      var4.setBaseSize(GulliverEnvoy.getNewBasePlayerSize());
      if (var4 != par1ICommandSender)
      {

        a(par1ICommandSender, "commands.instantkarma.success.other", new Object[] { var4.an(), Float.valueOf(sizeBaseMultiplier) });

      }
      else
      {
        a(par1ICommandSender, "commands.instantkarma.success.self", new Object[] { Float.valueOf(sizeBaseMultiplier) });
      }
      
    }
    else
    {
      par1ICommandSender.a(cv.e("commands.instantkarma.failure.notEnabled"));
    }
  }
  


  public List a(ad par1ICommandSender, String[] par2ArrayOfStr)
  {
    return par2ArrayOfStr.length == 1 ? a(par2ArrayOfStr, getPlayers()) : null;
  }
  
  protected String[] getPlayers()
  {
    return MinecraftServer.F().C();
  }
  



  public boolean a(String[] par1ArrayOfStr, int par2)
  {
    return par2 == 0;
  }
}
