package gulliver.command;

import ad;

public class CommandServerReloadGulliver extends z
{
  public CommandServerReloadGulliver() {}
  
  public String c()
  {
    return "reloadgullivercfg";
  }
  



  public int a()
  {
    return 4;
  }
  
  public String c(ad par1ICommandSender)
  {
    return "/reloadgullivercfg";
  }
  
  public void b(ad par1ICommandSender, String[] par2ArrayOfStr)
  {
    a(par1ICommandSender, "Reloading GulliverForged configuration", new Object[0]);
    gulliver.common.GulliverEnvoy.reloadConfiguration();
  }
}
