package gulliver.command;

import abw;
import ad;
import asp;
import bd;
import cv;
import net.minecraft.server.MinecraftServer;
import nn;
import of;
import uf;
import z;

public class CommandEntityShowSize
  extends z
{
  public CommandEntityShowSize() {}
  
  public String c()
  {
    return "entityshowsize";
  }
  



  public int a()
  {
    return 2;
  }
  

  public String c(ad par1ICommandSender)
  {
    return "commands.entityshowsize.usage";
  }
  
  public void b(ad par1ICommandSender, String[] par2ArrayOfStr)
  {
    if (par2ArrayOfStr.length > 0)
    {
      int var3 = a(par1ICommandSender, par2ArrayOfStr[0], 1);
      abw wc;
      abw wc;
      if ((par1ICommandSender instanceof asp))
      {
        wc = k;
      }
      else
      {
        uf var4 = b(par1ICommandSender);
        wc = MinecraftServer.F().a(ar);
      }
      nn var5 = wc.a(var3);
      
      if (var5 == null)
      {

        par1ICommandSender.a(cv.b("commands.entityshowsize.failure.noEntity", new Object[] { Integer.valueOf(var3) }));
      }
      else if ((var5 instanceof of))
      {

        par1ICommandSender.a(cv.b("commands.entityshowsize.success.living", new Object[] { Integer.valueOf(k), Float.valueOf(sizeBaseMultiplier), Float.valueOf(var5.getSizeMultiplier()) }));

      }
      else
      {
        par1ICommandSender.a(cv.b("commands.entityshowsize.success", new Object[] { Integer.valueOf(k), Float.valueOf(var5.getSizeMultiplier()) }));
      }
      
    }
    else
    {
      throw new bd(c(par1ICommandSender), new Object[0]);
    }
  }
}
