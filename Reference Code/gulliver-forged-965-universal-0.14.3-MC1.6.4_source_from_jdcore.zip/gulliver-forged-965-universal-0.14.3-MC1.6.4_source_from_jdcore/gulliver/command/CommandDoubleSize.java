package gulliver.command;

import ad;
import jv;
import net.minecraft.server.MinecraftServer;
import z;

public class CommandDoubleSize extends z
{
  public CommandDoubleSize() {}
  
  public String c()
  {
    return "doublesize";
  }
  



  public int a()
  {
    return 2;
  }
  

  public String c(ad par1ICommandSender)
  {
    return "commands.doublesize.usage";
  }
  
  public void b(ad par1ICommandSender, String[] par2ArrayOfStr)
  {
    jv var4 = par2ArrayOfStr.length >= 1 ? d(par1ICommandSender, par2ArrayOfStr[0]) : b(par1ICommandSender);
    var4.doubleSize();
    
    if (var4 != par1ICommandSender)
    {

      a(par1ICommandSender, "commands.basesize.success.other", new Object[] { var4.an(), Float.valueOf(sizeBaseMultiplier), Float.valueOf(sizeDestMultiplier) });

    }
    else
    {
      a(par1ICommandSender, "commands.basesize.success.self", new Object[] { Float.valueOf(sizeBaseMultiplier), Float.valueOf(sizeDestMultiplier) });
    }
  }
  



  public java.util.List a(ad par1ICommandSender, String[] par2ArrayOfStr)
  {
    return par2ArrayOfStr.length == 1 ? a(par2ArrayOfStr, getPlayers()) : null;
  }
  
  protected String[] getPlayers()
  {
    return MinecraftServer.F().C();
  }
  



  public boolean a(String[] par1ArrayOfStr, int par2)
  {
    return par2 == 0;
  }
}
