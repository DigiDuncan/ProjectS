package gulliver.command;

import ad;
import az;
import bd;
import gulliver.common.GulliverEnvoy;
import java.util.List;
import jv;
import net.minecraft.server.MinecraftServer;
import z;

public class CommandBaseSizeAdjust extends z
{
  public CommandBaseSizeAdjust() {}
  
  public String c()
  {
    return "basesizeadjust";
  }
  



  public int a()
  {
    return 2;
  }
  

  public String c(ad par1ICommandSender)
  {
    return "commands.basesizeadjust.usage";
  }
  



  public static float parseFloat(ad par0ICommandSender, String par1Str)
  {
    try
    {
      return Float.parseFloat(par1Str);
    }
    catch (NumberFormatException var3)
    {
      throw new az("commands.generic.num.invalid", new Object[] { par1Str });
    }
  }
  
  public void b(ad par1ICommandSender, String[] par2ArrayOfStr)
  {
    if (par2ArrayOfStr.length > 0)
    {
      float var3 = parseFloat(par1ICommandSender, par2ArrayOfStr[0]);
      if (GulliverEnvoy.isInvalidSize(var3))
      {
        throw new az("commands.basesize.num.invalid", new Object[] { Float.valueOf(var3) });
      }
      jv var4 = par2ArrayOfStr.length >= 2 ? d(par1ICommandSender, par2ArrayOfStr[1]) : b(par1ICommandSender);
      var4.adjustBaseSize(var3);
      
      if (var4 != par1ICommandSender)
      {


        a(par1ICommandSender, "commands.basesize.success.other", new Object[] { var4.an(), Float.valueOf(sizeBaseMultiplier), Float.valueOf(var4.getNewSizeDestMultiplier()) });

      }
      else
      {

        a(par1ICommandSender, "commands.basesize.success.self", new Object[] { Float.valueOf(sizeBaseMultiplier), Float.valueOf(var4.getNewSizeDestMultiplier()) });
      }
    }
    else
    {
      throw new bd(c(par1ICommandSender), new Object[0]);
    }
  }
  



  public List a(ad par1ICommandSender, String[] par2ArrayOfStr)
  {
    return par2ArrayOfStr.length == 2 ? a(par2ArrayOfStr, getPlayers()) : null;
  }
  
  protected String[] getPlayers()
  {
    return MinecraftServer.F().C();
  }
  



  public boolean a(String[] par1ArrayOfStr, int par2)
  {
    return par2 == 1;
  }
}
