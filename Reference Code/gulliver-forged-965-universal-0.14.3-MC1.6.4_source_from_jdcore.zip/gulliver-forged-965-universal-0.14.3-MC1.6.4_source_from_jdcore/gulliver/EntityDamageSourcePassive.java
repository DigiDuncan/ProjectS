package gulliver;

import nc;
import nn;


public class EntityDamageSourcePassive
  extends nc
{
  public EntityDamageSourcePassive(String par1Str, nn par2Entity)
  {
    super(par1Str, par2Entity);
  }
  



  public boolean p()
  {
    return false;
  }
}
