import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;







public class ux
{
  private int a = 20;
  

  private float b = 5.0F;
  

  private float c;
  
  private int d;
  
  private int e = 20;
  

  public ux() {}
  
  public void a(int par1, float par2)
  {
    a = Math.min(par1 + a, 20);
    b = Math.min(b + par1 * par2 * 2.0F, a);
  }
  



  public void a(xx par1ItemFood)
  {
    a(par1ItemFood.g(), par1ItemFood.i());
  }
  




  public void addStats(xx par1ItemFood, float par2)
  {
    a((int)(par1ItemFood.g() / par2 + 0.5F), par1ItemFood.i() / (par2 * par2));
  }
  



  public void a(uf par1EntityPlayer)
  {
    int i = q.r;
    e = a;
    
    if (c > 4.0F)
    {
      c -= 4.0F;
      
      if (b > 0.0F)
      {
        b = Math.max(b - 1.0F, 0.0F);
      }
      else if (i > 0)
      {
        a = Math.max(a - 1, 0);
      }
    }
    
    if ((q.O().b("naturalRegeneration")) && (a >= 18) && (par1EntityPlayer.bJ()))
    {
      d += 1;
      
      if (d >= 80)
      {
        par1EntityPlayer.f(1.0F);
        a(3.0F);
        d = 0;
      }
    }
    else if (a <= 0)
    {
      d += 1;
      
      if (d >= 80)
      {
        if ((par1EntityPlayer.aN() > 10.0F) || (i >= 3) || ((par1EntityPlayer.aN() > 1.0F) && (i >= 2)))
        {
          par1EntityPlayer.a(nb.f, 1.0F);
        }
        
        d = 0;
      }
    }
    else
    {
      d = 0;
    }
  }
  



  public void a(by par1NBTTagCompound)
  {
    if (par1NBTTagCompound.b("foodLevel"))
    {
      a = par1NBTTagCompound.e("foodLevel");
      d = par1NBTTagCompound.e("foodTickTimer");
      b = par1NBTTagCompound.g("foodSaturationLevel");
      c = par1NBTTagCompound.g("foodExhaustionLevel");
    }
  }
  



  public void b(by par1NBTTagCompound)
  {
    par1NBTTagCompound.a("foodLevel", a);
    par1NBTTagCompound.a("foodTickTimer", d);
    par1NBTTagCompound.a("foodSaturationLevel", b);
    par1NBTTagCompound.a("foodExhaustionLevel", c);
  }
  



  public int a()
  {
    return a;
  }
  
  @SideOnly(Side.CLIENT)
  public int b()
  {
    return e;
  }
  



  public boolean c()
  {
    return a < 20;
  }
  



  public void a(float par1)
  {
    c = Math.min(c + par1, 40.0F);
  }
  



  public float e()
  {
    return b;
  }
  
  @SideOnly(Side.CLIENT)
  public void a(int par1)
  {
    a = par1;
  }
  
  @SideOnly(Side.CLIENT)
  public void b(float par1)
  {
    b = par1;
  }
}
