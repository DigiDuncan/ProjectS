import java.util.Random;




















public class sc
  extends se
{
  public float bp;
  public float bq;
  public float br;
  public float bs;
  public float bt;
  public float bu;
  public float bv;
  public float bw;
  private float bx;
  private float by;
  private float bz;
  private float bA;
  private float bB;
  private float bC;
  
  public sc(abw par1World)
  {
    super(par1World);
    a(0.95F, 0.95F);
    by = (1.0F / (ab.nextFloat() + 1.0F) * 0.2F);
  }
  
  protected void az()
  {
    super.az();
    a(tp.a).a(10.0D);
  }
  



  protected String r()
  {
    return null;
  }
  



  protected String aO()
  {
    return null;
  }
  



  protected String aP()
  {
    return null;
  }
  



  protected float ba()
  {
    return 0.4F;
  }
  



  protected int s()
  {
    return 0;
  }
  




  protected boolean e_()
  {
    return false;
  }
  




  protected void b(boolean par1, int par2)
  {
    int j = ab.nextInt(2 + par2 + (int)getSizeMultiplierRoot()) + 1;
    
    for (int k = 0; k < j; k++)
    {
      a(new ye(yc.aY, 1, 0), 0.0F);
    }
  }
  




  public boolean H()
  {
    return q.a(E.b(0.0D, -0.6000000238418579D * getSizeMultiplier(), 0.0D), akc.h, this);
  }
  



  public asx getEntityCollisionBox()
  {
    return E.c();
  }
  



  public asx getEntityHitBox()
  {
    return E.c();
  }
  




  public void c()
  {
    super.c();
    bq = bp;
    bs = br;
    bu = bt;
    bw = bv;
    bt += by;
    
    if (bt > 6.2831855F)
    {
      bt -= 6.2831855F;
      
      if (ab.nextInt(10) == 0)
      {
        by = (1.0F / (ab.nextFloat() + 1.0F) * 0.2F);
      }
    }
    
    if (H())
    {


      if (bt < 3.1415927F)
      {
        float f = bt / 3.1415927F;
        bv = (ls.a(f * f * 3.1415927F) * 3.1415927F * 0.25F);
        
        if (f > 0.75D)
        {
          bx = 1.0F;
          bz = 1.0F;
        }
        else
        {
          bz *= 0.8F;
        }
      }
      else
      {
        bv = 0.0F;
        bx *= 0.9F;
        bz *= 0.99F;
      }
      
      if (!q.I)
      {
        x = (bA * bx);
        y = (bB * bx);
        z = (bC * bx);
      }
      
      float f = ls.a(x * x + z * z);
      aN += (-(float)Math.atan2(x, z) * 180.0F / 3.1415927F - aN) * 0.1F;
      A = aN;
      br += 3.1415927F * bz * 1.5F;
      bp += (-(float)Math.atan2(f, y) * 180.0F / 3.1415927F - bp) * 0.1F;
    }
    else
    {
      bv = (ls.e(ls.a(bt)) * 3.1415927F * 0.25F);
      
      if (!q.I)
      {
        y -= 0.08D;
        y *= 0.9800000190734863D;
        
        if (F)
        {
          x = 0.0D;
          z = 0.0D;
        }
      }
      
      bp = ((float)(bp + (-90.0F - bp) * 0.02D));
    }
  }
  



  public void e(float par1, float par2)
  {
    d(x, y, z);
  }
  
  protected void bl()
  {
    aV += 1;
    
    if (aV > 100)
    {
      bA = (this.bB = this.bC = 0.0F);
    }
    else if ((ab.nextInt(50) == 0) || (!ae) || ((bA == 0.0F) && (bB == 0.0F) && (bC == 0.0F)))
    {
      float f = ab.nextFloat() * 3.1415927F * 2.0F;
      bA = (ls.b(f) * 0.2F);
      bB = (-0.1F + ab.nextFloat() * 0.2F);
      bC = (ls.a(f) * 0.2F);
    }
    
    u();
  }
  



  public boolean bs()
  {
    return (v > 45.0D) && (v < 63.0D) && (super.bs());
  }
}
