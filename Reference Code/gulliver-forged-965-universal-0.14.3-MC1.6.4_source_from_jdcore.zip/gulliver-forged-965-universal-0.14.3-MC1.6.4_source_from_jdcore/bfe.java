import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import gulliver.common.GulliverOMHelper;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.FloatBuffer;
import java.util.List;
import java.util.Random;
import net.minecraftforge.client.ForgeHooksClient;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.ContextCapabilities;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GLContext;
import org.lwjgl.util.glu.Project;





































@SideOnly(Side.CLIENT)
public class bfe
{
  private static final bjo o = new bjo("textures/environment/rain.png");
  private static final bjo p = new bjo("textures/environment/snow.png");
  
  public static boolean a;
  
  public static int b;
  
  private atv q;
  
  private float r;
  
  public bfj c;
  
  private int s;
  
  private nn t;
  
  private lz u = new lz();
  private lz v = new lz();
  

  private lz w = new lz();
  

  private lz x = new lz();
  

  private lz y = new lz();
  

  private lz z = new lz();
  private float A = 4.0F;
  

  private float B = 4.0F;
  

  private float C;
  

  private float D;
  

  private float E;
  
  private float F;
  
  private float G;
  
  private float H;
  
  private float I;
  
  private float J;
  
  private float K;
  
  private float L;
  
  private float M;
  
  private float N;
  
  private float O;
  
  private final bib P;
  
  private final int[] Q;
  
  private final bjo R;
  
  private float S;
  
  private float T;
  
  private float U;
  
  private float V;
  
  private float W;
  
  private boolean X;
  
  private double Y = 1.0D;
  
  private double Z;
  
  private double aa;
  private long ab = atv.F();
  

  private long ac;
  

  private boolean ad;
  

  float d;
  

  float e;
  

  float f;
  

  float g;
  

  private Random ae = new Random();
  

  private int af;
  

  float[] h;
  

  float[] i;
  

  FloatBuffer j = atu.h(16);
  


  float k;
  


  float l;
  

  float m;
  

  private float ag;
  

  private float ah;
  

  public int n;
  

  private boolean initialized = false;
  private abw updatedWorld = null;
  public boolean fogStandard = false;
  
  public long[] frameTimes = null;
  public long[] tickTimes = null;
  public long[] chunkTimes = null;
  public long[] serverTimes = null;
  public int numRecordedFrameTimes = 0;
  public long prevFrameTimeNano = -1L;
  

  public float getRenderReachFactor(float par1)
  {
    if ((q.i.getSizeMultiplier() < 1.0F) && (q.h.bn.h() == null))
    {
      return q.i.getSizeMultiplier();
    }
    if ((q.i.getSizeMultiplier() < 1.0F) && (q.h.holdingPointyItem()))
    {
      return (float)Math.cbrt(q.i.getSizeMultiplier());
    }
    

    return q.i.getRangeMultiplier();
  }
  


  public float getRenderHeightFactor(float par1)
  {
    return q.i.getSizeMultiplier();
  }
  


  public float getRenderPerspectiveFactor(float par1)
  {
    return q.i.getSizeMultiplier();
  }
  


  public float getRenderRangeFactor(float par1)
  {
    return q.i.getRangeMultiplier();
  }
  


  public float getRenderViewbobFactor(float par1)
  {
    return q.i.getSizeMultiplierRoot();
  }
  

  public bfe(atv par1Minecraft)
  {
    q = par1Minecraft;
    c = new bfj(par1Minecraft);
    P = new bib(16, 16);
    R = par1Minecraft.J().a("lightMap", P);
    Q = P.c();
  }
  



  public void a()
  {
    e();
    f();
    ag = ah;
    B = A;
    D = C;
    F = E;
    M = L;
    O = N;
    


    if (q.u.af)
    {
      float f = q.u.c * 0.6F + 0.2F;
      float f1 = f * f * f * 8.0F;
      I = u.a(G, 0.05F * f1);
      J = v.a(H, 0.05F * f1);
      K = 0.0F;
      G = 0.0F;
      H = 0.0F;
    }
    
    if (q.i == null)
    {
      q.i = q.h;
    }
    
    float f = q.f.q(ls.c(q.i.u), ls.c(q.i.v), ls.c(q.i.w));
    float f1 = (3 - q.u.e) / 3.0F;
    float f2 = f * (1.0F - f1) + f1;
    ah += (f2 - ah) * 0.1F;
    s += 1;
    c.a();
    g();
    W = V;
    
    if (bez.d)
    {
      V += 0.05F;
      
      if (V > 1.0F)
      {
        V = 1.0F;
      }
      
      bez.d = false;
    }
    else if (V > 0.0F)
    {
      V -= 0.0125F;
    }
  }
  



  public void a(float par1)
  {
    if ((q.i != null) && (q.f != null))
    {
      q.j = null;
      

      double rfactor = getRenderReachFactor(par1);
      double d0 = q.c.d() * rfactor;
      q.t = q.i.a(d0, par1);
      double d1 = d0;
      atc vec3 = q.i.l(par1);
      
      if (q.c.i())
      {
        d0 = 6.0D * rfactor;
        d1 = 6.0D * rfactor;
      }
      else
      {
        if (d0 > 3.0D * rfactor)
        {
          d1 = 3.0D * rfactor;
        }
        
        d0 = d1;
      }
      
      if (q.t != null)
      {
        d1 = q.t.f.d(vec3);
      }
      
      atc vec31 = q.i.j(par1);
      atc vec32 = vec3.c(c * d0, d * d0, e * d0);
      t = null;
      float f1 = 1.0F;
      List list = q.f.b(q.i, q.i.E.a(c * d0, d * d0, e * d0).b(f1, f1, f1));
      double d2 = d1;
      
      for (int i = 0; i < list.size(); i++)
      {
        nn entity = (nn)list.get(i);
        
        if (entity.L())
        {
          float f2 = entity.Z();
          asx axisalignedbb = entity.getEntityHitBox().b(f2, f2, f2);
          ata movingobjectposition = axisalignedbb.a(vec3, vec32);
          
          if (axisalignedbb.a(vec3))
          {
            if ((0.0D < d2) || (d2 == 0.0D))
            {
              t = entity;
              d2 = 0.0D;
            }
          }
          else if (movingobjectposition != null)
          {
            double d3 = vec3.d(f);
            
            if ((d3 < d2) || (d2 == 0.0D))
            {

              if ((entity == q.i.o) && (!entity.canRiderInteract()) && (q.i.aZ() != null) && (q.i.aZ().d != Fcv) && ((!q.i.isTinierThan(entity)) || ((q.i.aZ().b() instanceof xx))))
              {
                if (d2 == 0.0D)
                {
                  t = entity;
                }
              }
              else
              {
                t = entity;
                d2 = d3;
              }
            }
          }
        }
      }
      
      if ((t != null) && ((d2 < d1) || (q.t == null)))
      {
        q.t = new ata(t);
        
        if ((t instanceof of))
        {
          q.j = ((of)t);
        }
      }
    }
  }
  



  private void e()
  {
    if ((q.i instanceof bex))
    {
      bex entityplayersp = (bex)q.i;
      U = entityplayersp.t();
    }
    else
    {
      U = q.h.t();
    }
    T = S;
    S += (U - S) * 0.5F;
    
    if (S > 1.5F)
    {
      S = 1.5F;
    }
    
    if (S < 0.1F)
    {
      S = 0.1F;
    }
  }
  



  private float a(float par1, boolean par2)
  {
    if (n > 0)
    {
      return 90.0F;
    }
    

    of entityplayer = q.i;
    float f1 = 70.0F;
    
    if (par2)
    {
      f1 += q.u.aj * 40.0F;
      f1 *= (T + (S - T) * par1);
    }
    
    if (GulliverOMHelper.hasOptifine())
    {
      boolean toggle = false;
      
      if (q.n == null)
      {
        if (GulliverOMHelper.ofZoomKeyCode < 0)
        {
          toggle = Mouse.isButtonDown(GulliverOMHelper.ofZoomKeyCode + 100);
        }
        else
        {
          toggle = Keyboard.isKeyDown(GulliverOMHelper.ofZoomKeyCode);
        }
      }
      
      if (toggle)
      {
        if (!GulliverOMHelper.getOptifineZoom())
        {
          GulliverOMHelper.setOptifineZoom(true);
          q.u.af = true;
        }
        
        if (GulliverOMHelper.getOptifineZoom())
        {
          f1 /= 4.0F;
        }
      }
      else if (GulliverOMHelper.getOptifineZoom())
      {
        GulliverOMHelper.setOptifineZoom(false);
        q.u.af = false;
        u = new lz();
        v = new lz();
      }
    }
    
    if (entityplayer.aN() <= 0.0F)
    {
      float f2 = aB + par1;
      f1 /= ((1.0F - 500.0F / (f2 + 500.0F)) * 2.0F + 1.0F);
    }
    
    int i = atp.a(q.f, entityplayer, par1);
    
    if ((i != 0) && (scU == akc.h))
    {
      f1 = f1 * 60.0F / 70.0F;
    }
    
    return f1 + M + (L - M) * par1;
  }
  

  private void e(float par1)
  {
    of entitylivingbase = q.i;
    float f1 = ay - par1;
    

    if (entitylivingbase.aN() <= 0.0F)
    {
      float f2 = aB + par1;
      GL11.glRotatef(40.0F - 8000.0F / (f2 + 200.0F), 0.0F, 0.0F, 1.0F);
    }
    
    if (f1 >= 0.0F)
    {
      f1 /= az;
      f1 = ls.a(f1 * f1 * f1 * f1 * 3.1415927F);
      float f2 = aA;
      GL11.glRotatef(-f2, 0.0F, 1.0F, 0.0F);
      GL11.glRotatef(-f1 * 14.0F, 0.0F, 0.0F, 1.0F);
      GL11.glRotatef(f2, 0.0F, 1.0F, 0.0F);
    }
  }
  



  private void f(float par1)
  {
    if ((q.i instanceof uf))
    {
      uf entityplayer = (uf)q.i;
      float f1 = R - Q;
      float f2 = -(R + f1 * par1);
      float f3 = bs + (bt - bs) * par1;
      float f4 = aJ + (aK - aJ) * par1;
      GL11.glTranslatef(ls.a(f2 * 3.1415927F) * f3 * 0.5F * getRenderViewbobFactor(par1), -Math.abs(ls.b(f2 * 3.1415927F) * f3), 0.0F);
      GL11.glRotatef(ls.a(f2 * 3.1415927F) * f3 * 3.0F, 0.0F, 0.0F, 1.0F);
      GL11.glRotatef(Math.abs(ls.b(f2 * 3.1415927F - 0.2F) * f3) * 5.0F, 1.0F, 0.0F, 0.0F);
      GL11.glRotatef(f4, 1.0F, 0.0F, 0.0F);
    }
  }
  



  private void g(float par1)
  {
    of entitylivingbase = q.i;
    float hfactor = getRenderHeightFactor(par1);
    float pfactor = getRenderPerspectiveFactor(par1);
    float f1 = N - 1.62F * hfactor;
    double d0 = r + (u - r) * par1;
    double d1 = s + (v - s) * par1 - f1;
    double d2 = t + (w - t) * par1;
    GL11.glRotatef(O + (N - O) * par1, 0.0F, 0.0F, 1.0F);
    
    if (entitylivingbase.bh())
    {
      f1 = (float)(f1 + 1.0D * hfactor);
      GL11.glTranslatef(0.0F, 0.3F * hfactor, 0.0F);
      
      if (!q.u.ag)
      {
        ForgeHooksClient.orientBedCamera(q, entitylivingbase);
        GL11.glRotatef(C + (A - C) * par1 + 180.0F, 0.0F, -1.0F, 0.0F);
        GL11.glRotatef(D + (B - D) * par1, -1.0F, 0.0F, 0.0F);
      }
    }
    else if (q.u.aa > 0)
    {
      double d3 = B + (A - B) * par1;
      

      d3 *= pfactor;
      
      if (q.u.ag)
      {
        float f3 = D + (C - D) * par1;
        float f2 = F + (E - F) * par1;
        GL11.glTranslatef(0.0F, 0.0F, (float)-d3);
        GL11.glRotatef(f2, 1.0F, 0.0F, 0.0F);
        GL11.glRotatef(f3, 0.0F, 1.0F, 0.0F);
      }
      else
      {
        float f3 = A;
        float f2 = B;
        
        if (q.u.aa == 2)
        {
          f2 += 180.0F;
        }
        
        double d4 = -ls.a(f3 / 180.0F * 3.1415927F) * ls.b(f2 / 180.0F * 3.1415927F) * d3;
        double d5 = ls.b(f3 / 180.0F * 3.1415927F) * ls.b(f2 / 180.0F * 3.1415927F) * d3;
        double d6 = -ls.a(f2 / 180.0F * 3.1415927F) * d3;
        
        for (int l = 0; l < 8; l++)
        {
          float f4 = (l & 0x1) * 2 - 1;
          float f5 = (l >> 1 & 0x1) * 2 - 1;
          float f6 = (l >> 2 & 0x1) * 2 - 1;
          f4 *= 0.1F * pfactor;
          f5 *= 0.1F * pfactor;
          f6 *= 0.1F * pfactor;
          ata movingobjectposition = null;
          if (pfactor > 2.0F)
          {

            movingobjectposition = q.f.rayTraceBlocks_do_do_leaves(q.f.V().a(d0 + f4, d1 + f5, d2 + f6), q.f.V().a(d0 - d4 + f4 + f6, d1 - d6 + f5, d2 - d5 + f6), false, false, entitylivingbase.isHuge());

          }
          else
          {
            movingobjectposition = q.f.a(q.f.V().a(d0 + f4, d1 + f5, d2 + f6), q.f.V().a(d0 - d4 + f4 + f6, d1 - d6 + f5, d2 - d5 + f6), false, true);
          }
          
          if (movingobjectposition != null)
          {
            double d7 = f.d(q.f.V().a(d0, d1, d2));
            
            if (d7 < d3)
            {
              d3 = d7;
            }
          }
          
          if ((pfactor < 1.0F) && (f5 > 0.0F))
          {

            movingobjectposition = q.f.a(q.f.V().a(d0 + f4, d1 + f5, d2 + f6), q.f.V().a(d0 - d4 + f4 + f6, d1 - d6 / pfactor + f5, d2 - d5 + f6), false, true);
            
            if (movingobjectposition != null)
            {
              double d7 = f.d(q.f.V().a(d0, d1, d2));
              
              if (d7 < d3)
              {
                d3 = d7;
              }
            }
          }
        }
        
        if (q.u.aa == 2)
        {
          GL11.glRotatef(180.0F, 0.0F, 1.0F, 0.0F);
        }
        
        GL11.glRotatef(B - f2, 1.0F, 0.0F, 0.0F);
        GL11.glRotatef(A - f3, 0.0F, 1.0F, 0.0F);
        GL11.glTranslatef(0.0F, 0.0F, (float)-d3);
        GL11.glRotatef(f3 - A, 0.0F, 1.0F, 0.0F);
        GL11.glRotatef(f2 - B, 1.0F, 0.0F, 0.0F);
      }
      
    }
    else
    {
      GL11.glTranslatef(0.0F, 0.0F, 0.1F * pfactor);
    }
    
    if (!q.u.ag)
    {
      GL11.glRotatef(D + (B - D) * par1, 1.0F, 0.0F, 0.0F);
      GL11.glRotatef(C + (A - C) * par1 + 180.0F, 0.0F, 1.0F, 0.0F);
    }
    
    GL11.glTranslatef(0.0F, f1, 0.0F);
    d0 = r + (u - r) * par1;
    d1 = s + (v - s) * par1 - f1;
    d2 = t + (w - t) * par1;
    X = q.g.a(d0, d1, d2, par1);
  }
  



  private void a(float par1, int par2)
  {
    r = (256 >> q.u.e);
    
    if (GulliverOMHelper.hasOptifine())
    {
      r = GulliverOMHelper.ofRenderDistanceFine;
      
      if (GulliverOMHelper.ofFancyFog)
      {
        r *= 0.95F;
      }
      
      if (GulliverOMHelper.ofFastFog)
      {
        r *= 0.83F;
      }
    }
    
    GL11.glMatrixMode(5889);
    GL11.glLoadIdentity();
    float f1 = 0.07F;
    
    if (q.u.g)
    {
      GL11.glTranslatef(-(par2 * 2 - 1) * f1, 0.0F, 0.0F);
    }
    
    float fardist = r * 2.0F;
    
    if ((GulliverOMHelper.hasOptifine()) && (fardist < 128.0F))
    {
      fardist = 128.0F;
    }
    
    if (Y != 1.0D)
    {
      GL11.glTranslatef((float)Z, (float)-aa, 0.0F);
      GL11.glScaled(Y, Y, 1.0D);
    }
    
    Project.gluPerspective(a(par1, true), q.d / q.e, 0.05F * getRenderPerspectiveFactor(par1), fardist);
    

    if (q.c.a())
    {
      float f2 = 0.6666667F;
      GL11.glScalef(1.0F, f2, 1.0F);
    }
    
    GL11.glMatrixMode(5888);
    GL11.glLoadIdentity();
    
    if (q.u.g)
    {
      GL11.glTranslatef((par2 * 2 - 1) * 0.1F, 0.0F, 0.0F);
    }
    
    e(par1);
    
    if (q.u.f)
    {
      f(par1);
    }
    
    float f2 = q.h.bO + (q.h.bN - q.h.bO) * par1;
    
    if (f2 > 0.0F)
    {
      byte b0 = 20;
      
      if (q.h.a(ni.k))
      {
        b0 = 7;
      }
      
      float f3 = 5.0F / (f2 * f2 + 5.0F) - f2 * 0.04F;
      f3 *= f3;
      GL11.glRotatef((s + par1) * b0, 0.0F, 1.0F, 1.0F);
      GL11.glScalef(1.0F / f3, 1.0F, 1.0F);
      GL11.glRotatef(-(s + par1) * b0, 0.0F, 1.0F, 1.0F);
    }
    
    g(par1);
    
    if (n > 0)
    {
      int j = n - 1;
      
      if (j == 1)
      {
        GL11.glRotatef(90.0F, 0.0F, 1.0F, 0.0F);
      }
      
      if (j == 2)
      {
        GL11.glRotatef(180.0F, 0.0F, 1.0F, 0.0F);
      }
      
      if (j == 3)
      {
        GL11.glRotatef(-90.0F, 0.0F, 1.0F, 0.0F);
      }
      
      if (j == 4)
      {
        GL11.glRotatef(90.0F, 1.0F, 0.0F, 0.0F);
      }
      
      if (j == 5)
      {
        GL11.glRotatef(-90.0F, 1.0F, 0.0F, 0.0F);
      }
    }
  }
  



  private void b(float par1, int par2)
  {
    if (n <= 0)
    {
      GL11.glMatrixMode(5889);
      GL11.glLoadIdentity();
      float f1 = 0.07F;
      
      if (q.u.g)
      {
        GL11.glTranslatef(-(par2 * 2 - 1) * f1, 0.0F, 0.0F);
      }
      
      if (Y != 1.0D)
      {
        GL11.glTranslatef((float)Z, (float)-aa, 0.0F);
        GL11.glScaled(Y, Y, 1.0D);
      }
      
      Project.gluPerspective(a(par1, false), q.d / q.e, 0.05F * (q.i.getSizeMultiplier() >= 1.0F ? 1.0F : getRenderPerspectiveFactor(par1)), r * 2.0F);
      
      if (q.c.a())
      {
        float f2 = 0.6666667F;
        GL11.glScalef(1.0F, f2, 1.0F);
      }
      
      GL11.glMatrixMode(5888);
      GL11.glLoadIdentity();
      
      if (q.u.g)
      {
        GL11.glTranslatef((par2 * 2 - 1) * 0.1F, 0.0F, 0.0F);
      }
      
      GL11.glPushMatrix();
      e(par1);
      
      if (q.u.f)
      {
        f(par1);
      }
      
      if ((q.u.aa == 0) && (!q.i.bh()) && (!q.u.Z) && (!q.c.a()))
      {
        b(par1);
        c.a(par1);
        a(par1);
      }
      
      GL11.glPopMatrix();
      
      if ((q.u.aa == 0) && (!q.i.bh()))
      {
        c.b(par1);
        e(par1);
      }
      
      if (q.u.f)
      {
        f(par1);
      }
    }
  }
  



  public void a(double par1)
  {
    bma.a(bma.b);
    GL11.glDisable(3553);
    bma.a(bma.a);
  }
  



  public void b(double par1)
  {
    bma.a(bma.b);
    GL11.glMatrixMode(5890);
    GL11.glLoadIdentity();
    float f = 0.00390625F;
    GL11.glScalef(f, f, f);
    GL11.glTranslatef(8.0F, 8.0F, 8.0F);
    GL11.glMatrixMode(5888);
    q.J().a(R);
    GL11.glTexParameteri(3553, 10241, 9729);
    GL11.glTexParameteri(3553, 10240, 9729);
    if (!GulliverOMHelper.hasOptifine())
    {
      GL11.glTexParameteri(3553, 10241, 9729);
      GL11.glTexParameteri(3553, 10240, 9729);
    }
    GL11.glTexParameteri(3553, 10242, 10496);
    GL11.glTexParameteri(3553, 10243, 10496);
    GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
    GL11.glEnable(3553);
    bma.a(bma.a);
  }
  



  private void f()
  {
    e = ((float)(e + (Math.random() - Math.random()) * Math.random() * Math.random()));
    g = ((float)(g + (Math.random() - Math.random()) * Math.random() * Math.random()));
    e = ((float)(e * 0.9D));
    g = ((float)(g * 0.9D));
    d += (e - d) * 1.0F;
    f += (g - f) * 1.0F;
    ad = true;
  }
  
  private void h(float par1)
  {
    bdd worldclient = q.f;
    
    if (worldclient != null)
    {
      if ((GulliverOMHelper.hasOptifine()) && (GulliverOMHelper.updateOptifineCustomLightmap(worldclient, d, Q, q.h.a(ni.r))))
      {
        P.a();
        ad = false;
        return;
      }
      
      for (int i = 0; i < 256; i++)
      {
        float f1 = worldclient.b(1.0F) * 0.95F + 0.05F;
        float f2 = t.h[(i / 16)] * f1;
        float f3 = t.h[(i % 16)] * (d * 0.1F + 1.5F);
        
        if (q > 0)
        {
          f2 = t.h[(i / 16)];
        }
        
        float f4 = f2 * (worldclient.b(1.0F) * 0.65F + 0.35F);
        float f5 = f2 * (worldclient.b(1.0F) * 0.65F + 0.35F);
        float f6 = f3 * ((f3 * 0.6F + 0.4F) * 0.6F + 0.4F);
        float f7 = f3 * (f3 * f3 * 0.6F + 0.4F);
        float f8 = f4 + f3;
        float f9 = f5 + f6;
        float f10 = f2 + f7;
        f8 = f8 * 0.96F + 0.03F;
        f9 = f9 * 0.96F + 0.03F;
        f10 = f10 * 0.96F + 0.03F;
        

        if (V > 0.0F)
        {
          float f11 = W + (V - W) * par1;
          f8 = f8 * (1.0F - f11) + f8 * 0.7F * f11;
          f9 = f9 * (1.0F - f11) + f9 * 0.6F * f11;
          f10 = f10 * (1.0F - f11) + f10 * 0.6F * f11;
        }
        
        if (t.i == 1)
        {
          f8 = 0.22F + f3 * 0.75F;
          f9 = 0.28F + f6 * 0.75F;
          f10 = 0.25F + f7 * 0.75F;
        }
        


        if (q.h.a(ni.r))
        {
          float f11 = a(q.h, par1);
          float f12 = 1.0F / f8;
          
          if (f12 > 1.0F / f9)
          {
            f12 = 1.0F / f9;
          }
          
          if (f12 > 1.0F / f10)
          {
            f12 = 1.0F / f10;
          }
          
          f8 = f8 * (1.0F - f11) + f8 * f12 * f11;
          f9 = f9 * (1.0F - f11) + f9 * f12 * f11;
          f10 = f10 * (1.0F - f11) + f10 * f12 * f11;
        }
        
        if (f8 > 1.0F)
        {
          f8 = 1.0F;
        }
        
        if (f9 > 1.0F)
        {
          f9 = 1.0F;
        }
        
        if (f10 > 1.0F)
        {
          f10 = 1.0F;
        }
        
        float f11 = q.u.ak;
        float f12 = 1.0F - f8;
        float f13 = 1.0F - f9;
        float f14 = 1.0F - f10;
        f12 = 1.0F - f12 * f12 * f12 * f12;
        f13 = 1.0F - f13 * f13 * f13 * f13;
        f14 = 1.0F - f14 * f14 * f14 * f14;
        f8 = f8 * (1.0F - f11) + f12 * f11;
        f9 = f9 * (1.0F - f11) + f13 * f11;
        f10 = f10 * (1.0F - f11) + f14 * f11;
        f8 = f8 * 0.96F + 0.03F;
        f9 = f9 * 0.96F + 0.03F;
        f10 = f10 * 0.96F + 0.03F;
        
        if (f8 > 1.0F)
        {
          f8 = 1.0F;
        }
        
        if (f9 > 1.0F)
        {
          f9 = 1.0F;
        }
        
        if (f10 > 1.0F)
        {
          f10 = 1.0F;
        }
        
        if (f8 < 0.0F)
        {
          f8 = 0.0F;
        }
        
        if (f9 < 0.0F)
        {
          f9 = 0.0F;
        }
        
        if (f10 < 0.0F)
        {
          f10 = 0.0F;
        }
        
        short short1 = 255;
        int j = (int)(f8 * 255.0F);
        int k = (int)(f9 * 255.0F);
        int l = (int)(f10 * 255.0F);
        Q[i] = (short1 << 24 | j << 16 | k << 8 | l);
      }
      
      P.a();
      ad = false;
    }
  }
  



  private float a(uf par1EntityPlayer, float par2)
  {
    int i = par1EntityPlayer.b(ni.r).b();
    return i > 200 ? 1.0F : 0.7F + ls.a((i - par2) * 3.1415927F * 0.2F) * 0.3F;
  }
  




  public void b(float par1)
  {
    if (GulliverOMHelper.hasOptifine())
    {
      GulliverOMHelper.checkOptifineSettings();
    }
    
    q.C.a("lightTex");
    
    if (GulliverOMHelper.hasOptifine())
    {
      if (!initialized)
      {
        GulliverOMHelper.optifineRegisterTextureUtilsListener();
        initialized = true;
      }
      
      GulliverOMHelper.optifineCheckDisplayMode();
      
      if (updatedWorld != q.f)
      {
        GulliverOMHelper.updateOptifineWorldStuff(updatedWorld, q.f);
        updatedWorld = q.f;
      }
      
      bfr.b = (GulliverOMHelper.ofFancyGrass) || (GulliverOMHelper.ofFancyBetterGrass);
      aqz.P.a(GulliverOMHelper.ofFancyTrees);
    }
    
    if (ad)
    {
      h(par1);
    }
    
    q.C.b();
    boolean flag = Display.isActive();
    
    if ((!flag) && (q.u.y) && ((!q.u.A) || (!Mouse.isButtonDown(1))))
    {
      if (atv.F() - ab > 500L)
      {
        q.i();
      }
      
    }
    else {
      ab = atv.F();
    }
    
    q.C.a("mouse");
    
    if ((q.A) && (flag))
    {
      q.w.c();
      float f1 = q.u.c * 0.6F + 0.2F;
      float f2 = f1 * f1 * f1 * 8.0F;
      float f3 = q.w.a * f2;
      float f4 = q.w.b * f2;
      byte b0 = 1;
      
      if (q.u.d)
      {
        b0 = -1;
      }
      
      if (q.u.af)
      {
        G += f3;
        H += f4;
        float f5 = par1 - K;
        K = par1;
        f3 = I * f5;
        f4 = J * f5;
        q.h.c(f3, f4 * b0);
      }
      else
      {
        q.h.c(f3, f4 * b0);
      }
    }
    
    q.C.b();
    
    if (!q.s)
    {
      a = q.u.g;
      awf scaledresolution = new awf(q.u, q.d, q.e);
      int i = scaledresolution.a();
      int j = scaledresolution.b();
      int k = Mouse.getX() * i / q.d;
      int l = j - Mouse.getY() * j / q.e - 1;
      int i1 = a(q.u.i);
      
      if (q.f != null)
      {
        q.C.a("level");
        
        if (q.u.i == 0)
        {
          a(par1, 0L);
        }
        else
        {
          a(par1, ac + 1000000000 / i1);
        }
        
        ac = System.nanoTime();
        q.C.c("gui");
        
        if ((!q.u.Z) || (q.n != null))
        {
          q.r.a(par1, q.n != null, k, l);
        }
        
        q.C.b();
      }
      else
      {
        GL11.glViewport(0, 0, q.d, q.e);
        GL11.glMatrixMode(5889);
        GL11.glLoadIdentity();
        GL11.glMatrixMode(5888);
        GL11.glLoadIdentity();
        c();
        ac = System.nanoTime();
      }
      
      if (q.n != null)
      {
        GL11.glClear(256);
        
        try
        {
          q.n.a(k, l, par1);
        }
        catch (Throwable throwable)
        {
          b crashreport = b.a(throwable, "Rendering screen");
          m crashreportcategory = crashreport.a("Screen render details");
          crashreportcategory.a("Screen name", new bff(this));
          crashreportcategory.a("Mouse location", new bfg(this, k, l));
          crashreportcategory.a("Screen size", new bfh(this, scaledresolution));
          throw new u(crashreport);
        }
      }
    }
  }
  
  private int renderSorted(float par1)
  {
    try {
      return ((Integer)bfl.class.getMethod("renderAllSortedRenderers", new Class[] { Integer.TYPE, Double.TYPE }).invoke(q.g, new Object[] { Integer.valueOf(1), Double.valueOf(par1) })).intValue();
    }
    catch (NoSuchMethodException e)
    {
      e.printStackTrace();
    }
    catch (InvocationTargetException e)
    {
      e.printStackTrace();
    }
    catch (IllegalAccessException e)
    {
      e.printStackTrace();
    }
    return 0;
  }
  
  public void a(float par1, long par2)
  {
    q.C.a("lightTex");
    
    if (ad)
    {
      h(par1);
    }
    
    GL11.glEnable(2884);
    GL11.glEnable(2929);
    
    if (q.i == null)
    {
      q.i = q.h;
    }
    
    q.C.c("pick");
    a(par1);
    of entitylivingbase = q.i;
    bfl renderglobal = q.g;
    beh effectrenderer = q.k;
    double d0 = U + (u - U) * par1;
    double d1 = V + (v - V) * par1;
    double d2 = W + (w - W) * par1;
    q.C.c("center");
    
    for (int j = 0; j < 2; j++)
    {
      if (q.u.g)
      {
        b = j;
        
        if (b == 0)
        {
          GL11.glColorMask(false, true, true, false);
        }
        else
        {
          GL11.glColorMask(true, false, false, false);
        }
      }
      
      q.C.c("clear");
      GL11.glViewport(0, 0, q.d, q.e);
      i(par1);
      GL11.glClear(16640);
      GL11.glEnable(2884);
      q.C.c("camera");
      a(par1, j);
      atp.a(q.h, q.u.aa == 2);
      q.C.c("frustrum");
      bfu.a();
      
      if (GulliverOMHelper.hasOptifine() ? (GulliverOMHelper.ofSkyEnabled) || (GulliverOMHelper.ofPlanetsEnabled) || (GulliverOMHelper.ofStarsEnabled) : q.u.e < 2)
      {
        a(-1, par1);
        q.C.c("sky");
        renderglobal.a(par1);
      }
      else if (GulliverOMHelper.hasOptifine())
      {
        GL11.glDisable(3042);
      }
      
      GL11.glEnable(2912);
      a(1, par1);
      
      if (q.u.k != 0)
      {
        GL11.glShadeModel(7425);
      }
      
      q.C.c("culling");
      bfv frustrum = new bfv();
      frustrum.a(d0, d1, d2);
      q.g.a(frustrum, par1);
      
      if (j == 0)
      {
        q.C.c("updatechunks");
        
        while ((!q.g.a(entitylivingbase, false)) && (par2 != 0L))
        {
          long k = par2 - System.nanoTime();
          
          if ((k < 0L) || (k > 1000000000L)) {
            break;
          }
        }
      }
      

      if (v < 128.0D)
      {
        a(renderglobal, par1);
      }
      
      q.C.c("prepareterrain");
      a(0, par1);
      GL11.glEnable(2912);
      q.J().a(bik.b);
      att.a();
      q.C.c("terrain");
      renderglobal.a(entitylivingbase, 0, par1);
      GL11.glShadeModel(7424);
      

      if (n == 0)
      {
        att.b();
        q.C.c("entities");
        ForgeHooksClient.setRenderPass(0);
        renderglobal.a(entitylivingbase.l(par1), frustrum, par1);
        ForgeHooksClient.setRenderPass(0);
        if (GulliverOMHelper.hasOptifine())
        {

          att.a();
        }
        










        if ((q.t != null) && (entitylivingbase.a(akc.h)) && ((entitylivingbase instanceof uf)) && (!q.u.Z))
        {
          uf entityplayer = (uf)entitylivingbase;
          GL11.glDisable(3008);
          q.C.c("outline");
          if (!ForgeHooksClient.onDrawBlockHighlight(renderglobal, entityplayer, q.t, 0, bn.h(), par1))
          {
            renderglobal.a(entityplayer, q.t, 0, par1);
          }
          GL11.glEnable(3008);
        }
      }
      
      GL11.glDisable(3042);
      GL11.glEnable(2884);
      GL11.glBlendFunc(770, 771);
      GL11.glDepthMask(true);
      a(0, par1);
      GL11.glEnable(3042);
      GL11.glDisable(2884);
      q.J().a(bik.b);
      if (GulliverOMHelper.hasOptifine())
      {
        GulliverOMHelper.resumeOptifineBackgroundUpdates();
      }
      
      if (GulliverOMHelper.hasOptifine() ? GulliverOMHelper.ofFancyWater : q.u.j)
      {
        q.C.c("water");
        
        if (q.u.k != 0)
        {
          GL11.glShadeModel(7425);
        }
        
        GL11.glColorMask(false, false, false, false);
        int l = GulliverOMHelper.hasOptifine() ? renderSorted(par1) : renderglobal.a(entitylivingbase, 1, par1);
        
        if (q.u.g)
        {
          if (b == 0)
          {
            GL11.glColorMask(false, true, true, true);
          }
          else
          {
            GL11.glColorMask(true, false, false, true);
          }
          
        }
        else {
          GL11.glColorMask(true, true, true, true);
        }
        
        if (l > 0)
        {
          if (GulliverOMHelper.hasOptifine())
          {
            renderSorted(par1);
          }
          else
          {
            renderglobal.a(1, par1);
          }
        }
        
        GL11.glShadeModel(7424);
      }
      else
      {
        q.C.c("water");
        if (GulliverOMHelper.hasOptifine())
        {
          renderSorted(par1);
        }
        else
        {
          renderglobal.a(entitylivingbase, 1, par1);
        }
      }
      
      if (GulliverOMHelper.hasOptifine())
      {
        GulliverOMHelper.pauseOptifineBackgroundUpdates();
      }
      
      if (n == 0)
      {
        att.b();
        q.C.c("entities");
        ForgeHooksClient.setRenderPass(1);
        renderglobal.a(entitylivingbase.l(par1), frustrum, par1);
        ForgeHooksClient.setRenderPass(-1);
        att.a();
      }
      
      GL11.glDepthMask(true);
      GL11.glEnable(2884);
      GL11.glDisable(3042);
      
      if ((Y == 1.0D) && ((entitylivingbase instanceof uf)) && (!q.u.Z) && (q.t != null) && (!entitylivingbase.a(akc.h)))
      {
        uf entityplayer = (uf)entitylivingbase;
        GL11.glDisable(3008);
        q.C.c("outline");
        if (!ForgeHooksClient.onDrawBlockHighlight(renderglobal, entityplayer, q.t, 0, bn.h(), par1))
        {
          renderglobal.a(entityplayer, q.t, 0, par1);
        }
        GL11.glEnable(3008);
      }
      
      q.C.c("destroyProgress");
      GL11.glEnable(3042);
      GL11.glBlendFunc(770, 1);
      renderglobal.drawBlockDamageTexture(bfq.a, entitylivingbase, par1);
      GL11.glDisable(3042);
      q.C.c("weather");
      d(par1);
      GL11.glDisable(2912);
      
      if (v >= 128.0D)
      {
        a(renderglobal, par1);
      }
      

      b(par1);
      q.C.c("litParticles");
      effectrenderer.b(entitylivingbase, par1);
      att.a();
      a(0, par1);
      q.C.c("particles");
      effectrenderer.a(entitylivingbase, par1);
      a(par1);
      

      q.C.c("FRenderLast");
      ForgeHooksClient.dispatchRenderLast(renderglobal, par1);
      q.C.c("hand");
      
      if (Y == 1.0D)
      {
        GL11.glClear(256);
        b(par1, j);
      }
      
      if (!q.u.g)
      {
        q.C.b();
        return;
      }
    }
    
    GL11.glColorMask(true, true, true, false);
    q.C.b();
  }
  



  private void a(bfl par1RenderGlobal, float par2)
  {
    if (q.u.d())
    {
      q.C.c("clouds");
      GL11.glPushMatrix();
      a(0, par2);
      GL11.glEnable(2912);
      par1RenderGlobal.b(par2);
      GL11.glDisable(2912);
      a(1, par2);
      GL11.glPopMatrix();
    }
  }
  
  private void g()
  {
    float f = q.f.i(1.0F);
    
    if (GulliverOMHelper.hasOptifine() ? !GulliverOMHelper.ofRainFancy : !q.u.j)
    {
      f /= 2.0F;
    }
    
    if (GulliverOMHelper.hasOptifine() ? !GulliverOMHelper.ofRainSplash : f != 0.0F)
    {
      ae.setSeed(s * 312987231L);
      of entitylivingbase = q.i;
      bdd worldclient = q.f;
      int i = ls.c(u);
      int j = ls.c(v);
      int k = ls.c(w);
      byte b0 = 10;
      double d0 = 0.0D;
      double d1 = 0.0D;
      double d2 = 0.0D;
      int l = 0;
      int i1 = (int)(100.0F * f * f);
      
      if (q.u.am == 1)
      {
        i1 >>= 1;
      }
      else if (q.u.am == 2)
      {
        i1 = 0;
      }
      
      for (int j1 = 0; j1 < i1; j1++)
      {
        int k1 = i + ae.nextInt(b0) - ae.nextInt(b0);
        int l1 = k + ae.nextInt(b0) - ae.nextInt(b0);
        int i2 = worldclient.h(k1, l1);
        int j2 = worldclient.a(k1, i2 - 1, l1);
        acq biomegenbase = worldclient.a(k1, l1);
        
        if ((i2 <= j + b0) && (i2 >= j - b0) && (biomegenbase.d()) && (biomegenbase.j() >= 0.2F))
        {
          float f1 = ae.nextFloat();
          float f2 = ae.nextFloat();
          
          if (j2 > 0)
          {
            if (scU == akc.i)
            {
              q.k.a(new bel(worldclient, k1 + f1, i2 + 0.1F - aqz.s[j2].w(), l1 + f2, 0.0D, 0.0D, 0.0D));
            }
            else
            {
              l++;
              
              if (ae.nextInt(l) == 0)
              {
                d0 = k1 + f1;
                d1 = i2 + 0.1F - aqz.s[j2].w();
                d2 = l1 + f2;
              }
              
              bet rainFX = new bet(worldclient, k1 + f1, i2 + 0.1F - aqz.s[j2].w(), l1 + f2);
              if (GulliverOMHelper.hasOptifine())
              {
                GulliverOMHelper.updateOptifineCustomWaterFX(rainFX, worldclient);
              }
              q.k.a(rainFX);
            }
          }
        }
      }
      
      if ((l > 0) && (ae.nextInt(3) < af++))
      {
        af = 0;
        
        if ((d1 > v + 1.0D) && (worldclient.h(ls.c(u), ls.c(w)) > ls.c(v)))
        {
          q.f.a(d0, d1, d2, "ambient.weather.rain", 0.1F, 0.5F, false);
        }
        else
        {
          q.f.a(d0, d1, d2, "ambient.weather.rain", 0.2F, 1.0F, false);
        }
      }
    }
  }
  



  protected void d(float par1)
  {
    float f1 = q.f.i(par1);
    
    if (f1 > 0.0F)
    {
      b(par1);
      
      if (h == null)
      {
        h = new float['Ѐ'];
        this.i = new float['Ѐ'];
        
        for (int i = 0; i < 32; i++)
        {
          for (int j = 0; j < 32; j++)
          {
            float f2 = j - 16;
            float f3 = i - 16;
            float f4 = ls.c(f2 * f2 + f3 * f3);
            h[(i << 5 | j)] = (-f3 / f4);
            this.i[(i << 5 | j)] = (f2 / f4);
          }
        }
      }
      
      if ((GulliverOMHelper.hasOptifine()) && (GulliverOMHelper.ofRainOff))
      {
        return;
      }
      
      of entitylivingbase = q.i;
      bdd worldclient = q.f;
      int k = ls.c(u);
      int l = ls.c(v);
      int i1 = ls.c(w);
      bfq tessellator = bfq.a;
      GL11.glDisable(2884);
      GL11.glNormal3f(0.0F, 1.0F, 0.0F);
      GL11.glEnable(3042);
      GL11.glBlendFunc(770, 771);
      GL11.glAlphaFunc(516, 0.01F);
      q.J().a(p);
      double d0 = U + (u - U) * par1;
      double d1 = V + (v - V) * par1;
      double d2 = W + (w - W) * par1;
      int j1 = ls.c(d1);
      int b0 = 5;
      
      if (GulliverOMHelper.hasOptifine() ? GulliverOMHelper.ofRainFancy : q.u.j)
      {
        b0 = 10;
      }
      
      boolean flag = false;
      byte b1 = -1;
      float f5 = s + par1;
      
      if (GulliverOMHelper.hasOptifine() ? GulliverOMHelper.ofRainFancy : q.u.j)
      {
        b0 = 10;
      }
      
      float rfactor = getRenderRangeFactor(par1);
      int range = 1;
      
      if (rfactor > 1.0F)
      {
        b0 = ls.d(b0 * rfactor + 0.5F);
        range = ls.d(rfactor);
        
        if (b0 / range > 15)
        {
          b0 = 15 * range;
        }
      }
      
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
      flag = false;
      
      for (int k1 = i1 - b0; k1 <= i1 + b0; k1++)
      {
        for (int l1 = k - b0; l1 <= k + b0; l1++)
        {
          int var22 = ((k1 - i1) / range + 16) * 32 + (l1 - k) / range + 16;
          float f6 = h[var22] * 0.5F;
          float f7 = this.i[var22] * 0.5F;
          acq biomegenbase = worldclient.a(l1, k1);
          
          if ((biomegenbase.d()) || (biomegenbase.c()))
          {
            int j2 = worldclient.h(l1, k1);
            int k2 = l - b0;
            int l2 = l + b0;
            
            if (k2 < j2)
            {
              k2 = j2;
            }
            
            if (l2 < j2)
            {
              l2 = j2;
            }
            
            float f8 = 1.0F;
            int i3 = j2;
            
            if (j2 < j1)
            {
              i3 = j1;
            }
            
            if (k2 != l2)
            {
              ae.setSeed(l1 * l1 * 3121 + l1 * 45238971 ^ k1 * k1 * 418711 + k1 * 13761);
              float f9 = biomegenbase.j();
              


              if (worldclient.u().a(f9, j2) >= 0.15F)
              {
                if (b1 != 0)
                {
                  if (b1 >= 0)
                  {
                    tessellator.a();
                  }
                  
                  b1 = 0;
                  q.J().a(o);
                  tessellator.b();
                }
                
                float f10 = ((s + l1 * l1 * 3121 + l1 * 45238971 + k1 * k1 * 418711 + k1 * 13761 & 0x1F) + par1) / 32.0F * (3.0F + ae.nextFloat());
                double d4 = l1 + 0.5F - u;
                double d3 = k1 + 0.5F - w;
                float f11 = ls.a(d4 * d4 + d3 * d3) / b0;
                float f12 = 1.0F;
                tessellator.c(worldclient.h(l1, i3, k1, 0));
                tessellator.a(f12, f12, f12, ((1.0F - f11 * f11) * 0.5F + 0.5F) * f1);
                tessellator.b(-d0 * 1.0D, -d1 * 1.0D, -d2 * 1.0D);
                tessellator.a(l1 - f6 + 0.5D, k2, k1 - f7 + 0.5D, 0.0F * f8, k2 * f8 / 4.0F + f10 * f8);
                tessellator.a(l1 + f6 + 0.5D, k2, k1 + f7 + 0.5D, 1.0F * f8, k2 * f8 / 4.0F + f10 * f8);
                tessellator.a(l1 + f6 + 0.5D, l2, k1 + f7 + 0.5D, 1.0F * f8, l2 * f8 / 4.0F + f10 * f8);
                tessellator.a(l1 - f6 + 0.5D, l2, k1 - f7 + 0.5D, 0.0F * f8, l2 * f8 / 4.0F + f10 * f8);
                tessellator.b(0.0D, 0.0D, 0.0D);
              }
              else
              {
                if (b1 != 1)
                {
                  if (b1 >= 0)
                  {
                    tessellator.a();
                  }
                  
                  b1 = 1;
                  q.J().a(new bjo("textures/environment/snow.png"));
                  tessellator.b();
                }
                
                float f10 = ((s & 0x1FF) + par1) / 512.0F;
                float f13 = ae.nextFloat() + f5 * 0.01F * (float)ae.nextGaussian();
                float f14 = ae.nextFloat() + f5 * (float)ae.nextGaussian() * 0.001F;
                double d3 = l1 + 0.5F - u;
                double d5 = k1 + 0.5F - w;
                float f15 = ls.a(d3 * d3 + d5 * d5) / b0;
                float f16 = 1.0F;
                tessellator.c((worldclient.h(l1, i3, k1, 0) * 3 + 15728880) / 4);
                tessellator.a(f16, f16, f16, ((1.0F - f15 * f15) * 0.3F + 0.5F) * f1);
                tessellator.b(-d0 * 1.0D, -d1 * 1.0D, -d2 * 1.0D);
                tessellator.a(l1 - f6 + 0.5D, k2, k1 - f7 + 0.5D, 0.0F * f8 + f13, k2 * f8 / 4.0F + f10 * f8 + f14);
                tessellator.a(l1 + f6 + 0.5D, k2, k1 + f7 + 0.5D, 1.0F * f8 + f13, k2 * f8 / 4.0F + f10 * f8 + f14);
                tessellator.a(l1 + f6 + 0.5D, l2, k1 + f7 + 0.5D, 1.0F * f8 + f13, l2 * f8 / 4.0F + f10 * f8 + f14);
                tessellator.a(l1 - f6 + 0.5D, l2, k1 - f7 + 0.5D, 0.0F * f8 + f13, l2 * f8 / 4.0F + f10 * f8 + f14);
                tessellator.b(0.0D, 0.0D, 0.0D);
              }
            }
          }
        }
      }
      
      if (b1 >= 0)
      {
        tessellator.a();
      }
      
      GL11.glEnable(2884);
      GL11.glDisable(3042);
      GL11.glAlphaFunc(516, 0.1F);
      a(par1);
    }
  }
  



  public void c()
  {
    awf scaledresolution = new awf(q.u, q.d, q.e);
    GL11.glClear(256);
    GL11.glMatrixMode(5889);
    GL11.glLoadIdentity();
    GL11.glOrtho(0.0D, scaledresolution.c(), scaledresolution.d(), 0.0D, 1000.0D, 3000.0D);
    GL11.glMatrixMode(5888);
    GL11.glLoadIdentity();
    GL11.glTranslatef(0.0F, 0.0F, -2000.0F);
  }
  



  private void i(float par1)
  {
    bdd worldclient = q.f;
    of entitylivingbase = q.i;
    float f1 = 1.0F / (4 - q.u.e);
    f1 = 1.0F - (float)Math.pow(f1, 0.25D);
    atc vec3 = worldclient.a(q.i, par1);
    
    if (GulliverOMHelper.hasOptifine())
    {
      switch (t.i)
      {
      case 0: 
        vec3 = GulliverOMHelper.getOptifineCustomPosColor("getSkyColor", vec3, q.f, q.i.u, q.i.v + 1.0D, q.i.w);
        break;
      
      case 1: 
        vec3 = GulliverOMHelper.getOptifineCustomColor("getSkyColorEnd", vec3);
      }
      
    }
    float f2 = (float)c;
    float f3 = (float)d;
    float f4 = (float)e;
    atc vec31 = worldclient.f(par1);
    
    if (GulliverOMHelper.hasOptifine())
    {
      switch (t.i)
      {
      case -1: 
        vec31 = GulliverOMHelper.getOptifineCustomColor("getFogColorNether", vec31);
        break;
      
      case 0: 
        vec31 = GulliverOMHelper.getOptifineCustomPosColor("getFogColor", vec31, q.f, q.i.u, q.i.v + 1.0D, q.i.w);
        break;
      
      case 1: 
        vec31 = GulliverOMHelper.getOptifineCustomColor("getFogColorEnd", vec31);
      }
      
    }
    k = ((float)c);
    l = ((float)d);
    m = ((float)e);
    

    if (q.u.e < 2)
    {
      atc vec32 = ls.a(worldclient.d(par1)) > 0.0F ? worldclient.V().a(-1.0D, 0.0D, 0.0D) : worldclient.V().a(1.0D, 0.0D, 0.0D);
      float f5 = (float)entitylivingbase.j(par1).b(vec32);
      
      if (f5 < 0.0F)
      {
        f5 = 0.0F;
      }
      
      if (f5 > 0.0F)
      {
        float[] afloat = t.a(worldclient.c(par1), par1);
        
        if (afloat != null)
        {
          f5 *= afloat[3];
          k = (k * (1.0F - f5) + afloat[0] * f5);
          l = (l * (1.0F - f5) + afloat[1] * f5);
          m = (m * (1.0F - f5) + afloat[2] * f5);
        }
      }
    }
    
    k += (f2 - k) * f1;
    l += (f3 - l) * f1;
    m += (f4 - m) * f1;
    float f6 = worldclient.i(par1);
    

    if (f6 > 0.0F)
    {
      float f5 = 1.0F - f6 * 0.5F;
      float f7 = 1.0F - f6 * 0.4F;
      k *= f5;
      l *= f5;
      m *= f7;
    }
    
    float f5 = worldclient.h(par1);
    
    if (f5 > 0.0F)
    {
      float f7 = 1.0F - f5 * 0.5F;
      k *= f7;
      l *= f7;
      m *= f7;
    }
    
    int i = atp.a(q.f, entitylivingbase, par1);
    


    if (X)
    {
      atc vec33 = worldclient.e(par1);
      k = ((float)c);
      l = ((float)d);
      m = ((float)e);
    }
    else if ((i != 0) && (scU == akc.h))
    {
      float f8 = aaw.b(entitylivingbase) * 0.2F;
      k = (0.02F + f8);
      l = (0.02F + f8);
      m = (0.2F + f8);
      if (GulliverOMHelper.hasOptifine())
      {
        atc vec33 = GulliverOMHelper.getOptifineCustomUnderwaterColor(q.f, q.i.u, q.i.v + 1.0D, q.i.w);
        
        if (vec33 != null)
        {
          k = ((float)c);
          l = ((float)d);
          m = ((float)e);
        }
      }
    }
    else if ((i != 0) && (scU == akc.i))
    {
      k = 0.6F;
      l = 0.1F;
      m = 0.0F;
    }
    
    float f8 = ag + (ah - ag) * par1;
    k *= f8;
    l *= f8;
    m *= f8;
    double vfogy = t.k();
    if ((GulliverOMHelper.hasOptifine()) && (!GulliverOMHelper.ofDepthFog))
    {
      vfogy = 1.0D;
    }
    double d0 = (V + (v - V) * par1) * vfogy;
    
    if (entitylivingbase.a(ni.q))
    {
      int j = entitylivingbase.b(ni.q).b();
      
      if (j < 20)
      {
        d0 *= (1.0F - j / 20.0F);
      }
      else
      {
        d0 = 0.0D;
      }
    }
    
    if (d0 < 1.0D)
    {
      if (d0 < 0.0D)
      {
        d0 = 0.0D;
      }
      
      d0 *= d0;
      k = ((float)(k * d0));
      l = ((float)(l * d0));
      m = ((float)(m * d0));
    }
    


    if (V > 0.0F)
    {
      float f9 = W + (V - W) * par1;
      k = (k * (1.0F - f9) + k * 0.7F * f9);
      l = (l * (1.0F - f9) + l * 0.6F * f9);
      m = (m * (1.0F - f9) + m * 0.6F * f9);
    }
    


    if (entitylivingbase.a(ni.r))
    {
      float f9 = a(q.h, par1);
      float f10 = 1.0F / k;
      
      if (f10 > 1.0F / l)
      {
        f10 = 1.0F / l;
      }
      
      if (f10 > 1.0F / m)
      {
        f10 = 1.0F / m;
      }
      
      k = (k * (1.0F - f9) + k * f10 * f9);
      l = (l * (1.0F - f9) + l * f10 * f9);
      m = (m * (1.0F - f9) + m * f10 * f9);
    }
    
    if (q.u.g)
    {
      float f9 = (k * 30.0F + l * 59.0F + m * 11.0F) / 100.0F;
      float f10 = (k * 30.0F + l * 70.0F) / 100.0F;
      float f11 = (k * 30.0F + m * 70.0F) / 100.0F;
      k = f9;
      l = f10;
      m = f11;
    }
    
    GL11.glClearColor(k, l, m, 0.0F);
  }
  




  private void a(int par1, float par2)
  {
    of entitylivingbase = q.i;
    boolean flag = false;
    fogStandard = false;
    
    if ((entitylivingbase instanceof uf))
    {
      flag = bG.d;
    }
    
    if (par1 == 999)
    {
      GL11.glFog(2918, a(0.0F, 0.0F, 0.0F, 1.0F));
      GL11.glFogi(2917, 9729);
      GL11.glFogf(2915, 0.0F);
      GL11.glFogf(2916, 8.0F);
      
      if (getCapabilitiesGL_NV_fog_distance)
      {
        GL11.glFogi(34138, 34139);
      }
      
      GL11.glFogf(2915, 0.0F);
    }
    else
    {
      GL11.glFog(2918, a(this.k, l, m, 1.0F));
      GL11.glNormal3f(0.0F, -1.0F, 0.0F);
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
      int j = atp.a(q.f, entitylivingbase, par2);
      

      if (entitylivingbase.a(ni.q))
      {
        float f1 = 5.0F;
        int k = entitylivingbase.b(ni.q).b();
        
        if (k < 20)
        {
          f1 = 5.0F + (r - 5.0F) * (1.0F - k / 20.0F);
        }
        
        GL11.glFogi(2917, 9729);
        
        if (par1 < 0)
        {
          GL11.glFogf(2915, 0.0F);
          GL11.glFogf(2916, f1 * 0.8F);
        }
        else
        {
          GL11.glFogf(2915, f1 * 0.25F);
          GL11.glFogf(2916, f1);
        }
        
        if (GulliverOMHelper.hasOptifine() ? GulliverOMHelper.ofFancyFog : getCapabilitiesGL_NV_fog_distance)
        {
          GL11.glFogi(34138, 34139);
        }
      }
      else if (X)
      {
        GL11.glFogi(2917, 2048);
        GL11.glFogf(2914, 0.1F);
      }
      else if ((j > 0) && (scU == akc.h))
      {
        GL11.glFogi(2917, 2048);
        
        if (entitylivingbase.a(ni.o))
        {
          GL11.glFogf(2914, 0.05F);
        }
        else
        {
          GL11.glFogf(2914, 0.1F - aaw.b(entitylivingbase) * 0.03F);
        }
        
        if ((GulliverOMHelper.hasOptifine()) && (GulliverOMHelper.ofClearWater))
        {
          GL11.glFogf(2914, 0.02F);
        }
      }
      else if ((j > 0) && (scU == akc.i))
      {
        GL11.glFogi(2917, 2048);
        GL11.glFogf(2914, 2.0F);
      }
      else
      {
        float f1 = r;
        fogStandard = true;
        
        if ((q.f.t.j()) && (!flag) && ((!GulliverOMHelper.hasOptifine()) || (GulliverOMHelper.ofDepthFog)))
        {
          double d0 = ((entitylivingbase.c(par2) & 0xF00000) >> 20) / 16.0D + (V + (v - V) * par2 + 4.0D) / 32.0D;
          
          if (d0 < 1.0D)
          {
            if (d0 < 0.0D)
            {
              d0 = 0.0D;
            }
            
            d0 *= d0;
            float f2 = 100.0F * (float)d0;
            
            if (f2 < 5.0F)
            {
              f2 = 5.0F;
            }
            
            if (f1 > f2)
            {
              f1 = f2;
            }
          }
        }
        
        GL11.glFogi(2917, 9729);
        
        if ((GulliverOMHelper.hasOptifine()) && (getCapabilitiesGL_NV_fog_distance))
        {
          if (GulliverOMHelper.ofFancyFog)
          {
            GL11.glFogi(34138, 34139);
          }
          
          if (GulliverOMHelper.ofFastFog)
          {
            GL11.glFogi(34138, 34140);
          }
        }
        
        float fogval = GulliverOMHelper.hasOptifine() ? GulliverOMHelper.ofFogStart : 0.25F;
        float var13 = 1.0F;
        
        if (par1 < 0)
        {
          fogval = 0.0F;
          var13 = 0.8F;
        }
        
        if (!GulliverOMHelper.hasOptifine())
        {
          GL11.glFogf(2915, f1 * fogval);
          GL11.glFogf(2916, f1 * var13);
          
          if (getCapabilitiesGL_NV_fog_distance)
          {
            GL11.glFogi(34138, 34139);
          }
        }
        
        if (q.f.t.b((int)u, (int)w))
        {
          fogval = 0.05F;
          
          if (GulliverOMHelper.hasOptifine())
          {
            var13 = 1.0F;
            f1 = r;
          }
          else
          {
            var13 = 0.5F;
            f1 = Math.min(f1, 192.0F);
          }
          
          GL11.glFogf(2915, f1 * fogval);
          GL11.glFogf(2916, f1 * var13);
        }
        else if (GulliverOMHelper.hasOptifine())
        {
          GL11.glFogf(2915, f1 * fogval);
          GL11.glFogf(2916, f1 * var13);
        }
      }
      
      GL11.glEnable(2903);
      GL11.glColorMaterial(1028, 4608);
    }
  }
  



  private FloatBuffer a(float par1, float par2, float par3, float par4)
  {
    j.clear();
    j.put(par1).put(par2).put(par3).put(par4);
    j.flip();
    return j;
  }
  



  public static int a(int par0)
  {
    short short1 = 200;
    
    if (par0 == 1)
    {
      short1 = 120;
    }
    
    if (par0 == 2)
    {
      short1 = 35;
    }
    
    return short1;
  }
  



  static atv a(bfe par0EntityRenderer)
  {
    return q;
  }
}
