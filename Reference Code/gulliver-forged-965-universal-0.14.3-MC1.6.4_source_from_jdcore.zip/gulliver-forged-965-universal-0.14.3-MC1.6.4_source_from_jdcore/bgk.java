import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.Random;
import org.lwjgl.opengl.GL11;














@SideOnly(Side.CLIENT)
public class bgk
  extends bhe
{
  private static final bjo a = new bjo("textures/entity/enderman/enderman_eyes.png");
  private static final bjo f = new bjo("textures/entity/enderman/enderman.png");
  
  private bbh g;
  
  private Random h = new Random();
  
  public bgk()
  {
    super(new bbh(), 0.5F);
    g = ((bbh)i);
    a(g);
  }
  



  public void a(tg par1EntityEnderman, double par2, double par4, double par6, float par8, float par9)
  {
    g.a = (par1EntityEnderman.bV() > 0);
    g.b = par1EntityEnderman.bX();
    
    if (par1EntityEnderman.bX())
    {
      double d3 = 0.02D;
      par2 += h.nextGaussian() * d3;
      par6 += h.nextGaussian() * d3;
    }
    
    super.a(par1EntityEnderman, par2, par4, par6, par8, par9);
  }
  
  protected bjo a(tg par1EntityEnderman)
  {
    return f;
  }
  



  protected void a(tg par1EntityEnderman, float par2)
  {
    super.c(par1EntityEnderman, par2);
    
    if (par1EntityEnderman.bV() > 0)
    {
      GL11.glEnable(32826);
      GL11.glPushMatrix();
      float f1 = 0.5F / par1EntityEnderman.getSizeMultiplierRoot();
      GL11.glTranslatef(0.0F, 0.6875F, -0.75F);
      f1 *= 1.0F;
      GL11.glRotatef(20.0F, 1.0F, 0.0F, 0.0F);
      GL11.glRotatef(45.0F, 0.0F, 1.0F, 0.0F);
      GL11.glScalef(-f1, -f1, f1);
      int i = par1EntityEnderman.c(par2);
      int j = i % 65536;
      int k = i / 65536;
      bma.a(bma.b, j / 1.0F, k / 1.0F);
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
      a(bik.b);
      c.a(aqz.s[par1EntityEnderman.bV()], par1EntityEnderman.bW(), 1.0F);
      GL11.glPopMatrix();
      GL11.glDisable(32826);
    }
  }
  



  protected int a(tg par1EntityEnderman, int par2, float par3)
  {
    if (par2 != 0)
    {
      return -1;
    }
    

    a(a);
    float f1 = 1.0F;
    GL11.glEnable(3042);
    GL11.glDisable(3008);
    GL11.glBlendFunc(1, 1);
    GL11.glDisable(2896);
    
    if (par1EntityEnderman.aj())
    {
      GL11.glDepthMask(false);
    }
    else
    {
      GL11.glDepthMask(true);
    }
    
    char c0 = 61680;
    int j = c0 % 65536;
    int k = c0 / 65536;
    bma.a(bma.b, j / 1.0F, k / 1.0F);
    GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
    GL11.glEnable(2896);
    GL11.glColor4f(1.0F, 1.0F, 1.0F, f1);
    return 1;
  }
  

  public void a(og par1EntityLiving, double par2, double par4, double par6, float par8, float par9)
  {
    a((tg)par1EntityLiving, par2, par4, par6, par8, par9);
  }
  



  protected int a(of par1EntityLivingBase, int par2, float par3)
  {
    return a((tg)par1EntityLivingBase, par2, par3);
  }
  
  protected void c(of par1EntityLivingBase, float par2)
  {
    a((tg)par1EntityLivingBase, par2);
  }
  
  public void a(of par1EntityLivingBase, double par2, double par4, double par6, float par8, float par9)
  {
    a((tg)par1EntityLivingBase, par2, par4, par6, par8, par9);
  }
  



  protected bjo a(nn par1Entity)
  {
    return a((tg)par1Entity);
  }
  






  public void a(nn par1Entity, double par2, double par4, double par6, float par8, float par9)
  {
    a((tg)par1Entity, par2, par4, par6, par8, par9);
  }
}
