import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import java.util.Random;












public abstract class uj
  extends nn
{
  private int e = -1;
  private int f = -1;
  private int g = -1;
  private int h;
  private boolean i;
  public of a;
  private int j;
  private int au;
  public double b;
  public double c;
  public double d;
  
  public uj(abw par1World)
  {
    super(par1World);
    a(1.0F, 1.0F);
  }
  



  protected void a() {}
  


  @SideOnly(Side.CLIENT)
  public boolean a(double par1)
  {
    double d1 = E.b() * 4.0D;
    d1 *= 64.0D;
    return par1 < d1 * d1;
  }
  
  public uj(abw par1World, double par2, double par4, double par6, double par8, double par10, double par12)
  {
    super(par1World);
    a(1.0F, 1.0F);
    b(par2, par4, par6, A, B);
    b(par2, par4, par6);
    double d6 = ls.a(par8 * par8 + par10 * par10 + par12 * par12);
    b = (par8 / d6 * 0.1D);
    c = (par10 / d6 * 0.1D);
    d = (par12 / d6 * 0.1D);
  }
  
  public uj(abw par1World, of par2EntityLivingBase, double par3, double par5, double par7)
  {
    super(par1World);
    setSizeMultiplier(par2EntityLivingBase.getSizeMultiplierRoot());
    a = par2EntityLivingBase;
    a(1.0F, 1.0F);
    b(u, v, w, A, B);
    b(u, v, w);
    N = 0.0F;
    x = (this.y = this.z = 0.0D);
    par3 += ab.nextGaussian() * 0.4D;
    par5 += ab.nextGaussian() * 0.4D;
    par7 += ab.nextGaussian() * 0.4D;
    double d3 = ls.a(par3 * par3 + par5 * par5 + par7 * par7);
    b = (par3 / d3 * 0.1D);
    c = (par5 / d3 * 0.1D);
    d = (par7 / d3 * 0.1D);
  }
  
  public boolean isResizable()
  {
    return true;
  }
  



  public void a(float par1, float par2)
  {
    super.a(par1 * getSizeMultiplier(), par2 * getSizeMultiplier());
  }
  



  public void l_()
  {
    if ((!q.I) && (((a != null) && (a.M)) || (!q.f((int)u, (int)v, (int)w))))
    {
      x();
    }
    else
    {
      super.l_();
      d(1);
      
      if (this.i)
      {
        int i = q.a(e, this.f, g);
        
        if (i == h)
        {
          this.j += 1;
          
          if (this.j == 600)
          {
            x();
          }
          
          return;
        }
        
        this.i = false;
        x *= ab.nextFloat() * 0.2F;
        y *= ab.nextFloat() * 0.2F;
        z *= ab.nextFloat() * 0.2F;
        this.j = 0;
        au = 0;
      }
      else
      {
        au += 1;
      }
      
      atc vec3 = q.V().a(u, v, w);
      atc vec31 = q.V().a(u + x, v + y, w + z);
      ata movingobjectposition = q.a(vec3, vec31);
      vec3 = q.V().a(u, v, w);
      vec31 = q.V().a(u + x, v + y, w + z);
      
      if (movingobjectposition != null)
      {
        vec31 = q.V().a(f.c, f.d, f.e);
      }
      
      nn entity = null;
      List list = q.b(this, E.a(x, y, z).b(1.0D, 1.0D, 1.0D));
      double d0 = 0.0D;
      
      for (int j = 0; j < list.size(); j++)
      {
        nn entity1 = (nn)list.get(j);
        
        if ((entity1.L()) && ((!entity1.h(a)) || (au >= 25)))
        {
          float f = 0.3F * getSizeMultiplierRoot();
          asx axisalignedbb = E.b(f, f, f);
          ata movingobjectposition1 = axisalignedbb.a(vec3, vec31);
          
          if (movingobjectposition1 != null)
          {
            double d1 = vec3.d(f);
            
            if ((d1 < d0) || (d0 == 0.0D))
            {
              entity = entity1;
              d0 = d1;
            }
          }
        }
      }
      
      if (entity != null)
      {
        movingobjectposition = new ata(entity);
      }
      
      if (movingobjectposition != null)
      {
        a(movingobjectposition);
      }
      
      u += x;
      v += y;
      w += z;
      float f1 = ls.a(x * x + z * z);
      A = ((float)(Math.atan2(z, x) * 180.0D / 3.141592653589793D) + 90.0F);
      
      for (B = ((float)(Math.atan2(f1, y) * 180.0D / 3.141592653589793D) - 90.0F); B - D < -180.0F; D -= 360.0F) {}
      



      while (B - D >= 180.0F)
      {
        D += 360.0F;
      }
      
      while (A - C < -180.0F)
      {
        C -= 360.0F;
      }
      
      while (A - C >= 180.0F)
      {
        C += 360.0F;
      }
      
      B = (D + (B - D) * 0.2F);
      A = (C + (A - C) * 0.2F);
      float f2 = c();
      
      if (H())
      {
        for (int k = 0; k < 4; k++)
        {
          float f3 = 0.25F;
          q.a("bubble", u - x * f3, v - y * f3, w - z * f3, x, y, z);
        }
        
        f2 = 0.8F;
      }
      
      x += b;
      y += c;
      z += d;
      x *= f2;
      y *= f2;
      z *= f2;
      q.a("smoke", u, v + 0.5D, w, 0.0D, 0.0D, 0.0D);
      b(u, v, w);
    }
  }
  



  protected float c()
  {
    return 0.95F;
  }
  



  protected abstract void a(ata paramAta);
  



  public void b(by par1NBTTagCompound)
  {
    par1NBTTagCompound.a("xTile", (short)e);
    par1NBTTagCompound.a("yTile", (short)f);
    par1NBTTagCompound.a("zTile", (short)g);
    par1NBTTagCompound.a("inTile", (byte)h);
    par1NBTTagCompound.a("inGround", (byte)(i ? 1 : 0));
    par1NBTTagCompound.a("direction", a(new double[] { x, y, z }));
  }
  



  public void a(by par1NBTTagCompound)
  {
    e = par1NBTTagCompound.d("xTile");
    f = par1NBTTagCompound.d("yTile");
    g = par1NBTTagCompound.d("zTile");
    h = (par1NBTTagCompound.c("inTile") & 0xFF);
    i = (par1NBTTagCompound.c("inGround") == 1);
    
    if (par1NBTTagCompound.b("direction"))
    {
      cg nbttaglist = par1NBTTagCompound.m("direction");
      x = b0a;
      y = b1a;
      z = b2a;
    }
    else
    {
      x();
    }
  }
  



  public boolean L()
  {
    return true;
  }
  
  public float Z()
  {
    return 1.0F * getSizeMultiplierRoot();
  }
  



  public boolean a(nb par1DamageSource, float par2)
  {
    if (ar())
    {
      return false;
    }
    

    K();
    
    if (par1DamageSource.i() != null)
    {
      atc vec3 = par1DamageSource.i().aa();
      
      if (vec3 != null)
      {
        x = c;
        y = d;
        z = e;
        b = (x * 0.1D);
        c = (y * 0.1D);
        d = (z * 0.1D);
      }
      
      if ((par1DamageSource.i() instanceof of))
      {
        a = ((of)par1DamageSource.i());
      }
      
      return true;
    }
    

    return false;
  }
  


  @SideOnly(Side.CLIENT)
  public float S()
  {
    return 0.0F;
  }
  



  public float d(float par1)
  {
    return 1.0F;
  }
  
  @SideOnly(Side.CLIENT)
  public int c(float par1)
  {
    return 15728880;
  }
}
