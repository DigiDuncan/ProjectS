import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.Random;










public class td
  extends tm
{
  private float bp = 0.5F;
  
  private int bq;
  
  private int br;
  
  public td(abw par1World)
  {
    super(par1World);
    ag = true;
    b = 10;
  }
  
  protected void az()
  {
    super.az();
    a(tp.e).a(6.0D);
  }
  
  protected void a()
  {
    super.a();
    ah.a(16, new Byte((byte)0));
  }
  



  protected String r()
  {
    return "mob.blaze.breathe";
  }
  



  protected String aO()
  {
    return "mob.blaze.hit";
  }
  



  protected String aP()
  {
    return "mob.blaze.death";
  }
  
  @SideOnly(Side.CLIENT)
  public int c(float par1)
  {
    return 15728880;
  }
  



  public float d(float par1)
  {
    return 1.0F;
  }
  




  public void c()
  {
    if (!q.I)
    {
      if (G())
      {
        a(nb.e, 1.0F);
      }
      
      bq -= 1;
      
      if (bq <= 0)
      {
        bq = 100;
        bp = (0.5F + (float)ab.nextGaussian() * 3.0F);
      }
      
      if ((bN() != null) && (bNv + bN().f() > v + f() + bp))
      {
        y += (0.30000001192092896D - y) * 0.30000001192092896D;
      }
    }
    
    if (ab.nextInt(24) == 0)
    {
      q.a(u + 0.5D, v + 0.5D, w + 0.5D, "fire.fire", 1.0F + ab.nextFloat(), ab.nextFloat() * 0.7F + 0.3F);
    }
    
    if ((!F) && (y < 0.0D))
    {
      y *= 0.6D;
    }
    
    if (!isHuge())
    {
      if (!isTiny())
      {
        for (int i = 0; i < 2; i++)
        {
          q.a("largesmoke", u + (ab.nextDouble() - 0.5D) * O, v + ab.nextDouble() * P, w + (ab.nextDouble() - 0.5D) * O, 0.0D, 0.0D, 0.0D);
        }
        
      }
      else {
        q.a("smoke", u + (ab.nextDouble() - 0.5D) * O, v + ab.nextDouble() * P, w + (ab.nextDouble() - 0.5D) * O, 0.0D, 0.0D, 0.0D);
      }
    }
    else
    {
      int num = ls.d(getSizeMultiplier());
      
      for (int i = 0; i < 2; i++)
      {
        q.a("largesmoke", u + (ab.nextDouble() - 0.5D) * O, v + ab.nextDouble() * P, w + (ab.nextDouble() - 0.5D) * O, 0.0D, 0.0D, 0.0D);
      }
    }
    
    super.c();
  }
  



  protected void a(nn par1Entity, float par2)
  {
    if ((aC <= 0) && (par2 < 2.0F) && (E.e > E.b) && (E.b < E.e))
    {
      aC = 20;
      m(par1Entity);
    }
    else if (par2 < 30.0F)
    {
      double d0 = u - u;
      double d1 = E.b + P / 2.0F - (v + P / 2.0F);
      double d2 = w - w;
      
      if (aC == 0)
      {
        br += 1;
        
        if (br == 1)
        {
          aC = 60;
          a(true);
        }
        else if (br <= 4)
        {
          aC = 6;
        }
        else
        {
          aC = 100;
          br = 0;
          a(false);
        }
        
        if (br > 1)
        {
          float f1 = ls.c(par2) * 0.5F;
          q.a((uf)null, 1009, (int)u, (int)v, (int)w, 0);
          
          for (int i = 0; i < 1; i++)
          {
            uo entitysmallfireball = new uo(q, this, d0 + ab.nextGaussian() * f1, d1, d2 + ab.nextGaussian() * f1);
            v = (v + P / 2.0F + 0.5D * getSizeMultiplier());
            q.d(entitysmallfireball);
          }
        }
      }
      
      A = ((float)(Math.atan2(d2, d0) * 180.0D / 3.141592653589793D) - 90.0F);
      bn = true;
    }
  }
  



  protected void b(float par1) {}
  



  protected int s()
  {
    return bqcv;
  }
  



  public boolean af()
  {
    return bT();
  }
  




  protected void b(boolean par1, int par2)
  {
    if (par1)
    {
      dropItemSizedAmount(par2 + 1, bqcv, 0, 0);
    }
  }
  
  public boolean bT()
  {
    return (ah.a(16) & 0x1) != 0;
  }
  
  public void a(boolean par1)
  {
    byte b0 = ah.a(16);
    
    if (par1)
    {
      b0 = (byte)(b0 | 0x1);
    }
    else
    {
      b0 = (byte)(b0 & 0xFFFFFFFE);
    }
    
    ah.b(16, Byte.valueOf(b0));
  }
  



  protected boolean i_()
  {
    return true;
  }
}
