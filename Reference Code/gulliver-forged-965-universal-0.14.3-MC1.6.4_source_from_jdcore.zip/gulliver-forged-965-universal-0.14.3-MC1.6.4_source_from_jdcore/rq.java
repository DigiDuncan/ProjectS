import java.util.Random;
















public class rq
  extends rp
{
  public float bp;
  public float bq;
  public float br;
  public float bs;
  public float bt = 1.0F;
  
  public int bu;
  

  public rq(abw par1World)
  {
    super(par1World);
    a(0.3F, 0.7F);
    minLookSize = 0.1F;
    bu = (ab.nextInt(6000) + 6000);
    c.a(0, new pp(this));
    c.a(1, new qj(this, 1.4D));
    c.a(2, new pk(this, 1.0D));
    c.a(3, new qu(this, 1.0D, Ucv, false));
    c.a(4, new pr(this, 1.1D));
    c.a(5, new qm(this, 1.0D));
    c.a(6, new px(this, uf.class, 6.0F));
    c.a(7, new ql(this));
  }
  



  public boolean bf()
  {
    return true;
  }
  
  protected void az()
  {
    super.az();
    a(tp.a).a(4.0D);
    a(tp.d).a(0.25D);
  }
  



  public double Y()
  {
    if (!g_())
    {
      return P * 0.7D;
    }
    

    return P * 0.4D;
  }
  





  public void c()
  {
    super.c();
    bs = bp;
    br = bq;
    bq = ((float)(bq + (F ? -1 : 4) * 0.3D));
    
    if (bq < 0.0F)
    {
      bq = 0.0F;
    }
    
    if (bq > 1.0F)
    {
      bq = 1.0F;
    }
    
    if ((!F) && (bt < 1.0F))
    {
      bt = 1.0F;
    }
    
    bt = ((float)(bt * 0.9D));
    
    if ((!F) && (y < 0.0D))
    {
      y *= 0.6D;
    }
    
    bp += bt * 2.0F;
    
    if ((!g_()) && (!q.I) && (--bu <= 0))
    {
      a("mob.chicken.plop", 1.0F, (ab.nextFloat() - ab.nextFloat()) * 0.2F + 1.0F);
      b(aRcv, 1);
      bu = (ab.nextInt(6000) + 6000);
    }
  }
  



  protected void b(float par1) {}
  



  protected String r()
  {
    return "mob.chicken.say";
  }
  



  protected String aO()
  {
    return "mob.chicken.hurt";
  }
  



  protected String aP()
  {
    return "mob.chicken.hurt";
  }
  



  protected void a(int par1, int par2, int par3, int par4)
  {
    a("mob.chicken.step", 0.15F, 1.0F);
  }
  



  protected int s()
  {
    return Ncv;
  }
  




  protected void b(boolean par1, int par2)
  {
    int id = s();
    dropItemSizedAmount(par2, id, 0, 3);
    id = (af()) && (getCookedMeatItemId() > 0) ? getCookedMeatItemId() : getMeatItemId();
    dropItemSizedAmount(par2, id, 1, isHuge() ? 1 : 0);
  }
  



  protected int getMeatItemId()
  {
    return bmcv;
  }
  



  protected int getCookedMeatItemId()
  {
    return bncv;
  }
  



  public rq b(nk par1EntityAgeable)
  {
    return new rq(q);
  }
  




  public boolean c(ye par1ItemStack)
  {
    return (par1ItemStack != null) && ((par1ItemStack.b() instanceof yw));
  }
  
  public nk a(nk par1EntityAgeable)
  {
    return b(par1EntityAgeable);
  }
}
