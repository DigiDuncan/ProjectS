import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Set;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.EventBus;
import net.minecraftforge.event.world.WorldEvent.Load;






























@SideOnly(Side.CLIENT)
public class bdd
  extends abw
{
  private bcw a;
  private bdb b;
  private lm c = new lm();
  

  private Set J = new HashSet();
  




  private Set K = new HashSet();
  private final atv L = atv.w();
  private final Set M = new HashSet();
  
  public bdd(bcw par1NetClientHandler, acd par2WorldSettings, int par3, int par4, lv par5Profiler, lp par6ILogAgent)
  {
    super(new amp(), "MpServer", aei.a(par3), par2WorldSettings, par5Profiler, par6ILogAgent);
    a = par1NetClientHandler;
    r = par4;
    z = b;
    I = true;
    finishSetup();
    E(8, 64, 8);
    MinecraftForge.EVENT_BUS.post(new WorldEvent.Load(this));
  }
  



  public void b()
  {
    super.b();
    a(I() + 1L);
    
    if (O().b("doDaylightCycle"))
    {
      b(J() + 1L);
    }
    
    C.a("reEntryProcessing");
    
    for (int i = 0; (i < 10) && (!K.isEmpty()); i++)
    {
      nn entity = (nn)K.iterator().next();
      K.remove(entity);
      
      if (!e.contains(entity))
      {
        d(entity);
      }
    }
    
    C.c("connection");
    a.e();
    C.c("chunkCache");
    b.c();
    C.c("tiles");
    g();
    C.b();
  }
  




  public void c(int par1, int par2, int par3, int par4, int par5, int par6) {}
  



  protected ado j()
  {
    b = new bdb(this);
    return b;
  }
  




  protected void g()
  {
    super.g();
    M.retainAll(G);
    
    if (M.size() == G.size())
    {
      M.clear();
    }
    
    int i = 0;
    Iterator iterator = G.iterator();
    
    while (iterator.hasNext())
    {
      abp chunkcoordintpair = (abp)iterator.next();
      
      if (!M.contains(chunkcoordintpair))
      {
        int j = a * 16;
        int k = b * 16;
        C.a("getChunk");
        adr chunk = e(a, b);
        a(j, k, chunk);
        C.b();
        M.add(chunkcoordintpair);
        i++;
        
        if (i >= 10)
        {
          return;
        }
      }
    }
  }
  
  public void a(int par1, int par2, boolean par3)
  {
    if (par3)
    {
      b.c(par1, par2);
    }
    else
    {
      b.b(par1, par2);
    }
    
    if (!par3)
    {
      g(par1 * 16, 0, par2 * 16, par1 * 16 + 15, 256, par2 * 16 + 15);
    }
  }
  



  public boolean d(nn par1Entity)
  {
    boolean flag = super.d(par1Entity);
    J.add(par1Entity);
    
    if (!flag)
    {
      K.add(par1Entity);
    }
    
    return flag;
  }
  



  public void e(nn par1Entity)
  {
    super.e(par1Entity);
    J.remove(par1Entity);
  }
  
  protected void a(nn par1Entity)
  {
    super.a(par1Entity);
    
    if (K.contains(par1Entity))
    {
      K.remove(par1Entity);
    }
  }
  
  public void b(nn par1Entity)
  {
    super.b(par1Entity);
    
    if (J.contains(par1Entity))
    {
      if (par1Entity.T())
      {
        K.add(par1Entity);
      }
      else
      {
        J.remove(par1Entity);
      }
    }
  }
  



  public void a(int par1, nn par2Entity)
  {
    nn entity1 = a(par1);
    
    if (entity1 != null)
    {
      e(entity1);
    }
    
    J.add(par2Entity);
    k = par1;
    
    if (!d(par2Entity))
    {
      K.add(par2Entity);
    }
    
    c.a(par1, par2Entity);
  }
  



  public nn a(int par1)
  {
    return par1 == L.h.k ? L.h : (nn)c.a(par1);
  }
  
  public nn b(int par1)
  {
    nn entity = (nn)c.d(par1);
    
    if (entity != null)
    {
      J.remove(entity);
      e(entity);
    }
    
    return entity;
  }
  
  public boolean g(int par1, int par2, int par3, int par4, int par5)
  {
    c(par1, par2, par3, par1, par2, par3);
    return super.f(par1, par2, par3, par4, par5, 3);
  }
  



  public void F()
  {
    a.b(new eb("Quitting"));
  }
  
  public hr a(st par1EntityMinecart)
  {
    return new bll(L.v, par1EntityMinecart, L.h);
  }
  



  protected void o()
  {
    super.o();
  }
  

  public void updateWeatherBody()
  {
    if (!t.g)
    {
      m = n;
      
      if (x.p())
      {
        n = ((float)(n + 0.01D));
      }
      else
      {
        n = ((float)(n - 0.01D));
      }
      
      if (n < 0.0F)
      {
        n = 0.0F;
      }
      
      if (n > 1.0F)
      {
        n = 1.0F;
      }
      
      o = p;
      
      if (x.n())
      {
        p = ((float)(p + 0.01D));
      }
      else
      {
        p = ((float)(p - 0.01D));
      }
      
      if (p < 0.0F)
      {
        p = 0.0F;
      }
      
      if (p > 1.0F)
      {
        p = 1.0F;
      }
    }
  }
  
  public void J(int par1, int par2, int par3)
  {
    byte b0 = 16;
    Random random = new Random();
    
    for (int l = 0; l < 1000; l++)
    {
      int i1 = par1 + s.nextInt(b0) - s.nextInt(b0);
      int j1 = par2 + s.nextInt(b0) - s.nextInt(b0);
      int k1 = par3 + s.nextInt(b0) - s.nextInt(b0);
      int l1 = a(i1, j1, k1);
      
      if ((l1 == 0) && (s.nextInt(8) > j1) && (t.j()))
      {
        a("depthsuspend", i1 + s.nextFloat(), j1 + s.nextFloat(), k1 + s.nextFloat(), 0.0D, 0.0D, 0.0D);
      }
      else if (l1 > 0)
      {
        aqz.s[l1].b(this, i1, j1, k1, random);
      }
    }
  }
  



  public void a()
  {
    e.removeAll(f);
    




    for (int i = 0; i < f.size(); i++)
    {
      nn entity = (nn)f.get(i);
      int j = aj;
      int k = al;
      
      if ((ai) && (c(j, k)))
      {
        e(j, k).b(entity);
      }
    }
    
    for (i = 0; i < f.size(); i++)
    {
      b((nn)f.get(i));
    }
    
    f.clear();
    
    for (i = 0; i < e.size(); i++)
    {
      nn entity = (nn)e.get(i);
      
      if (o != null)
      {
        if ((o.M) || (o.n != entity))
        {



          o.n = null;
          o = null;
        }
      }
      else if (M)
      {
        int j = aj;
        int k = al;
        
        if ((ai) && (c(j, k)))
        {
          e(j, k).b(entity);
        }
        
        e.remove(i--);
        b(entity);
      }
    }
  }
  



  public m a(b par1CrashReport)
  {
    m crashreportcategory = super.a(par1CrashReport);
    crashreportcategory.a("Forced entities", new bde(this));
    crashreportcategory.a("Retry entities", new bdf(this));
    crashreportcategory.a("Server brand", new bdg(this));
    crashreportcategory.a("Server type", new bdh(this));
    return crashreportcategory;
  }
  




  public void a(double par1, double par3, double par5, String par7Str, float par8, float par9, boolean par10)
  {
    float listensize = L.i.getSizeMultiplierRoot();
    float f2 = 16.0F * listensize;
    par9 *= (0.8F + 0.2F * listensize);
    par8 *= (0.8F + 0.2F / listensize);
    
    if (par8 > 1.0F)
    {
      f2 *= par8;
    }
    
    double d3 = L.i.e(par1, par3, par5);
    
    if (d3 < f2 * f2)
    {
      if ((par10) && (d3 > 100.0D))
      {
        double d4 = Math.sqrt(d3) / 40.0D;
        L.v.a(par7Str, (float)par1, (float)par3, (float)par5, par8, par9, (int)Math.round(d4 * 20.0D));
      }
      else
      {
        L.v.a(par7Str, (float)par1, (float)par3, (float)par5, par8, par9);
      }
    }
  }
  
  public void a(double par1, double par3, double par5, double par7, double par9, double par11, by par13NBTTagCompound)
  {
    L.k.a(new bdy(this, par1, par3, par5, par7, par9, par11, L.k, par13NBTTagCompound));
  }
  
  public void a(atj par1Scoreboard)
  {
    D = par1Scoreboard;
  }
  



  public void b(long par1)
  {
    if (par1 < 0L)
    {
      par1 = -par1;
      O().b("doDaylightCycle", "false");
    }
    else
    {
      O().b("doDaylightCycle", "true");
    }
    
    super.b(par1);
  }
  
  static Set a(bdd par0WorldClient)
  {
    return J;
  }
  
  static Set b(bdd par0WorldClient)
  {
    return K;
  }
  
  static atv c(bdd par0WorldClient)
  {
    return L;
  }
}
