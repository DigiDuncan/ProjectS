import java.util.Random;




public abstract class se
  extends on
  implements nl
{
  public se(abw par1World)
  {
    super(par1World);
  }
  
  public boolean aA()
  {
    return true;
  }
  



  public boolean bs()
  {
    return q.b(E);
  }
  



  public int o()
  {
    return 120;
  }
  



  protected boolean t()
  {
    return true;
  }
  




  protected int e(uf par1EntityPlayer)
  {
    return 1 + q.s.nextInt((int)(2.0F * getSizeMultiplier()) + 1);
  }
  



  public void y()
  {
    int i = al();
    super.y();
    
    if ((T()) && (!H()))
    {
      i--;
      g(i);
      
      if (al() == -20)
      {
        g(0);
        a(nb.e, 2.0F);
      }
    }
    else
    {
      g(300);
    }
  }
}
