



















public class qn
  extends ps
{
  private final og a;
  private final to b;
  private of c;
  private int d;
  private double e;
  private int f;
  private int g;
  private int h;
  private float i;
  private float j;
  
  public qn(to par1IRangedAttackMob, double par2, int par4, float par5)
  {
    this(par1IRangedAttackMob, par2, par4, par4, par5);
  }
  
  public qn(to par1IRangedAttackMob, double par2, int par4, int par5, float par6)
  {
    d = -1;
    
    if (!(par1IRangedAttackMob instanceof of))
    {
      throw new IllegalArgumentException("ArrowAttackGoal requires Mob implements RangedAttackMob");
    }
    

    b = par1IRangedAttackMob;
    a = ((og)par1IRangedAttackMob);
    e = par2;
    g = par4;
    h = par5;
    i = par6;
    j = (par6 * par6);
    a(3);
  }
  




  public boolean a()
  {
    of entitylivingbase = a.m();
    
    if (entitylivingbase == null)
    {
      return false;
    }
    

    c = entitylivingbase;
    return true;
  }
  




  public boolean b()
  {
    return (a()) || (!a.k().g());
  }
  



  public void d()
  {
    c = null;
    f = 0;
    d = -1;
  }
  



  public void e()
  {
    double d0 = a.e(c.u, c.E.b, c.w);
    boolean flag = a.l().a(c);
    
    if (flag)
    {
      this.f += 1;
    }
    else
    {
      this.f = 0;
    }
    

    if ((d0 <= j * a.getSizeMultiplier()) && (this.f >= 20) && ((!a.canSquish(c)) || (d0 <= j * (c.O * c.O) * 0.25D)))
    {
      a.k().h();
    }
    else
    {
      a.k().a(c, e);
    }
    
    a.h().a(c, 30.0F, 30.0F);
    

    if (--d == 0)
    {
      if ((d0 > j * a.getSizeMultiplier()) || (!flag))
      {
        return;
      }
      
      float f = ls.a(d0) / i;
      float f1 = f;
      
      if (f < 0.1F)
      {
        f1 = 0.1F;
      }
      
      if (f1 > 1.0F)
      {
        f1 = 1.0F;
      }
      
      b.a(c, f1);
      d = ls.d(f * (h - g) + g);
    }
    else if (d < 0)
    {
      float f = ls.a(d0) / i;
      d = ls.d(f * (h - g) + g);
    }
  }
}
