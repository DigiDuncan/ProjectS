import java.util.Random;













public class alf
{
  private final ale[] a;
  private int b;
  private int c;
  
  public alf(ale[] par1ArrayOfPathPoint)
  {
    a = par1ArrayOfPathPoint;
    c = par1ArrayOfPathPoint.length;
  }
  



  public void a()
  {
    b += 1;
  }
  



  public boolean b()
  {
    return b >= c;
  }
  



  public ale c()
  {
    return c > 0 ? a[(c - 1)] : null;
  }
  



  public ale a(int par1)
  {
    return a[par1];
  }
  
  public int d()
  {
    return c;
  }
  
  public void b(int par1)
  {
    c = par1;
  }
  
  public int e()
  {
    return b;
  }
  
  public void c(int par1)
  {
    b = par1;
  }
  





  public atc a(nn par1Entity, int par2)
  {
    double var5 = a[par2].b;
    double var7;
    double var3; double var7; if (O > 0.5F)
    {
      double var3 = a[par2].a + (int)(O + 1.0F) * 0.5D;
      var7 = a[par2].c + (int)(O + 1.0F) * 0.5D;
    }
    else
    {
      int var8 = q.a(a[par2].a, a[par2].b, a[par2].c);
      
      if ((aqz.s[var8] != null) && ((var8 == becF) || (var8 == bAcF) || (var8 == bKcF) || ((aqz.s[var8] instanceof aqp)) || ((aqz.s[var8] instanceof aqt)) || ((aqz.s[var8] instanceof aqy))))
      {
        int md = q.h(a[par2].a, a[par2].b, a[par2].c);
        
        double var3 = a[par2].a + (par1Entity.getEntityRNG().nextInt(2) + 1) / 3.0D;
        double var7 = a[par2].c + (par1Entity.getEntityRNG().nextInt(2) + 1) / 3.0D;
        if ((aqz.s[var8] instanceof aqp))
        {
          if ((md & 0x2) == 0)
          {
            var3 = a[par2].a + ((md & 0x1) == 0 ? 1 : 2) / 3.0D;
            var7 = a[par2].c + 0.5D;
          }
          else
          {
            var3 = a[par2].a + 0.5D;
            var7 = a[par2].c + ((md & 0x1) == 0 ? 1 : 2) / 3.0D;
          }
        }
        if ((((aqz.s[var8] instanceof aqp)) || ((aqz.s[var8] instanceof aqt))) && ((md & 0x4) == 0))
        {
          var5 = a[par2].b + 0.5D;
        }
      }
      else
      {
        var3 = a[par2].a + 0.5D;
        var7 = a[par2].c + 0.5D;
      }
    }
    
    return q.V().a(var3, var5, var7);
  }
  



  public atc a(nn par1Entity)
  {
    return a(par1Entity, b);
  }
  



  public boolean a(alf par1PathEntity)
  {
    if (par1PathEntity == null)
    {
      return false;
    }
    if (a.length != a.length)
    {
      return false;
    }
    

    for (int i = 0; i < a.length; i++)
    {
      if ((a[i].a != a[i].a) || (a[i].b != a[i].b) || (a[i].c != a[i].c))
      {
        return false;
      }
    }
    
    return true;
  }
  




  public boolean b(atc par1Vec3)
  {
    ale pathpoint = c();
    return pathpoint != null;
  }
}
