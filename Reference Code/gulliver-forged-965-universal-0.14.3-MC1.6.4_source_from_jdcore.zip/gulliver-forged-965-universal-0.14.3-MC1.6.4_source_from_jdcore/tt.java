import java.util.Random;











public class tt
  extends tm
{
  public tt(abw par1World)
  {
    super(par1World);
    a(1.4F, 0.9F);
  }
  
  protected void a()
  {
    super.a();
    ah.a(16, new Byte((byte)0));
  }
  



  public void l_()
  {
    super.l_();
    
    if (!q.I)
    {
      a(G);
    }
  }
  
  protected void az()
  {
    super.az();
    a(tp.a).a(16.0D);
    a(tp.d).a(0.800000011920929D);
  }
  



  public double Y()
  {
    return 0.625D * P;
  }
  




  protected nn bL()
  {
    float f = d(1.0F);
    
    if (f < 0.5F)
    {
      double d0 = 16.0D;
      return q.b(this, d0);
    }
    

    return null;
  }
  




  protected String r()
  {
    return "mob.spider.say";
  }
  



  protected String aO()
  {
    return "mob.spider.say";
  }
  



  protected String aP()
  {
    return "mob.spider.death";
  }
  



  protected void a(int par1, int par2, int par3, int par4)
  {
    a("mob.spider.step", 0.15F, 1.0F);
  }
  



  protected void a(nn par1Entity, float par2)
  {
    float f1 = d(1.0F);
    
    if ((f1 > 0.5F) && (ab.nextInt(100) == 0))
    {
      j = null;
    }
    else
    {
      float sizeroot = getSizeMultiplierRoot();
      
      if ((par2 > 2.0F * sizeroot) && (par2 < 6.0F * sizeroot) && (ab.nextInt(10) == 0))
      {
        if (F)
        {
          double d0 = u - u;
          double d1 = w - w;
          float f2 = ls.a(d0 * d0 + d1 * d1);
          x = (d0 / f2 * 0.5D * 0.800000011920929D * sizeroot + x * 0.20000000298023224D);
          z = (d1 / f2 * 0.5D * 0.800000011920929D * sizeroot + z * 0.20000000298023224D);
          y = 0.4000000059604645D;
          if (sizeroot > 1.0F)
          {
            y *= Math.sqrt(sizeroot);
          }
          else if (isSticky())
          {
            y *= sizeroot;
          }
          else if (isTiny())
          {

            y *= Math.cbrt(sizeroot);
          }
          
        }
      }
      else {
        super.a(par1Entity, par2);
      }
    }
  }
  
  public boolean shouldSquish(nn par1Entity)
  {
    return canSquish(par1Entity);
  }
  



  protected int s()
  {
    return Mcv;
  }
  




  protected void b(boolean par1, int par2)
  {
    super.b(par1, par2);
    
    if ((par1) && ((ab.nextInt(3) == 0) || (ab.nextInt(1 + par2) > 0)))
    {
      b(bwcv, 1);
    }
  }
  



  public boolean e()
  {
    return bT();
  }
  



  public void am() {}
  



  public oj aY()
  {
    return oj.c;
  }
  
  public boolean d(nj par1PotionEffect)
  {
    return par1PotionEffect.a() == uH ? false : super.d(par1PotionEffect);
  }
  




  public boolean bT()
  {
    return (ah.a(16) & 0x1) != 0;
  }
  




  public void a(boolean par1)
  {
    byte b0 = ah.a(16);
    
    if (par1)
    {
      b0 = (byte)(b0 | 0x1);
    }
    else
    {
      b0 = (byte)(b0 & 0xFFFFFFFE);
    }
    
    ah.b(16, Byte.valueOf(b0));
  }
  
  public oi a(oi par1EntityLivingData)
  {
    Object par1EntityLivingData1 = super.a(par1EntityLivingData);
    
    if (q.s.nextInt(100) == 0)
    {
      tr entityskeleton = new tr(q);
      entityskeleton.setSizeBaseMultiplier(getSizeMultiplier());
      entityskeleton.doResize(getSizeMultiplier(), false);
      entityskeleton.b(u, v, w, A, 0.0F);
      entityskeleton.a((oi)null);
      q.d(entityskeleton);
      entityskeleton.a(this);
    }
    
    if (par1EntityLivingData1 == null)
    {
      par1EntityLivingData1 = new tu();
      
      if ((q.r > 2) && (q.s.nextFloat() < 0.1F * q.b(u, v, w)))
      {
        ((tu)par1EntityLivingData1).a(q.s);
      }
    }
    
    if ((par1EntityLivingData1 instanceof tu))
    {
      int i = a;
      
      if ((i > 0) && (ni.a[i] != null))
      {
        c(new nj(i, Integer.MAX_VALUE));
      }
    }
    
    return (oi)par1EntityLivingData1;
  }
}
