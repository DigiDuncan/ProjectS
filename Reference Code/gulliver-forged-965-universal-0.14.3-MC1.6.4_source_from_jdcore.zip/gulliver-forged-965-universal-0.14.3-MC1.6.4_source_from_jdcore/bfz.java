import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import org.lwjgl.opengl.GL11;








@SideOnly(Side.CLIENT)
public class bfz
  extends bgm
{
  private static final bjo a = new bjo("textures/entity/arrow.png");
  
  public bfz() {}
  
  public void a(uh par1EntityArrow, double par2, double par4, double par6, float par8, float par9) { b(par1EntityArrow);
    GL11.glPushMatrix();
    GL11.glTranslatef((float)par2, (float)par4, (float)par6);
    GL11.glRotatef(C + (A - C) * par9 - 90.0F, 0.0F, 1.0F, 0.0F);
    GL11.glRotatef(D + (B - D) * par9, 0.0F, 0.0F, 1.0F);
    bfq tessellator = bfq.a;
    byte b0 = 0;
    float f2 = 0.0F;
    float f3 = 0.5F;
    float f4 = (0 + b0 * 10) / 32.0F;
    float f5 = (5 + b0 * 10) / 32.0F;
    float f6 = 0.0F;
    float f7 = 0.15625F;
    float f8 = (5 + b0 * 10) / 32.0F;
    float f9 = (10 + b0 * 10) / 32.0F;
    float f10 = 0.05625F * par1EntityArrow.getSizeMultiplier();
    GL11.glEnable(32826);
    float f11 = b - par9;
    
    if (f11 > 0.0F)
    {
      float f12 = -ls.a(f11 * 3.0F) * f11;
      GL11.glRotatef(f12, 0.0F, 0.0F, 1.0F);
    }
    
    GL11.glRotatef(45.0F, 1.0F, 0.0F, 0.0F);
    GL11.glScalef(f10, f10, f10);
    GL11.glTranslatef(-4.0F, 0.0F, 0.0F);
    GL11.glNormal3f(f10, 0.0F, 0.0F);
    tessellator.b();
    tessellator.a(-7.0D, -2.0D, -2.0D, f6, f8);
    tessellator.a(-7.0D, -2.0D, 2.0D, f7, f8);
    tessellator.a(-7.0D, 2.0D, 2.0D, f7, f9);
    tessellator.a(-7.0D, 2.0D, -2.0D, f6, f9);
    tessellator.a();
    GL11.glNormal3f(-f10, 0.0F, 0.0F);
    tessellator.b();
    tessellator.a(-7.0D, 2.0D, -2.0D, f6, f8);
    tessellator.a(-7.0D, 2.0D, 2.0D, f7, f8);
    tessellator.a(-7.0D, -2.0D, 2.0D, f7, f9);
    tessellator.a(-7.0D, -2.0D, -2.0D, f6, f9);
    tessellator.a();
    
    for (int i = 0; i < 4; i++)
    {
      GL11.glRotatef(90.0F, 1.0F, 0.0F, 0.0F);
      GL11.glNormal3f(0.0F, 0.0F, f10);
      tessellator.b();
      tessellator.a(-8.0D, -2.0D, 0.0D, f2, f4);
      tessellator.a(8.0D, -2.0D, 0.0D, f3, f4);
      tessellator.a(8.0D, 2.0D, 0.0D, f3, f5);
      tessellator.a(-8.0D, 2.0D, 0.0D, f2, f5);
      tessellator.a();
    }
    
    GL11.glDisable(32826);
    GL11.glPopMatrix();
  }
  
  protected bjo a(uh par1EntityArrow)
  {
    return a;
  }
  



  protected bjo a(nn par1Entity)
  {
    return a((uh)par1Entity);
  }
  






  public void a(nn par1Entity, double par2, double par4, double par6, float par8, float par9)
  {
    a((uh)par1Entity, par2, par4, par6, par8, par9);
  }
}
