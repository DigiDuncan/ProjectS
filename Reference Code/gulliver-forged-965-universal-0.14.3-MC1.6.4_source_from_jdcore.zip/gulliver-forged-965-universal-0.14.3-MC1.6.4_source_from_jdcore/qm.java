import java.util.Random;



public class qm
  extends ps
{
  private on a;
  private double b;
  private double c;
  private double d;
  private double e;
  
  public qm(on par1EntityCreature, double par2)
  {
    a = par1EntityCreature;
    e = par2;
    a(1);
  }
  



  public boolean a()
  {
    if (a.aI() >= 100)
    {
      return false;
    }
    if (a.aD().nextInt((int)(120.0F / a.getSizeMultiplierRoot())) != 0)
    {
      return false;
    }
    

    atc vec3 = rh.a(a, (int)(5.0F + 5.0F * a.getSizeMultiplierRoot()), (int)(4.0F + 3.0F * a.getSizeMultiplierRoot()));
    
    if (vec3 == null)
    {
      return false;
    }
    

    b = c;
    c = d;
    d = e;
    return true;
  }
  





  public boolean b()
  {
    return !a.k().g();
  }
  



  public void c()
  {
    a.k().a(b, c, d, e);
  }
}
