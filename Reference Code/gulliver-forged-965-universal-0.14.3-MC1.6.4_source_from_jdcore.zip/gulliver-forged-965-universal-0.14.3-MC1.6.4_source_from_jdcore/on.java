import java.util.Random;
import java.util.UUID;














public abstract class on
  extends og
{
  public static final UUID h = UUID.fromString("E199AD21-BA8A-4C53-8D13-6182D5C69D3A");
  public static final ot i = new ot(h, "Fleeing speed bonus", 2.0D, 2).a(false);
  

  private alf bp;
  

  protected nn j;
  

  protected boolean bn;
  
  protected int bo;
  
  private t bq = new t(0, 0, 0);
  

  private float br = -1.0F;
  private ps bs = new qd(this, 1.0D);
  private boolean bt;
  
  public on(abw par1World)
  {
    super(par1World);
  }
  



  protected boolean bJ()
  {
    return false;
  }
  
  protected void bl()
  {
    q.C.a("ai");
    
    if ((bo > 0) && (--bo == 0))
    {
      os attributeinstance = a(tp.d);
      attributeinstance.b(i);
    }
    
    bn = bJ();
    float f = 16.0F * getSizeMultiplierRoot();
    
    if (j == null)
    {
      j = ((holdingEntity instanceof uf) ? holdingEntity : bL());
      
      if (j != null)
      {
        bp = q.a(this, j, f, true, false, false, true);
      }
    }
    else if (j.T())
    {
      float f1 = j.d(this);
      
      if (o(j))
      {
        a(j, f1);
      }
    }
    else
    {
      j = null;
    }
    
    q.C.b();
    
    if ((!bn) && (j != null) && ((bp == null) || (ab.nextInt(20) == 0)))
    {
      bp = q.a(this, j, f, true, false, false, true);
    }
    else if ((!bn) && (((bp == null) && (ab.nextInt((int)(180.0F / getSizeMultiplierRoot())) == 0)) || (((ab.nextInt((int)(120.0F / getSizeMultiplierRoot())) == 0) || (bo > 0)) && (aV < 100))))
    {
      bK();
    }
    
    int i = ls.c(E.b + getStepHeight());
    boolean flag = H();
    boolean flag1 = J();
    B = 0.0F;
    
    if ((bp != null) && (ab.nextInt(100) != 0))
    {
      q.C.a("followpath");
      atc vec3 = bp.a(this);
      double d0 = O * 2.0F;
      
      while ((vec3 != null) && (vec3.d(u, d, w) < d0 * d0))
      {
        bp.a();
        
        if (bp.b())
        {
          vec3 = null;
          bp = null;
        }
        else
        {
          vec3 = bp.a(this);
        }
      }
      
      bd = false;
      
      if (vec3 != null)
      {

        double d1 = c - u;
        double d2 = e - w;
        double d3 = d - i;
        float f2 = (float)(Math.atan2(d2, d1) * 180.0D / 3.141592653589793D) - 90.0F;
        float f3 = ls.g(f2 - A);
        bf = ((float)a(tp.d).e());
        
        if (f3 > 30.0F)
        {
          f3 = 30.0F;
        }
        
        if (f3 < -30.0F)
        {
          f3 = -30.0F;
        }
        
        A += f3;
        
        if ((bn) && (j != null))
        {
          double d4 = j.u - u;
          double d5 = j.w - w;
          float f4 = A;
          A = ((float)(Math.atan2(d5, d4) * 180.0D / 3.141592653589793D) - 90.0F);
          f3 = (f4 - A + 90.0F) * 3.1415927F / 180.0F;
          be = (-ls.a(f3) * bf * 1.0F);
          bf = (ls.b(f3) * bf * 1.0F);
        }
        
        if (d3 > 0.0D)
        {
          bd = true;
        }
      }
      
      if (j != null)
      {
        a(j, 30.0F, 30.0F);
      }
      
      if ((G) && (!bM()))
      {
        bd = true;
      }
      
      if ((ab.nextFloat() < 0.8F) && ((flag) || (flag1)))
      {
        bd = true;
      }
      
      q.C.b();
    }
    else
    {
      super.bl();
      bp = null;
    }
  }
  



  protected void bK()
  {
    q.C.a("stroll");
    boolean flag = false;
    int i = -1;
    int j = -1;
    int k = -1;
    float f = -99999.0F;
    
    for (int l = 0; l < 10; l++)
    {
      int hrange = (int)(8.0F + 5.0F * getSizeMultiplierRoot());
      int vrange = (int)(4.0F + 3.0F * getSizeMultiplierRoot());
      int i1 = ls.c(u + ab.nextInt(hrange) - hrange / 2);
      int j1 = ls.c(v + ab.nextInt(vrange) - vrange / 2);
      int k1 = ls.c(w + ab.nextInt(hrange) - hrange / 2);
      float f1 = a(i1, j1, k1);
      
      if (f1 > f)
      {
        f = f1;
        i = i1;
        j = j1;
        k = k1;
        flag = true;
      }
    }
    
    if (flag)
    {
      bp = q.a(this, i, j, k, 10.0F * getRangeMultiplier(), true, false, false, true);
    }
    
    q.C.b();
  }
  




  protected void a(nn par1Entity, float par2) {}
  



  public float a(int par1, int par2, int par3)
  {
    return 0.0F;
  }
  




  protected nn bL()
  {
    return null;
  }
  



  public boolean bs()
  {
    int i = ls.c(u);
    int j = ls.c(E.b);
    int k = ls.c(w);
    return (super.bs()) && (a(i, j, k) >= 0.0F);
  }
  



  public boolean bM()
  {
    return bp != null;
  }
  



  public void a(alf par1PathEntity)
  {
    bp = par1PathEntity;
  }
  



  public nn bN()
  {
    return j;
  }
  



  public void b(nn par1Entity)
  {
    j = par1Entity;
  }
  
  public boolean bO()
  {
    return b(ls.c(u), ls.c(v), ls.c(w));
  }
  
  public boolean b(int par1, int par2, int par3)
  {
    return br == -1.0F;
  }
  
  public void b(int par1, int par2, int par3, int par4)
  {
    bq.b(par1, par2, par3);
    br = par4;
  }
  



  public t bP()
  {
    return bq;
  }
  
  public float bQ()
  {
    return br;
  }
  
  public void bR()
  {
    br = -1.0F;
  }
  



  public boolean bS()
  {
    return br != -1.0F;
  }
  
  protected void bF()
  {
    super.bF();
    
    if ((bH()) && (bI() != null) && (bIq == q))
    {
      nn entity = bI();
      boolean leashedToTiny = (entity instanceof oe) ? isHuge() : entity.isTinierThan(this);
      float amt = entity.getSizeMultiplierRoot() * getSizeMultiplierRoot();
      if (amt < 1.0F)
      {
        amt = 1.0F;
      }
      
      if (!leashedToTiny)
      {
        b((int)u, (int)v, (int)w, 5);
      }
      else
      {
        if (bt)
        {
          bt = false;
          c.a(bs);
        }
        k().a(true);
        bR();
      }
      float f = d(entity);
      
      if (((this instanceof oq)) && (((oq)this).bU()))
      {
        if (f > 10.0F * amt)
        {
          a(true, true);
        }
        
        return;
      }
      
      if (!bt)
      {
        c.a(2, bs);
        k().a(false);
        bt = true;
      }
      
      o(f);
      
      if ((f > 4.0F * amt) && (!leashedToTiny))
      {
        k().a(entity, 1.0D);
      }
      
      if (f > 6.0F * amt)
      {
        double d0 = (u - u) / f;
        double d1 = (v - v) / f;
        double d2 = (w - w) / f;
        double damt = entity.getSizeMultiplierRoot() * getSizeMultiplierRoot();
        if (!leashedToTiny)
        {
          x += d0 * Math.abs(d0) * 0.4D * damt;
          y += d1 * Math.abs(d1) * 0.4D * damt;
          z += d2 * Math.abs(d2) * 0.4D * damt;
        }
        else if ((entity instanceof of))
        {
          if (!G)
          {
            x -= d0 * Math.abs(d0) * 0.25D * damt;
            y -= d1 * Math.abs(d1) * 0.25D * amt;
            z -= d2 * Math.abs(d2) * 0.25D * damt;
          }
          else
          {
            y += (d0 * d0 + d1 * d1 + d2 * d2) * 0.25D * amt;
          }
          an = true;
          
          if ((entity instanceof jv))
          {
            jv toy = (jv)entity;
            a.b(new fp(k, x, y, z));
          }
        }
      }
      
      if (f > 10.0F * amt)
      {
        if ((f > 15.0F * amt) || (!isQuiteSmallerThan(entity)))
        {
          a(true, true);
        }
      }
    }
    else if ((!bH()) && (bt))
    {
      bt = false;
      c.a(bs);
      k().a(true);
      bR();
    }
  }
  
  protected void o(float par1) {}
}
