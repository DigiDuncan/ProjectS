






public class pq
  extends ps
{
  private oq d;
  private of e;
  abw a;
  private double f;
  private rf g;
  private int h;
  float b;
  float c;
  private boolean i;
  
  public pq(oq par1EntityTameable, double par2, float par4, float par5)
  {
    d = par1EntityTameable;
    a = q;
    f = par2;
    g = par1EntityTameable.k();
    c = par4;
    b = par5;
    a(3);
  }
  



  public boolean a()
  {
    of entitylivingbase = d.bV();
    
    if (entitylivingbase == null)
    {
      return false;
    }
    if ((d.bU()) || (!d.isEntityInRelativeSizeRange(entitylivingbase, minTargetSize, maxTargetSize)))
    {
      return false;
    }
    if (d.e(entitylivingbase) < c * c * d.getRangeMultiplier() * d.getRangeMultiplier())
    {
      return false;
    }
    

    e = entitylivingbase;
    return true;
  }
  




  public boolean b()
  {
    return (!g.g()) && (d.e(e) > b * b * d.getRangeMultiplier() * d.getRangeMultiplier()) && (!d.bU());
  }
  



  public void c()
  {
    h = 0;
    i = d.k().a();
    d.k().a(false);
  }
  



  public void d()
  {
    e = null;
    g.h();
    d.k().a(i);
  }
  



  public void e()
  {
    d.h().a(e, 10.0F, d.bp());
    
    if (!d.bU())
    {
      if (--h <= 0)
      {
        h = 10;
        
        if (!g.a(e, f))
        {
          if (!d.bH())
          {
            if (d.e(e) >= 144.0D * (d.getRangeMultiplier() * d.getRangeMultiplier()))
            {
              int r1 = ls.d(d.O * 2.0F);
              int r2 = ls.d(e.O * 2.0F);
              int r3 = r1 + r2;
              if (r3 < 2)
              {
                r3 = 2;
              }
              int r4 = r3 / 2;
              int i = ls.c(e.u) - r3;
              int j = ls.c(e.w) - r3;
              int k = ls.c(e.E.b);
              
              for (int l = 0; l <= r3 * 2; l++)
              {
                for (int i1 = 0; i1 <= r3 * 2; i1++)
                {
                  if (((l < r4) || (i1 < r4) || (l > r3 + r4) || (i1 > r3 + r4)) && (a.w(i + l, k - 1, j + i1)) && (!a.u(i + l, k, j + i1)) && (!a.u(i + l, k + 1, j + i1)))
                  {
                    d.b(i + l + 0.5F, k, j + i1 + 0.5F, d.A, d.B);
                    g.h();
                    return;
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
