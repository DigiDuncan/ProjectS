import java.util.Random;





public class qq
  extends ps
{
  private rs a;
  private double b;
  private double c;
  private double d;
  private double e;
  
  public qq(rs par1EntityHorse, double par2)
  {
    a = par1EntityHorse;
    b = par2;
    a(1);
  }
  



  public boolean a()
  {
    if ((!a.bW()) && (a.n != null) && (!a.n.isTinierThan(a)))
    {
      atc vec3 = rh.a(a, (int)(2.0F + 3.0F * a.getSizeMultiplierRoot()), (int)(2.0F + 2.0F * a.getSizeMultiplierRoot()));
      
      if (vec3 == null)
      {
        return false;
      }
      

      c = c;
      d = d;
      e = e;
      return true;
    }
    


    return false;
  }
  




  public void c()
  {
    a.k().a(c, d, e, b);
  }
  



  public boolean b()
  {
    return (!a.k().g()) && (a.n != null);
  }
  



  public void e()
  {
    if (a.aD().nextInt(50) == 0)
    {
      if ((a.n instanceof uf))
      {
        int i = a.ck();
        int j = a.cq();
        
        if ((j > 0) && (a.aD().nextInt(j) < i))
        {
          a.g((uf)a.n);
          a.q.a(a, (byte)7);
          return;
        }
        
        a.t((int)(5.0F * a.getSizeMultiplierRoot() / a.n.getSizeMultiplierRoot()));
      }
      
      a.n.a((nn)null);
      a.n = null;
      a.cD();
      a.q.a(a, (byte)6);
    }
  }
}
