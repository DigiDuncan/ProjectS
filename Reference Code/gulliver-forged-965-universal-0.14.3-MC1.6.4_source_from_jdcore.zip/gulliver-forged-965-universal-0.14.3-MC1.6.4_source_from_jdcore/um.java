import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;








public class um
  extends uj
{
  public int e = 1;
  
  public um(abw par1World)
  {
    super(par1World);
  }
  
  @SideOnly(Side.CLIENT)
  public um(abw par1World, double par2, double par4, double par6, double par8, double par10, double par12)
  {
    super(par1World, par2, par4, par6, par8, par10, par12);
  }
  
  public um(abw par1World, of par2EntityLivingBase, double par3, double par5, double par7)
  {
    super(par1World, par2EntityLivingBase, par3, par5, par7);
  }
  



  protected void a(ata par1MovingObjectPosition)
  {
    if (!q.I)
    {
      if (g != null)
      {
        g.a(nb.a(this, a), 6.0F);
      }
      
      q.a((nn)null, u, v, w, e * getSizeMultiplier(), true, q.O().b("mobGriefing"));
      x();
    }
  }
  



  public void b(by par1NBTTagCompound)
  {
    super.b(par1NBTTagCompound);
    par1NBTTagCompound.a("ExplosionPower", e);
  }
  



  public void a(by par1NBTTagCompound)
  {
    super.a(par1NBTTagCompound);
    
    if (par1NBTTagCompound.b("ExplosionPower"))
    {
      e = par1NBTTagCompound.e("ExplosionPower");
    }
  }
}
