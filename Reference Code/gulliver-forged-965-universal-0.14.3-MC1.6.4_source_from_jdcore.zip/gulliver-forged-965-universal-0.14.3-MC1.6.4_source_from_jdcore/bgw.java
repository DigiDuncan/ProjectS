import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import gulliver.common.GulliverOMHelper;
import java.util.Random;
import net.minecraftforge.client.ForgeHooksClient;
import org.lwjgl.opengl.GL11;




















@SideOnly(Side.CLIENT)
public class bgw
  extends bgm
{
  private static final bjo h = new bjo("textures/misc/enchanted_item_glint.png");
  private bfr i = new bfr();
  

  private Random j = new Random();
  public boolean a = true;
  
  public float f;
  
  public static boolean g;
  
  public bgw()
  {
    d = 0.15F;
    e = 0.75F;
  }
  



  public void a(ss par1EntityItem, double par2, double par4, double par6, float par8, float par9)
  {
    b(par1EntityItem);
    this.j.setSeed(187L);
    ye itemstack = par1EntityItem.d();
    
    if (itemstack.b() != null)
    {
      GL11.glPushMatrix();
      float sizemult = par1EntityItem.getSizeMultiplier();
      d = (0.15F * sizemult);
      float f2 = shouldBob() ? ls.a((a + par9) / 10.0F + c) * 0.1F + 0.1F : 0.0F;
      f2 *= sizemult;
      float f3 = ((a + par9) / 20.0F + c) * 57.295776F;
      byte b0 = getMiniBlockCount(itemstack);
      
      GL11.glTranslatef((float)par2, (float)par4 + f2, (float)par6);
      GL11.glEnable(32826);
      




      aqz block = null;
      if (d < aqz.s.length)
      {
        block = aqz.s[d];
      }
      
      if (!g)
      {
        GL11.glScalef(sizemult, sizemult, sizemult);
      }
      
      if (!ForgeHooksClient.renderEntityItem(par1EntityItem, itemstack, f2, f3, this.j, b.e, c))
      {


        if ((itemstack.d() == 0) && (block != null) && (bfr.a(aqz.s[d].d())))
        {
          GL11.glRotatef(f3, 0.0F, 1.0F, 0.0F);
          
          if (g)
          {
            GL11.glScalef(1.25F, 1.25F, 1.25F);
            GL11.glTranslatef(0.0F, 0.05F, 0.0F);
            GL11.glRotatef(-90.0F, 0.0F, 1.0F, 0.0F);
          }
          
          float f7 = 0.25F;
          int j = block.d();
          
          if ((j == 1) || (j == 19) || (j == 12) || (j == 2))
          {
            f7 = 0.5F;
          }
          
          GL11.glScalef(f7, f7, f7);
          
          for (int i = 0; i < b0; i++)
          {
            GL11.glPushMatrix();
            
            if (i > 0)
            {
              float f5 = (this.j.nextFloat() * 2.0F - 1.0F) * 0.2F / f7;
              float f4 = (this.j.nextFloat() * 2.0F - 1.0F) * 0.2F / f7;
              float f6 = (this.j.nextFloat() * 2.0F - 1.0F) * 0.2F / f7;
              GL11.glTranslatef(f5, f4, f6);
            }
            
            float f5 = 1.0F;
            this.i.a(block, itemstack.k(), f5);
            GL11.glPopMatrix();

          }
          


        }
        else if (itemstack.b().b())
        {
          if (g)
          {
            GL11.glScalef(0.5128205F, 0.5128205F, 0.5128205F);
            GL11.glTranslatef(0.0F, -0.05F, 0.0F);
          }
          else
          {
            GL11.glScalef(0.5F, 0.5F, 0.5F);
          }
          
          for (int k = 0; k < itemstack.b().getRenderPasses(itemstack.k()); k++)
          {
            this.j.setSeed(187L);
            ms icon = itemstack.b().getIcon(itemstack, k);
            float f8 = 1.0F;
            
            if (a)
            {
              int i = yc.g[d].a(itemstack, k);
              float f5 = (i >> 16 & 0xFF) / 255.0F;
              float f4 = (i >> 8 & 0xFF) / 255.0F;
              float f6 = (i & 0xFF) / 255.0F;
              GL11.glColor4f(f5 * f8, f4 * f8, f6 * f8, 1.0F);
              renderDroppedItem(par1EntityItem, icon, b0, par9, f5 * f8, f4 * f8, f6 * f8, k);
            }
            else
            {
              renderDroppedItem(par1EntityItem, icon, b0, par9, 1.0F, 1.0F, 1.0F, k);
            }
          }
        }
        else
        {
          if (g)
          {
            GL11.glScalef(0.5128205F, 0.5128205F, 0.5128205F);
            GL11.glTranslatef(0.0F, -0.05F, 0.0F);
          }
          else
          {
            GL11.glScalef(0.5F, 0.5F, 0.5F);
          }
          
          ms icon1 = itemstack.c();
          
          if (a)
          {
            int l = yc.g[d].a(itemstack, 0);
            float f8 = (l >> 16 & 0xFF) / 255.0F;
            float f9 = (l >> 8 & 0xFF) / 255.0F;
            float f5 = (l & 0xFF) / 255.0F;
            float f4 = 1.0F;
            a(par1EntityItem, icon1, b0, par9, f8 * f4, f9 * f4, f5 * f4);
          }
          else
          {
            a(par1EntityItem, icon1, b0, par9, 1.0F, 1.0F, 1.0F);
          }
        }
      }
      
      GL11.glDisable(32826);
      GL11.glPopMatrix();
    }
  }
  
  protected bjo a(ss par1EntityItem)
  {
    return b.e.a(par1EntityItem.d().d());
  }
  



  private void a(ss par1EntityItem, ms par2Icon, int par3, float par4, float par5, float par6, float par7)
  {
    renderDroppedItem(par1EntityItem, par2Icon, par3, par4, par5, par6, par7, 0);
  }
  
  private void renderDroppedItem(ss par1EntityItem, ms par2Icon, int par3, float par4, float par5, float par6, float par7, int pass) {
    bfq tessellator = bfq.a;
    
    if (par2Icon == null)
    {
      bim texturemanager = atv.w().J();
      bjo resourcelocation = texturemanager.a(par1EntityItem.d().d());
      par2Icon = ((bik)texturemanager.b(resourcelocation)).b("missingno");
    }
    
    float f4 = par2Icon.c();
    float f5 = par2Icon.d();
    float f6 = par2Icon.e();
    float f7 = par2Icon.f();
    float f8 = 1.0F;
    float f9 = 0.5F;
    float f10 = 0.25F;
    

    if (GulliverOMHelper.hasOptifine() ? GulliverOMHelper.ofFancyDrops : b.l.j)
    {
      GL11.glPushMatrix();
      
      if (g)
      {
        GL11.glRotatef(180.0F, 0.0F, 1.0F, 0.0F);
      }
      else
      {
        GL11.glRotatef(((a + par4) / 20.0F + c) * 57.295776F, 0.0F, 1.0F, 0.0F);
      }
      
      float f12 = 0.0625F;
      float f11 = 0.021875F;
      ye itemstack = par1EntityItem.d();
      int j = b;
      byte b0 = getMiniItemCount(itemstack);
      
      GL11.glTranslatef(-f9, -f10, -((f12 + f11) * b0 / 2.0F));
      
      for (int k = 0; k < b0; k++)
      {

        if ((k > 0) && (shouldSpreadItems()))
        {
          float x = (this.j.nextFloat() * 2.0F - 1.0F) * 0.3F / 0.5F;
          float y = (this.j.nextFloat() * 2.0F - 1.0F) * 0.3F / 0.5F;
          float z = (this.j.nextFloat() * 2.0F - 1.0F) * 0.3F / 0.5F;
          GL11.glTranslatef(x, y, f12 + f11);
        }
        else
        {
          GL11.glTranslatef(0.0F, 0.0F, f12 + f11);
        }
        
        if (itemstack.d() == 0)
        {
          a(bik.b);
        }
        else
        {
          a(bik.c);
        }
        
        GL11.glColor4f(par5, par6, par7, 1.0F);
        bfj.a(tessellator, f5, f6, f4, f7, par2Icon.a(), par2Icon.b(), f12);
        
        if (itemstack.hasEffect(pass))
        {
          GL11.glDepthFunc(514);
          GL11.glDisable(2896);
          b.e.a(h);
          GL11.glEnable(3042);
          GL11.glBlendFunc(768, 1);
          float f13 = 0.76F;
          GL11.glColor4f(0.5F * f13, 0.25F * f13, 0.8F * f13, 1.0F);
          GL11.glMatrixMode(5890);
          GL11.glPushMatrix();
          float f14 = 0.125F;
          GL11.glScalef(f14, f14, f14);
          float f15 = (float)(atv.F() % 3000L) / 3000.0F * 8.0F;
          GL11.glTranslatef(f15, 0.0F, 0.0F);
          GL11.glRotatef(-50.0F, 0.0F, 0.0F, 1.0F);
          bfj.a(tessellator, 0.0F, 0.0F, 1.0F, 1.0F, 255, 255, f12);
          GL11.glPopMatrix();
          GL11.glPushMatrix();
          GL11.glScalef(f14, f14, f14);
          f15 = (float)(atv.F() % 4873L) / 4873.0F * 8.0F;
          GL11.glTranslatef(-f15, 0.0F, 0.0F);
          GL11.glRotatef(10.0F, 0.0F, 0.0F, 1.0F);
          bfj.a(tessellator, 0.0F, 0.0F, 1.0F, 1.0F, 255, 255, f12);
          GL11.glPopMatrix();
          GL11.glMatrixMode(5888);
          GL11.glDisable(3042);
          GL11.glEnable(2896);
          GL11.glDepthFunc(515);
        }
      }
      
      GL11.glPopMatrix();
    }
    else
    {
      for (int l = 0; l < par3; l++)
      {
        GL11.glPushMatrix();
        
        if (l > 0)
        {
          float f11 = (this.j.nextFloat() * 2.0F - 1.0F) * 0.3F;
          float f16 = (this.j.nextFloat() * 2.0F - 1.0F) * 0.3F;
          float f17 = (this.j.nextFloat() * 2.0F - 1.0F) * 0.3F;
          GL11.glTranslatef(f11, f16, f17);
        }
        
        if (!g)
        {
          GL11.glRotatef(180.0F - b.j, 0.0F, 1.0F, 0.0F);
        }
        
        GL11.glColor4f(par5, par6, par7, 1.0F);
        tessellator.b();
        tessellator.b(0.0F, 1.0F, 0.0F);
        tessellator.a(0.0F - f9, 0.0F - f10, 0.0D, f4, f7);
        tessellator.a(f8 - f9, 0.0F - f10, 0.0D, f5, f7);
        tessellator.a(f8 - f9, 1.0F - f10, 0.0D, f5, f6);
        tessellator.a(0.0F - f9, 1.0F - f10, 0.0D, f4, f6);
        tessellator.a();
        GL11.glPopMatrix();
      }
    }
  }
  



  public void a(avi par1FontRenderer, bim par2TextureManager, ye par3ItemStack, int par4, int par5)
  {
    renderItemIntoGUI(par1FontRenderer, par2TextureManager, par3ItemStack, par4, par5, false);
  }
  
  public void renderItemIntoGUI(avi par1FontRenderer, bim par2TextureManager, ye par3ItemStack, int par4, int par5, boolean renderEffect) {
    int k = d;
    int l = par3ItemStack.k();
    Object object = par3ItemStack.c();
    




    aqz block = k < aqz.s.length ? aqz.s[k] : null;
    if ((par3ItemStack.d() == 0) && (block != null) && (bfr.a(aqz.s[k].d())))
    {
      par2TextureManager.a(bik.b);
      GL11.glPushMatrix();
      GL11.glTranslatef(par4 - 2, par5 + 3, -3.0F + this.f);
      GL11.glScalef(10.0F, 10.0F, 10.0F);
      GL11.glTranslatef(1.0F, 0.5F, 1.0F);
      GL11.glScalef(1.0F, 1.0F, -1.0F);
      GL11.glRotatef(210.0F, 1.0F, 0.0F, 0.0F);
      GL11.glRotatef(45.0F, 0.0F, 1.0F, 0.0F);
      int i1 = yc.g[k].a(par3ItemStack, 0);
      float f2 = (i1 >> 16 & 0xFF) / 255.0F;
      float f = (i1 >> 8 & 0xFF) / 255.0F;
      float f1 = (i1 & 0xFF) / 255.0F;
      
      if (a)
      {
        GL11.glColor4f(f2, f, f1, 1.0F);
      }
      
      GL11.glRotatef(-90.0F, 0.0F, 1.0F, 0.0F);
      i.c = a;
      i.a(block, l, 1.0F);
      i.c = true;
      GL11.glPopMatrix();
    }
    else if (yc.g[k].b())
    {
      GL11.glDisable(2896);
      
      for (int j1 = 0; j1 < yc.g[k].getRenderPasses(l); j1++)
      {
        par2TextureManager.a(par3ItemStack.d() == 0 ? bik.b : bik.c);
        ms icon = yc.g[k].getIcon(par3ItemStack, j1);
        int k1 = yc.g[k].a(par3ItemStack, j1);
        float f = (k1 >> 16 & 0xFF) / 255.0F;
        float f1 = (k1 >> 8 & 0xFF) / 255.0F;
        float f3 = (k1 & 0xFF) / 255.0F;
        
        if (a)
        {
          GL11.glColor4f(f, f1, f3, 1.0F);
        }
        
        a(par4, par5, icon, 16, 16);
        
        if (par3ItemStack.hasEffect(j1))
        {
          renderEffect(par2TextureManager, par4, par5);
        }
      }
      
      GL11.glEnable(2896);
    }
    else
    {
      GL11.glDisable(2896);
      bjo resourcelocation = par2TextureManager.a(par3ItemStack.d());
      par2TextureManager.a(resourcelocation);
      
      if (object == null)
      {
        object = ((bik)atv.w().J().b(resourcelocation)).b("missingno");
      }
      
      int i1 = yc.g[k].a(par3ItemStack, 0);
      float f2 = (i1 >> 16 & 0xFF) / 255.0F;
      float f = (i1 >> 8 & 0xFF) / 255.0F;
      float f1 = (i1 & 0xFF) / 255.0F;
      
      if (a)
      {
        GL11.glColor4f(f2, f, f1, 1.0F);
      }
      
      a(par4, par5, (ms)object, 16, 16);
      GL11.glEnable(2896);
      
      if (par3ItemStack.hasEffect(0))
      {
        renderEffect(par2TextureManager, par4, par5);
      }
    }
    
    GL11.glEnable(2884);
  }
  
  private void renderEffect(bim manager, int x, int y)
  {
    GL11.glDepthFunc(516);
    GL11.glDisable(2896);
    GL11.glDepthMask(false);
    manager.a(h);
    f -= 50.0F;
    GL11.glEnable(3042);
    GL11.glBlendFunc(774, 774);
    GL11.glColor4f(0.5F, 0.25F, 0.8F, 1.0F);
    a(x * 431278612 + y * 32178161, x - 2, y - 2, 20, 20);
    GL11.glDisable(3042);
    GL11.glDepthMask(true);
    f += 50.0F;
    GL11.glEnable(2896);
    GL11.glDepthFunc(515);
  }
  



  public void b(avi par1FontRenderer, bim par2TextureManager, ye par3ItemStack, int par4, int par5)
  {
    if (par3ItemStack != null)
    {
      if (!ForgeHooksClient.renderInventoryItem(c, par2TextureManager, par3ItemStack, a, f, par4, par5))
      {
        renderItemIntoGUI(par1FontRenderer, par2TextureManager, par3ItemStack, par4, par5, true);
      }
    }
  }
  




















  private void a(int par1, int par2, int par3, int par4, int par5)
  {
    for (int j1 = 0; j1 < 2; j1++)
    {
      if (j1 == 0)
      {
        GL11.glBlendFunc(768, 1);
      }
      
      if (j1 == 1)
      {
        GL11.glBlendFunc(768, 1);
      }
      
      float f = 0.00390625F;
      float f1 = 0.00390625F;
      float f2 = (float)(atv.F() % (3000 + j1 * 1873)) / (3000.0F + j1 * 1873) * 256.0F;
      float f3 = 0.0F;
      bfq tessellator = bfq.a;
      float f4 = 4.0F;
      
      if (j1 == 1)
      {
        f4 = -1.0F;
      }
      
      tessellator.b();
      tessellator.a(par2 + 0, par3 + par5, this.f, (f2 + par5 * f4) * f, (f3 + par5) * f1);
      tessellator.a(par2 + par4, par3 + par5, this.f, (f2 + par4 + par5 * f4) * f, (f3 + par5) * f1);
      tessellator.a(par2 + par4, par3 + 0, this.f, (f2 + par4) * f, (f3 + 0.0F) * f1);
      tessellator.a(par2 + 0, par3 + 0, this.f, (f2 + 0.0F) * f, (f3 + 0.0F) * f1);
      tessellator.a();
    }
  }
  




  public void c(avi par1FontRenderer, bim par2TextureManager, ye par3ItemStack, int par4, int par5)
  {
    a(par1FontRenderer, par2TextureManager, par3ItemStack, par4, par5, (String)null);
  }
  
  public void a(avi par1FontRenderer, bim par2TextureManager, ye par3ItemStack, int par4, int par5, String par6Str)
  {
    if (par3ItemStack != null)
    {
      if ((b > 1) || (par6Str != null))
      {
        String s1 = par6Str == null ? String.valueOf(b) : par6Str;
        GL11.glDisable(2896);
        GL11.glDisable(2929);
        par1FontRenderer.a(s1, par4 + 19 - 2 - par1FontRenderer.a(s1), par5 + 6 + 3, 16777215);
        GL11.glEnable(2896);
        GL11.glEnable(2929);
      }
      
      if (par3ItemStack.i())
      {
        int k = (int)Math.round(13.0D - par3ItemStack.j() * 13.0D / par3ItemStack.l());
        int l = (int)Math.round(255.0D - par3ItemStack.j() * 255.0D / par3ItemStack.l());
        GL11.glDisable(2896);
        GL11.glDisable(2929);
        GL11.glDisable(3553);
        bfq tessellator = bfq.a;
        int i1 = 255 - l << 16 | l << 8;
        int j1 = (255 - l) / 4 << 16 | 0x3F00;
        a(tessellator, par4 + 2, par5 + 13, 13, 2, 0);
        a(tessellator, par4 + 2, par5 + 13, 12, 1, j1);
        a(tessellator, par4 + 2, par5 + 13, k, 1, i1);
        GL11.glEnable(3553);
        GL11.glEnable(2896);
        GL11.glEnable(2929);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
      }
    }
  }
  




  private void a(bfq par1Tessellator, int par2, int par3, int par4, int par5, int par6)
  {
    par1Tessellator.b();
    par1Tessellator.d(par6);
    par1Tessellator.a(par2 + 0, par3 + 0, 0.0D);
    par1Tessellator.a(par2 + 0, par3 + par5, 0.0D);
    par1Tessellator.a(par2 + par4, par3 + par5, 0.0D);
    par1Tessellator.a(par2 + par4, par3 + 0, 0.0D);
    par1Tessellator.a();
  }
  
  public void a(int par1, int par2, ms par3Icon, int par4, int par5)
  {
    bfq tessellator = bfq.a;
    tessellator.b();
    tessellator.a(par1 + 0, par2 + par5, f, par3Icon.c(), par3Icon.f());
    tessellator.a(par1 + par4, par2 + par5, f, par3Icon.d(), par3Icon.f());
    tessellator.a(par1 + par4, par2 + 0, f, par3Icon.d(), par3Icon.e());
    tessellator.a(par1 + 0, par2 + 0, f, par3Icon.c(), par3Icon.e());
    tessellator.a();
  }
  



  protected bjo a(nn par1Entity)
  {
    return a((ss)par1Entity);
  }
  






  public void a(nn par1Entity, double par2, double par4, double par6, float par8, float par9)
  {
    a((ss)par1Entity, par2, par4, par6, par8, par9);
  }
  




  public boolean shouldSpreadItems()
  {
    return true;
  }
  




  public boolean shouldBob()
  {
    return true;
  }
  
  public byte getMiniBlockCount(ye stack)
  {
    byte ret = 1;
    if (b > 1) ret = 2;
    if (b > 5) ret = 3;
    if (b > 20) ret = 4;
    if (b > 40) ret = 5;
    return ret;
  }
  






  public byte getMiniItemCount(ye stack)
  {
    byte ret = 1;
    if (b > 1) ret = 2;
    if (b > 15) ret = 3;
    if (b > 31) ret = 4;
    return ret;
  }
}
