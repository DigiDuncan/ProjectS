import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.Event.Result;
import net.minecraftforge.event.EventBus;
import net.minecraftforge.event.entity.player.UseHoeEvent;





public class yb
  extends yc
{
  protected yd a;
  
  public yb(int par1, yd par2EnumToolMaterial)
  {
    super(par1);
    a = par2EnumToolMaterial;
    cw = 1;
    e(par2EnumToolMaterial.a());
    a(ww.i);
  }
  




  public boolean a(ye par1ItemStack, uf par2EntityPlayer, abw par3World, int par4, int par5, int par6, int par7, float par8, float par9, float par10)
  {
    if (!par2EntityPlayer.a(par4, par5, par6, par7, par1ItemStack))
    {
      return false;
    }
    

    UseHoeEvent event = new UseHoeEvent(par2EntityPlayer, par1ItemStack, par3World, par4, par5, par6);
    if (MinecraftForge.EVENT_BUS.post(event))
    {
      return false;
    }
    
    if (event.getResult() == Event.Result.ALLOW)
    {
      par1ItemStack.a(1, par2EntityPlayer);
      return true;
    }
    
    int i1 = par3World.a(par4, par5, par6);
    boolean air = par3World.c(par4, par5 + 1, par6);
    
    if ((par7 != 0) && (air) && ((i1 == zcF) || (i1 == AcF)))
    {
      aqz block = aqz.aF;
      
      if (par2EntityPlayer.isTiny())
      {
        if (i1 == zcF)
        {
          block = aqz.z;
        }
        else if (par2EntityPlayer.smallerAndNotUseBlock())
        {
          block = aqz.A;
        }
      }
      
      if (block == aqz.aF)
      {
        par3World.a(par4 + 0.5F, par5 + 0.5F, par6 + 0.5F, cS.e(), (cS.c() + 1.0F) / 2.0F, cS.d() * 0.8F);
      }
      else
      {
        par3World.a(par4 + 0.5F, par5 + 0.5F, par6 + 0.5F, cS.e(), (cS.c() + 1.0F) / 2.0F * par2EntityPlayer.getSizeMultiplierRoot(), cS.d() * 0.8F);
      }
      
      if (I)
      {
        return true;
      }
      

      par3World.c(par4, par5, par6, cF);
      par1ItemStack.a(1, par2EntityPlayer);
      return true;
    }
    


    return false;
  }
  






  @SideOnly(Side.CLIENT)
  public boolean n_()
  {
    return true;
  }
  




  public String g()
  {
    return a.toString();
  }
}
