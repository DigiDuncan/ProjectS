






















public class ry
  extends rp
{
  private final pl bp;
  
  public ry(abw par1World)
  {
    super(par1World);
    a(0.9F, 0.9F);
    k().a(true);
    c.a(0, new pp(this));
    c.a(1, new qj(this, 1.25D));
    c.a(2, this.bp = new pl(this, 0.3F));
    c.a(3, new pk(this, 1.0D));
    c.a(4, new qu(this, 1.2D, bTcv, false));
    c.a(4, new qu(this, 1.2D, bMcv, false));
    c.a(5, new pr(this, 1.1D));
    c.a(6, new qm(this, 1.0D));
    c.a(7, new px(this, uf.class, 6.0F));
    c.a(8, new ql(this));
  }
  



  public boolean bf()
  {
    return true;
  }
  
  protected void az()
  {
    super.az();
    a(tp.a).a(10.0D);
    a(tp.d).a(0.25D);
  }
  
  protected void bi()
  {
    super.bi();
  }
  




  public boolean by()
  {
    ye itemstack = n != null ? ((of)n).aZ() : null;
    return (itemstack != null) && (d == bTcv) && (isEntityInRelativeSizeRange(n, 0.2F, 0.0F));
  }
  
  protected void a()
  {
    super.a();
    ah.a(16, Byte.valueOf((byte)0));
  }
  



  public void b(by par1NBTTagCompound)
  {
    super.b(par1NBTTagCompound);
    par1NBTTagCompound.a("Saddle", bT());
  }
  



  public void a(by par1NBTTagCompound)
  {
    super.a(par1NBTTagCompound);
    i(par1NBTTagCompound.n("Saddle"));
  }
  



  protected String r()
  {
    return "mob.pig.say";
  }
  



  protected String aO()
  {
    return "mob.pig.say";
  }
  



  protected String aP()
  {
    return "mob.pig.death";
  }
  



  protected void a(int par1, int par2, int par3, int par4)
  {
    a("mob.pig.step", 0.15F, 1.0F);
  }
  



  public boolean a(uf par1EntityPlayer)
  {
    if (super.a(par1EntityPlayer))
    {
      return true;
    }
    if ((bT()) && (!q.I) && (n == null) && (!isQuiteSmallerThan(par1EntityPlayer)))
    {
      par1EntityPlayer.a(this);
      return true;
    }
    

    return false;
  }
  




  protected int getMeatItemId()
  {
    return ascv;
  }
  



  protected int getCookedMeatItemId()
  {
    return atcv;
  }
  




  protected void b(boolean par1, int par2)
  {
    super.b(par1, par2);
    
    if (bT())
    {
      b(aCcv, 1);
    }
  }
  



  public boolean bT()
  {
    return (ah.a(16) & 0x1) != 0;
  }
  



  public void i(boolean par1)
  {
    if (par1)
    {
      ah.b(16, Byte.valueOf((byte)1));
    }
    else
    {
      ah.b(16, Byte.valueOf((byte)0));
    }
  }
  



  public void a(sp par1EntityLightningBolt)
  {
    if (!q.I)
    {
      tn entitypigzombie = new tn(q);
      entitypigzombie.b(u, v, w, A, B);
      q.d(entitypigzombie);
      x();
    }
  }
  



  protected void b(float par1)
  {
    super.b(par1);
    
    if ((par1 > 5.0F) && ((n instanceof uf)))
    {
      ((uf)n).a(kp.u);
    }
  }
  



  public ry b(nk par1EntityAgeable)
  {
    return new ry(q);
  }
  




  public boolean c(ye par1ItemStack)
  {
    return (par1ItemStack != null) && (d == bMcv);
  }
  



  public pl bU()
  {
    return bp;
  }
  
  public nk a(nk par1EntityAgeable)
  {
    return b(par1EntityAgeable);
  }
}
