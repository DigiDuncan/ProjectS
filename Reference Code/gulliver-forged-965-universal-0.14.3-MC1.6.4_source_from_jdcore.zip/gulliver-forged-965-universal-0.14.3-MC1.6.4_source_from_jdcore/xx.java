import java.util.Random;
























public class xx
  extends yc
{
  public final int a;
  private final int b;
  private final float c;
  private final boolean d;
  private boolean cB;
  private int cC;
  private int cD;
  private int cE;
  private float cF;
  
  public xx(int par1, int par2, float par3, boolean par4)
  {
    super(par1);
    a = 32;
    b = par2;
    d = par4;
    c = par3;
    a(ww.h);
  }
  
  public xx(int par1, int par2, boolean par3)
  {
    this(par1, par2, 0.6F, par3);
  }
  
  public ye b(ye par1ItemStack, abw par2World, uf par3EntityPlayer)
  {
    b -= 1;
    par3EntityPlayer.bI().addStats(this, par3EntityPlayer.getSizeMultiplierRoot());
    par2World.a(par3EntityPlayer, "random.burp", 0.5F * par3EntityPlayer.getSizeMultiplierRoot(), s.nextFloat() * 0.1F + 0.5F + 0.4F / par3EntityPlayer.getSizeMultiplierRoot());
    c(par1ItemStack, par2World, par3EntityPlayer);
    return par1ItemStack;
  }
  
  protected void c(ye par1ItemStack, abw par2World, uf par3EntityPlayer)
  {
    if ((!I) && (cC > 0) && (s.nextFloat() < cF))
    {
      par3EntityPlayer.c(new nj(cC, cD * 20, cE));
    }
  }
  



  public int d_(ye par1ItemStack)
  {
    return 32;
  }
  



  public zj c_(ye par1ItemStack)
  {
    return zj.b;
  }
  



  public ye a(ye par1ItemStack, abw par2World, uf par3EntityPlayer)
  {
    if (par3EntityPlayer.g(cB))
    {
      par3EntityPlayer.a(par1ItemStack, d_(par1ItemStack));
    }
    
    return par1ItemStack;
  }
  
  public int g()
  {
    return b;
  }
  



  public float i()
  {
    return c;
  }
  



  public boolean j()
  {
    return d;
  }
  




  public xx a(int par1, int par2, int par3, float par4)
  {
    cC = par1;
    cD = par2;
    cE = par3;
    cF = par4;
    return this;
  }
  



  public xx k()
  {
    cB = true;
    return this;
  }
}
