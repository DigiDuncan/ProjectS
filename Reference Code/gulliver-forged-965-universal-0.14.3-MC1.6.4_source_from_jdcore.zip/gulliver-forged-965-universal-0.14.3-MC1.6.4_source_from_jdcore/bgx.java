import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import org.lwjgl.opengl.GL11;












@SideOnly(Side.CLIENT)
public class bgx
  extends bgm
{
  private yc a;
  private int f;
  
  public bgx(yc par1Item, int par2)
  {
    a = par1Item;
    f = par2;
  }
  
  public bgx(yc par1Item)
  {
    this(par1Item, 0);
  }
  






  public void a(nn par1Entity, double par2, double par4, double par6, float par8, float par9)
  {
    ms icon = a.b_(f);
    
    if (icon != null)
    {
      GL11.glPushMatrix();
      GL11.glTranslatef((float)par2, (float)par4, (float)par6);
      GL11.glEnable(32826);
      float scale = 0.5F * par1Entity.getSizeMultiplier();
      GL11.glScalef(scale, scale, scale);
      b(par1Entity);
      bfq tessellator = bfq.a;
      
      if (icon == yp.e("bottle_splash"))
      {
        int i = zp.a(((uu)par1Entity).i(), false);
        float f2 = (i >> 16 & 0xFF) / 255.0F;
        float f3 = (i >> 8 & 0xFF) / 255.0F;
        float f4 = (i & 0xFF) / 255.0F;
        GL11.glColor3f(f2, f3, f4);
        GL11.glPushMatrix();
        a(tessellator, yp.e("overlay"));
        GL11.glPopMatrix();
        GL11.glColor3f(1.0F, 1.0F, 1.0F);
      }
      
      a(tessellator, icon);
      GL11.glDisable(32826);
      GL11.glPopMatrix();
    }
  }
  



  protected bjo a(nn par1Entity)
  {
    return bik.c;
  }
  
  private void a(bfq par1Tessellator, ms par2Icon)
  {
    float f = par2Icon.c();
    float f1 = par2Icon.d();
    float f2 = par2Icon.e();
    float f3 = par2Icon.f();
    float f4 = 1.0F;
    float f5 = 0.5F;
    float f6 = 0.25F;
    GL11.glRotatef(180.0F - b.j, 0.0F, 1.0F, 0.0F);
    GL11.glRotatef(-b.k, 1.0F, 0.0F, 0.0F);
    par1Tessellator.b();
    par1Tessellator.b(0.0F, 1.0F, 0.0F);
    par1Tessellator.a(0.0F - f5, 0.0F - f6, 0.0D, f, f3);
    par1Tessellator.a(f4 - f5, 0.0F - f6, 0.0D, f1, f3);
    par1Tessellator.a(f4 - f5, f4 - f6, 0.0D, f1, f2);
    par1Tessellator.a(0.0F - f5, f4 - f6, 0.0D, f, f2);
    par1Tessellator.a();
  }
}
