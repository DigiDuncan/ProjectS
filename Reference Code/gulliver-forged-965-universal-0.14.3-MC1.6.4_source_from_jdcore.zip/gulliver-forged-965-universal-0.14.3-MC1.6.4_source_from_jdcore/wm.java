import java.util.List;













public class wm
  extends yc
{
  public wm(int par1)
  {
    super(par1);
    cw = 1;
    a(ww.e);
  }
  



  public ye a(ye par1ItemStack, abw par2World, uf par3EntityPlayer)
  {
    float f = 1.0F;
    float f1 = D + (B - D) * f;
    float f2 = C + (A - C) * f;
    double d0 = r + (u - r) * f;
    double d1 = s + (v - s) * f + 1.62D * par3EntityPlayer.getSizeMultiplier() - N;
    double d2 = t + (w - t) * f;
    atc vec3 = par2World.V().a(d0, d1, d2);
    float f3 = ls.b(-f2 * 0.017453292F - 3.1415927F);
    float f4 = ls.a(-f2 * 0.017453292F - 3.1415927F);
    float f5 = -ls.b(-f1 * 0.017453292F);
    float f6 = ls.a(-f1 * 0.017453292F);
    float f7 = f4 * f5;
    float f8 = f3 * f5;
    double d3 = 5.0D * par3EntityPlayer.getRangeMultiplier();
    atc vec31 = vec3.c(f7 * d3, f6 * d3, f8 * d3);
    ata movingobjectposition = par2World.a(vec3, vec31, true);
    
    if (movingobjectposition == null)
    {
      return par1ItemStack;
    }
    

    atc vec32 = par3EntityPlayer.j(f);
    boolean flag = false;
    float f9 = 1.0F;
    List list = par2World.b(par3EntityPlayer, E.a(c * d3, d * d3, e * d3).b(f9, f9, f9));
    

    for (int i = 0; i < list.size(); i++)
    {
      nn entity = (nn)list.get(i);
      
      if (entity.L())
      {
        float f10 = entity.Z();
        asx axisalignedbb = E.b(f10, f10, f10);
        
        if (axisalignedbb.a(vec3))
        {
          flag = true;
        }
      }
    }
    
    if (flag)
    {
      return par1ItemStack;
    }
    

    if (a == atb.a)
    {
      i = b;
      int j = c;
      int k = d;
      
      if (par2World.a(i, j, k) == aXcF)
      {
        j--;
      }
      
      sq entityboat = new sq(par2World, i + 0.5F, j + 1.0F, k + 0.5F);
      A = (((ls.c(A * 4.0F / 360.0F + 0.5D) & 0x3) - 1) * 90);
      
      if (!par2World.a(entityboat, E.b(-0.1D, -0.1D, -0.1D)).isEmpty())
      {
        return par1ItemStack;
      }
      
      if (!I)
      {
        par2World.d(entityboat);
      }
      
      if (!bG.d)
      {
        b -= 1;
      }
    }
    
    return par1ItemStack;
  }
}
