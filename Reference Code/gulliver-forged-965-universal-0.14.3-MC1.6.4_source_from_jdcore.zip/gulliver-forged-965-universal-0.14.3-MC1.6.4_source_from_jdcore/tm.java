import java.util.Random;











public abstract class tm
  extends on
  implements th
{
  public tm(abw par1World)
  {
    super(par1World);
    b = 5;
  }
  




  public void c()
  {
    aW();
    float f = d(1.0F);
    
    if (f > 0.5F)
    {
      aV += 2;
    }
    
    super.c();
  }
  



  public void l_()
  {
    super.l_();
    
    if ((!q.I) && (q.r == 0))
    {
      x();
    }
  }
  



  public double Y()
  {
    if (O * 2.5F < P)
    {

      return P * (g_() ? 0.6D : 0.72D);
    }
    

    return P * 0.75D;
  }
  





  protected nn bL()
  {
    uf entityplayer = q.b(this, 16.0D);
    return (entityplayer != null) && (o(entityplayer)) ? entityplayer : null;
  }
  



  public boolean a(nb par1DamageSource, float par2)
  {
    if (ar())
    {
      return false;
    }
    if (super.a(par1DamageSource, par2))
    {
      nn entity = par1DamageSource.i();
      
      if ((n != entity) && (o != entity))
      {
        if (entity != this)
        {
          j = entity;
        }
        
        return true;
      }
      

      return true;
    }
    


    return false;
  }
  

  public boolean m(nn par1Entity)
  {
    float f = (float)a(tp.e).e();
    int i = 0;
    
    if ((par1Entity instanceof of))
    {
      f += aaw.a(this, (of)par1Entity);
      i += aaw.b(this, (of)par1Entity);
    }
    
    boolean flag = par1Entity.a(nb.a(this), f);
    
    if (flag)
    {
      if (i > 0)
      {
        par1Entity.g(-ls.a(A * 3.1415927F / 180.0F) * i * 0.5F, 0.1D, ls.b(A * 3.1415927F / 180.0F) * i * 0.5F);
        x *= 0.6D;
        z *= 0.6D;
      }
      
      int j = aaw.a(this);
      
      if (j > 0)
      {
        par1Entity.d(j * 4);
      }
      
      if ((par1Entity instanceof of))
      {
        abh.a(this, (of)par1Entity, ab);
      }
    }
    
    return flag;
  }
  



  protected void a(nn par1Entity, float par2)
  {
    if ((aC <= 0) && (par2 < 2.0F * getSizeMultiplierRoot()) && (E.e > E.b) && (E.b < E.e))
    {
      aC = 20;
      m(par1Entity);
    }
  }
  
  public boolean shouldSquish(nn par1Entity)
  {
    return (canSquish(par1Entity)) && (E.e < E.b + P * 0.6D);
  }
  




  public float a(int par1, int par2, int par3)
  {
    return 0.5F - q.q(par1, par2, par3);
  }
  



  protected boolean i_()
  {
    int i = ls.c(u);
    int j = ls.c(E.b);
    int k = ls.c(w);
    
    if (q.b(ach.a, i, j, k) > ab.nextInt(32))
    {
      return false;
    }
    

    int l = q.n(i, j, k);
    
    if (q.P())
    {
      int i1 = q.j;
      q.j = 10;
      l = q.n(i, j, k);
      q.j = i1;
    }
    
    return l <= ab.nextInt(8);
  }
  




  public boolean bs()
  {
    return (q.r > 0) && (i_()) && (super.bs());
  }
  
  protected void az()
  {
    super.az();
    aX().b(tp.e);
  }
  



  protected float ba()
  {
    return (this instanceof tk) ? super.ba() * 2.0F : super.ba();
  }
  



  protected float bb()
  {
    return (this instanceof tk) ? super.bb() * 0.5F : super.bb();
  }
}
