import gulliver.common.GulliverEnvoy;
import java.util.Iterator;
import java.util.List;









public class arq
  extends amx
{
  private final int a;
  
  protected arq(int par1, String par2Str, akc par3Material, int par4)
  {
    super(par1, par2Str, par3Material);
    a = par4;
  }
  




  protected int e(abw par1World, int par2, int par3, int par4)
  {
    if (a < 100)
    {
      List lst = par1World.a(of.class, a(par2, par3, par4));
      GulliverEnvoy.pruneLargerEntities(0.3F, lst);
      int tc = lst.size();
      
      if (tc > 0)
      {

        return Math.min(15, tc);
      }
    }
    
    int l = 0;
    Iterator iterator = par1World.a(ss.class, a(par2, par3, par4)).iterator();
    
    while (iterator.hasNext())
    {
      ss entityitem = (ss)iterator.next();
      l += db;
      
      if (l >= a) {
        break;
      }
    }
    

    if (l <= 0)
    {
      return 0;
    }
    

    float f = Math.min(a, l) / a;
    return ls.f(f * 15.0F);
  }
  




  protected int c(int par1)
  {
    return par1;
  }
  



  protected int d(int par1)
  {
    return par1;
  }
  



  public int a(abw par1World)
  {
    return 10;
  }
}
