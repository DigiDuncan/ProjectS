import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import gulliver.common.GulliverEnvoy;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraftforge.common.EnumPlantType;
import net.minecraftforge.common.ForgeDirection;
import net.minecraftforge.common.ForgeHooks;
import net.minecraftforge.common.IPlantable;
import net.minecraftforge.common.RotationHelper;
import net.minecraftforge.event.ForgeEventFactory;

















































public class aqz
{
  protected static int[] blockFireSpreadSpeed = new int['က'];
  protected static int[] blockFlammability = new int['က'];
  
  private ww a;
  
  protected String f;
  
  public static final ard g = new ard("stone", 1.0F, 1.0F);
  public static final ard h = new ard("wood", 1.0F, 1.0F);
  public static final ard i = new ard("gravel", 1.0F, 1.0F);
  public static final ard j = new ard("grass", 1.0F, 1.0F);
  public static final ard k = new ard("stone", 1.0F, 1.0F);
  public static final ard l = new ard("stone", 1.0F, 1.5F);
  public static final ard m = new ara("stone", 1.0F, 1.0F);
  public static final ard n = new ard("cloth", 1.0F, 1.0F);
  public static final ard o = new ard("sand", 1.0F, 1.0F);
  public static final ard p = new ard("snow", 1.0F, 1.0F);
  public static final ard q = new arb("ladder", 1.0F, 1.0F);
  public static final ard r = new arc("anvil", 0.3F, 1.0F);
  

  public static final aqz[] s = new aqz['က'];
  



  public static final boolean[] t = new boolean['က'];
  

  public static final int[] u = new int['က'];
  

  public static final boolean[] v = new boolean['က'];
  

  public static final int[] w = new int['က'];
  



  public static boolean[] x = new boolean['က'];
  public static final aqz y = new aqu(1).c(1.5F).b(10.0F).a(k).c("stone").d("stone");
  public static final aon z = (aon)new aon(2).c(0.6F).a(j).c("grass").d("grass");
  public static final aqz A = new anx(3).c(0.5F).a(i).c("dirt").d("dirt");
  public static final aqz B = new aqz(4, akc.e).c(2.0F).b(10.0F).a(k).c("stonebrick").a(ww.b).d("cobblestone");
  public static final aqz C = new art(5).c(2.0F).b(5.0F).a(h).c("wood").d("planks");
  public static final aqz D = new aqi(6).c(0.0F).a(j).c("sapling").d("sapling");
  public static final aqz E = new aqz(7, akc.e).r().b(6000000.0F).a(k).c("bedrock").C().a(ww.b).d("bedrock");
  public static final apc F = (apc)new apd(8, akc.h).c(100.0F).k(3).c("water").C().d("water_flow");
  public static final aqz G = new ape(9, akc.h).c(100.0F).k(3).c("water").C().d("water_still");
  public static final apc H = (apc)new apd(10, akc.i).c(0.0F).a(1.0F).c("lava").C().d("lava_flow");
  

  public static final aqz I = new ape(11, akc.i).c(100.0F).a(1.0F).c("lava").C().d("lava_still");
  public static final aqz J = new aos(12).c(0.5F).a(o).c("sand").d("sand");
  public static final aqz K = new aoo(13).c(0.6F).a(i).c("gravel").d("gravel");
  public static final aqz L = new apr(14).c(3.0F).b(5.0F).a(k).c("oreGold").d("gold_ore");
  public static final aqz M = new apr(15).c(3.0F).b(5.0F).a(k).c("oreIron").d("iron_ore");
  public static final aqz N = new apr(16).c(3.0F).b(5.0F).a(k).c("oreCoal").d("coal_ore");
  public static final aqz O = new arj(17).c(2.0F).a(h).c("log").d("log");
  public static final aoz P = (aoz)new aoz(18).c(0.2F).k(1).a(j).c("leaves").d("leaves");
  public static final aqz Q = new aqo(19).c(0.6F).a(j).c("sponge").d("sponge");
  public static final aqz R = new aol(20, akc.s, false).c(0.3F).a(m).c("glass").d("glass");
  public static final aqz S = new apr(21).c(3.0F).b(5.0F).a(k).c("oreLapis").d("lapis_ore");
  public static final aqz T = new aqz(22, akc.e).c(3.0F).b(5.0F).a(k).c("blockLapis").a(ww.b).d("lapis_block");
  public static final aqz U = new any(23).c(3.5F).a(k).c("dispenser").d("dispenser");
  public static final aqz V = new aqh(24).a(k).c(0.8F).c("sandStone").d("sandstone");
  public static final aqz W = new app(25).c(0.8F).c("musicBlock").d("noteblock");
  public static final aqz X = new anb(26).c(0.2F).c("bed").C().d("bed");
  public static final aqz Y = new apv(27).c(0.7F).a(l).c("goldenRail").d("rail_golden");
  public static final aqz Z = new anu(28).c(0.7F).a(l).c("detectorRail").d("rail_detector");
  public static final ast aa = (ast)new ast(29, true).c("pistonStickyBase");
  public static final aqz ab = new arp(30).k(1).c(4.0F).c("web").d("web");
  public static final aqv ac = (aqv)new aqv(31).c(0.0F).a(j).c("tallgrass");
  public static final ant ad = (ant)new ant(32).c(0.0F).a(j).c("deadbush").d("deadbush");
  public static final ast ae = (ast)new ast(33, false).c("pistonBase");
  public static final asu af = new asu(34);
  public static final aqz ag = new ann(35, akc.n).c(0.8F).a(n).c("cloth").d("wool_colored");
  public static final asv ah = new asv(36);
  public static final ane ai = (ane)new ane(37).c(0.0F).a(j).c("flower").d("flower_dandelion");
  public static final ane aj = (ane)new ane(38).c(0.0F).a(j).c("rose").d("flower_rose");
  public static final ane ak = (ane)new apj(39).c(0.0F).a(j).a(0.125F).c("mushroom").d("mushroom_brown");
  public static final ane al = (ane)new apj(40).c(0.0F).a(j).c("mushroom").d("mushroom_red");
  public static final aqz am = new aph(41).c(3.0F).b(10.0F).a(l).c("blockGold").d("gold_block");
  public static final aqz an = new aph(42).c(5.0F).b(10.0F).a(l).c("blockIron").d("iron_block");
  

  public static final aop ao = (aop)new aqt(43, true).c(2.0F).b(10.0F).a(k).c("stoneSlab");
  

  public static final aop ap = (aop)new aqt(44, false).c(2.0F).b(10.0F).a(k).c("stoneSlab");
  public static final aqz aq = new aqz(45, akc.e).c(2.0F).b(10.0F).a(k).c("brick").a(ww.b).d("brick");
  public static final aqz ar = new are(46).c(0.0F).a(j).c("tnt").d("tnt");
  public static final aqz as = new anc(47).c(1.5F).a(h).c("bookshelf").d("bookshelf");
  public static final aqz at = new aqz(48, akc.e).c(2.0F).b(10.0F).a(k).c("stoneMoss").a(ww.b).d("cobblestone_mossy");
  public static final aqz au = new apq(49).c(50.0F).b(2000.0F).a(k).c("obsidian").d("obsidian");
  public static final aqz av = new arg(50).c(0.0F).a(0.9375F).a(h).c("torch").d("torch_on");
  public static final aoi aw = (aoi)new aoi(51).c(0.0F).a(1.0F).a(h).c("fire").C().d("fire");
  public static final aqz ax = new api(52).c(5.0F).a(l).c("mobSpawner").C().d("mob_spawner");
  public static final aqz ay = new aqp(53, C, 0).c("stairsWood");
  public static final ank az = (ank)new ank(54, 0).c(2.5F).a(h).c("chest");
  public static final aqb aA = (aqb)new aqb(55).c(0.0F).a(g).c("redstoneDust").C().d("redstone_dust");
  public static final aqz aB = new apr(56).c(3.0F).b(5.0F).a(k).c("oreDiamond").d("diamond_ore");
  public static final aqz aC = new aph(57).c(5.0F).b(10.0F).a(l).c("blockDiamond").d("diamond_block");
  public static final aqz aD = new arv(58).c(2.5F).a(h).c("workbench").d("crafting_table");
  public static final aqz aE = new anr(59).c("crops").d("wheat");
  public static final aqz aF = new aof(60).c(0.6F).a(i).c("farmland").d("farmland");
  public static final aqz aG = new aok(61, false).c(3.5F).a(k).c("furnace").a(ww.c);
  public static final aqz aH = new aok(62, true).c(3.5F).a(k).a(0.875F).c("furnace");
  public static final aqz aI = new aqj(63, asm.class, true).c(1.0F).a(h).c("sign").C();
  public static final aqz aJ = new anz(64, akc.d).c(3.0F).a(h).c("doorWood").C().d("door_wood");
  public static final aqz aK = new aoy(65).c(0.4F).a(q).c("ladder").d("ladder");
  public static final aqz aL = new aqa(66).c(0.7F).a(l).c("rail").d("rail_normal");
  public static final aqz aM = new aqp(67, B, 0).c("stairsStone");
  public static final aqz aN = new aqj(68, asm.class, false).c(1.0F).a(h).c("sign").C();
  public static final aqz aO = new apb(69).c(0.5F).a(h).c("lever").d("lever");
  public static final aqz aP = new apw(70, "stone", akc.e, apx.b).c(0.5F).a(k).c("pressurePlate");
  public static final aqz aQ = new anz(71, akc.f).c(5.0F).a(l).c("doorIron").C().d("door_iron");
  public static final aqz aR = new apw(72, "planks_oak", akc.d, apx.a).c(0.5F).a(h).c("pressurePlate");
  public static final aqz aS = new aqc(73, false).c(3.0F).b(5.0F).a(k).c("oreRedstone").a(ww.b).d("redstone_ore");
  public static final aqz aT = new aqc(74, true).a(0.625F).c(3.0F).b(5.0F).a(k).c("oreRedstone").d("redstone_ore");
  public static final aqz aU = new apn(75, false).c(0.0F).a(h).c("notGate").d("redstone_torch_off");
  public static final aqz aV = new apn(76, true).c(0.0F).a(0.5F).a(h).c("notGate").a(ww.d).d("redstone_torch_on");
  public static final aqz aW = new aqr(77).c(0.5F).a(k).c("button");
  public static final aqz aX = new arf(78).c(0.1F).a(p).c("snow").k(0).d("snow");
  public static final aqz aY = new aov(79).c(0.5F).k(3).a(m).c("ice").d("ice");
  public static final aqz aZ = new aqm(80).c(0.2F).a(p).c("snow").d("snow");
  public static final aqz ba = new ang(81).c(0.4F).a(n).c("cactus").d("cactus");
  public static final aqz bb = new anl(82).c(0.6F).a(i).c("clay").d("clay");
  public static final aqz bc = new aqe(83).c(0.0F).a(j).c("reeds").C().d("reeds");
  public static final aqz bd = new aow(84).c(2.0F).b(10.0F).a(k).c("jukebox").d("jukebox");
  public static final aqz be = new aoh(85, "planks_oak", akc.d).c(2.0F).b(5.0F).a(h).c("fence");
  public static final aqz bf = new apy(86, false).c(1.0F).a(h).c("pumpkin").d("pumpkin");
  public static final aqz bg = new apm(87).c(0.4F).a(k).c("hellrock").d("netherrack");
  public static final aqz bh = new aqn(88).c(0.5F).a(o).c("hellsand").d("soul_sand");
  public static final aqz bi = new aom(89, akc.s).c(0.3F).a(m).a(1.0F).c("lightgem").d("glowstone");
  

  public static final aps bj = (aps)new aps(90).c(-1.0F).a(m).a(0.75F).c("portal").d("portal");
  public static final aqz bk = new apy(91, true).c(1.0F).a(h).a(1.0F).c("litpumpkin").d("pumpkin");
  public static final aqz bl = new anh(92).c(0.5F).a(n).c("cake").C().d("cake");
  public static final aqf bm = (aqf)new aqf(93, false).c(0.0F).a(h).c("diode").C().d("repeater_off");
  public static final aqf bn = (aqf)new aqf(94, true).c(0.0F).a(0.625F).a(h).c("diode").C().d("repeater_on");
  



  public static final aqz bo = new apf(95).c(0.0F).a(1.0F).a(h).c("lockedchest").b(true);
  public static final aqz bp = new ari(96, akc.d).c(3.0F).a(h).c("trapdoor").C().d("trapdoor");
  public static final aqz bq = new aqs(97).c(0.75F).c("monsterStoneEgg");
  public static final aqz br = new aql(98).c(1.5F).b(10.0F).a(k).c("stonebricksmooth").d("stonebrick");
  public static final aqz bs = new aou(99, akc.d, 0).c(0.2F).a(h).c("mushroom").d("mushroom_block");
  public static final aqz bt = new aou(100, akc.d, 1).c(0.2F).a(h).c("mushroom").d("mushroom_block");
  public static final aqz bu = new aqy(101, "iron_bars", "iron_bars", akc.f, true).c(5.0F).b(10.0F).a(l).c("fenceIron");
  public static final aqz bv = new aqy(102, "glass", "glass_pane_top", akc.s, false).c(0.3F).a(m).c("thinGlass");
  public static final aqz bw = new apg(103).c(1.0F).a(h).c("melon").d("melon");
  public static final aqz bx = new aqq(104, bf).c(0.0F).a(h).c("pumpkinStem").d("pumpkin_stem");
  public static final aqz by = new aqq(105, bw).c(0.0F).a(h).c("pumpkinStem").d("melon_stem");
  public static final aqz bz = new arm(106).c(0.2F).a(j).c("vine").d("vine");
  public static final aqz bA = new aog(107).c(2.0F).b(5.0F).a(h).c("fenceGate");
  public static final aqz bB = new aqp(108, aq, 0).c("stairsBrick");
  public static final aqz bC = new aqp(109, br, 0).c("stairsStoneBrickSmooth");
  public static final apk bD = (apk)new apk(110).c(0.6F).a(j).c("mycel").d("mycelium");
  public static final aqz bE = new aro(111).c(0.0F).a(j).c("waterlily").d("waterlily");
  public static final aqz bF = new aqz(112, akc.e).c(2.0F).b(10.0F).a(k).c("netherBrick").a(ww.b).d("nether_brick");
  public static final aqz bG = new aoh(113, "nether_brick", akc.e).c(2.0F).b(10.0F).a(k).c("netherFence");
  public static final aqz bH = new aqp(114, bF, 0).c("stairsNetherBrick");
  public static final aqz bI = new apl(115).c("netherStalk").d("nether_wart");
  public static final aqz bJ = new aoc(116).c(5.0F).b(2000.0F).c("enchantmentTable").d("enchanting_table");
  public static final aqz bK = new and(117).c(0.5F).a(0.125F).c("brewingStand").d("brewing_stand");
  public static final anj bL = (anj)new anj(118).c(2.0F).c("cauldron").d("cauldron");
  public static final aqz bM = new aqw(119, akc.D).c(-1.0F).b(6000000.0F);
  public static final aqz bN = new aqx(120).a(m).a(0.125F).c(-1.0F).c("endPortalFrame").b(6000000.0F).a(ww.c).d("endframe");
  

  public static final aqz bO = new aqz(121, akc.e).c(3.0F).b(15.0F).a(k).c("whiteStone").a(ww.b).d("end_stone");
  public static final aqz bP = new aob(122).c(3.0F).b(15.0F).a(k).a(0.125F).c("dragonEgg").d("dragon_egg");
  public static final aqz bQ = new aqd(123, false).c(0.3F).a(m).c("redstoneLight").a(ww.d).d("redstone_lamp_off");
  public static final aqz bR = new aqd(124, true).c(0.3F).a(m).c("redstoneLight").d("redstone_lamp_on");
  public static final aop bS = (aop)new ars(125, true).c(2.0F).b(5.0F).a(h).c("woodSlab");
  public static final aop bT = (aop)new ars(126, false).c(2.0F).b(5.0F).a(h).c("woodSlab");
  public static final aqz bU = new anm(127).c(0.2F).b(5.0F).a(h).c("cocoa").d("cocoa");
  public static final aqz bV = new aqp(128, V, 0).c("stairsSandStone");
  public static final aqz bW = new apr(129).c(3.0F).b(5.0F).a(k).c("oreEmerald").d("emerald_ore");
  public static final aqz bX = new aod(130).c(22.5F).b(1000.0F).a(k).c("enderChest").a(0.5F);
  public static final ark bY = (ark)new ark(131).c("tripWireSource").d("trip_wire_source");
  public static final aqz bZ = new arl(132).c("tripWire").d("trip_wire");
  public static final aqz ca = new aph(133).c(5.0F).b(10.0F).a(l).c("blockEmerald").d("emerald_block");
  public static final aqz cb = new aqp(134, C, 1).c("stairsWoodSpruce");
  public static final aqz cc = new aqp(135, C, 2).c("stairsWoodBirch");
  public static final aqz cd = new aqp(136, C, 3).c("stairsWoodJungle");
  public static final aqz ce = new ano(137).r().b(6000000.0F).c("commandBlock").d("command_block");
  public static final ana cf = (ana)new ana(138).c("beacon").a(1.0F).d("beacon");
  public static final aqz cg = new arn(139, B).c("cobbleWall");
  public static final aqz ch = new aoj(140).c(0.0F).a(g).c("flowerPot").d("flower_pot");
  public static final aqz ci = new ani(141).c("carrots").d("carrots");
  public static final aqz cj = new apt(142).c("potatoes").d("potatoes");
  public static final aqz ck = new arr(143).c(0.5F).a(h).c("button");
  public static final aqz cl = new aqk(144).c(1.0F).a(k).c("skull").d("skull");
  public static final aqz cm = new amv(145).c(5.0F).a(r).b(2000.0F).c("anvil");
  public static final aqz cn = new ank(146, 1).c(2.5F).a(h).c("chestTrap");
  public static final aqz co = new arq(147, "gold_block", akc.f, 64).c(0.5F).a(h).c("weightedPlate_light");
  public static final aqz cp = new arq(148, "iron_block", akc.f, 640).c(0.5F).a(h).c("weightedPlate_heavy");
  public static final anp cq = (anp)new anp(149, false).c(0.0F).a(h).c("comparator").C().d("comparator_off");
  public static final anp cr = (anp)new anp(150, true).c(0.0F).a(0.625F).a(h).c("comparator").C().d("comparator_on");
  public static final ans cs = (ans)new ans(151).c(0.2F).a(h).c("daylightDetector").d("daylight_detector");
  public static final aqz ct = new apu(152).c(5.0F).b(10.0F).a(l).c("blockRedstone").d("redstone_block");
  public static final aqz cu = new apr(153).c(3.0F).b(5.0F).a(k).c("netherquartz").d("quartz_ore");
  public static final aot cv = (aot)new aot(154).c(3.0F).b(8.0F).a(h).c("hopper").d("hopper");
  public static final aqz cw = new apz(155).a(k).c(0.8F).c("quartzBlock").d("quartz_block");
  public static final aqz cx = new aqp(156, cw, 0).c("stairsQuartz");
  public static final aqz cy = new apv(157).c(0.7F).a(l).c("activatorRail").d("rail_activator");
  public static final aqz cz = new aoa(158).c(3.5F).a(k).c("dropper").d("dropper");
  public static final aqz cA = new ann(159, akc.e).c(1.25F).b(7.0F).a(k).c("clayHardenedStained").d("hardened_clay_stained");
  public static final aqz cB = new aor(170).c(0.5F).a(j).c("hayBlock").a(ww.b).d("hay_block");
  public static final aqz cC = new aru(171).c(0.1F).a(n).c("woolCarpet").k(0);
  public static final aqz cD = new aqz(172, akc.e).c(1.25F).b(7.0F).a(k).c("clayHardened").a(ww.b).d("hardened_clay");
  public static final aqz cE = new aqz(173, akc.e).c(5.0F).b(10.0F).a(k).c("blockCoal").a(ww.b).d("coal_block");
  


  public final int cF;
  


  public float cG;
  

  public float cH;
  

  protected boolean cI = true;
  



  protected boolean cJ = true;
  

  protected boolean cK;
  

  protected boolean cL;
  

  protected double cM;
  

  protected double cN;
  

  protected double cO;
  

  protected double cP;
  

  protected double cQ;
  

  protected double cR;
  

  public ard cS;
  

  public float cT;
  

  public final akc cU;
  

  public float cV;
  

  private String b;
  

  @SideOnly(Side.CLIENT)
  protected ms cW;
  

  public aqz(int par1, akc par2Material)
  {
    cS = g;
    cT = 1.0F;
    cV = 0.6F;
    
    if (s[par1] != null)
    {
      throw new IllegalArgumentException("Slot " + par1 + " is already occupied by " + s[par1] + " when adding " + this);
    }
    

    cU = par2Material;
    s[par1] = this;
    cF = par1;
    a(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
    t[par1] = c();
    u[par1] = (c() ? 'ÿ' : 0);
    v[par1] = (!par2Material.b() ? 1 : false);
  }
  










  public aqz a(ard par1StepSound)
  {
    cS = par1StepSound;
    return this;
  }
  



  public aqz k(int par1)
  {
    u[cF] = par1;
    return this;
  }
  




  public aqz a(float par1)
  {
    w[cF] = ((int)(15.0F * par1));
    return this;
  }
  



  public aqz b(float par1)
  {
    cH = (par1 * 3.0F);
    return this;
  }
  
  public static boolean l(int par0)
  {
    aqz block = s[par0];
    return block != null;
  }
  



  public boolean b()
  {
    return true;
  }
  
  public boolean b(acf par1IBlockAccess, int par2, int par3, int par4)
  {
    return !cU.c();
  }
  



  public int d()
  {
    return 0;
  }
  



  public aqz c(float par1)
  {
    cG = par1;
    
    if (cH < par1 * 5.0F)
    {
      cH = (par1 * 5.0F);
    }
    
    return this;
  }
  



  public aqz r()
  {
    c(-1.0F);
    return this;
  }
  



  public float l(abw par1World, int par2, int par3, int par4)
  {
    return cG;
  }
  



  public aqz b(boolean par1)
  {
    cK = par1;
    return this;
  }
  




  public boolean s()
  {
    return cK;
  }
  
  @Deprecated
  public boolean t()
  {
    return hasTileEntity(0);
  }
  



  public final void a(float par1, float par2, float par3, float par4, float par5, float par6)
  {
    cM = par1;
    cN = par2;
    cO = par3;
    cP = par4;
    cQ = par5;
    cR = par6;
  }
  




  @SideOnly(Side.CLIENT)
  public float f(acf par1IBlockAccess, int par2, int par3, int par4)
  {
    return par1IBlockAccess.i(par2, par3, par4, getLightValue(par1IBlockAccess, par2, par3, par4));
  }
  




  @SideOnly(Side.CLIENT)
  public int e(acf par1IBlockAccess, int par2, int par3, int par4)
  {
    return par1IBlockAccess.h(par2, par3, par4, getLightValue(par1IBlockAccess, par2, par3, par4));
  }
  





  @SideOnly(Side.CLIENT)
  public boolean a(acf par1IBlockAccess, int par2, int par3, int par4, int par5)
  {
    return (par5 == 0) && (cN > 0.0D);
  }
  




  public boolean a_(acf par1IBlockAccess, int par2, int par3, int par4, int par5)
  {
    return par1IBlockAccess.g(par2, par3, par4).a();
  }
  




  @SideOnly(Side.CLIENT)
  public ms b_(acf par1IBlockAccess, int par2, int par3, int par4, int par5)
  {
    return a(par5, par1IBlockAccess.h(par2, par3, par4));
  }
  




  @SideOnly(Side.CLIENT)
  public ms a(int par1, int par2)
  {
    return cW;
  }
  




  public void a(abw par1World, int par2, int par3, int par4, asx par5AxisAlignedBB, List par6List, nn par7Entity)
  {
    asx axisalignedbb1 = b(par1World, par2, par3, par4);
    
    if ((axisalignedbb1 != null) && (par5AxisAlignedBB.b(axisalignedbb1)))
    {
      par6List.add(axisalignedbb1);
    }
  }
  




  @SideOnly(Side.CLIENT)
  public final ms m(int par1)
  {
    return a(par1, 0);
  }
  




  @SideOnly(Side.CLIENT)
  public asx c_(abw par1World, int par2, int par3, int par4)
  {
    return asx.a().a(par2 + cM, par3 + cN, par4 + cO, par2 + cP, par3 + cQ, par4 + cR);
  }
  




  public asx b(abw par1World, int par2, int par3, int par4)
  {
    return asx.a().a(par2 + cM, par3 + cN, par4 + cO, par2 + cP, par3 + cQ, par4 + cR);
  }
  




  public boolean c()
  {
    return true;
  }
  




  public boolean a(int par1, boolean par2)
  {
    return m();
  }
  



  public boolean m()
  {
    return true;
  }
  


























  public int a(abw par1World)
  {
    return 10;
  }
  










  public void a(abw par1World, int par2, int par3, int par4, int par5, int par6)
  {
    if ((hasTileEntity(par6)) && (!(this instanceof amw)))
    {
      par1World.s(par2, par3, par4);
    }
  }
  



  public int a(Random par1Random)
  {
    return 1;
  }
  



  public int a(int par1, Random par2Random, int par3)
  {
    return cF;
  }
  







  public float a(uf par1EntityPlayer, abw par2World, int par3, int par4, int par5)
  {
    float var6 = l(par2World, par3, par4, par5);
    
    if (var6 < 0.0F)
    {
      return 0.0F;
    }
    
    float psize = par1EntityPlayer.getSizeMultiplier();
    
    if (par1EntityPlayer.by() != null)
    {
      psize = par1EntityPlayer.getSizeMultiplierRoot();
    }
    
    if (!par1EntityPlayer.a(this))
    {
      return par1EntityPlayer.a(this, false) / var6 / 100.0F * psize;
    }
    

    float tmp = cG;
    
    if ((var6 == 0.0F) && (d() != 5) && (par1EntityPlayer.getSizeMultiplier() < 0.5F))
    {


      cG = (var6 = 0.2F);
    }
    
    float strength = par1EntityPlayer.a(this, true) / var6 / 30.0F * psize;
    cG = tmp;
    return strength;
  }
  




  public final void c(abw par1World, int par2, int par3, int par4, int par5, int par6)
  {
    a(par1World, par2, par3, par4, par5, 1.0F, par6);
  }
  



  public void a(abw par1World, int par2, int par3, int par4, int par5, float par6, int par7)
  {
    if (!I)
    {
      ArrayList<ye> items = getBlockDropped(par1World, par2, par3, par4, par5, par7);
      par6 = ForgeEventFactory.fireBlockHarvesting(items, par1World, this, par2, par3, par4, par5, par7, par6, false, (uf)harvesters.get());
      
      for (ye item : items)
      {
        if (s.nextFloat() <= par6)
        {
          b(par1World, par2, par3, par4, item);
        }
      }
    }
  }
  



  protected void b(abw par1World, int par2, int par3, int par4, ye par5ItemStack)
  {
    if ((!I) && (par1World.O().b("doTileDrops")))
    {
      float f = 0.7F;
      double d0 = s.nextFloat() * f + (1.0F - f) * 0.5D;
      double d1 = s.nextFloat() * f + (1.0F - f) * 0.5D;
      double d2 = s.nextFloat() * f + (1.0F - f) * 0.5D;
      ss entityitem = new ss(par1World, par2 + d0, par3 + d1, par4 + d2, par5ItemStack);
      b = 10;
      par1World.d(entityitem);
    }
  }
  



  public void j(abw par1World, int par2, int par3, int par4, int par5)
  {
    if (!I)
    {
      while (par5 > 0)
      {
        int i1 = oa.a(par5);
        par5 -= i1;
        par1World.d(new oa(par1World, par2 + 0.5D, par3 + 0.5D, par4 + 0.5D, i1));
      }
    }
  }
  



  public int a(int par1)
  {
    return 0;
  }
  



  public float a(nn par1Entity)
  {
    return cH / 5.0F;
  }
  




  public ata a(abw par1World, int par2, int par3, int par4, atc par5Vec3, atc par6Vec3)
  {
    a(par1World, par2, par3, par4);
    par5Vec3 = par5Vec3.c(-par2, -par3, -par4);
    par6Vec3 = par6Vec3.c(-par2, -par3, -par4);
    atc vec32 = par5Vec3.b(par6Vec3, cM);
    atc vec33 = par5Vec3.b(par6Vec3, cP);
    atc vec34 = par5Vec3.c(par6Vec3, cN);
    atc vec35 = par5Vec3.c(par6Vec3, cQ);
    atc vec36 = par5Vec3.d(par6Vec3, cO);
    atc vec37 = par5Vec3.d(par6Vec3, cR);
    
    if (!a(vec32))
    {
      vec32 = null;
    }
    
    if (!a(vec33))
    {
      vec33 = null;
    }
    
    if (!b(vec34))
    {
      vec34 = null;
    }
    
    if (!b(vec35))
    {
      vec35 = null;
    }
    
    if (!c(vec36))
    {
      vec36 = null;
    }
    
    if (!c(vec37))
    {
      vec37 = null;
    }
    
    atc vec38 = null;
    
    if ((vec32 != null) && ((vec38 == null) || (par5Vec3.e(vec32) < par5Vec3.e(vec38))))
    {
      vec38 = vec32;
    }
    
    if ((vec33 != null) && ((vec38 == null) || (par5Vec3.e(vec33) < par5Vec3.e(vec38))))
    {
      vec38 = vec33;
    }
    
    if ((vec34 != null) && ((vec38 == null) || (par5Vec3.e(vec34) < par5Vec3.e(vec38))))
    {
      vec38 = vec34;
    }
    
    if ((vec35 != null) && ((vec38 == null) || (par5Vec3.e(vec35) < par5Vec3.e(vec38))))
    {
      vec38 = vec35;
    }
    
    if ((vec36 != null) && ((vec38 == null) || (par5Vec3.e(vec36) < par5Vec3.e(vec38))))
    {
      vec38 = vec36;
    }
    
    if ((vec37 != null) && ((vec38 == null) || (par5Vec3.e(vec37) < par5Vec3.e(vec38))))
    {
      vec38 = vec37;
    }
    
    if (vec38 == null)
    {
      return null;
    }
    

    byte b0 = -1;
    
    if (vec38 == vec32)
    {
      b0 = 4;
    }
    
    if (vec38 == vec33)
    {
      b0 = 5;
    }
    
    if (vec38 == vec34)
    {
      b0 = 0;
    }
    
    if (vec38 == vec35)
    {
      b0 = 1;
    }
    
    if (vec38 == vec36)
    {
      b0 = 2;
    }
    
    if (vec38 == vec37)
    {
      b0 = 3;
    }
    
    return new ata(par2, par3, par4, b0, vec38.c(par2, par3, par4));
  }
  




  private boolean a(atc par1Vec3)
  {
    return par1Vec3 != null;
  }
  



  private boolean b(atc par1Vec3)
  {
    return par1Vec3 != null;
  }
  



  private boolean c(atc par1Vec3)
  {
    return par1Vec3 != null;
  }
  





  public boolean a(abw par1World, int par2, int par3, int par4, int par5, ye par6ItemStack)
  {
    return c(par1World, par2, par3, par4, par5);
  }
  




  @SideOnly(Side.CLIENT)
  public int n()
  {
    return 0;
  }
  



  public boolean c(abw par1World, int par2, int par3, int par4, int par5)
  {
    return c(par1World, par2, par3, par4);
  }
  



  public boolean c(abw par1World, int par2, int par3, int par4)
  {
    int l = par1World.a(par2, par3, par4);
    aqz block = s[l];
    return (block == null) || (block.isBlockReplaceable(par1World, par2, par3, par4));
  }
  



  public boolean a(abw par1World, int par2, int par3, int par4, uf par5EntityPlayer, int par6, float par7, float par8, float par9)
  {
    return false;
  }
  



  public void b(abw par1World, int par2, int par3, int par4, nn par5Entity)
  {
    if ((!I) && (par5Entity.isHuge()) && (!par5Entity.ah()))
    {
      if ((!(par5Entity instanceof uf)) && (!par1World.O().b("mobGriefing")))
      {
        return;
      }
      
      if (((par5Entity instanceof uf)) && (!par1World.a((uf)par5Entity, par2, par3, par4)))
      {
        return;
      }
      

      int i = par1World.a(par2, par3 + 1, par4);
      akc m = par1World.g(par2, par3 + 1, par4);
      
      if ((s[i] != null) && ((m == akc.k) || (m == akc.l)))
      {
        s[i].c(par1World, par2, par3 + 1, par4, par1World.h(par2, par3 + 1, par4), 0);
        par1World.i(par2, par3 + 1, par4);
      }
      else if (!(par5Entity instanceof sb))
      {
        akc m2 = par1World.g(par2, par3, par4);
        
        if ((m == akc.x) || (m2 == akc.x))
        {
          int amt = (int)par5Entity.getSizeMultiplierRoot();
          int yoff = m == akc.x ? par3 + 1 : par3;
          
          while ((yoff >= par3) && (amt > 0) && (par1World.g(par2, yoff, par4) == akc.x))
          {
            i = par1World.a(par2, yoff, par4);
            int d = (par1World.h(par2, yoff, par4) & 0x7) + 1;
            
            if (d <= amt)
            {
              par1World.i(par2, yoff, par4);
            }
            else
            {
              par1World.f(par2, yoff, par4, i, d - amt - 1, 3);
            }
            
            amt -= d;
            yoff--;
          }
        }
      }
    }
  }
  



  public int a(abw par1World, int par2, int par3, int par4, int par5, float par6, float par7, float par8, int par9)
  {
    return par9;
  }
  


















  public final double u()
  {
    return cM;
  }
  



  public final double v()
  {
    return cP;
  }
  



  public final double w()
  {
    return cN;
  }
  



  public final double x()
  {
    return cQ;
  }
  



  public final double y()
  {
    return cO;
  }
  



  public final double z()
  {
    return cR;
  }
  
  @SideOnly(Side.CLIENT)
  public int o()
  {
    return 16777215;
  }
  




  @SideOnly(Side.CLIENT)
  public int b(int par1)
  {
    return 16777215;
  }
  





  public int b(acf par1IBlockAccess, int par2, int par3, int par4, int par5)
  {
    return 0;
  }
  





  @SideOnly(Side.CLIENT)
  public int c(acf par1IBlockAccess, int par2, int par3, int par4)
  {
    return 16777215;
  }
  



  public boolean f()
  {
    return false;
  }
  









  public int c(acf par1IBlockAccess, int par2, int par3, int par4, int par5)
  {
    return 0;
  }
  





  private ThreadLocal<uf> harvesters = new ThreadLocal();
  



  public void a(abw par1World, uf par2EntityPlayer, int par3, int par4, int par5, int par6)
  {
    par2EntityPlayer.a(la.C[cF], 1);
    par2EntityPlayer.a(0.025F / par2EntityPlayer.getSizeMultiplierRoot());
    
    if ((canSilkHarvest(par1World, par2EntityPlayer, par3, par4, par5, par6)) && (aaw.e(par2EntityPlayer)))
    {
      ArrayList<ye> items = new ArrayList();
      ye itemstack = d_(par6);
      
      if (itemstack != null)
      {
        items.add(itemstack);
      }
      ForgeEventFactory.fireBlockHarvesting(items, par1World, this, par3, par4, par5, par6, 0, 1.0F, true, par2EntityPlayer);
      for (ye is : items)
      {
        b(par1World, par3, par4, par5, is);
      }
    }
    else
    {
      harvesters.set(par2EntityPlayer);
      int i1 = aaw.f(par2EntityPlayer);
      c(par1World, par3, par4, par5, par6, i1);
      harvesters.set(null);
    }
  }
  
  private int silk_check_meta = -1;
  


  protected boolean r_()
  {
    return (b()) && (!hasTileEntity(silk_check_meta));
  }
  




  protected ye d_(int par1)
  {
    int j = 0;
    
    if ((cF >= 0) && (cF < yc.g.length) && (yc.g[cF].n()))
    {
      j = par1;
    }
    
    return new ye(cF, 1, j);
  }
  



  public int a(int par1, Random par2Random)
  {
    return a(par2Random);
  }
  



  public boolean f(abw par1World, int par2, int par3, int par4)
  {
    return true;
  }
  










  public aqz c(String par1Str)
  {
    b = par1Str;
    return this;
  }
  



  public String A()
  {
    return bu.a(a() + ".name");
  }
  



  public String a()
  {
    return "tile." + b;
  }
  




  public boolean b(abw par1World, int par2, int par3, int par4, int par5, int par6)
  {
    return false;
  }
  



  public boolean B()
  {
    return cJ;
  }
  



  protected aqz C()
  {
    cJ = false;
    return this;
  }
  




  public int h()
  {
    return cU.m();
  }
  




  @SideOnly(Side.CLIENT)
  public float i(acf par1IBlockAccess, int par2, int par3, int par4)
  {
    return par1IBlockAccess.u(par2, par3, par4) ? 0.2F : 1.0F;
  }
  



  public void a(abw par1World, int par2, int par3, int par4, nn par5Entity, float par6)
  {
    if ((!I) && (par5Entity.isHuge()) && (!par5Entity.ah()) && (GulliverEnvoy.canSizeGrief(par5Entity)) && ((!(par5Entity instanceof uf)) || (par1World.a((uf)par5Entity, par2, par3, par4))))
    {

      int i = par1World.a(par2, par3, par4);
      akc m = par1World.g(par2, par3, par4);
      
      if ((s[i] != null) && ((m == akc.s) || (m == akc.w)))
      {
        s[i].c(par1World, par2, par3, par4, par1World.h(par2, par3, par4), 0);
        par1World.c(par2, par3, par4, m == akc.w ? FcF : 0);
        par1World.e(2001, par2, par3, par4, scF + (par1World.h(par2, par3, par4) << 12));
      }
      else if ((i == brcF) && (par1World.h(par2, par3, par4) == 0) && (s.nextInt(5) == 0))
      {

        par1World.f(par2, par3, par4, i, 2, 3);
        par1World.e(2001, par2, par3, par4, scF + (par1World.h(par2, par3, par4) << 12));
      }
    }
    
    if ((!I) && (par5Entity.isHuge()))
    {
      if ((!(par5Entity instanceof uf)) && (!par1World.O().b("mobGriefing")))
      {
        return;
      }
      
      if (((par5Entity instanceof uf)) && (!par1World.a((uf)par5Entity, par2, par3, par4)))
      {
        return;
      }
      

      int i = par1World.a(par2, par3 + 1, par4);
      akc m = par1World.g(par2, par3 + 1, par4);
      
      if ((s[i] != null) && ((m == akc.k) || (m == akc.l)))
      {
        s[i].c(par1World, par2, par3 + 1, par4, par1World.h(par2, par3 + 1, par4), 0);
        par1World.i(par2, par3 + 1, par4);
      }
      else
      {
        akc m2 = par1World.g(par2, par3, par4);
        

        if ((m2 == akc.b) && (i == 0))
        {
          par1World.c(par2, par3, par4, AcF);
        }
        
        if ((m == akc.x) || (m2 == akc.x))
        {
          int amt = (int)par5Entity.getSizeMultiplierRoot();
          int yoff = m == akc.x ? par3 + 1 : par3;
          
          while ((yoff >= par3) && (amt > 0) && (par1World.g(par2, yoff, par4) == akc.x))
          {
            i = par1World.a(par2, yoff, par4);
            int d = (par1World.h(par2, yoff, par4) & 0x7) + 1;
            
            if (d <= amt)
            {
              par1World.i(par2, yoff, par4);
            }
            else
            {
              par1World.f(par2, yoff, par4, i, d - amt - 1, 3);
            }
            
            amt -= d;
            yoff--;
          }
        }
      }
    }
  }
  



  @SideOnly(Side.CLIENT)
  public int d(abw par1World, int par2, int par3, int par4)
  {
    return cF;
  }
  



  public int h(abw par1World, int par2, int par3, int par4)
  {
    return a(par1World.h(par2, par3, par4));
  }
  




  @SideOnly(Side.CLIENT)
  public void a(int par1, ww par2CreativeTabs, List par3List)
  {
    par3List.add(new ye(par1, 1, 0));
  }
  



  public aqz a(ww par1CreativeTabs)
  {
    a = par1CreativeTabs;
    return this;
  }
  









  @SideOnly(Side.CLIENT)
  public ww D()
  {
    return a;
  }
  















  @SideOnly(Side.CLIENT)
  public boolean t_()
  {
    return false;
  }
  
  public boolean l()
  {
    return true;
  }
  



  public boolean a(abr par1Explosion)
  {
    return true;
  }
  




  public boolean i(int par1)
  {
    return cF == par1;
  }
  



  public static boolean b(int par0, int par1)
  {
    return par0 == par1;
  }
  




  public boolean q_()
  {
    return false;
  }
  




  public int b_(abw par1World, int par2, int par3, int par4, int par5)
  {
    return 0;
  }
  
  public aqz d(String par1Str)
  {
    f = par1Str;
    return this;
  }
  
  @SideOnly(Side.CLIENT)
  protected String E()
  {
    return f == null ? "MISSING_ICON_TILE_" + cF + "_" + b : f;
  }
  





  @SideOnly(Side.CLIENT)
  public void a(mt par1IconRegister)
  {
    cW = par1IconRegister.a(E());
  }
  




  @SideOnly(Side.CLIENT)
  public String u_()
  {
    return null;
  }
  
  static
  {
    yc.g[agcF] = new zm(agcF - 256).b("cloth");
    yc.g[cAcF] = new zm(cAcF - 256).b("clayHardenedStained");
    yc.g[cCcF] = new zm(cCcF - 256).b("woolCarpet");
    yc.g[OcF] = new yl(OcF - 256, O, arj.b).b("log");
    yc.g[CcF] = new yl(CcF - 256, C, art.a).b("wood");
    yc.g[bqcF] = new yl(bqcF - 256, bq, aqs.a).b("monsterStoneEgg");
    yc.g[brcF] = new yl(brcF - 256, br, aql.a).b("stonebricksmooth");
    yc.g[VcF] = new yl(VcF - 256, V, aqh.a).b("sandStone");
    yc.g[cwcF] = new yl(cwcF - 256, cw, apz.a).b("quartzBlock");
    yc.g[apcF] = new zg(apcF - 256, ap, ao, false).b("stoneSlab");
    yc.g[aocF] = new zg(aocF - 256, ap, ao, true).b("stoneSlab");
    yc.g[bTcF] = new zg(bTcF - 256, bT, bS, false).b("woodSlab");
    yc.g[bScF] = new zg(bScF - 256, bT, bS, true).b("woodSlab");
    yc.g[DcF] = new yl(DcF - 256, D, aqi.a).b("sapling");
    yc.g[PcF] = new yf(PcF - 256).b("leaves");
    yc.g[bzcF] = new wu(bzcF - 256, false);
    
    yc.g[alcF] = new zh(alcF - 256).c("+0+1+2-3&4-4+13").b("mushroom");
    yc.g[akcF] = new zh(akcF - 256).c("+0+1+2+3&4-4+13").b("mushroom");
    yc.g[accF] = new wu(accF - 256, true).a(new String[] { "shrub", "grass", "fern" });
    yc.g[aXcF] = new zc(aXcF - 256, aX);
    yc.g[bEcF] = new zk(bEcF - 256);
    yc.g[aecF] = new yo(aecF - 256);
    yc.g[aacF] = new yo(aacF - 256);
    yc.g[cgcF] = new yl(cgcF - 256, cg, arn.a).b("cobbleWall");
    yc.g[cmcF] = new wg(cm).b("anvil");
    
    for (int i = 0; i < 256; i++)
    {
      if (s[i] != null)
      {
        if (yc.g[i] == null)
        {
          yc.g[i] = new zh(i - 256);
          s[i].s_();
        }
        
        boolean flag = false;
        
        if ((i > 0) && (s[i].d() == 10))
        {
          flag = true;
        }
        
        if ((i > 0) && ((s[i] instanceof aop)))
        {
          flag = true;
        }
        
        if (i == aFcF)
        {
          flag = true;
        }
        
        if (v[i] != 0)
        {
          flag = true;
        }
        
        if (u[i] == 0)
        {
          flag = true;
        }
        
        x[i] = flag;
      }
    }
    
    v[0] = true;
    la.b();
  }
  










  public int getLightValue(acf world, int x, int y, int z)
  {
    aqz block = s[world.a(x, y, z)];
    if ((block != null) && (block != this))
    {
      return block.getLightValue(world, x, y, z);
    }
    return w[cF];
  }
  










  public boolean isLadder(abw world, int x, int y, int z, of entity)
  {
    return false;
  }
  











  public boolean isBlockNormalCube(abw world, int x, int y, int z)
  {
    return (cU.k()) && (b()) && (!f());
  }
  










  public boolean isBlockSolidOnSide(abw world, int x, int y, int z, ForgeDirection side)
  {
    int meta = world.h(x, y, z);
    if ((this instanceof aop))
    {
      return (((meta & 0x8) == 8) && (side == ForgeDirection.UP)) || (c());
    }
    if ((this instanceof aof))
    {
      return (side != ForgeDirection.DOWN) && (side != ForgeDirection.UP);
    }
    if ((this instanceof aqp))
    {
      boolean flipped = (meta & 0x4) != 0;
      return ((meta & 0x3) + side.ordinal() == 5) || ((side == ForgeDirection.UP) && (flipped));
    }
    if (((this instanceof aot)) && (side == ForgeDirection.UP))
    {
      return true;
    }
    if ((this instanceof apu))
    {
      return true;
    }
    return isBlockNormalCube(world, x, y, z);
  }
  










  public boolean isBlockReplaceable(abw world, int x, int y, int z)
  {
    return cU.j();
  }
  










  public boolean isBlockBurning(abw world, int x, int y, int z)
  {
    return false;
  }
  












  public boolean isAirBlock(abw world, int x, int y, int z)
  {
    return false;
  }
  







  public boolean canHarvestBlock(uf player, int meta)
  {
    return ForgeHooks.canHarvestBlock(this, player, meta);
  }
  


















  public boolean removeBlockByPlayer(abw world, uf player, int x, int y, int z)
  {
    return world.i(x, y, z);
  }
  
























  public int getFlammability(acf world, int x, int y, int z, int metadata, ForgeDirection face)
  {
    return blockFlammability[cF];
  }
  












  public boolean isFlammable(acf world, int x, int y, int z, int metadata, ForgeDirection face)
  {
    return getFlammability(world, x, y, z, metadata, face) > 0;
  }
  












  public int getFireSpreadSpeed(abw world, int x, int y, int z, int metadata, ForgeDirection face)
  {
    return blockFireSpreadSpeed[cF];
  }
  













  public boolean isFireSource(abw world, int x, int y, int z, int metadata, ForgeDirection side)
  {
    if ((cF == bgcF) && (side == ForgeDirection.UP))
    {
      return true;
    }
    if (((t instanceof ael)) && (cF == EcF) && (side == ForgeDirection.UP))
    {
      return true;
    }
    return false;
  }
  






  public static void setBurnProperties(int id, int encouragement, int flammability)
  {
    blockFireSpreadSpeed[id] = encouragement;
    blockFlammability[id] = flammability;
  }
  
  private boolean isTileProvider = this instanceof aoe;
  









  public boolean hasTileEntity(int metadata)
  {
    return isTileProvider;
  }
  








  public asp createTileEntity(abw world, int metadata)
  {
    if (isTileProvider)
    {
      return ((aoe)this).b(world);
    }
    return null;
  }
  









  public int quantityDropped(int meta, int fortune, Random random)
  {
    return a(fortune, random);
  }
  











  public ArrayList<ye> getBlockDropped(abw world, int x, int y, int z, int metadata, int fortune)
  {
    ArrayList<ye> ret = new ArrayList();
    
    int count = quantityDropped(metadata, fortune, s);
    for (int i = 0; i < count; i++)
    {
      int id = a(metadata, s, fortune);
      if (id > 0)
      {
        ret.add(new ye(id, 1, a(metadata)));
      }
    }
    return ret;
  }
  











  public boolean canSilkHarvest(abw world, uf player, int x, int y, int z, int metadata)
  {
    silk_check_meta = metadata;
    boolean ret = r_();
    silk_check_meta = 0;
    return ret;
  }
  











  public boolean canCreatureSpawn(oh type, abw world, int x, int y, int z)
  {
    int meta = world.h(x, y, z);
    if ((this instanceof aqt))
    {
      return ((meta & 0x8) == 8) || (c());
    }
    if ((this instanceof aqp))
    {
      return (meta & 0x4) != 0;
    }
    return isBlockSolidOnSide(world, x, y, z, ForgeDirection.UP);
  }
  












  public boolean isBed(abw world, int x, int y, int z, of player)
  {
    return cF == XcF;
  }
  











  public t getBedSpawnPosition(abw world, int x, int y, int z, uf player)
  {
    return anb.b(world, x, y, z, 0);
  }
  










  public void setBedOccupied(abw world, int x, int y, int z, uf player, boolean occupied)
  {
    anb.a(world, x, y, z, occupied);
  }
  










  public int getBedDirection(acf world, int x, int y, int z)
  {
    return anb.j(world.h(x, y, z));
  }
  









  public boolean isBedFoot(acf world, int x, int y, int z)
  {
    return anb.f_(world.h(x, y, z));
  }
  



















  public boolean canSustainLeaves(abw world, int x, int y, int z)
  {
    return false;
  }
  









  public boolean isLeaves(abw world, int x, int y, int z)
  {
    return false;
  }
  









  public boolean canBeReplacedByLeaves(abw world, int x, int y, int z)
  {
    return t[cF] == 0;
  }
  








  public boolean isWood(abw world, int x, int y, int z)
  {
    return false;
  }
  











  public boolean isGenMineableReplaceable(abw world, int x, int y, int z, int target)
  {
    return cF == target;
  }
  













  public float getExplosionResistance(nn par1Entity, abw world, int x, int y, int z, double explosionX, double explosionY, double explosionZ)
  {
    return a(par1Entity);
  }
  











  public void onBlockExploded(abw world, int x, int y, int z, abr explosion)
  {
    world.i(x, y, z);
    a(world, x, y, z, explosion);
  }
  


















  public boolean canConnectRedstone(acf world, int x, int y, int z, int side)
  {
    return (s[cF].f()) && (side != -1);
  }
  










  public boolean canPlaceTorchOnTop(abw world, int x, int y, int z)
  {
    if (world.w(x, y, z))
    {
      return true;
    }
    

    int id = world.a(x, y, z);
    return (id == becF) || (id == bGcF) || (id == RcF) || (id == cgcF);
  }
  








  public boolean canRenderInPass(int pass)
  {
    return pass == n();
  }
  






  public ye getPickBlock(ata target, abw world, int x, int y, int z)
  {
    int id = d(world, x, y, z);
    
    if (id == 0)
    {
      return null;
    }
    
    yc item = yc.g[id];
    if (item == null)
    {
      return null;
    }
    
    return new ye(id, 1, h(world, x, y, z));
  }
  






  public boolean isBlockFoliage(abw world, int x, int y, int z)
  {
    return false;
  }
  











  @SideOnly(Side.CLIENT)
  public boolean addBlockHitEffects(abw worldObj, ata target, beh effectRenderer)
  {
    return false;
  }
  














  @SideOnly(Side.CLIENT)
  public boolean addBlockDestroyEffects(abw world, int x, int y, int z, int meta, beh effectRenderer)
  {
    return false;
  }
  



















  public boolean canSustainPlant(abw world, int x, int y, int z, ForgeDirection direction, IPlantable plant)
  {
    int plantID = plant.getPlantID(world, x, y + 1, z);
    EnumPlantType plantType = plant.getPlantType(world, x, y + 1, z);
    
    if ((plantID == bacF) && (cF == bacF))
    {
      return true;
    }
    
    if ((plantID == bccF) && (cF == bccF))
    {
      return true;
    }
    
    if (((plant instanceof ane)) && (((ane)plant).g_(cF)))
    {
      return true;
    }
    
    switch (aqz.1.$SwitchMap$net$minecraftforge$common$EnumPlantType[plantType.ordinal()]) {
    case 1: 
      return cF == JcF;
    case 2:  return cF == bhcF;
    case 3:  return cF == aFcF;
    case 4:  return isBlockSolidOnSide(world, x, y, z, ForgeDirection.UP);
    case 5:  return (cF == zcF) || (cF == AcF);
    case 6:  return (world.g(x, y, z) == akc.h) && (world.h(x, y, z) == 0);
    case 7: 
      boolean isBeach = (cF == zcF) || (cF == AcF) || (cF == JcF);
      boolean hasWater = (world.g(x - 1, y, z) == akc.h) || (world.g(x + 1, y, z) == akc.h) || (world.g(x, y, z - 1) == akc.h) || (world.g(x, y, z + 1) == akc.h);
      


      return (isBeach) && (hasWater);
    }
    
    return false;
  }
  

















  public void onPlantGrow(abw world, int x, int y, int z, int sourceX, int sourceY, int sourceZ)
  {
    if (cF == zcF)
    {
      world.f(x, y, z, AcF, 0, 2);
    }
  }
  











  public boolean isFertile(abw world, int x, int y, int z)
  {
    if (cF == aFcF)
    {
      return world.h(x, y, z) > 0;
    }
    
    return false;
  }
  














  public int getLightOpacity(abw world, int x, int y, int z)
  {
    return u[cF];
  }
  









  public boolean canEntityDestroy(abw world, int x, int y, int z, nn entity)
  {
    if ((entity instanceof sm))
    {
      return (cF != EcF) && (cF != bMcF) && (cF != bNcF);
    }
    if ((entity instanceof sk))
    {
      return canDragonDestroy(world, x, y, z);
    }
    
    return true;
  }
  
  @Deprecated
  public boolean canDragonDestroy(abw world, int x, int y, int z) {
    return (cF != aucF) && (cF != bOcF) && (cF != EcF);
  }
  












  public boolean isBeaconBase(abw worldObj, int x, int y, int z, int beaconX, int beaconY, int beaconZ)
  {
    return (cF == cacF) || (cF == amcF) || (cF == aCcF) || (cF == ancF);
  }
  













  public boolean rotateBlock(abw worldObj, int x, int y, int z, ForgeDirection axis)
  {
    return RotationHelper.rotateVanillaBlock(this, worldObj, x, y, z, axis);
  }
  









  public ForgeDirection[] getValidRotations(abw worldObj, int x, int y, int z)
  {
    return RotationHelper.getValidVanillaBlockRotations(this);
  }
  








  public float getEnchantPowerBonus(abw world, int x, int y, int z)
  {
    return cF == ascF ? 1.0F : 0.0F;
  }
  









  public boolean recolourBlock(abw world, int x, int y, int z, ForgeDirection side, int colour)
  {
    if (cF == agcF)
    {
      int meta = world.h(x, y, z);
      if (meta != colour)
      {
        world.b(x, y, z, colour, 3);
        return true;
      }
    }
    return false;
  }
  



  public int getExpDrop(abw world, int data, int enchantmentLevel)
  {
    return 0;
  }
  

















  public boolean weakTileChanges()
  {
    return false;
  }
  









  public boolean shouldCheckWeakPower(abw world, int x, int y, int z, int side)
  {
    return !l(world.a(x, y, z));
  }
  
  @Deprecated
  public float getFilledPercentage(abw world, int x, int y, int z) {
    return 1.0F;
  }
  
  public String getTextureBaseName()
  {
    return f;
  }
  
  protected void s_() {}
  
  public void a(abw par1World, int par2, int par3, int par4, Random par5Random) {}
  
  @SideOnly(Side.CLIENT)
  public void b(abw par1World, int par2, int par3, int par4, Random par5Random) {}
  
  public void g(abw par1World, int par2, int par3, int par4, int par5) {}
  
  public void a(abw par1World, int par2, int par3, int par4, int par5) {}
  
  public void a(abw par1World, int par2, int par3, int par4) {}
  
  public void a(abw par1World, int par2, int par3, int par4, abr par5Explosion) {}
  
  public void a(abw par1World, int par2, int par3, int par4, uf par5EntityPlayer) {}
  
  public void a(abw par1World, int par2, int par3, int par4, nn par5Entity, atc par6Vec3) {}
  
  public void a(acf par1IBlockAccess, int par2, int par3, int par4) {}
  
  public void a(abw par1World, int par2, int par3, int par4, nn par5Entity) {}
  
  public void g() {}
  
  public void a(abw par1World, int par2, int par3, int par4, of par5EntityLivingBase, ye par6ItemStack) {}
  
  public void k(abw par1World, int par2, int par3, int par4, int par5) {}
  
  public void a(abw par1World, int par2, int par3, int par4, int par5, uf par6EntityPlayer) {}
  
  public void l(abw par1World, int par2, int par3, int par4, int par5) {}
  
  public void g(abw par1World, int par2, int par3, int par4) {}
  
  @Deprecated
  public void addCreativeItems(ArrayList itemList) {}
  
  public void beginLeavesDecay(abw world, int x, int y, int z) {}
  
  public void onNeighborTileChange(abw world, int x, int y, int z, int tileX, int tileY, int tileZ) {}
}
