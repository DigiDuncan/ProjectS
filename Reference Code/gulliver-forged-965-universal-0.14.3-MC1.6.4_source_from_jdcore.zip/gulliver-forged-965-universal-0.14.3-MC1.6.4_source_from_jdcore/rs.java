import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.Iterator;
import java.util.List;
import java.util.Random;


































public class rs
  extends rp
  implements mp
{
  private static final nw bu = new rt();
  private static final or bv = new oy("horse.jumpStrength", 0.7D, 0.0D, 2.0D).a("Jump Strength").a(true);
  private static final String[] bw = { null, "textures/entity/horse/armor/horse_armor_iron.png", "textures/entity/horse/armor/horse_armor_gold.png", "textures/entity/horse/armor/horse_armor_diamond.png" };
  private static final String[] bx = { "", "meo", "goo", "dio" };
  private static final int[] by = { 0, 5, 7, 11 };
  private static final String[] bz = { "textures/entity/horse/horse_white.png", "textures/entity/horse/horse_creamy.png", "textures/entity/horse/horse_chestnut.png", "textures/entity/horse/horse_brown.png", "textures/entity/horse/horse_black.png", "textures/entity/horse/horse_gray.png", "textures/entity/horse/horse_darkbrown.png" };
  private static final String[] bA = { "hwh", "hcr", "hch", "hbr", "hbl", "hgr", "hdb" };
  private static final String[] bB = { null, "textures/entity/horse/horse_markings_white.png", "textures/entity/horse/horse_markings_whitefield.png", "textures/entity/horse/horse_markings_whitedots.png", "textures/entity/horse/horse_markings_blackdots.png" };
  private static final String[] bC = { "", "wo_", "wmo", "wdo", "bdo" };
  
  private int bD;
  
  private int bE;
  
  private int bF;
  
  public int bp;
  public int bq;
  protected boolean br;
  private uz bG;
  private boolean bH;
  protected int bs;
  protected float bt;
  private boolean bI;
  private float bJ;
  private float bK;
  private float bL;
  private float bM;
  private float bN;
  private float bO;
  private int bP;
  private String bQ;
  private String[] bR = new String[3];
  
  public rs(abw par1World)
  {
    super(par1World);
    a(1.4F, 1.6F);
    minLookSize = (this.minTargetSize = 0.1F);
    ag = false;
    l(false);
    k().a(true);
    c.a(0, new pp(this));
    c.a(1, new qj(this, 1.2D));
    c.a(1, new qq(this, 1.2D));
    c.a(2, new pk(this, 1.0D));
    c.a(4, new pr(this, 1.0D));
    c.a(6, new qm(this, 0.7D));
    c.a(7, new px(this, uf.class, 6.0F));
    c.a(8, new ql(this));
    cH();
  }
  
  protected void a()
  {
    super.a();
    ah.a(16, Integer.valueOf(0));
    ah.a(19, Byte.valueOf((byte)0));
    ah.a(20, Integer.valueOf(0));
    ah.a(21, String.valueOf(""));
    ah.a(22, Integer.valueOf(0));
  }
  
  public void p(int par1)
  {
    ah.b(19, Byte.valueOf((byte)par1));
    cJ();
  }
  



  public int bT()
  {
    return ah.a(19);
  }
  
  public void q(int par1)
  {
    ah.b(20, Integer.valueOf(par1));
    cJ();
  }
  
  public int bU()
  {
    return ah.c(20);
  }
  



  public String an()
  {
    if (bB())
    {
      return bA();
    }
    

    int i = bT();
    
    switch (i)
    {
    case 0: 
    default: 
      return bu.a("entity.horse.name");
    case 1: 
      return bu.a("entity.donkey.name");
    case 2: 
      return bu.a("entity.mule.name");
    case 3: 
      return bu.a("entity.zombiehorse.name");
    }
    return bu.a("entity.skeletonhorse.name");
  }
  


  private boolean w(int par1)
  {
    return (ah.c(16) & par1) != 0;
  }
  
  private void b(int par1, boolean par2)
  {
    int j = ah.c(16);
    
    if (par2)
    {
      ah.b(16, Integer.valueOf(j | par1));
    }
    else
    {
      ah.b(16, Integer.valueOf(j & (par1 ^ 0xFFFFFFFF)));
    }
  }
  
  public boolean bV()
  {
    return !g_();
  }
  
  public boolean bW()
  {
    return w(2);
  }
  
  public boolean ca()
  {
    return bV();
  }
  
  public String cb()
  {
    return ah.e(21);
  }
  
  public void b(String par1Str)
  {
    ah.b(21, par1Str);
  }
  
  public float cc()
  {
    int i = b();
    return i >= 0 ? 1.0F : 0.5F + (41536 - i) / -24000.0F * 0.5F;
  }
  



  public void a(boolean par1)
  {
    if (par1)
    {
      a(cc());
    }
    else
    {
      a(1.0F);
    }
  }
  
  public boolean cd()
  {
    return br;
  }
  
  public void i(boolean par1)
  {
    b(2, par1);
  }
  
  public void j(boolean par1)
  {
    br = par1;
  }
  
  public boolean bG()
  {
    return (!cy()) && (super.bG());
  }
  
  protected void o(float par1)
  {
    if ((par1 > 6.0F) && (cg()))
    {
      o(false);
    }
  }
  
  public boolean ce()
  {
    return w(8);
  }
  
  public int cf()
  {
    return ah.c(22);
  }
  



  public int d(ye par1ItemStack)
  {
    return d == cgcv ? 3 : d == cfcv ? 2 : d == cecv ? 1 : par1ItemStack == null ? 0 : 0;
  }
  
  public boolean cg()
  {
    return w(32);
  }
  
  public boolean ch()
  {
    return w(64);
  }
  
  public boolean ci()
  {
    return w(16);
  }
  
  public boolean cj()
  {
    return bH;
  }
  
  public void r(int par1)
  {
    ah.b(22, Integer.valueOf(par1));
    cJ();
  }
  
  public void k(boolean par1)
  {
    b(16, par1);
  }
  
  public void l(boolean par1)
  {
    b(8, par1);
  }
  
  public void m(boolean par1)
  {
    bH = par1;
  }
  
  public void n(boolean par1)
  {
    b(4, par1);
  }
  
  public int ck()
  {
    return bs;
  }
  
  public void s(int par1)
  {
    bs = par1;
  }
  
  public int t(int par1)
  {
    int j = ls.a(ck() + par1, 0, cq());
    s(j);
    return j;
  }
  



  public boolean a(nb par1DamageSource, float par2)
  {
    nn entity = par1DamageSource.i();
    return (n != null) && (n.equals(entity)) ? false : super.a(par1DamageSource, par2);
  }
  



  public int aQ()
  {
    return by[cf()];
  }
  



  public boolean M()
  {
    return (n == null) || (n.isQuiteSmallerThan(this));
  }
  
  public boolean cl()
  {
    int i = ls.c(u);
    int j = ls.c(w);
    q.a(i, j);
    return true;
  }
  
  public void cm()
  {
    if ((!q.I) && (ce()))
    {
      b(azcF, 1);
      l(false);
    }
  }
  
  private void cF()
  {
    cM();
    q.a(this, "eating", 1.0F * getSizeMultiplierRoot(), 1.0F + (ab.nextFloat() - ab.nextFloat()) * 0.2F);
  }
  



  protected void b(float par1)
  {
    if (par1 > 1.0F)
    {
      a("mob.horse.land", 0.4F, 1.0F);
    }
    
    int i = ls.f(par1 * 0.5F - 3.0F);
    
    if (i > 0)
    {
      a(nb.h, i);
      
      if (n != null)
      {
        n.a(nb.h, i);
      }
      
      int j = q.a(ls.c(u), ls.c(v - 0.2D - C), ls.c(w));
      
      if (j > 0)
      {
        ard stepsound = scS;
        q.a(this, stepsound.e(), stepsound.c() * 0.5F * getSizeMultiplierRoot(), stepsound.d() * 0.75F);
      }
    }
  }
  
  private int cG()
  {
    int i = bT();
    return (ce()) && ((i == 1) || (i == 2)) ? 17 : 2;
  }
  
  private void cH()
  {
    uz animalchest = bG;
    bG = new uz("HorseChest", cG());
    bG.a(an());
    
    if (animalchest != null)
    {
      animalchest.b(this);
      int i = Math.min(animalchest.j_(), bG.j_());
      
      for (int j = 0; j < i; j++)
      {
        ye itemstack = animalchest.a(j);
        
        if (itemstack != null)
        {
          bG.a(j, itemstack.m());
        }
      }
      
      animalchest = null;
    }
    
    bG.a(this);
    cI();
  }
  
  private void cI()
  {
    if (!q.I)
    {
      n(bG.a(0) != null);
      
      if (cv())
      {
        r(d(bG.a(1)));
      }
    }
  }
  



  public void a(mu par1InventoryBasic)
  {
    int i = cf();
    boolean flag = co();
    cI();
    
    if (ac > 20)
    {
      if ((i == 0) && (i != cf()))
      {
        a("mob.horse.armor", 0.5F, 1.0F);
      }
      
      if ((!flag) && (co()))
      {
        a("mob.horse.leather", 0.5F, 1.0F);
      }
    }
  }
  



  public boolean bs()
  {
    cl();
    return super.bs();
  }
  
  protected rs a(nn par1Entity, double par2)
  {
    double d1 = Double.MAX_VALUE;
    nn entity1 = null;
    List list = q.a(par1Entity, E.a(par2, par2, par2), bu);
    Iterator iterator = list.iterator();
    
    while (iterator.hasNext())
    {
      nn entity2 = (nn)iterator.next();
      double d2 = entity2.e(u, v, w);
      
      if (d2 < d1)
      {
        entity1 = entity2;
        d1 = d2;
      }
    }
    
    return (rs)entity1;
  }
  
  public double cn()
  {
    return a(bv).e();
  }
  



  protected String aP()
  {
    cM();
    int i = bT();
    return (i != 1) && (i != 2) ? "mob.horse.death" : i == 4 ? "mob.horse.skeleton.death" : i == 3 ? "mob.horse.zombie.death" : "mob.horse.donkey.death";
  }
  



  protected int s()
  {
    boolean flag = ab.nextInt(4) == 0;
    int i = bT();
    return i == 3 ? bocv : flag ? 0 : i == 4 ? aZcv : aHcv;
  }
  



  protected String aO()
  {
    cM();
    
    if (ab.nextInt(3) == 0)
    {
      cO();
    }
    
    int i = bT();
    return (i != 1) && (i != 2) ? "mob.horse.hit" : i == 4 ? "mob.horse.skeleton.hit" : i == 3 ? "mob.horse.zombie.hit" : "mob.horse.donkey.hit";
  }
  
  public boolean co()
  {
    return w(4);
  }
  



  public boolean getSaddled()
  {
    return co();
  }
  



  protected String r()
  {
    cM();
    
    if ((ab.nextInt(10) == 0) && (!bc()))
    {
      cO();
    }
    
    int i = bT();
    return (i != 1) && (i != 2) ? "mob.horse.idle" : i == 4 ? "mob.horse.skeleton.idle" : i == 3 ? "mob.horse.zombie.idle" : "mob.horse.donkey.idle";
  }
  
  protected String cp()
  {
    cM();
    cO();
    int i = bT();
    return (i != 3) && (i != 4) ? "mob.horse.donkey.angry" : (i != 1) && (i != 2) ? "mob.horse.angry" : null;
  }
  



  protected void a(int par1, int par2, int par3, int par4)
  {
    ard stepsound = scS;
    
    if (q.a(par1, par2 + 1, par3) == aXcF)
    {
      stepsound = aXcS;
    }
    
    if (!scU.d())
    {
      int i1 = bT();
      
      if ((n != null) && (i1 != 1) && (i1 != 2))
      {
        bP += 1;
        
        if ((bP > 5) && (bP % 3 == 0))
        {
          a("mob.horse.gallop", stepsound.c() * 0.15F, stepsound.d());
          
          if ((i1 == 0) && (ab.nextInt(10) == 0))
          {
            a("mob.horse.breathe", stepsound.c() * 0.6F, stepsound.d());
          }
        }
        else if (bP <= 5)
        {
          a("mob.horse.wood", stepsound.c() * 0.15F, stepsound.d());
        }
      }
      else if (stepsound == aqz.h)
      {
        a("mob.horse.soft", stepsound.c() * 0.15F, stepsound.d());
      }
      else
      {
        a("mob.horse.wood", stepsound.c() * 0.15F, stepsound.d());
      }
    }
  }
  
  protected void az()
  {
    super.az();
    aX().b(bv);
    a(tp.a).a(53.0D);
    a(tp.d).a(0.22499999403953552D);
  }
  



  public int bv()
  {
    return 6;
  }
  
  public int cq()
  {
    return 100;
  }
  



  protected float ba()
  {
    return 0.8F;
  }
  



  public int o()
  {
    return 400;
  }
  
  @SideOnly(Side.CLIENT)
  public boolean cr()
  {
    return (bT() == 0) || (cf() > 0);
  }
  
  private void cJ()
  {
    bQ = null;
  }
  
  @SideOnly(Side.CLIENT)
  private void cK()
  {
    bQ = "horse/";
    bR[0] = null;
    bR[1] = null;
    bR[2] = null;
    int i = bT();
    int j = bU();
    

    if (i == 0)
    {
      int k = j & 0xFF;
      int l = (j & 0xFF00) >> 8;
      bR[0] = bz[k];
      bQ += bA[k];
      bR[1] = bB[l];
      bQ += bC[l];
    }
    else
    {
      bR[0] = "";
      bQ = (bQ + "_" + i + "_");
    }
    
    int k = cf();
    bR[2] = bw[k];
    bQ += bx[k];
  }
  
  @SideOnly(Side.CLIENT)
  public String cs()
  {
    if (bQ == null)
    {
      cK();
    }
    
    return bQ;
  }
  
  @SideOnly(Side.CLIENT)
  public String[] ct()
  {
    if (bQ == null)
    {
      cK();
    }
    
    return bR;
  }
  
  public void f(uf par1EntityPlayer)
  {
    if ((!q.I) && (bW()) && (!par1EntityPlayer.isTinierThan(this)) && ((n == null) || (n == par1EntityPlayer) || (n.isTinierThan(this))))
    {
      bG.a(an());
      par1EntityPlayer.a(this, bG);
    }
  }
  



  public boolean a(uf par1EntityPlayer)
  {
    ye itemstack = bn.h();
    
    if ((itemstack != null) && (d == bEcv))
    {
      return super.a(par1EntityPlayer);
    }
    if ((!bW()) && (cy()))
    {
      return false;
    }
    if ((bW()) && (bV()) && (par1EntityPlayer.ah()))
    {
      f(par1EntityPlayer);
      return true;
    }
    if ((ca()) && (n != null))
    {
      return super.a(par1EntityPlayer);
    }
    

    if (itemstack != null)
    {
      boolean flag = false;
      
      if (cv())
      {
        byte b0 = -1;
        
        if (d == cecv)
        {
          b0 = 1;
        }
        else if (d == cfcv)
        {
          b0 = 2;
        }
        else if (d == cgcv)
        {
          b0 = 3;
        }
        
        if (b0 >= 0)
        {
          if (!bW())
          {
            if (!par1EntityPlayer.isTinierThan(this))
            {
              cD();
            }
            return true;
          }
          
          f(par1EntityPlayer);
          return true;
        }
      }
      
      if ((!flag) && (!cy()))
      {
        float f = 0.0F;
        short short1 = 0;
        byte b1 = 0;
        
        if (d == Vcv)
        {
          f = 2.0F;
          short1 = 60;
          b1 = 3;
        }
        else if (d == bacv)
        {
          f = 1.0F;
          short1 = 30;
          b1 = 3;
        }
        else if (d == Wcv)
        {
          f = 7.0F;
          short1 = 180;
          b1 = 3;
        }
        else if (d == cBcF)
        {
          f = 20.0F;
          short1 = 180;
        }
        else if (d == lcv)
        {
          f = 3.0F;
          short1 = 60;
          b1 = 3;
        }
        else if (d == bRcv)
        {
          f = 4.0F;
          short1 = 60;
          b1 = 5;
          
          if ((bW()) && (b() == 0))
          {
            flag = true;
            bX();
          }
        }
        else if (d == avcv)
        {
          f = 10.0F;
          short1 = 240;
          b1 = 10;
          
          if ((bW()) && (b() == 0))
          {
            flag = true;
            bX();
          }
        }
        
        if ((aN() < aT()) && (f > 0.0F))
        {
          f(f);
          flag = true;
        }
        
        if ((!bV()) && (short1 > 0))
        {
          a(short1);
          flag = true;
        }
        
        if ((b1 > 0) && ((flag) || (!bW())) && (b1 < cq()))
        {
          flag = true;
          t(b1);
          
          if ((par1EntityPlayer.isTinierThan(this)) && ((n == null) || (n.isTinierThan(this))))
          {
            t(b1);
            if (ck() >= cq())
            {
              g(par1EntityPlayer);
              q.a(this, (byte)7);
            }
          }
        }
        
        if (flag)
        {
          cF();
        }
      }
      
      if ((!bW()) && (!flag))
      {
        if ((itemstack != null) && (itemstack.a(par1EntityPlayer, this)))
        {
          return true;
        }
        
        if (!par1EntityPlayer.isTinierThan(this))
        {
          cD();
        }
        return true;
      }
      
      if ((!flag) && (cw()) && (!ce()) && (d == azcF) && (!par1EntityPlayer.isTinierThan(this)))
      {
        l(true);
        a("mob.chickenplop", 1.0F, (ab.nextFloat() - ab.nextFloat()) * 0.2F + 1.0F);
        flag = true;
        cH();
      }
      
      if ((!flag) && (ca()) && (!co()) && (d == aCcv))
      {
        f(par1EntityPlayer);
        return true;
      }
      
      if (flag)
      {
        if (!bG.d) { if (--b == 0)
          {
            bn.a(bn.c, (ye)null);
          }
        }
        return true;
      }
    }
    
    if ((ca()) && (n == null))
    {
      if ((itemstack != null) && (itemstack.a(par1EntityPlayer, this)))
      {
        return true;
      }
      

      h(par1EntityPlayer);
      return true;
    }
    


    return super.a(par1EntityPlayer);
  }
  


  private void h(uf par1EntityPlayer)
  {
    A = A;
    B = B;
    if (!par1EntityPlayer.isTinierThan(this))
    {
      o(false);
    }
    p(false);
    
    if (!q.I)
    {
      par1EntityPlayer.a(this);
    }
  }
  
  public boolean cv()
  {
    return bT() == 0;
  }
  
  public boolean cw()
  {
    int i = bT();
    return (i == 2) || (i == 1);
  }
  



  protected boolean bc()
  {
    return (n != null) && (!n.isQuiteSmallerThan(this)) && (co());
  }
  
  public boolean cy()
  {
    int i = bT();
    return (i == 3) || (i == 4);
  }
  
  public boolean cz()
  {
    return (cy()) || (bT() == 2);
  }
  




  public boolean c(ye par1ItemStack)
  {
    return false;
  }
  
  private void cL()
  {
    bp = 1;
  }
  



  public void a(nb par1DamageSource)
  {
    super.a(par1DamageSource);
    
    if (!q.I)
    {
      cE();
    }
  }
  



  public boolean isWeighted()
  {
    if ((bG != null) && (bG.j_() > 1) && (!cw()))
    {
      ye itemstack = bG.a(1);
      
      if ((itemstack != null) && (d == cfcv))
      {
        return true;
      }
    }
    
    return false;
  }
  




  public void c()
  {
    if (ab.nextInt(200) == 0)
    {
      cL();
    }
    
    super.c();
    
    if (!q.I)
    {

      if ((isHuge()) || (isTiny()))
      {
        if (bG != null)
        {
          for (int i = 1; i < bG.j_(); i++)
          {
            ye itemstack = bG.a(i);
            
            if (itemstack != null)
            {

              if ((isHuge()) || (i != 1) || (cw()) || (d != cfcv))
              {
                bG.a(i, null);
                a(itemstack, 0.0F);
              }
            }
          }
          cm();
        }
      }
      
      if ((ab.nextInt(900) == 0) && (aB == 0))
      {
        f(1.0F);
      }
      
      if ((!cg()) && (n == null) && (ab.nextInt(300) == 0) && (q.a(ls.c(u), ls.c(v) - 1, ls.c(w)) == zcF))
      {
        o(true);
      }
      
      if ((cg()) && (++bD > 50))
      {
        bD = 0;
        o(false);
      }
      
      if ((ci()) && (!bV()) && (!cg()))
      {
        rs entityhorse = a(this, 16.0D);
        
        if ((entityhorse != null) && (e(entityhorse) > 4.0D))
        {
          alf pathentity = q.a(this, entityhorse, 16.0F, true, false, false, true);
          a(pathentity);
        }
      }
    }
  }
  



  public void l_()
  {
    super.l_();
    
    if ((q.I) && (ah.a()))
    {
      ah.e();
      cJ();
    }
    
    if ((bE > 0) && (++bE > 30))
    {
      bE = 0;
      b(128, false);
    }
    
    if ((!q.I) && (bF > 0) && (++bF > 20))
    {
      bF = 0;
      p(false);
    }
    
    if ((bp > 0) && (++bp > 8))
    {
      bp = 0;
    }
    
    if (bq > 0)
    {
      bq += 1;
      
      if (bq > 300)
      {
        bq = 0;
      }
    }
    
    bK = bJ;
    
    if (cg())
    {
      bJ += (1.0F - bJ) * 0.4F + 0.05F;
      
      if (bJ > 1.0F)
      {
        bJ = 1.0F;
      }
    }
    else
    {
      bJ += (0.0F - bJ) * 0.4F - 0.05F;
      
      if (bJ < 0.0F)
      {
        bJ = 0.0F;
      }
    }
    
    bM = bL;
    
    if (ch())
    {
      bK = (this.bJ = 0.0F);
      bL += (1.0F - bL) * 0.4F + 0.05F;
      
      if (bL > 1.0F)
      {
        bL = 1.0F;
      }
    }
    else
    {
      bI = false;
      bL += (0.8F * bL * bL * bL - bL) * 0.6F - 0.05F;
      
      if (bL < 0.0F)
      {
        bL = 0.0F;
      }
    }
    
    bO = bN;
    
    if (w(128))
    {
      bN += (1.0F - bN) * 0.7F + 0.05F;
      
      if (bN > 1.0F)
      {
        bN = 1.0F;
      }
    }
    else
    {
      bN += (0.0F - bN) * 0.7F - 0.05F;
      
      if (bN < 0.0F)
      {
        bN = 0.0F;
      }
    }
  }
  
  private void cM()
  {
    if (!q.I)
    {
      bE = 1;
      b(128, true);
    }
  }
  
  private boolean cN()
  {
    return (n == null) && (o == null) && (bW()) && (bV()) && (!cz()) && (aN() >= aT());
  }
  
  public void e(boolean par1)
  {
    b(32, par1);
  }
  
  public void o(boolean par1)
  {
    e(par1);
  }
  
  public void p(boolean par1)
  {
    if (par1)
    {
      o(false);
    }
    
    b(64, par1);
  }
  
  private void cO()
  {
    if (!q.I)
    {
      bF = 1;
      p(true);
    }
  }
  
  public void cD()
  {
    cO();
    String s = cp();
    
    if (s != null)
    {
      a(s, ba(), bb());
    }
  }
  
  public void cE()
  {
    a(this, bG);
    cm();
  }
  
  private void a(nn par1Entity, uz par2AnimalChest)
  {
    if ((par2AnimalChest != null) && (!q.I))
    {
      for (int i = 0; i < par2AnimalChest.j_(); i++)
      {
        ye itemstack = par2AnimalChest.a(i);
        
        if (itemstack != null)
        {
          a(itemstack, 0.0F);
        }
      }
    }
  }
  
  public boolean g(uf par1EntityPlayer)
  {
    b(par1EntityPlayer.c_());
    i(true);
    return true;
  }
  



  public void e(float par1, float par2)
  {
    boolean isPlayer = (n != null) && ((n instanceof uf));
    boolean isOwner = (isPlayer) && (((uf)n).c_().equalsIgnoreCase(cb()));
    if ((n != null) && ((n instanceof of)) && (((co()) && (!n.isTinierThan(this))) || ((n.isTinierThan(this)) && (isEntityInRelativeSizeRange(n, 0.1F, 0.0F)) && ((isOwner) || (co())))))
    {

      boolean partialctrl = (n.isTinierThan(this)) && ((!isOwner) || (!co()));
      float sizeratio = n.getSizeMultiplier() / getSizeMultiplier();
      float sizerootratio = n.getSizeMultiplierRoot() / getSizeMultiplierRoot();
      
      if (!partialctrl)
      {
        C = (this.A = n.A);
        B = (n.B * 0.5F);
        b(A, B);
        aP = (this.aN = A);
        par1 = n).be * 0.5F * sizerootratio;
        par2 = n).bf * sizerootratio;
        
        if (par2 <= 0.0F)
        {
          par2 *= 0.25F;
          bP = 0;
        }
      }
      else
      {
        float strafe = n).be * 0.5F;
        float fwd = n).bf;
        if ((strafe != 0.0F) || (fwd != 0.0F))
        {
          A = ls.g(A + ls.g(n.A - A) * sizeratio * 0.5F);
          B = (n.B * 0.5F);
          b(A, B);
          aP = (this.aN = A);
          
          if (fwd <= 0.0F)
          {
            fwd *= 0.5F;
            bP = 0;
          }
          par1 += strafe * sizerootratio;
          par2 += fwd * sizerootratio;
        }
      }
      
      if ((F) && (bt == 0.0F) && (ch()) && (!bI))
      {
        par1 = 0.0F;
        par2 = 0.0F;
      }
      
      if (!partialctrl)
      {
        if ((bt > 0.0F) && (!cd()) && (F))
        {
          y = (cn() * bt);
          
          if (getSizeMultiplier() != 1.0F)
          {

            y = (y * 0.9D + (getSizeMultiplier() <= 1.0F ? getSizeMultiplier() : getSizeMultiplierRoot()) * y * 0.1D);
            
            if ((isWeighted()) || ((isSticky()) && (isTiny())))
            {

              y *= getSizeMultiplierRoot();


            }
            else if (getSizeMultiplier() > 1.0F)
            {
              y *= Math.sqrt(getSizeMultiplierRoot());
            }
            else if ((isTiny()) && (bt < 0.5F))
            {


              y *= Math.cbrt(getSizeMultiplierRoot());
            }
          }
          

          if (a(ni.j))
          {
            y += (b(ni.j).c() + 1) * 0.1F * Math.sqrt(getSizeMultiplierRoot());
          }
          
          j(true);
          an = true;
          
          if (par2 > 0.0F)
          {
            float f2 = ls.a(A * 3.1415927F / 180.0F);
            float f3 = ls.b(A * 3.1415927F / 180.0F);
            x += -0.4F * f2 * bt * getSizeMultiplierRoot();
            z += 0.4F * f3 * bt * getSizeMultiplierRoot();
            a("mob.horse.jump", 0.4F, 1.0F);
          }
          
          bt = 0.0F;
        }
      }
      
      Y = 1.0F;
      aR = (bg() * 0.1F);
      
      if (!q.I)
      {
        i((float)a(tp.d).e());
        super.e(par1, par2);
      }
      
      if (F)
      {
        bt = 0.0F;
        j(false);
      }
      
      aF = aG;
      double d0 = u - r;
      double d1 = w - t;
      float f4 = ls.a(d0 * d0 + d1 * d1) * 4.0F / getSizeMovementMultiplier();
      
      if (f4 > 1.0F)
      {
        f4 = 1.0F;
      }
      
      aG += (f4 - aG) * 0.4F;
      aH += aG;
    }
    else
    {
      Y = 0.5F;
      aR = 0.02F;
      super.e(par1, par2);
    }
  }
  



  public void b(by par1NBTTagCompound)
  {
    super.b(par1NBTTagCompound);
    par1NBTTagCompound.a("EatingHaystack", cg());
    par1NBTTagCompound.a("ChestedHorse", ce());
    par1NBTTagCompound.a("HasReproduced", cj());
    par1NBTTagCompound.a("Bred", ci());
    par1NBTTagCompound.a("Type", bT());
    par1NBTTagCompound.a("Variant", bU());
    par1NBTTagCompound.a("Temper", ck());
    par1NBTTagCompound.a("Tame", bW());
    par1NBTTagCompound.a("OwnerName", cb());
    
    if (ce())
    {
      cg nbttaglist = new cg();
      
      for (int i = 2; i < bG.j_(); i++)
      {
        ye itemstack = bG.a(i);
        
        if (itemstack != null)
        {
          by nbttagcompound1 = new by();
          nbttagcompound1.a("Slot", (byte)i);
          itemstack.b(nbttagcompound1);
          nbttaglist.a(nbttagcompound1);
        }
      }
      
      par1NBTTagCompound.a("Items", nbttaglist);
    }
    
    if (bG.a(1) != null)
    {
      par1NBTTagCompound.a("ArmorItem", bG.a(1).b(new by("ArmorItem")));
    }
    
    if (bG.a(0) != null)
    {
      par1NBTTagCompound.a("SaddleItem", bG.a(0).b(new by("SaddleItem")));
    }
  }
  



  public void a(by par1NBTTagCompound)
  {
    super.a(par1NBTTagCompound);
    o(par1NBTTagCompound.n("EatingHaystack"));
    k(par1NBTTagCompound.n("Bred"));
    l(par1NBTTagCompound.n("ChestedHorse"));
    m(par1NBTTagCompound.n("HasReproduced"));
    p(par1NBTTagCompound.e("Type"));
    q(par1NBTTagCompound.e("Variant"));
    s(par1NBTTagCompound.e("Temper"));
    i(par1NBTTagCompound.n("Tame"));
    
    if (par1NBTTagCompound.b("OwnerName"))
    {
      b(par1NBTTagCompound.i("OwnerName"));
    }
    
    os attributeinstance = aX().a("Speed");
    
    if (attributeinstance != null)
    {
      a(tp.d).a(attributeinstance.b() * 0.25D);
    }
    
    if (ce())
    {
      cg nbttaglist = par1NBTTagCompound.m("Items");
      cH();
      
      for (int i = 0; i < nbttaglist.c(); i++)
      {
        by nbttagcompound1 = (by)nbttaglist.b(i);
        int j = nbttagcompound1.c("Slot") & 0xFF;
        
        if ((j >= 2) && (j < bG.j_()))
        {
          bG.a(j, ye.a(nbttagcompound1));
        }
      }
    }
    


    if (par1NBTTagCompound.b("ArmorItem"))
    {
      ye itemstack = ye.a(par1NBTTagCompound.l("ArmorItem"));
      
      if ((itemstack != null) && (v(d)))
      {
        bG.a(1, itemstack);
      }
    }
    
    if (par1NBTTagCompound.b("SaddleItem"))
    {
      ye itemstack = ye.a(par1NBTTagCompound.l("SaddleItem"));
      
      if ((itemstack != null) && (d == aCcv))
      {
        bG.a(0, itemstack);
      }
    }
    else if (par1NBTTagCompound.n("Saddle"))
    {
      bG.a(0, new ye(yc.aC));
    }
    
    cI();
  }
  



  public boolean a(rp par1EntityAnimal)
  {
    if (par1EntityAnimal == this)
    {
      return false;
    }
    if (par1EntityAnimal.getClass() != getClass())
    {
      return false;
    }
    

    rs entityhorse = (rs)par1EntityAnimal;
    
    if ((cN()) && (entityhorse.cN()))
    {
      int i = bT();
      int j = entityhorse.bT();
      return (i == j) || ((i == 0) && (j == 1)) || ((i == 1) && (j == 0));
    }
    

    return false;
  }
  


  public nk a(nk par1EntityAgeable)
  {
    rs entityhorse = (rs)par1EntityAgeable;
    rs entityhorse1 = new rs(q);
    int i = bT();
    int j = entityhorse.bT();
    int k = 0;
    
    if (i == j)
    {
      k = i;
    }
    else if (((i == 0) && (j == 1)) || ((i == 1) && (j == 0)))
    {
      k = 2;
    }
    
    if (k == 0)
    {
      int l = ab.nextInt(9);
      int i1;
      int i1;
      if (l < 4)
      {
        i1 = bU() & 0xFF;
      } else { int i1;
        if (l < 8)
        {
          i1 = entityhorse.bU() & 0xFF;
        }
        else
        {
          i1 = ab.nextInt(7);
        }
      }
      int j1 = ab.nextInt(5);
      
      if (j1 < 4)
      {
        i1 |= bU() & 0xFF00;
      }
      else if (j1 < 8)
      {
        i1 |= entityhorse.bU() & 0xFF00;
      }
      else
      {
        i1 |= ab.nextInt(5) << 8 & 0xFF00;
      }
      
      entityhorse1.q(i1);
    }
    
    entityhorse1.p(k);
    double d0 = a(tp.a).b() + par1EntityAgeable.a(tp.a).b() + cP();
    entityhorse1.a(tp.a).a(d0 / 3.0D);
    double d1 = a(bv).b() + par1EntityAgeable.a(bv).b() + cQ();
    entityhorse1.a(bv).a(d1 / 3.0D);
    double d2 = a(tp.d).b() + par1EntityAgeable.a(tp.d).b() + cR();
    entityhorse1.a(tp.d).a(d2 / 3.0D);
    return entityhorse1;
  }
  
  public oi a(oi par1EntityLivingData)
  {
    Object par1EntityLivingData1 = super.a(par1EntityLivingData);
    boolean flag = false;
    int i = 0;
    
    int j;
    if ((par1EntityLivingData1 instanceof ru))
    {
      int j = a;
      i = b & 0xFF | ab.nextInt(5) << 8;
    }
    else {
      int j;
      if (ab.nextInt(10) == 0)
      {
        j = 1;
      }
      else
      {
        int k = ab.nextInt(7);
        int l = ab.nextInt(5);
        j = 0;
        i = k | l << 8;
      }
      
      par1EntityLivingData1 = new ru(j, i);
    }
    
    p(j);
    q(i);
    
    if (ab.nextInt(5) == 0)
    {
      c(41536);
    }
    
    if ((j != 4) && (j != 3))
    {
      a(tp.a).a(cP());
      
      if (j == 0)
      {
        a(tp.d).a(cR());
      }
      else
      {
        a(tp.d).a(0.17499999701976776D);
      }
    }
    else
    {
      a(tp.a).a(15.0D);
      a(tp.d).a(0.20000000298023224D);
    }
    
    if ((j != 2) && (j != 1))
    {
      a(bv).a(cQ());
    }
    else
    {
      a(bv).a(0.5D);
    }
    
    g(aT());
    return (oi)par1EntityLivingData1;
  }
  
  @SideOnly(Side.CLIENT)
  public float p(float par1)
  {
    return bK + (bJ - bK) * par1;
  }
  
  @SideOnly(Side.CLIENT)
  public float q(float par1)
  {
    return bM + (bL - bM) * par1;
  }
  
  @SideOnly(Side.CLIENT)
  public float r(float par1)
  {
    return bO + (bN - bO) * par1;
  }
  



  protected boolean bf()
  {
    return true;
  }
  
  public void u(int par1)
  {
    if (co())
    {
      if (par1 < 0)
      {
        par1 = 0;
      }
      else
      {
        bI = true;
        cO();
      }
      
      if (par1 >= 90)
      {
        bt = 1.0F;
      }
      else
      {
        bt = (0.4F + 0.4F * par1 / 90.0F);
      }
    }
  }
  




  @SideOnly(Side.CLIENT)
  protected void q(boolean par1)
  {
    String s = par1 ? "heart" : "smoke";
    
    for (int i = 0; i < 7; i++)
    {
      double d0 = ab.nextGaussian() * 0.02D;
      double d1 = ab.nextGaussian() * 0.02D;
      double d2 = ab.nextGaussian() * 0.02D;
      q.a(s, u + ab.nextFloat() * O * 2.0F - O, v + 0.5D + ab.nextFloat() * P, w + ab.nextFloat() * O * 2.0F - O, d0, d1, d2);
    }
  }
  
  @SideOnly(Side.CLIENT)
  public void a(byte par1)
  {
    if (par1 == 7)
    {
      q(true);
    }
    else if (par1 == 6)
    {
      q(false);
    }
    else
    {
      super.a(par1);
    }
  }
  
  public void W()
  {
    super.W();
    
    if (bM > 0.0F)
    {
      float f = ls.a(aN * 3.1415927F / 180.0F);
      float f1 = ls.b(aN * 3.1415927F / 180.0F);
      float f2 = 0.7F * bM * getSizeMultiplier();
      float f3 = 0.15F * bM * getSizeMultiplier();
      n.b(u + f2 * f, v + Y() + n.X() + f3, w - f2 * f1);
      
      if ((n instanceof of))
      {
        n).aN = aN;
      }
    }
  }
  



  public double Y()
  {
    if (!g_())
    {
      return P * 0.75D;
    }
    

    return P * (0.9D + (1.0F - cc()) * 0.5D);
  }
  

  private float cP()
  {
    return 15.0F + ab.nextInt(8) + ab.nextInt(9);
  }
  
  private double cQ()
  {
    return 0.4000000059604645D + ab.nextDouble() * 0.2D + ab.nextDouble() * 0.2D + ab.nextDouble() * 0.2D;
  }
  
  private double cR()
  {
    return (0.44999998807907104D + ab.nextDouble() * 0.3D + ab.nextDouble() * 0.3D + ab.nextDouble() * 0.3D) * 0.25D;
  }
  
  public static boolean v(int par0)
  {
    return (par0 == cecv) || (par0 == cfcv) || (par0 == cgcv);
  }
  



  public boolean e()
  {
    return false;
  }
}
