import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import net.minecraft.server.MinecraftServer;
import net.minecraftforge.common.IMinecartCollisionHandler;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.EventBus;
import net.minecraftforge.event.entity.minecart.MinecartCollisionEvent;
import net.minecraftforge.event.entity.minecart.MinecartUpdateEvent;




















public abstract class st
  extends nn
{
  protected boolean a;
  protected final hr b;
  protected String c;
  protected static final int[][][] d = { { { 0, 0, -1 }, { 0, 0, 1 } }, { { -1, 0, 0 }, { 1, 0, 0 } }, { { -1, -1, 0 }, { 1, 0, 0 } }, { { -1, 0, 0 }, { 1, -1, 0 } }, { { 0, 0, -1 }, { 0, -1, 1 } }, { { 0, -1, -1 }, { 0, 0, 1 } }, { { 0, 0, 1 }, { 1, 0, 0 } }, { { 0, 0, 1 }, { -1, 0, 0 } }, { { 0, 0, -1 }, { -1, 0, 0 } }, { { 0, 0, -1 }, { 1, 0, 0 } } };
  
  protected int e;
  
  protected double f;
  
  protected double g;
  
  protected double h;
  protected double i;
  protected double j;
  @SideOnly(Side.CLIENT)
  protected double au;
  @SideOnly(Side.CLIENT)
  protected double av;
  @SideOnly(Side.CLIENT)
  protected double aw;
  private nn throwingEntity;
  public static float defaultMaxSpeedAirLateral = 0.4F;
  public static float defaultMaxSpeedAirVertical = -1.0F;
  public static double defaultDragAir = 0.949999988079071D;
  protected boolean canUseRail = true;
  protected boolean canBePushed = true;
  private static IMinecartCollisionHandler collisionHandler = null;
  

  private float currentSpeedRail = getMaxCartSpeedOnRail();
  protected float maxSpeedAirLateral = defaultMaxSpeedAirLateral;
  protected float maxSpeedAirVertical = defaultMaxSpeedAirVertical;
  protected double dragAir = defaultDragAir;
  
  public st(abw par1World)
  {
    super(par1World);
    m = true;
    a(0.98F, 0.7F);
    N = (P / 2.0F);
    b = (par1World != null ? par1World.a(this) : null);
  }
  






  public static st a(abw par0World, double par1, double par3, double par5, int par7)
  {
    switch (par7)
    {
    case 1: 
      return new su(par0World, par1, par3, par5);
    case 2: 
      return new sw(par0World, par1, par3, par5);
    case 3: 
      return new tb(par0World, par1, par3, par5);
    case 4: 
      return new sz(par0World, par1, par3, par5);
    case 5: 
      return new sx(par0World, par1, par3, par5);
    }
    return new sy(par0World, par1, par3, par5);
  }
  





  protected boolean e_()
  {
    return false;
  }
  
  protected void a()
  {
    ah.a(17, new Integer(0));
    ah.a(18, new Integer(1));
    ah.a(19, new Float(0.0F));
    ah.a(20, new Integer(0));
    ah.a(21, new Integer(6));
    ah.a(22, Byte.valueOf((byte)0));
  }
  




  public asx g(nn par1Entity)
  {
    if (getCollisionHandler() != null)
    {
      return getCollisionHandler().getCollisionBox(this, par1Entity);
    }
    return par1Entity.M() ? E : null;
  }
  



  public asx E()
  {
    if (getCollisionHandler() != null)
    {
      return getCollisionHandler().getBoundingBox(this);
    }
    return null;
  }
  



  public boolean M()
  {
    return canBePushed;
  }
  
  public st(abw par1World, double par2, double par4, double par6)
  {
    this(par1World);
    b(par2, par4, par6);
    x = 0.0D;
    y = 0.0D;
    z = 0.0D;
    r = par2;
    s = par4;
    t = par6;
  }
  



  public double Y()
  {
    return P * 0.0D - 0.30000001192092896D;
  }
  



  public boolean a(nb par1DamageSource, float par2)
  {
    if ((!q.I) && (!M))
    {
      if (ar())
      {
        return false;
      }
      

      h(-k());
      c(10);
      K();
      a(i() + par2 * 10.0F);
      boolean flag = ((par1DamageSource.i() instanceof uf)) && (ibG.d);
      
      if ((flag) || (i() > 40.0F))
      {
        if (n != null)
        {
          n.a(this);
        }
        
        if ((flag) && (!c()))
        {
          x();
        }
        else
        {
          a(par1DamageSource);
        }
      }
      
      return true;
    }
    


    return true;
  }
  

  public void a(nb par1DamageSource)
  {
    x();
    ye itemstack = new ye(yc.aB, 1);
    
    if (c != null)
    {
      itemstack.c(c);
    }
    
    a(itemstack, 0.0F);
  }
  




  @SideOnly(Side.CLIENT)
  public void ad()
  {
    h(-k());
    c(10);
    a(i() + i() * 10.0F);
  }
  



  public boolean L()
  {
    return !M;
  }
  



  public void x()
  {
    super.x();
    
    if (b != null)
    {
      b.a();
    }
  }
  
  public void getDroppedByEntity(nn par1Entity)
  {
    nn holder = holdingEntity;
    super.getDroppedByEntity(par1Entity);
    
    if ((holder != null) && (holdingEntity == null))
    {
      throwingEntity = holder;
    }
  }
  



  public void l_()
  {
    if (b != null)
    {
      b.a();
    }
    
    if (j() > 0)
    {
      c(j() - 1);
    }
    
    if (i() > 0.0F)
    {
      a(i() - 1.0F);
    }
    
    if (v < -64.0D)
    {
      C();
    }
    
    if ((holdingEntity != null) || (F))
    {
      throwingEntity = null;
    }
    


    if ((!q.I) && ((q instanceof js)))
    {
      q.C.a("portal");
      MinecraftServer minecraftserver = ((js)q).p();
      int i = z();
      
      if (ap)
      {
        if (minecraftserver.u())
        {
          if ((o == null) && (aq++ >= i))
          {
            aq = i;
            ao = ac();
            byte b0;
            byte b0;
            if (q.t.i == -1)
            {
              b0 = 0;
            }
            else
            {
              b0 = -1;
            }
            
            b(b0);
          }
          
          ap = false;
        }
      }
      else
      {
        if (aq > 0)
        {
          aq -= 4;
        }
        
        if (aq < 0)
        {
          aq = 0;
        }
      }
      
      if (ao > 0)
      {
        ao -= 1;
      }
      
      q.C.b();
    }
    
    if ((q.I) && (holdingEntity == null) && (throwingEntity == null))
    {
      if (e > 0)
      {
        double d0 = u + (f - u) / e;
        double d1 = v + (g - v) / e;
        double d2 = w + (h - w) / e;
        double d3 = ls.g(this.i - A);
        A = ((float)(A + d3 / e));
        B = ((float)(B + (this.j - B) / e));
        e -= 1;
        b(d0, d1, d2);
        b(A, B);
      }
      else
      {
        b(u, v, w);
        b(A, B);
      }
    }
    else if ((holdingEntity == null) && (throwingEntity == null))
    {
      r = u;
      s = v;
      t = w;
      y -= 0.03999999910593033D;
      int j = ls.c(u);
      int i = ls.c(v);
      int k = ls.c(w);
      
      if (amy.d_(q, j, i - 1, k))
      {
        i--;
      }
      
      double d4 = 0.4D;
      double d5 = 0.0078125D;
      int l = q.a(j, i, k);
      
      if ((canUseRail()) && (amy.e_(l)))
      {
        amy rail = (amy)aqz.s[l];
        float railMaxSpeed = rail.getRailMaxSpeed(q, this, j, i, k);
        double maxSpeed = Math.min(railMaxSpeed, getCurrentCartSpeedCapOnRail());
        int i1 = rail.getBasicRailMetadata(q, this, j, i, k);
        a(j, i, k, maxSpeed, getSlopeAdjustment(), l, i1);
        if (l == cycF)
        {
          a(j, i, k, (q.h(j, i, k) & 0x8) != 0);
        }
      }
      else
      {
        b(F ? d4 : getMaxSpeedAirLateral());
      }
      
      D();
      B = 0.0F;
      double d6 = r - u;
      double d7 = t - w;
      
      if (d6 * d6 + d7 * d7 > 0.001D)
      {
        A = ((float)(Math.atan2(d7, d6) * 180.0D / 3.141592653589793D));
        
        if (a)
        {
          A += 180.0F;
        }
      }
      
      double d8 = ls.g(A - C);
      
      if ((d8 < -170.0D) || (d8 >= 170.0D))
      {
        A += 180.0F;
        a = (!a);
      }
      
      b(A, B);
      asx box;
      asx box;
      if (getCollisionHandler() != null)
      {
        box = getCollisionHandler().getMinecartCollisionBox(this);
      }
      else
      {
        box = E.b(0.2D, 0.0D, 0.2D);
      }
      
      List list = q.b(this, box);
      
      if ((list != null) && (!list.isEmpty()))
      {
        for (int j1 = 0; j1 < list.size(); j1++)
        {
          nn entity = (nn)list.get(j1);
          
          if ((entity != n) && (entity.M()) && ((entity instanceof st)))
          {
            entity.f(this);
          }
        }
      }
      
      if ((n != null) && (n.M))
      {
        if (n.o == this)
        {
          n.o = null;
        }
        
        n = null;
      }
      
      MinecraftForge.EVENT_BUS.post(new MinecartUpdateEvent(this, j, i, k));
    }
  }
  


  public void a(int par1, int par2, int par3, boolean par4) {}
  

  protected void b(double par1)
  {
    if (x < -par1)
    {
      x = (-par1);
    }
    
    if (x > par1)
    {
      x = par1;
    }
    
    if (z < -par1)
    {
      z = (-par1);
    }
    
    if (z > par1)
    {
      z = par1;
    }
    
    double moveY = y;
    if ((getMaxSpeedAirVertical() > 0.0F) && (y > getMaxSpeedAirVertical()))
    {
      moveY = getMaxSpeedAirVertical();
      if ((Math.abs(x) < 0.30000001192092896D) && (Math.abs(z) < 0.30000001192092896D))
      {
        moveY = 0.15000000596046448D;
        y = moveY;
      }
    }
    
    if (F)
    {
      x *= 0.5D;
      y *= 0.5D;
      z *= 0.5D;
    }
    
    d(x, moveY, z);
    
    if (!F)
    {
      x *= getDragAir();
      y *= getDragAir();
      z *= getDragAir();
    }
  }
  
  protected void a(int par1, int par2, int par3, double par4, double par6, int par8, int par9)
  {
    T = 0.0F;
    atc vec3 = a(u, v, w);
    v = par2;
    boolean flag = false;
    boolean flag1 = false;
    
    if (par8 == YcF)
    {
      flag = (q.h(par1, par2, par3) & 0x8) != 0;
      flag1 = !flag;
    }
    
    if (((amy)aqz.s[par8]).e())
    {
      par9 &= 0x7;
    }
    
    if ((par9 >= 2) && (par9 <= 5))
    {
      v = (par2 + 1);
    }
    
    if (par9 == 2)
    {
      x -= par6;
    }
    
    if (par9 == 3)
    {
      x += par6;
    }
    
    if (par9 == 4)
    {
      z += par6;
    }
    
    if (par9 == 5)
    {
      z -= par6;
    }
    
    int[][] aint = d[par9];
    double d2 = aint[1][0] - aint[0][0];
    double d3 = aint[1][2] - aint[0][2];
    double d4 = Math.sqrt(d2 * d2 + d3 * d3);
    double d5 = x * d2 + z * d3;
    
    if (d5 < 0.0D)
    {
      d2 = -d2;
      d3 = -d3;
    }
    
    double d6 = Math.sqrt(x * x + z * z);
    
    if (d6 > 2.0D)
    {
      d6 = 2.0D;
    }
    
    x = (d6 * d2 / d4);
    z = (d6 * d3 / d4);
    




    if ((n != null) && ((n instanceof of)))
    {
      double d7 = n).bf;
      
      if (d7 > 0.0D)
      {
        double d8 = -Math.sin(n.A * 3.1415927F / 180.0F);
        double d9 = Math.cos(n.A * 3.1415927F / 180.0F);
        double d10 = x * x + z * z;
        
        if (d10 < 0.01D)
        {
          x += d8 * 0.1D;
          z += d9 * 0.1D;
          flag1 = false;
        }
      }
    }
    
    if ((flag1) && (shouldDoRailFunctions()))
    {
      double d7 = Math.sqrt(x * x + z * z);
      
      if (d7 < 0.03D)
      {
        x *= 0.0D;
        y *= 0.0D;
        z *= 0.0D;
      }
      else
      {
        x *= 0.5D;
        y *= 0.0D;
        z *= 0.5D;
      }
    }
    
    double d7 = 0.0D;
    double d8 = par1 + 0.5D + aint[0][0] * 0.5D;
    double d9 = par3 + 0.5D + aint[0][2] * 0.5D;
    double d10 = par1 + 0.5D + aint[1][0] * 0.5D;
    double d11 = par3 + 0.5D + aint[1][2] * 0.5D;
    d2 = d10 - d8;
    d3 = d11 - d9;
    


    if (d2 == 0.0D)
    {
      u = (par1 + 0.5D);
      d7 = w - par3;
    }
    else if (d3 == 0.0D)
    {
      w = (par3 + 0.5D);
      d7 = u - par1;
    }
    else
    {
      double d12 = u - d8;
      double d13 = w - d9;
      d7 = (d12 * d2 + d13 * d3) * 2.0D;
    }
    
    u = (d8 + d2 * d7);
    w = (d9 + d3 * d7);
    b(u, v + N, w);
    
    moveMinecartOnRail(par1, par2, par3, par4);
    
    if ((aint[0][1] != 0) && (ls.c(u) - par1 == aint[0][0]) && (ls.c(w) - par3 == aint[0][2]))
    {
      b(u, v + aint[0][1], w);
    }
    else if ((aint[1][1] != 0) && (ls.c(u) - par1 == aint[1][0]) && (ls.c(w) - par3 == aint[1][2]))
    {
      b(u, v + aint[1][1], w);
    }
    
    h();
    atc vec31 = a(u, v, w);
    
    if ((vec31 != null) && (vec3 != null))
    {
      double d14 = (d - d) * 0.05D;
      d6 = Math.sqrt(x * x + z * z);
      
      if (d6 > 0.0D)
      {
        x = (x / d6 * (d6 + d14));
        z = (z / d6 * (d6 + d14));
      }
      
      b(u, d, w);
    }
    
    int j1 = ls.c(u);
    int k1 = ls.c(w);
    
    if ((j1 != par1) || (k1 != par3))
    {
      d6 = Math.sqrt(x * x + z * z);
      x = (d6 * (j1 - par1));
      z = (d6 * (k1 - par3));
    }
    
    if (shouldDoRailFunctions())
    {
      ((amy)aqz.s[par8]).onMinecartPass(q, this, par1, par2, par3);
    }
    
    if ((flag) && (shouldDoRailFunctions()))
    {
      double d15 = Math.sqrt(x * x + z * z);
      
      if (d15 > 0.01D)
      {
        double d16 = 0.06D;
        x += x / d15 * d16;
        z += z / d15 * d16;
      }
      else if (par9 == 1)
      {
        if (q.u(par1 - 1, par2, par3))
        {
          x = 0.02D;
        }
        else if (q.u(par1 + 1, par2, par3))
        {
          x = -0.02D;
        }
      }
      else if (par9 == 0)
      {
        if (q.u(par1, par2, par3 - 1))
        {
          z = 0.02D;
        }
        else if (q.u(par1, par2, par3 + 1))
        {
          z = -0.02D;
        }
      }
    }
  }
  
  protected void h()
  {
    if (n != null)
    {
      x *= 0.996999979019165D;
      y *= 0.0D;
      z *= 0.996999979019165D;
    }
    else
    {
      x *= 0.9599999785423279D;
      y *= 0.0D;
      z *= 0.9599999785423279D;
    }
  }
  
  @SideOnly(Side.CLIENT)
  public atc a(double par1, double par3, double par5, double par7)
  {
    int i = ls.c(par1);
    int j = ls.c(par3);
    int k = ls.c(par5);
    
    if (amy.d_(q, i, j - 1, k))
    {
      j--;
    }
    
    int l = q.a(i, j, k);
    
    if (!amy.e_(l))
    {
      return null;
    }
    

    int i1 = ((amy)aqz.s[l]).getBasicRailMetadata(q, this, i, j, k);
    
    par3 = j;
    
    if ((i1 >= 2) && (i1 <= 5))
    {
      par3 = j + 1;
    }
    
    int[][] aint = d[i1];
    double d4 = aint[1][0] - aint[0][0];
    double d5 = aint[1][2] - aint[0][2];
    double d6 = Math.sqrt(d4 * d4 + d5 * d5);
    d4 /= d6;
    d5 /= d6;
    par1 += d4 * par7;
    par5 += d5 * par7;
    
    if ((aint[0][1] != 0) && (ls.c(par1) - i == aint[0][0]) && (ls.c(par5) - k == aint[0][2]))
    {
      par3 += aint[0][1];
    }
    else if ((aint[1][1] != 0) && (ls.c(par1) - i == aint[1][0]) && (ls.c(par5) - k == aint[1][2]))
    {
      par3 += aint[1][1];
    }
    
    return a(par1, par3, par5);
  }
  

  public atc a(double par1, double par3, double par5)
  {
    int i = ls.c(par1);
    int j = ls.c(par3);
    int k = ls.c(par5);
    
    if (amy.d_(q, i, j - 1, k))
    {
      j--;
    }
    
    int l = q.a(i, j, k);
    
    if (amy.e_(l))
    {
      int i1 = ((amy)aqz.s[l]).getBasicRailMetadata(q, this, i, j, k);
      par3 = j;
      
      if ((i1 >= 2) && (i1 <= 5))
      {
        par3 = j + 1;
      }
      
      int[][] aint = d[i1];
      double d3 = 0.0D;
      double d4 = i + 0.5D + aint[0][0] * 0.5D;
      double d5 = j + 0.5D + aint[0][1] * 0.5D;
      double d6 = k + 0.5D + aint[0][2] * 0.5D;
      double d7 = i + 0.5D + aint[1][0] * 0.5D;
      double d8 = j + 0.5D + aint[1][1] * 0.5D;
      double d9 = k + 0.5D + aint[1][2] * 0.5D;
      double d10 = d7 - d4;
      double d11 = (d8 - d5) * 2.0D;
      double d12 = d9 - d6;
      
      if (d10 == 0.0D)
      {
        par1 = i + 0.5D;
        d3 = par5 - k;
      }
      else if (d12 == 0.0D)
      {
        par5 = k + 0.5D;
        d3 = par1 - i;
      }
      else
      {
        double d13 = par1 - d4;
        double d14 = par5 - d6;
        d3 = (d13 * d10 + d14 * d12) * 2.0D;
      }
      
      par1 = d4 + d10 * d3;
      par3 = d5 + d11 * d3;
      par5 = d6 + d12 * d3;
      
      if (d11 < 0.0D)
      {
        par3 += 1.0D;
      }
      
      if (d11 > 0.0D)
      {
        par3 += 0.5D;
      }
      
      return q.V().a(par1, par3, par5);
    }
    

    return null;
  }
  




  protected void a(by par1NBTTagCompound)
  {
    if (par1NBTTagCompound.n("CustomDisplayTile"))
    {
      i(par1NBTTagCompound.e("DisplayTile"));
      j(par1NBTTagCompound.e("DisplayData"));
      k(par1NBTTagCompound.e("DisplayOffset"));
    }
    
    if ((par1NBTTagCompound.b("CustomName")) && (par1NBTTagCompound.i("CustomName").length() > 0))
    {
      c = par1NBTTagCompound.i("CustomName");
    }
  }
  



  protected void b(by par1NBTTagCompound)
  {
    if (s())
    {
      par1NBTTagCompound.a("CustomDisplayTile", true);
      par1NBTTagCompound.a("DisplayTile", m() == null ? 0 : mcF);
      par1NBTTagCompound.a("DisplayData", o());
      par1NBTTagCompound.a("DisplayOffset", q());
    }
    
    if ((c != null) && (c.length() > 0))
    {
      par1NBTTagCompound.a("CustomName", c);
    }
  }
  
  @SideOnly(Side.CLIENT)
  public float S()
  {
    return 0.0F;
  }
  



  public void f(nn par1Entity)
  {
    MinecraftForge.EVENT_BUS.post(new MinecartCollisionEvent(this, par1Entity));
    if (getCollisionHandler() != null)
    {
      getCollisionHandler().onEntityCollision(this, par1Entity);
      return;
    }
    if (!q.I)
    {
      if (par1Entity != n)
      {
        if (((par1Entity instanceof of)) && (O <= maxRiderWidth(par1Entity)) && ((par1Entity.isTiny()) || ((!(par1Entity instanceof uf)) && (!(par1Entity instanceof sd)))) && (canBeRidden()) && (x * x + z * z > 0.01D) && (n == null) && (o == null) && (holdingEntity == null))
        {
          par1Entity.a(this);
        }
        
        double d0 = u - u;
        double d1 = w - w;
        double d2 = d0 * d0 + d1 * d1;
        
        if (d2 >= 9.999999747378752E-5D)
        {
          d2 = ls.a(d2);
          d0 /= d2;
          d1 /= d2;
          double d3 = 1.0D / d2;
          
          if (d3 > 1.0D)
          {
            d3 = 1.0D;
          }
          
          d0 *= d3;
          d1 *= d3;
          d0 *= 0.10000000149011612D;
          d1 *= 0.10000000149011612D;
          d0 *= (1.0F - aa);
          d1 *= (1.0F - aa);
          d0 *= 0.5D;
          d1 *= 0.5D;
          
          if ((par1Entity instanceof st))
          {
            double d4 = u - u;
            double d5 = w - w;
            atc vec3 = q.V().a(d4, 0.0D, d5).a();
            atc vec31 = q.V().a(ls.b(A * 3.1415927F / 180.0F), 0.0D, ls.a(A * 3.1415927F / 180.0F)).a();
            double d6 = Math.abs(vec3.b(vec31));
            
            if (d6 < 0.800000011920929D)
            {
              return;
            }
            
            double d7 = x + x;
            double d8 = z + z;
            
            if ((((st)par1Entity).isPoweredCart()) && (!isPoweredCart()))
            {
              x *= 0.20000000298023224D;
              z *= 0.20000000298023224D;
              g(x - d0, 0.0D, z - d1);
              x *= 0.949999988079071D;
              z *= 0.949999988079071D;
            }
            else if ((!((st)par1Entity).isPoweredCart()) && (isPoweredCart()))
            {
              x *= 0.20000000298023224D;
              z *= 0.20000000298023224D;
              par1Entity.g(x + d0, 0.0D, z + d1);
              x *= 0.949999988079071D;
              z *= 0.949999988079071D;
            }
            else
            {
              d7 /= 2.0D;
              d8 /= 2.0D;
              x *= 0.20000000298023224D;
              z *= 0.20000000298023224D;
              g(d7 - d0, 0.0D, d8 - d1);
              x *= 0.20000000298023224D;
              z *= 0.20000000298023224D;
              par1Entity.g(d7 + d0, 0.0D, d8 + d1);
            }
          }
          else
          {
            if (!par1Entity.isExtraTiny())
            {
              g(-d0 * par1Entity.getSizeMultiplierRoot(), 0.0D, -d1 * par1Entity.getSizeMultiplierRoot());
            }
            
            par1Entity.g(d0 / 4.0D, 0.0D, d1 / 4.0D);
          }
        }
      }
    }
  }
  





  @SideOnly(Side.CLIENT)
  public void a(double par1, double par3, double par5, float par7, float par8, int par9)
  {
    f = par1;
    g = par3;
    h = par5;
    i = par7;
    j = par8;
    e = (par9 + 2);
    x = au;
    y = av;
    z = aw;
  }
  




  public void a(float par1)
  {
    ah.b(19, Float.valueOf(par1));
  }
  




  @SideOnly(Side.CLIENT)
  public void h(double par1, double par3, double par5)
  {
    au = (this.x = par1);
    av = (this.y = par3);
    aw = (this.z = par5);
  }
  




  public float i()
  {
    return ah.d(19);
  }
  



  public void c(int par1)
  {
    ah.b(17, Integer.valueOf(par1));
  }
  



  public int j()
  {
    return ah.c(17);
  }
  



  public void h(int par1)
  {
    ah.b(18, Integer.valueOf(par1));
  }
  



  public int k()
  {
    return ah.c(18);
  }
  
  public abstract int l();
  
  public aqz m()
  {
    if (!s())
    {
      return n();
    }
    

    int i = v().c(20) & 0xFFFF;
    return (i > 0) && (i < aqz.s.length) ? aqz.s[i] : null;
  }
  

  public aqz n()
  {
    return null;
  }
  
  public int o()
  {
    return !s() ? p() : v().c(20) >> 16;
  }
  
  public int p()
  {
    return 0;
  }
  
  public float maxRiderWidth(nn par1Entity)
  {
    return 1.0E-4F;
  }
  
  public int q()
  {
    return !s() ? r() : v().c(21);
  }
  
  public int r()
  {
    return 6;
  }
  
  public void i(int par1)
  {
    v().b(20, Integer.valueOf(par1 & 0xFFFF | o() << 16));
    a(true);
  }
  
  public void j(int par1)
  {
    aqz block = m();
    int j = block == null ? 0 : cF;
    v().b(20, Integer.valueOf(j & 0xFFFF | par1 << 16));
    a(true);
  }
  
  public void k(int par1)
  {
    v().b(21, Integer.valueOf(par1));
    a(true);
  }
  
  public boolean s()
  {
    return v().a(22) == 1;
  }
  
  public void a(boolean par1)
  {
    v().b(22, Byte.valueOf((byte)(par1 ? 1 : 0)));
  }
  



  public void a(String par1Str)
  {
    c = par1Str;
  }
  



  public String an()
  {
    return c != null ? c : super.an();
  }
  




  public boolean c()
  {
    return c != null;
  }
  
  public String t()
  {
    return c;
  }
  



  public void moveMinecartOnRail(int x, int y, int z, double par4)
  {
    double d12 = this.x;
    double d13 = this.z;
    
    if (n != null)
    {
      d12 *= 0.75D;
      d13 *= 0.75D;
    }
    
    if (d12 < -par4)
    {
      d12 = -par4;
    }
    
    if (d12 > par4)
    {
      d12 = par4;
    }
    
    if (d13 < -par4)
    {
      d13 = -par4;
    }
    
    if (d13 > par4)
    {
      d13 = par4;
    }
    
    d(d12, 0.0D, d13);
  }
  





  public static IMinecartCollisionHandler getCollisionHandler()
  {
    return collisionHandler;
  }
  





  public static void setCollisionHandler(IMinecartCollisionHandler handler)
  {
    collisionHandler = handler;
  }
  






  public ye getCartItem()
  {
    if ((this instanceof su))
    {
      return new ye(yc.aP);
    }
    if ((this instanceof tb))
    {
      return new ye(yc.cc);
    }
    if ((this instanceof sw))
    {
      return new ye(yc.aQ);
    }
    if ((this instanceof sx))
    {
      return new ye(yc.cd);
    }
    return new ye(yc.aB);
  }
  





  public boolean canUseRail()
  {
    return canUseRail;
  }
  





  public void setCanUseRail(boolean use)
  {
    canUseRail = use;
  }
  




  public boolean shouldDoRailFunctions()
  {
    return true;
  }
  




  public boolean isPoweredCart()
  {
    return l() == 2;
  }
  




  public boolean canBeRidden()
  {
    if ((this instanceof sy))
    {
      return true;
    }
    return false;
  }
  













  public float getMaxCartSpeedOnRail()
  {
    return 1.2F;
  }
  








  public final float getCurrentCartSpeedCapOnRail()
  {
    return currentSpeedRail;
  }
  
  public final void setCurrentCartSpeedCapOnRail(float value)
  {
    value = Math.min(value, getMaxCartSpeedOnRail());
    currentSpeedRail = value;
  }
  
  public float getMaxSpeedAirLateral()
  {
    return maxSpeedAirLateral;
  }
  
  public void setMaxSpeedAirLateral(float value)
  {
    maxSpeedAirLateral = value;
  }
  
  public float getMaxSpeedAirVertical()
  {
    return maxSpeedAirVertical;
  }
  
  public void setMaxSpeedAirVertical(float value)
  {
    maxSpeedAirVertical = value;
  }
  
  public double getDragAir()
  {
    return dragAir;
  }
  
  public void setDragAir(double value)
  {
    dragAir = value;
  }
  
  public double getSlopeAdjustment()
  {
    return 0.0078125D;
  }
}
