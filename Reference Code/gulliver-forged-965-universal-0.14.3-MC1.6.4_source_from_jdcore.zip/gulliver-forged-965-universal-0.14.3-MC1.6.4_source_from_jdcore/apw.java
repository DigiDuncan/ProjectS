import gulliver.common.GulliverEnvoy;
import gulliver.common.GulliverOMHelper;
import java.util.Iterator;
import java.util.List;









public class apw
  extends amx
{
  private apx a;
  
  protected apw(int par1, String par2Str, akc par3Material, apx par4EnumMobType)
  {
    super(par1, par2Str, par3Material);
    a = par4EnumMobType;
  }
  



  protected int d(int par1)
  {
    return par1 > 0 ? 1 : 0;
  }
  



  protected int c(int par1)
  {
    return par1 == 1 ? 15 : 0;
  }
  




  protected int e(abw par1World, int par2, int par3, int par4)
  {
    List list = null;
    
    if (a == apx.a)
    {
      list = par1World.b((nn)null, a(par2, par3, par4));
    }
    
    if (a == apx.b)
    {
      list = par1World.a(of.class, a(par2, par3, par4));
      
      GulliverEnvoy.pruneSmallerEntities(0.3F, list);
    }
    
    if (a == apx.c)
    {
      list = par1World.a(uf.class, a(par2, par3, par4));
      
      GulliverEnvoy.pruneSmallerEntities(0.3F, list);
    }
    
    if ((list != null) && (!list.isEmpty()))
    {
      Iterator iterator = list.iterator();
      
      while (iterator.hasNext())
      {
        nn entity = (nn)iterator.next();
        
        if (!entity.au())
        {
          return 15;
        }
      }
    }
    
    return 0;
  }
  



  public boolean a(abw par1World, int par2, int par3, int par4, uf par5EntityPlayer, int par6, float par7, float par8, float par9)
  {
    if ((I) || (GulliverOMHelper.isLittleBlocksWorld(par1World)) || (!GulliverEnvoy.canPressPlateLikeButton(par5EntityPlayer)) || (par1World.h(par2, par3, par4) == 1))
    {
      return true;
    }
    
    par1World.b(par2, par3, par4, 1, 2);
    b_(par1World, par2, par3, par4);
    par1World.g(par2, par3, par4, par2, par3, par4);
    par1World.a(par2 + 0.5D, par3 + 0.1D, par4 + 0.5D, "random.click", 0.3F, 0.6F);
    par1World.a(par2, par3, par4, cF, a(par1World));
    
    return true;
  }
}
