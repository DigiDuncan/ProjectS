import com.google.common.base.Charsets;
import cpw.mods.fml.common.network.FMLNetworkHandler;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import gulliver.common.GulliverEnvoy;
import gulliver.network.packet.Packet171EntitySize;
import gulliver.network.packet.Packet172AttachEntitySpecial;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigInteger;
import java.net.InetAddress;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.security.PublicKey;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.logging.Logger;
import javax.crypto.SecretKey;
import net.minecraft.client.ClientBrandRetriever;
import net.minecraftforge.client.event.ClientChatReceivedEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.EventBus;
import org.lwjgl.input.Keyboard;


















































































































































































@SideOnly(Side.CLIENT)
public class bcw
  extends ez
{
  private boolean f;
  private cm g;
  public String a;
  private atv h;
  private bdd i;
  private boolean j;
  public amr b = new amr((amc)null);
  

  private Map k = new HashMap();
  



  public List c = new ArrayList();
  public int d = 20;
  
  private awe l;
  
  Random e = new Random();
  private static byte connectionCompatibilityLevel;
  
  public bcw(atv par1Minecraft, String par2Str, int par3)
    throws IOException
  {
    h = par1Minecraft;
    Socket socket = new Socket(InetAddress.getByName(par2Str), par3);
    g = new co(par1Minecraft.an(), socket, "Client", this);
    FMLNetworkHandler.onClientConnectionToRemoteServer(this, par2Str, par3, g);
  }
  
  public bcw(atv par1Minecraft, String par2Str, int par3, awe par4GuiScreen) throws IOException
  {
    h = par1Minecraft;
    l = par4GuiScreen;
    Socket socket = new Socket(InetAddress.getByName(par2Str), par3);
    g = new co(par1Minecraft.an(), socket, "Client", this);
    FMLNetworkHandler.onClientConnectionToRemoteServer(this, par2Str, par3, g);
  }
  
  public bcw(atv par1Minecraft, bkz par2IntegratedServer) throws IOException
  {
    h = par1Minecraft;
    g = new cn(par1Minecraft.an(), this);
    par2IntegratedServer.a().a((cn)g, par1Minecraft.H().a());
    FMLNetworkHandler.onClientConnectionToIntegratedServer(this, par2IntegratedServer, g);
  }
  



  public void d()
  {
    if (g != null)
    {
      g.a();
    }
    
    g = null;
    i = null;
  }
  



  public void e()
  {
    if ((!f) && (g != null))
    {
      g.b();
    }
    
    if (g != null)
    {
      g.a();
    }
  }
  
  public void a(fj par1Packet253ServerAuthData)
  {
    String s = par1Packet253ServerAuthData.d().trim();
    PublicKey publickey = par1Packet253ServerAuthData.f();
    SecretKey secretkey = lg.a();
    
    if (!"-".equals(s))
    {
      String s1 = new BigInteger(lg.a(s, publickey, secretkey)).toString(16);
      String s2 = a(h.H().a(), h.H().b(), s1);
      
      if (!"ok".equalsIgnoreCase(s2))
      {
        g.a("disconnect.loginFailedInfo", new Object[] { s2 });
        return;
      }
    }
    
    c(new fy(secretkey, publickey, par1Packet253ServerAuthData.g()));
  }
  



  private String a(String par1Str, String par2Str, String par3Str)
  {
    try
    {
      URL url = new URL("http://session.minecraft.net/game/joinserver.jsp?user=" + a(par1Str) + "&sessionId=" + a(par2Str) + "&serverId=" + a(par3Str));
      InputStream inputstream = url.openConnection(h.I()).getInputStream();
      BufferedReader bufferedreader = new BufferedReader(new InputStreamReader(inputstream));
      String s3 = bufferedreader.readLine();
      bufferedreader.close();
      return s3;
    }
    catch (IOException ioexception)
    {
      return ioexception.toString();
    }
  }
  


  private static String a(String par0Str)
    throws IOException
  {
    return URLEncoder.encode(par0Str, "UTF-8");
  }
  
  public void a(fy par1Packet252SharedKey)
  {
    c(FMLNetworkHandler.getFMLFakeLoginPacket());
    c(new do(0));
  }
  
  public void a(ep par1Packet1Login)
  {
    h.c = new bdc(h, this);
    h.y.a(la.i, 1);
    i = new bdd(this, new acd(0L, d, false, c, b), e, f, h.C, h.an());
    i.I = true;
    h.a(i);
    h.h.ar = e;
    h.a(new bdk(this));
    h.h.k = a;
    d = h;
    h.c.a(d);
    FMLNetworkHandler.onConnectionEstablishedToServer(this, g, par1Packet1Login);
    h.u.c();
    g.a(new ea("MC|Brand", ClientBrandRetriever.getClientModName().getBytes(Charsets.UTF_8)));
  }
  
  public void a(dd par1Packet23VehicleSpawn)
  {
    double d0 = b / 32.0D;
    double d1 = c / 32.0D;
    double d2 = d / 32.0D;
    Object object = null;
    
    if (j == 10)
    {
      object = st.a(this.i, d0, d1, d2, k);
    }
    else if (j == 90)
    {
      nn entity = a(k);
      
      if ((entity instanceof uf))
      {
        object = new ul(this.i, d0, d1, d2, (uf)entity);
      }
      
      k = 0;
    }
    else if (j == 60)
    {
      object = new uh(this.i, d0, d1, d2);
    }
    else if (j == 61)
    {
      object = new up(this.i, d0, d1, d2);
    }
    else if (j == 71)
    {
      object = new od(this.i, (int)d0, (int)d1, (int)d2, k);
      k = 0;
    }
    else if (j == 77)
    {
      object = new oe(this.i, (int)d0, (int)d1, (int)d2);
      k = 0;
    }
    else if (j == 65)
    {
      object = new us(this.i, d0, d1, d2);
    }
    else if (j == 72)
    {
      object = new ui(this.i, d0, d1, d2);
    }
    else if (j == 76)
    {
      object = new uk(this.i, d0, d1, d2, (ye)null);
    }
    else if (j == 63)
    {
      object = new um(this.i, d0, d1, d2, e / 8000.0D, f / 8000.0D, g / 8000.0D);
      k = 0;
    }
    else if (j == 64)
    {
      object = new uo(this.i, d0, d1, d2, e / 8000.0D, f / 8000.0D, g / 8000.0D);
      k = 0;
    }
    else if (j == 66)
    {
      object = new uv(this.i, d0, d1, d2, e / 8000.0D, f / 8000.0D, g / 8000.0D);
      k = 0;
    }
    else if (j == 62)
    {
      object = new ur(this.i, d0, d1, d2);
    }
    else if (j == 73)
    {
      object = new uu(this.i, d0, d1, d2, k);
      k = 0;
    }
    else if (j == 75)
    {
      object = new ut(this.i, d0, d1, d2);
      k = 0;
    }
    else if (j == 1)
    {
      object = new sq(this.i, d0, d1, d2);
    }
    else if (j == 50)
    {
      object = new tc(this.i, d0, d1, d2, (of)null);
    }
    else if (j == 51)
    {
      object = new sj(this.i, d0, d1, d2);
    }
    else if (j == 2)
    {
      object = new ss(this.i, d0, d1, d2);
    }
    else if (j == 70)
    {
      object = new sr(this.i, d0, d1, d2, k & 0xFFFF, k >> 16);
      k = 0;
    }
    
    if (object != null)
    {
      bZ = b;
      ca = c;
      cb = d;
      B = (h * 360 / 256.0F);
      A = (i * 360 / 256.0F);
      nn[] aentity = ((nn)object).ao();
      
      if (aentity != null)
      {
        int i = a - k;
        
        for (int j = 0; j < aentity.length; j++)
        {
          k += i;
        }
      }
      
      k = a;
      this.i.a(a, (nn)object);
      
      if (k > 0)
      {
        if (j == 60)
        {
          nn entity1 = a(k);
          
          if ((entity1 instanceof of))
          {
            uh entityarrow = (uh)object;
            c = entity1;
          }
        }
        
        ((nn)object).h(e / 8000.0D, f / 8000.0D, g / 8000.0D);
      }
    }
  }
  



  public void a(de par1Packet26EntityExpOrb)
  {
    oa entityxporb = new oa(i, b, c, d, e);
    bZ = b;
    ca = c;
    cb = d;
    A = 0.0F;
    B = 0.0F;
    k = a;
    i.a(a, entityxporb);
  }
  



  public void a(df par1Packet71Weather)
  {
    double d0 = b / 32.0D;
    double d1 = c / 32.0D;
    double d2 = d / 32.0D;
    sp entitylightningbolt = null;
    
    if (e == 1)
    {
      entitylightningbolt = new sp(i, d0, d1, d2);
    }
    
    if (entitylightningbolt != null)
    {
      bZ = b;
      ca = c;
      cb = d;
      A = 0.0F;
      B = 0.0F;
      k = a;
      i.c(entitylightningbolt);
    }
  }
  



  public void a(dh par1Packet25EntityPainting)
  {
    ol entitypainting = new ol(i, b, c, d, e, f);
    i.a(a, entitypainting);
  }
  



  public void a(fp par1Packet28EntityVelocity)
  {
    nn entity = a(a);
    
    if (entity != null)
    {
      entity.h(b / 8000.0D, c / 8000.0D, d / 8000.0D);
    }
  }
  



  public void a(fn par1Packet40EntityMetadata)
  {
    nn entity = a(a);
    
    if ((entity != null) && (par1Packet40EntityMetadata.d() != null))
    {
      entity.v().a(par1Packet40EntityMetadata.d());
    }
  }
  
  public void a(di par1Packet20NamedEntitySpawn)
  {
    double d0 = c / 32.0D;
    double d1 = d / 32.0D;
    double d2 = e / 32.0D;
    float f = f * 360 / 256.0F;
    float f1 = g * 360 / 256.0F;
    bey entityotherplayermp = new bey(h.f, b);
    r = (entityotherplayermp.U = entityotherplayermp.bZ = c);
    s = (entityotherplayermp.V = entityotherplayermp.ca = d);
    t = (entityotherplayermp.W = entityotherplayermp.cb = e);
    int i = h;
    
    if (i == 0)
    {
      bn.a[bn.c] = null;
    }
    else
    {
      bn.a[bn.c] = new ye(i, 1, 0);
    }
    
    entityotherplayermp.a(d0, d1, d2, f, f1);
    this.i.a(a, entityotherplayermp);
    List list = par1Packet20NamedEntitySpawn.c();
    
    if (list != null)
    {
      entityotherplayermp.v().a(list);
    }
  }
  
  public void a(gb par1Packet34EntityTeleport)
  {
    nn entity = a(a);
    
    if (entity != null)
    {
      bZ = b;
      ca = c;
      cb = d;
      double d0 = bZ / 32.0D;
      double d1 = ca / 32.0D + 0.015625D;
      double d2 = cb / 32.0D;
      float f = e * 360 / 256.0F;
      float f1 = f * 360 / 256.0F;
      entity.a(d0, d1, d2, f, f1, 3);
    }
  }
  
  public void handleEntitySize(Packet171EntitySize par1Packet171EntitySize)
  {
    nn var2 = a(entityId);
    
    if (var2 != null)
    {
      if ((var2 instanceof of))
      {
        ((of)var2).doResize(sizeMult, true);
      }
      else
      {
        float f = var2.getSizeMultiplier();
        var2.setSizeMultiplier(sizeMult);
        if ((var2 instanceof ss))
        {
          var2.a(O * var2.getSizeMultiplier(), P * var2.getSizeMultiplier());
          N = (P / 2.0F);
        }
        else if ((f == 1.0F) || (f == 0.0F))
        {
          var2.a(O, P);
        }
        else if (var2.isResizable())
        {
          var2.a(O / f, P / f);
        }
      }
    }
  }
  

  public void handleAttachEntitySpecial(Packet172AttachEntitySpecial par1Packet172AttachEntitySpecial)
  {
    Object var2 = a(entityId);
    nn var3 = a(vehicleEntityId);
    

    if (entityId == h.h.k)
    {
      var2 = h.h;
      
      if ((var3 instanceof sq))
      {
        ((sq)var3).a(false);
      }
    }
    else if ((var3 instanceof sq))
    {
      ((sq)var3).a(true);
    }
    
    if ((attachmentType == 0) && (var3 != null))
    {


      if ((var2 != null) && ((var2 instanceof sq)))
      {
        ((sq)var2).a(true);
      }
      
      var3.dropHeldEntity((nn)var2);
    }
    else if ((attachmentType == 1) && (var2 != null))
    {

      ((nn)var2).a(var3);
    }
    else if ((attachmentType == 3) && (var3 != null))
    {


      if ((var2 != null) && ((var2 instanceof sq))) {}
      



      var3.pickUpEntity((nn)var2);
    }
  }
  
  public void a(fk par1Packet16BlockItemSwitch)
  {
    if ((a >= 0) && (a < ud.i()))
    {
      h.h.bn.c = a;
    }
  }
  
  public void a(eq par1Packet30Entity)
  {
    nn entity = a(a);
    
    if (entity != null)
    {
      bZ += b;
      ca += c;
      cb += d;
      double d0 = bZ / 32.0D;
      double d1 = ca / 32.0D;
      double d2 = cb / 32.0D;
      float f = g ? e * 360 / 256.0F : A;
      float f1 = g ? f * 360 / 256.0F : B;
      entity.a(d0, d1, d2, f, f1, 3);
    }
  }
  
  public void a(fi par1Packet35EntityHeadRotation)
  {
    nn entity = a(a);
    
    if (entity != null)
    {
      float f = b * 360 / 256.0F;
      entity.e(f);
    }
  }
  
  public void a(ff par1Packet29DestroyEntity)
  {
    for (int i = 0; i < a.length; i++)
    {
      this.i.b(a[i]);
    }
  }
  
  public void a(eu par1Packet10Flying)
  {
    bdi entityclientplayermp = h.h;
    double d0 = u;
    double d1 = v;
    double d2 = w;
    float f = A;
    float f1 = B;
    
    if (h)
    {
      d0 = a;
      d1 = b;
      d2 = c;
    }
    
    if (i)
    {
      f = e;
      f1 = f;
    }
    
    X = 0.0F;
    x = (entityclientplayermp.y = entityclientplayermp.z = 0.0D);
    entityclientplayermp.a(d0, d1, d2, f, f1);
    a = u;
    b = E.b;
    c = w;
    d = v;
    g.a(par1Packet10Flying);
    if (v < E.b)
    {


      GulliverEnvoy.getLogger().warning("Uh oh, player position (" + u + "," + v + "," + w + ") is beneath player bounding box " + E.toString() + " (sizemult=" + entityclientplayermp.getSizeMultiplier() + ")");
    }
    
    if (!j)
    {
      h.h.r = h.h.u;
      h.h.s = h.h.v;
      h.h.t = h.h.w;
      j = true;
      h.a((awe)null);
    }
  }
  
  public void a(dn par1Packet52MultiBlockChange)
  {
    int i = a * 16;
    int j = b * 16;
    
    if (c != null)
    {
      DataInputStream datainputstream = new DataInputStream(new ByteArrayInputStream(c));
      
      try
      {
        for (int k = 0; k < d; k++)
        {
          short short1 = datainputstream.readShort();
          short short2 = datainputstream.readShort();
          int l = short2 >> 4 & 0xFFF;
          int i1 = short2 & 0xF;
          int j1 = short1 >> 12 & 0xF;
          int k1 = short1 >> 8 & 0xF;
          int l1 = short1 & 0xFF;
          this.i.g(j1 + i, l1, k1 + j, l, i1);
        }
      }
      catch (IOException ioexception) {}
    }
  }
  






  public void a(ej par1Packet51MapChunk)
  {
    if (e)
    {
      if (c == 0)
      {
        i.a(a, b, false);
        return;
      }
      
      i.a(a, b, true);
    }
    
    i.c(a << 4, 0, b << 4, (a << 4) + 15, 256, (b << 4) + 15);
    adr chunk = i.e(a, b);
    
    if ((e) && (chunk == null))
    {
      i.a(a, b, true);
      chunk = i.e(a, b);
    }
    
    if (chunk != null)
    {
      chunk.a(par1Packet51MapChunk.d(), c, d, e);
      i.g(a << 4, 0, b << 4, (a << 4) + 15, 256, (b << 4) + 15);
      
      if ((!e) || (!(i.t instanceof aek)))
      {
        chunk.n();
      }
    }
  }
  
  public void a(gg par1Packet53BlockChange)
  {
    i.g(a, b, c, d, e);
  }
  
  public void a(eb par1Packet255KickDisconnect)
  {
    g.a("disconnect.kicked", new Object[] { a });
    f = true;
    h.a((bdd)null);
    
    if (l != null)
    {
      h.a(new ayj(l, "disconnect.disconnected", "disconnect.genericReason", new Object[] { a }));
    }
    else
    {
      h.a(new bda(new avn(new blt()), "disconnect.disconnected", "disconnect.genericReason", new Object[] { a }));
    }
  }
  
  public void a(String par1Str, Object[] par2ArrayOfObj)
  {
    if (!f)
    {
      f = true;
      h.a((bdd)null);
      
      if (l != null)
      {
        h.a(new ayj(l, "disconnect.lost", par1Str, par2ArrayOfObj));
      }
      else
      {
        h.a(new bda(new avn(new blt()), "disconnect.lost", par1Str, par2ArrayOfObj));
      }
    }
  }
  
  public void b(ey par1Packet)
  {
    if (!f)
    {
      g.a(par1Packet);
      g.d();
      FMLNetworkHandler.onConnectionClosed(g, getPlayer());
    }
  }
  



  public void c(ey par1Packet)
  {
    if (!f)
    {
      g.a(par1Packet);
    }
  }
  
  public void a(ga par1Packet22Collect)
  {
    nn entity = a(a);
    Object object = (of)a(b);
    
    if (object == null)
    {
      object = h.h;
    }
    
    if (entity != null)
    {
      if ((entity instanceof oa))
      {
        i.a(entity, "random.orb", 0.2F, ((e.nextFloat() - e.nextFloat()) * 0.7F + 1.0F) * 2.0F);
      }
      else
      {
        i.a(entity, "random.pop", 0.2F, ((e.nextFloat() - e.nextFloat()) * 0.7F + 1.0F) * 2.0F);
      }
      
      h.k.a(new ber(h.f, entity, (nn)object, -0.5F));
      i.b(a);
    }
  }
  
  public void a(dm par1Packet3Chat)
  {
    par1Packet3Chat = FMLNetworkHandler.handleChatMessage(this, par1Packet3Chat);
    if (par1Packet3Chat == null)
    {
      return;
    }
    ClientChatReceivedEvent event = new ClientChatReceivedEvent(a);
    if ((!MinecraftForge.EVENT_BUS.post(event)) && (message != null))
    {
      h.r.b().a(cv.c(message).a(true));
    }
  }
  
  public void a(dj par1Packet18Animation)
  {
    nn entity = a(a);
    
    if (entity != null)
    {
      if (b == 1)
      {
        of entitylivingbase = (of)entity;
        entitylivingbase.aV();
      }
      else if (b == 2)
      {
        entity.ad();
      }
      else if (b == 3)
      {
        uf entityplayer = (uf)entity;
        entityplayer.a(false, false, false);
      }
      else if (b != 4)
      {
        if (b == 6)
        {
          h.k.a(new bdq(h.f, entity));
        }
        else if (b == 7)
        {
          bdq entitycrit2fx = new bdq(h.f, entity, "magicCrit");
          h.k.a(entitycrit2fx);
        }
        else if ((b != 5) || (!(entity instanceof bey))) {}
      }
    }
  }
  



  public void a(ec par1Packet17Sleep)
  {
    nn entity = a(a);
    
    if (entity != null)
    {
      if (e == 0)
      {
        uf entityplayer = (uf)entity;
        entityplayer.a(b, c, d);
      }
    }
  }
  



  public void f()
  {
    f = true;
    g.a();
    g.a("disconnect.closed", new Object[0]);
  }
  
  public void a(dg par1Packet24MobSpawn)
  {
    double d0 = c / 32.0D;
    double d1 = d / 32.0D;
    double d2 = e / 32.0D;
    float f = i * 360 / 256.0F;
    float f1 = j * 360 / 256.0F;
    of entitylivingbase = (of)nt.a(b, h.f);
    bZ = c;
    ca = d;
    cb = e;
    aP = (k * 360 / 256.0F);
    nn[] aentity = entitylivingbase.ao();
    
    if (aentity != null)
    {
      int i = a - k;
      
      for (int j = 0; j < aentity.length; j++)
      {
        k += i;
      }
    }
    
    k = a;
    entitylivingbase.a(d0, d1, d2, f, f1);
    x = (f / 8000.0F);
    y = (g / 8000.0F);
    z = (h / 8000.0F);
    this.i.a(a, entitylivingbase);
    List list = par1Packet24MobSpawn.c();
    
    if (list != null)
    {
      entitylivingbase.v().a(list);
    }
    
    if ((entitylivingbase instanceof ts))
    {

      ((ts)entitylivingbase).a(((ts)entitylivingbase).bR());
    }
  }
  
  public void a(fx par1Packet4UpdateTime)
  {
    h.f.a(a);
    h.f.b(b);
  }
  
  public void a(fw par1Packet6SpawnPosition)
  {
    h.h.a(new t(a, b, c), true);
    h.f.N().a(a, b, c);
  }
  



  public void a(fo par1Packet39AttachEntity)
  {
    Object object = a(b);
    nn entity = a(c);
    
    if (a == 0)
    {
      boolean flag = false;
      
      if (b == h.h.k)
      {
        object = h.h;
        
        if ((entity instanceof sq))
        {
          ((sq)entity).a(false);
        }
        
        flag = (o == null) && (entity != null);
      }
      else if ((entity instanceof sq))
      {
        ((sq)entity).a(true);
      }
      
      if (object == null)
      {
        return;
      }
      
      ((nn)object).a(entity);
      
      if (flag)
      {
        aul gamesettings = h.u;
        h.r.a(bkb.a("mount.onboard", new Object[] { aul.c(Q.d) }), false);
      }
    }
    else if ((a == 1) && (object != null) && ((object instanceof og)))
    {
      if (entity != null)
      {
        ((og)object).b(entity, false);
      }
      else
      {
        ((og)object).a(false, false);
      }
    }
  }
  



  public void a(ed par1Packet38EntityStatus)
  {
    nn entity = a(a);
    
    if (entity != null)
    {
      entity.a(b);
    }
  }
  
  private nn a(int par1)
  {
    return par1 == h.h.k ? h.h : i.a(par1);
  }
  



  public void a(fs par1Packet8UpdateHealth)
  {
    h.h.n(a);
    h.h.bI().a(b);
    h.h.bI().b(c);
  }
  



  public void a(fr par1Packet43Experience)
  {
    h.h.a(a, b, c);
  }
  



  public void a(fh par1Packet9Respawn)
  {
    if (a != h.h.ar)
    {
      j = false;
      atj scoreboard = i.X();
      i = new bdd(this, new acd(0L, d, false, h.f.N().t(), e), a, b, h.C, h.an());
      i.a(scoreboard);
      i.I = true;
      h.a(i);
      h.h.ar = a;
      h.a(new bdk(this));
    }
    
    h.a(a);
    h.c.a(d);
  }
  
  public void a(ee par1Packet60Explosion)
  {
    abr explosion = new abr(h.f, (nn)null, a, b, c, d);
    h = e;
    explosion.a(true);
    h.h.x += par1Packet60Explosion.d();
    h.h.y += par1Packet60Explosion.f();
    h.h.z += par1Packet60Explosion.g();
  }
  
  public void a(dw par1Packet100OpenWindow)
  {
    bdi entityclientplayermp = h.h;
    
    switch (b)
    {
    case 0: 
      entityclientplayermp.a(new mu(c, e, d));
      bp.d = a;
      break;
    case 1: 
      entityclientplayermp.b(ls.c(u), ls.c(v), ls.c(w));
      bp.d = a;
      break;
    case 2: 
      asg tileentityfurnace = new asg();
      
      if (e)
      {
        tileentityfurnace.a(c);
      }
      
      entityclientplayermp.a(tileentityfurnace);
      bp.d = a;
      break;
    case 3: 
      asc tileentitydispenser = new asc();
      
      if (e)
      {
        tileentitydispenser.a(c);
      }
      
      entityclientplayermp.a(tileentitydispenser);
      bp.d = a;
      break;
    case 4: 
      entityclientplayermp.a(ls.c(u), ls.c(v), ls.c(w), e ? c : null);
      bp.d = a;
      break;
    case 5: 
      arx tileentitybrewingstand = new arx();
      
      if (e)
      {
        tileentitybrewingstand.a(c);
      }
      
      entityclientplayermp.a(tileentitybrewingstand);
      bp.d = a;
      break;
    case 6: 
      entityclientplayermp.a(new tz(entityclientplayermp), e ? c : null);
      bp.d = a;
      break;
    case 7: 
      arw tileentitybeacon = new arw();
      entityclientplayermp.a(tileentitybeacon);
      
      if (e)
      {
        tileentitybeacon.a(c);
      }
      
      bp.d = a;
      break;
    case 8: 
      entityclientplayermp.c(ls.c(u), ls.c(v), ls.c(w));
      bp.d = a;
      break;
    case 9: 
      asi tileentityhopper = new asi();
      
      if (e)
      {
        tileentityhopper.a(c);
      }
      
      entityclientplayermp.a(tileentityhopper);
      bp.d = a;
      break;
    case 10: 
      asd tileentitydropper = new asd();
      
      if (e)
      {
        tileentitydropper.a(c);
      }
      
      entityclientplayermp.a(tileentitydropper);
      bp.d = a;
      break;
    case 11: 
      nn entity = a(f);
      
      if ((entity != null) && ((entity instanceof rs)))
      {
        entityclientplayermp.a((rs)entity, new uz(c, e, d));
        bp.d = a;
      }
      break;
    }
  }
  
  public void a(dz par1Packet103SetSlot) {
    bdi entityclientplayermp = h.h;
    
    if (a == -1)
    {
      bn.b(c);
    }
    else
    {
      boolean flag = false;
      
      if ((h.n instanceof axm))
      {
        axm guicontainercreative = (axm)h.n;
        flag = guicontainercreative.g() != ww.m.a();
      }
      
      if ((a == 0) && (b >= 36) && (b < 45))
      {
        ye itemstack = bo.a(b).d();
        
        if ((c != null) && ((itemstack == null) || (b < c.b)))
        {
          c.c = 5;
        }
        
        bo.a(b, c);
      }
      else if ((a == bp.d) && ((a != 0) || (!flag)))
      {
        bp.a(b, c);
      }
    }
  }
  
  public void a(ds par1Packet106Transaction)
  {
    uy container = null;
    bdi entityclientplayermp = h.h;
    
    if (a == 0)
    {
      container = bo;
    }
    else if (a == bp.d)
    {
      container = bp;
    }
    
    if ((container != null) && (!c))
    {
      c(new ds(a, b, true));
    }
  }
  
  public void a(dx par1Packet104WindowItems)
  {
    bdi entityclientplayermp = h.h;
    
    if (a == 0)
    {
      bo.a(b);
    }
    else if (a == bp.d)
    {
      bp.a(b);
    }
  }
  
  public void a(gd par1Packet133TileEditorOpen)
  {
    asp tileentity = i.r(b, c, d);
    
    if (tileentity != null)
    {
      h.h.a(tileentity);
    }
    else if (a == 0)
    {
      asm tileentitysign = new asm();
      tileentitysign.b(i);
      l = b;
      m = c;
      n = d;
      h.h.a(tileentitysign);
    }
  }
  



  public void a(fz par1Packet130UpdateSign)
  {
    boolean flag = false;
    
    if (h.f.f(a, b, c))
    {
      asp tileentity = h.f.r(a, b, c);
      
      if ((tileentity instanceof asm))
      {
        asm tileentitysign = (asm)tileentity;
        
        if (tileentitysign.a())
        {
          for (int i = 0; i < 4; i++)
          {
            a[i] = d[i];
          }
          
          tileentitysign.e();
        }
        
        flag = true;
      }
    }
    
    if ((!flag) && (h.h != null))
    {
      h.h.a(cv.d("Unable to locate sign at " + a + ", " + b + ", " + c));
    }
  }
  
  public void a(ge par1Packet132TileEntityData)
  {
    if (h.f.f(a, b, c))
    {
      asp tileentity = h.f.r(a, b, c);
      
      if (tileentity != null)
      {
        if ((d == 1) && ((tileentity instanceof asj)))
        {
          tileentity.a(e);
        }
        else if ((d == 2) && ((tileentity instanceof arz)))
        {
          tileentity.a(e);
        }
        else if ((d == 3) && ((tileentity instanceof arw)))
        {
          tileentity.a(e);
        }
        else if ((d == 4) && ((tileentity instanceof asn)))
        {
          tileentity.a(e);
        }
        else
        {
          tileentity.onDataPacket(g, par1Packet132TileEntityData);
        }
      }
    }
  }
  
  public void a(dy par1Packet105UpdateProgressbar)
  {
    bdi entityclientplayermp = h.h;
    a(par1Packet105UpdateProgressbar);
    
    if ((bp != null) && (bp.d == a))
    {
      bp.b(b, c);
    }
  }
  
  public void a(fq par1Packet5PlayerInventory)
  {
    nn entity = a(a);
    
    if (entity != null)
    {
      entity.c(b, par1Packet5PlayerInventory.d());
    }
  }
  
  public void a(dv par1Packet101CloseWindow)
  {
    h.h.g();
  }
  
  public void a(gf par1Packet54PlayNoteBlock)
  {
    h.f.d(a, b, c, f, d, e);
  }
  
  public void a(gc par1Packet55BlockDestroy)
  {
    h.f.f(par1Packet55BlockDestroy.d(), par1Packet55BlockDestroy.f(), par1Packet55BlockDestroy.g(), par1Packet55BlockDestroy.h(), par1Packet55BlockDestroy.i());
  }
  
  public void a(el par1Packet56MapChunks)
  {
    for (int i = 0; i < par1Packet56MapChunks.d(); i++)
    {
      int j = par1Packet56MapChunks.a(i);
      int k = par1Packet56MapChunks.b(i);
      this.i.a(j, k, true);
      this.i.c(j << 4, 0, k << 4, (j << 4) + 15, 256, (k << 4) + 15);
      adr chunk = this.i.e(j, k);
      
      if (chunk == null)
      {
        this.i.a(j, k, true);
        chunk = this.i.e(j, k);
      }
      
      if (chunk != null)
      {
        chunk.a(par1Packet56MapChunks.c(i), a[i], b[i], true);
        this.i.g(j << 4, 0, k << 4, (j << 4) + 15, 256, (k << 4) + 15);
        
        if (!(it instanceof aek))
        {
          chunk.n();
        }
      }
    }
  }
  





  public boolean b()
  {
    return (h != null) && (h.f != null) && (h.h != null) && (i != null);
  }
  
  public void a(ef par1Packet70GameEvent)
  {
    bdi entityclientplayermp = h.h;
    int i = b;
    int j = c;
    
    if ((i >= 0) && (i < ef.a.length) && (ef.a[i] != null))
    {
      entityclientplayermp.a(ef.a[i]);
    }
    
    if (i == 1)
    {
      this.i.N().b(true);
      this.i.j(0.0F);
    }
    else if (i == 2)
    {
      this.i.N().b(false);
      this.i.j(1.0F);
    }
    else if (i == 3)
    {
      h.c.a(ace.a(j));
    }
    else if (i == 4)
    {
      h.a(new azr());
    }
    else if (i == 5)
    {
      aul gamesettings = h.u;
      
      if (j == 0)
      {
        h.a(new avd());
      }
      else if (j == 101)
      {
        h.r.b().a("demo.help.movement", new Object[] { Keyboard.getKeyName(I.d), Keyboard.getKeyName(J.d), Keyboard.getKeyName(K.d), Keyboard.getKeyName(L.d) });
      }
      else if (j == 102)
      {
        h.r.b().a("demo.help.jump", new Object[] { Keyboard.getKeyName(M.d) });
      }
      else if (j == 103)
      {
        h.r.b().a("demo.help.inventory", new Object[] { Keyboard.getKeyName(N.d) });
      }
    }
    else if (i == 6)
    {
      this.i.a(u, v + entityclientplayermp.f(), w, "random.successful_hit", 0.18F, 0.45F, false);
    }
  }
  



  public void a(dr par1Packet131MapData)
  {
    FMLNetworkHandler.handlePacket131Packet(this, par1Packet131MapData);
  }
  
  public void fmlPacket131Callback(dr par1Packet131MapData)
  {
    if (a == bfcv)
    {
      yh.a(b, h.f).a(c);
    }
    else
    {
      h.an().b("Unknown itemid: " + b);
    }
  }
  
  public void a(em par1Packet61DoorChange)
  {
    if (par1Packet61DoorChange.d())
    {
      h.f.d(a, c, d, e, b);
    }
    else
    {
      h.f.e(a, c, d, e, b);
    }
  }
  



  public void a(dk par1Packet200Statistic)
  {
    h.h.b(la.a(a), b);
  }
  



  public void a(gj par1Packet41EntityEffect)
  {
    nn entity = a(a);
    
    if ((entity instanceof of))
    {
      nj potioneffect = new nj(b, d, c);
      potioneffect.b(par1Packet41EntityEffect.d());
      ((of)entity).c(potioneffect);
    }
  }
  



  public void a(fg par1Packet42RemoveEntityEffect)
  {
    nn entity = a(a);
    
    if ((entity instanceof of))
    {
      ((of)entity).j(b);
    }
  }
  



  public boolean a()
  {
    return false;
  }
  



  public void a(fd par1Packet201PlayerInfo)
  {
    bdj guiplayerinfo = (bdj)k.get(a);
    
    if ((guiplayerinfo == null) && (b))
    {
      guiplayerinfo = new bdj(a);
      k.put(a, guiplayerinfo);
      c.add(guiplayerinfo);
    }
    
    if ((guiplayerinfo != null) && (!b))
    {
      k.remove(a);
      c.remove(guiplayerinfo);
    }
    
    if ((b) && (guiplayerinfo != null))
    {
      b = c;
    }
  }
  



  public void a(ei par1Packet0KeepAlive)
  {
    c(new ei(a));
  }
  



  public void a(fa par1Packet202PlayerAbilities)
  {
    bdi entityclientplayermp = h.h;
    bG.b = par1Packet202PlayerAbilities.f();
    bG.d = par1Packet202PlayerAbilities.h();
    bG.a = par1Packet202PlayerAbilities.d();
    bG.c = par1Packet202PlayerAbilities.g();
    bG.a(par1Packet202PlayerAbilities.i());
    bG.b(par1Packet202PlayerAbilities.j());
  }
  
  public void a(dl par1Packet203AutoComplete)
  {
    String[] astring = par1Packet203AutoComplete.d().split("\000");
    
    if ((h.n instanceof auw))
    {
      auw guichat = (auw)h.n;
      guichat.a(astring);
    }
  }
  
  public void a(eo par1Packet62LevelSound)
  {
    h.f.a(par1Packet62LevelSound.f(), par1Packet62LevelSound.g(), par1Packet62LevelSound.h(), par1Packet62LevelSound.d(), par1Packet62LevelSound.i(), par1Packet62LevelSound.j(), false);
  }
  
  public void a(ea par1Packet250CustomPayload)
  {
    FMLNetworkHandler.handlePacket250Packet(par1Packet250CustomPayload, g, this);
  }
  
  public void handleVanilla250Packet(ea par1Packet250CustomPayload)
  {
    if ("MC|TrList".equals(a))
    {
      DataInputStream datainputstream = new DataInputStream(new ByteArrayInputStream(c));
      
      try
      {
        int i = datainputstream.readInt();
        awe guiscreen = h.n;
        
        if ((guiscreen != null) && ((guiscreen instanceof axw)) && (i == h.h.bp.d))
        {
          abk imerchant = ((axw)guiscreen).g();
          abm merchantrecipelist = abm.a(datainputstream);
          imerchant.a(merchantrecipelist);
        }
      }
      catch (IOException ioexception)
      {
        ioexception.printStackTrace();
      }
    }
    else if ("MC|Brand".equals(a))
    {
      h.h.c(new String(c, Charsets.UTF_8));
    }
  }
  



  public void a(ft par1Packet206SetObjective)
  {
    atj scoreboard = i.X();
    

    if (c == 0)
    {
      ate scoreobjective = scoreboard.a(a, ato.b);
      scoreobjective.a(b);
    }
    else
    {
      ate scoreobjective = scoreboard.b(a);
      
      if (c == 1)
      {
        scoreboard.k(scoreobjective);
      }
      else if (c == 2)
      {
        scoreobjective.a(b);
      }
    }
  }
  



  public void a(fv par1Packet207SetScore)
  {
    atj scoreboard = i.X();
    ate scoreobjective = scoreboard.b(b);
    
    if (d == 0)
    {
      atg score = scoreboard.a(a, scoreobjective);
      score.c(c);
    }
    else if (d == 1)
    {
      scoreboard.c(a);
    }
  }
  



  public void a(fm par1Packet208SetDisplayObjective)
  {
    atj scoreboard = i.X();
    
    if (b.length() == 0)
    {
      scoreboard.a(a, (ate)null);
    }
    else
    {
      ate scoreobjective = scoreboard.b(b);
      scoreboard.a(a, scoreobjective);
    }
  }
  



  public void a(fu par1Packet209SetPlayerTeam)
  {
    atj scoreboard = i.X();
    atf scoreplayerteam;
    atf scoreplayerteam;
    if (f == 0)
    {
      scoreplayerteam = scoreboard.f(a);
    }
    else
    {
      scoreplayerteam = scoreboard.e(a);
    }
    
    if ((f == 0) || (f == 2))
    {
      scoreplayerteam.a(b);
      scoreplayerteam.b(c);
      scoreplayerteam.c(d);
      scoreplayerteam.a(g);
    }
    



    if ((f == 0) || (f == 3))
    {
      Iterator iterator = e.iterator();
      
      while (iterator.hasNext())
      {
        String s = (String)iterator.next();
        scoreboard.a(s, scoreplayerteam);
      }
    }
    
    if (f == 4)
    {
      Iterator iterator = e.iterator();
      
      while (iterator.hasNext())
      {
        String s = (String)iterator.next();
        scoreboard.b(s, scoreplayerteam);
      }
    }
    
    if (f == 1)
    {
      scoreboard.d(scoreplayerteam);
    }
  }
  



  public void a(en par1Packet63WorldParticles)
  {
    for (int i = 0; i < par1Packet63WorldParticles.m(); i++)
    {
      double d0 = e.nextGaussian() * par1Packet63WorldParticles.i();
      double d1 = e.nextGaussian() * par1Packet63WorldParticles.j();
      double d2 = e.nextGaussian() * par1Packet63WorldParticles.k();
      double d3 = e.nextGaussian() * par1Packet63WorldParticles.l();
      double d4 = e.nextGaussian() * par1Packet63WorldParticles.l();
      double d5 = e.nextGaussian() * par1Packet63WorldParticles.l();
      this.i.a(par1Packet63WorldParticles.d(), par1Packet63WorldParticles.f() + d0, par1Packet63WorldParticles.g() + d1, par1Packet63WorldParticles.h() + d2, d3, d4, d5);
    }
  }
  
  public void a(gh par1Packet44UpdateAttributes)
  {
    nn entity = a(par1Packet44UpdateAttributes.d());
    
    if (entity != null)
    {
      if (!(entity instanceof of))
      {
        throw new IllegalStateException("Server tried to update attributes of a non-living entity (actually: " + entity + ")");
      }
      

      ov baseattributemap = ((of)entity).aX();
      Iterator iterator = par1Packet44UpdateAttributes.f().iterator();
      
      while (iterator.hasNext())
      {
        gi packet44updateattributessnapshot = (gi)iterator.next();
        os attributeinstance = baseattributemap.a(packet44updateattributessnapshot.a());
        
        if (attributeinstance == null)
        {
          attributeinstance = baseattributemap.b(new oy(packet44updateattributessnapshot.a(), 0.0D, 2.2250738585072014E-308D, Double.MAX_VALUE));
        }
        
        attributeinstance.a(packet44updateattributessnapshot.b());
        attributeinstance.d();
        Iterator iterator1 = packet44updateattributessnapshot.c().iterator();
        
        while (iterator1.hasNext())
        {
          ot attributemodifier = (ot)iterator1.next();
          attributeinstance.a(attributemodifier);
        }
      }
    }
  }
  




  public cm g()
  {
    return g;
  }
  

  public uf getPlayer()
  {
    return h.h;
  }
  
  public static void setConnectionCompatibilityLevel(byte connectionCompatibilityLevel)
  {
    connectionCompatibilityLevel = connectionCompatibilityLevel;
  }
  
  public static byte getConnectionCompatibilityLevel()
  {
    return connectionCompatibilityLevel;
  }
}
