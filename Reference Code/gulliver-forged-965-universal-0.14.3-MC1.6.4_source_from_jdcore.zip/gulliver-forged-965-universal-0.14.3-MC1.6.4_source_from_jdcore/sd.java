import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.Random;


























public class sd
  extends rv
{
  private int bq;
  rj bp;
  private int br;
  private int bs;
  
  public sd(abw par1World)
  {
    super(par1World);
    a(1.4F, 2.9F);
    minLookSize = (this.minTargetSize = 0.1F);
    maxLookSize = (this.maxTargetSize = 10.0F);
    k().a(true);
    c.a(1, new qa(this, 1.0D, true));
    c.a(2, new qe(this, 0.9D, 32.0F));
    c.a(3, new qc(this, 0.6D, true));
    c.a(4, new qd(this, 1.0D));
    c.a(5, new qh(this));
    c.a(6, new qm(this, 0.6D));
    c.a(7, new px(this, uf.class, 6.0F));
    c.a(8, new ql(this));
    d.a(1, new qw(this));
    d.a(2, new qx(this, false));
    d.a(3, new qy(this, og.class, 0, false, true, th.a));
  }
  
  protected void a()
  {
    super.a();
    ah.a(16, Byte.valueOf((byte)0));
  }
  



  public boolean bf()
  {
    return true;
  }
  



  protected void bk()
  {
    if (--bq <= 0)
    {
      bq = (70 + ab.nextInt(50));
      bp = q.A.a(ls.c(u), ls.c(v), ls.c(w), 32);
      
      if (bp == null)
      {
        bR();
      }
      else
      {
        t chunkcoordinates = bp.a();
        b(a, b, c, (int)(bp.b() * 0.6F));
      }
    }
    
    super.bk();
  }
  
  protected void az()
  {
    super.az();
    a(tp.a).a(100.0D);
    a(tp.d).a(0.25D);
  }
  



  protected int h(int par1)
  {
    return par1;
  }
  
  protected void n(nn par1Entity)
  {
    if (((par1Entity instanceof th)) && (aD().nextInt(20) == 0))
    {
      d((of)par1Entity);
    }
    
    super.n(par1Entity);
  }
  

  public void W()
  {
    double dist = Y() + n.X();
    double dist1 = O * 0.4D;
    double rot = 90.0D - Math.atan2(dist1, dist) * 180.0D / 3.141592653589793D;
    
    if (aG >= 0.01F)
    {
      float f = 13.0F;
      float f1 = aH - aG + 6.0F;
      rot -= 6.5D * ((Math.abs(f1 % f - f * 0.5F) - f * 0.25F) / (f * 0.25F));
    }
    
    double pitch = Math.cos(rot * 3.141592653589793D / 180.0D);
    double pitch1 = Math.sin(rot * 3.141592653589793D / 180.0D);
    double yaw = Math.cos(aN * 3.141592653589793D / 180.0D);
    double yaw1 = Math.sin(aN * 3.141592653589793D / 180.0D);
    double mag2 = pitch * pitch * (yaw * yaw + yaw1 * yaw1) + pitch1 * pitch1;
    
    dist = Math.sqrt((dist * dist + dist1 * dist1) / mag2);
    
    n.b(u + dist * yaw * pitch, v + dist * pitch1, w + dist * yaw1 * pitch);
  }
  



  public double Y()
  {
    return P * 0.65D;
  }
  
  public float maxRiderWidth(nn par1Entity)
  {
    return O * 0.8F;
  }
  




  public void c()
  {
    super.c();
    
    if (br > 0)
    {
      br -= 1;
    }
    
    if (bs > 0)
    {
      bs -= 1;
    }
    
    if ((x * x + z * z > 2.500000277905201E-7D) && (ab.nextInt(5) == 0))
    {
      int i = ls.c(u);
      int j = ls.c(v - 0.20000000298023224D - N);
      int k = ls.c(w);
      int l = q.a(i, j, k);
      
      if (l > 0)
      {
        q.a("tilecrack_" + l + "_" + q.h(i, j, k), u + (ab.nextFloat() - 0.5D) * O, E.b + 0.1D, w + (ab.nextFloat() - 0.5D) * O, 4.0D * (ab.nextFloat() - 0.5D), 0.5D, (ab.nextFloat() - 0.5D) * 4.0D);
      }
    }
  }
  



  public boolean a(Class par1Class)
  {
    return (bW()) && (uf.class.isAssignableFrom(par1Class)) ? false : super.a(par1Class);
  }
  



  public void b(by par1NBTTagCompound)
  {
    super.b(par1NBTTagCompound);
    par1NBTTagCompound.a("PlayerCreated", bW());
  }
  



  public void a(by par1NBTTagCompound)
  {
    super.a(par1NBTTagCompound);
    i(par1NBTTagCompound.n("PlayerCreated"));
  }
  
  public boolean m(nn par1Entity)
  {
    br = 10;
    q.a(this, (byte)4);
    boolean flag = par1Entity.a(nb.a(this), 7 + ab.nextInt(15));
    
    if (flag)
    {
      y += 0.4000000059604645D * getSizeMultiplierRoot();
    }
    
    a("mob.irongolem.throw", 1.0F, 1.0F);
    return flag;
  }
  



  protected void b(float par1)
  {
    doLivingFall(par1);
  }
  



  public boolean attackEntityFrom(nb par1DamageSource, int par2)
  {
    if (par1DamageSource == nb.h)
    {
      return false;
    }
    

    return super.a(par1DamageSource, par2);
  }
  

  @SideOnly(Side.CLIENT)
  public void a(byte par1)
  {
    if (par1 == 4)
    {
      br = 10;
      a("mob.irongolem.throw", 1.0F, 1.0F);
    }
    else if (par1 == 11)
    {
      bs = 400;
    }
    else
    {
      super.a(par1);
    }
  }
  
  public rj bT()
  {
    return bp;
  }
  
  @SideOnly(Side.CLIENT)
  public int bU()
  {
    return br;
  }
  
  public void a(boolean par1)
  {
    bs = (par1 ? 400 : 0);
    q.a(this, (byte)11);
  }
  



  protected String r()
  {
    return "none";
  }
  



  protected String aO()
  {
    return "mob.irongolem.hit";
  }
  



  protected String aP()
  {
    return "mob.irongolem.death";
  }
  



  protected void a(int par1, int par2, int par3, int par4)
  {
    a("mob.irongolem.walk", 1.0F, 1.0F);
  }
  




  protected void b(boolean par1, int par2)
  {
    dropItemSizedAmount(0, ajcF, 0, 3);
    dropItemSizedAmount(0, qcv, 3, 3);
  }
  
  public int bV()
  {
    return bs;
  }
  
  public boolean bW()
  {
    return (ah.a(16) & 0x1) != 0;
  }
  
  public void i(boolean par1)
  {
    byte b0 = ah.a(16);
    
    if (par1)
    {
      ah.b(16, Byte.valueOf((byte)(b0 | 0x1)));
    }
    else
    {
      ah.b(16, Byte.valueOf((byte)(b0 & 0xFFFFFFFE)));
    }
  }
  



  public void a(nb par1DamageSource)
  {
    if ((!bW()) && (aS != null) && (bp != null))
    {
      bp.a(aS.c_(), -5);
    }
    
    super.a(par1DamageSource);
  }
}
