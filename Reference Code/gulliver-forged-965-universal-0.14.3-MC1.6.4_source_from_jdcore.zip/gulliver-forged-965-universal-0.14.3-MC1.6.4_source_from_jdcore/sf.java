import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import gulliver.common.GulliverEnvoy;
import java.util.Random;






































public class sf
  extends oq
{
  private float bq;
  private float br;
  private boolean bs;
  private boolean bt;
  private float bu;
  private float bv;
  
  public float getSizeItemMultiplier()
  {
    if (!GulliverEnvoy.isDyeResizingEnabled())
    {
      return 1.0F;
    }
    if (cd() == 10)
    {
      return 2.0F;
    }
    if (cd() == 9)
    {
      return 0.5F;
    }
    

    return 1.0F;
  }
  

  public sf(abw par1World)
  {
    super(par1World);
    a(0.6F, 0.8F);
    k().a(true);
    c.a(1, new pp(this));
    c.a(2, bp.setTargetSizeRange(0.3F, 0.0F));
    c.a(3, new pw(this, 0.4F));
    c.a(4, new qa(this, 1.0D, true));
    c.a(5, new pq(this, 1.0D, 10.0F, 2.0F));
    c.a(6, new pk(this, 1.0D));
    c.a(7, new qm(this, 1.0D));
    c.a(8, new pi(this, 8.0F));
    c.a(9, new px(this, uf.class, 8.0F));
    c.a(9, new ql(this));
    d.a(1, new rc(this).setTargetSizeRange(0.1F, 40.0F));
    d.a(2, new rd(this).setTargetSizeRange(0.1F, 40.0F));
    d.a(3, new qx(this, true));
    
    d.a(4, new rb(this, rz.class, 200, false).setTargetSizeRange(0.3F, 1.5F));
    j(false);
  }
  
  protected void az()
  {
    super.az();
    a(tp.d).a(0.30000001192092896D);
    
    if (bT())
    {
      a(tp.a).a(20.0D);
    }
    else
    {
      a(tp.a).a(8.0D);
    }
  }
  



  public boolean bf()
  {
    return true;
  }
  



  public void d(of par1EntityLivingBase)
  {
    super.d(par1EntityLivingBase);
    
    if (par1EntityLivingBase == null)
    {
      l(false);
    }
    else if (!bT())
    {
      l(true);
    }
  }
  



  protected void bk()
  {
    ah.b(18, Float.valueOf(aN()));
  }
  

  public void W()
  {
    double off = -0.1D;
    double d = Math.cos(aN * 3.141592653589793D / 180.0D) * O * off + Math.cos((aN - 90.0F) * 3.141592653589793D / 180.0D) * O * 0.0625D;
    double d1 = Math.sin(aN * 3.141592653589793D / 180.0D) * O * off + Math.sin((aN - 90.0F) * 3.141592653589793D / 180.0D) * O * 0.0625D;
    
    n.b(u + d, v - N + Y() + n.X(), w + d1);
  }
  
  protected void a()
  {
    super.a();
    ah.a(18, new Float(aN()));
    ah.a(19, new Byte((byte)0));
    ah.a(20, new Byte((byte)ann.j_(1)));
  }
  



  protected void a(int par1, int par2, int par3, int par4)
  {
    a("mob.wolf.step", 0.15F, 1.0F);
  }
  



  public void b(by par1NBTTagCompound)
  {
    super.b(par1NBTTagCompound);
    par1NBTTagCompound.a("Angry", cc());
    par1NBTTagCompound.a("CollarColor", (byte)cd());
  }
  



  public void a(by par1NBTTagCompound)
  {
    super.a(par1NBTTagCompound);
    l(par1NBTTagCompound.n("Angry"));
    
    if (par1NBTTagCompound.b("CollarColor"))
    {
      p(par1NBTTagCompound.c("CollarColor"));
    }
  }
  



  protected String r()
  {
    return ab.nextInt(3) == 0 ? "mob.wolf.panting" : (bT()) && (ah.d(18) < 10.0F) ? "mob.wolf.whine" : cc() ? "mob.wolf.growl" : "mob.wolf.bark";
  }
  



  protected String aO()
  {
    return "mob.wolf.hurt";
  }
  



  protected String aP()
  {
    return "mob.wolf.death";
  }
  



  protected float ba()
  {
    return 0.4F;
  }
  



  protected int s()
  {
    return -1;
  }
  




  public void c()
  {
    super.c();
    
    if ((!q.I) && (bs) && (!bt) && (!bM()) && (F))
    {
      bt = true;
      bu = 0.0F;
      bv = 0.0F;
      q.a(this, (byte)8);
    }
  }
  



  public void l_()
  {
    super.l_();
    br = bq;
    
    if (ce())
    {
      bq += (1.0F - bq) * 0.4F;
    }
    else
    {
      bq += (0.0F - bq) * 0.4F;
    }
    
    if (ce())
    {
      g = 10;
    }
    
    if (G())
    {
      bs = true;
      bt = false;
      bu = 0.0F;
      bv = 0.0F;
    }
    else if (((bs) || (bt)) && (bt))
    {
      if (bu == 0.0F)
      {
        a("mob.wolf.shake", ba(), (ab.nextFloat() - ab.nextFloat()) * 0.2F + 1.0F);
      }
      
      bv = bu;
      bu += 0.05F;
      
      if (bv >= 2.0F)
      {
        bs = false;
        bt = false;
        bv = 0.0F;
        bu = 0.0F;
      }
      
      if (bu > 0.4F)
      {
        float f = (float)E.b;
        int i = (int)(ls.a((bu - 0.4F) * 3.1415927F) * 7.0F);
        
        for (int j = 0; j < i; j++)
        {
          float f1 = (ab.nextFloat() * 2.0F - 1.0F) * O * 0.5F;
          float f2 = (ab.nextFloat() * 2.0F - 1.0F) * O * 0.5F;
          q.a("splash", u + f1, f + 0.8F, w + f2, x, y, z);
        }
      }
    }
  }
  
  @SideOnly(Side.CLIENT)
  public boolean ca()
  {
    return bs;
  }
  




  @SideOnly(Side.CLIENT)
  public float p(float par1)
  {
    return 0.75F + (bv + (bu - bv) * par1) / 2.0F * 0.25F;
  }
  
  @SideOnly(Side.CLIENT)
  public float g(float par1, float par2)
  {
    float f2 = (bv + (bu - bv) * par1 + par2) / 1.8F;
    
    if (f2 < 0.0F)
    {
      f2 = 0.0F;
    }
    else if (f2 > 1.0F)
    {
      f2 = 1.0F;
    }
    
    return ls.a(f2 * 3.1415927F) * ls.a(f2 * 3.1415927F * 11.0F) * 0.15F * 3.1415927F;
  }
  
  @SideOnly(Side.CLIENT)
  public float q(float par1)
  {
    return (br + (bq - br) * par1) * 0.15F * 3.1415927F;
  }
  
  public float f()
  {
    return P * 0.8F;
  }
  




  public int bp()
  {
    return bU() ? 20 : super.bp();
  }
  



  public boolean a(nb par1DamageSource, float par2)
  {
    if (ar())
    {
      return false;
    }
    

    nn entity = par1DamageSource.i();
    bp.a(false);
    
    if ((entity != null) && (!(entity instanceof uf)) && (!(entity instanceof uh)))
    {
      par2 = (par2 + 1.0F) / 2.0F;
    }
    
    return super.a(par1DamageSource, par2);
  }
  

  public boolean m(nn par1Entity)
  {
    int i = bT() ? 4 : 2;
    return par1Entity.a(nb.a(this), i);
  }
  
  public void j(boolean par1)
  {
    super.j(par1);
    
    if (par1)
    {
      a(tp.a).a(20.0D);
    }
    else
    {
      a(tp.a).a(8.0D);
    }
  }
  



  public boolean a(uf par1EntityPlayer)
  {
    ye itemstack = bn.h();
    
    if (bT())
    {
      if (itemstack != null)
      {
        if ((yc.g[d] instanceof xx))
        {
          xx itemfood = (xx)yc.g[d];
          
          if ((itemfood.j()) && (ah.d(18) < 20.0F))
          {
            if (!bG.d)
            {
              b -= 1;
            }
            
            f(itemfood.g() / getSizeMultiplierRoot());
            
            if (b <= 0)
            {
              bn.a(bn.c, (ye)null);
            }
            
            return true;
          }
        }
        else if (d == aYcv)
        {
          int i = ann.j_(itemstack.k());
          
          if (i != cd())
          {
            p(i);
            
            if (!bG.d) { if (--b <= 0)
              {
                bn.a(bn.c, (ye)null);
              }
            }
            return true;
          }
        }
      }
      else if ((holdingEntity == null) && (bn.h() == null) && (!par1EntityPlayer.ah()) && (n == null) && (bU()) && (isEntityInRelativeSizeRange(par1EntityPlayer, 0.0F, 0.65F)) && (o == null) && (getEyeDistanceToEntityLiving(par1EntityPlayer) <= O * 1.5F) && ((n == null) || (n.isTinierThan(par1EntityPlayer))))
      {

        if (!q.I)
        {
          par1EntityPlayer.a(this);
        }
        
        return true;
      }
      
      if ((par1EntityPlayer.c_().equalsIgnoreCase(h_())) && (!par1EntityPlayer.isTinierThan(this)) && (!q.I) && (!c(itemstack)))
      {
        bp.a(!bU());
        bd = false;
        a((alf)null);
        b((nn)null);
        d((of)null);
      }
    }
    else if ((itemstack != null) && (d == aZcv) && (!cc()))
    {
      if (!bG.d)
      {
        b -= 1;
      }
      
      if (b <= 0)
      {
        bn.a(bn.c, (ye)null);
      }
      
      if (!q.I)
      {
        if (ab.nextInt(3) == 0)
        {
          j(true);
          a((alf)null);
          d((of)null);
          bp.a(!par1EntityPlayer.isTinierThan(this));
          g(20.0F);
          b(par1EntityPlayer.c_());
          i(true);
          q.a(this, (byte)7);
        }
        else
        {
          i(false);
          q.a(this, (byte)6);
        }
      }
      
      return true;
    }
    
    return super.a(par1EntityPlayer);
  }
  



  public void e(float par1, float par2)
  {
    boolean isOwner = (n != null) && ((n instanceof uf)) && (((uf)n).c_().equalsIgnoreCase(h_()));
    if ((isOwner) && (isEntityInRelativeSizeRange(n, 0.1F, 0.0F)))
    {

      float strafe = n).be * 0.25F;
      float fwd = n).bf * 0.5F;
      boolean fullctrl = (bU()) || ((!n.isTinierThan(this)) && ((strafe != 0.0F) || (fwd != 0.0F)));
      float sizeratio = n.getSizeMultiplier() / getSizeMultiplier();
      float sizerootratio = n.getSizeMultiplierRoot() / getSizeMultiplierRoot();
      
      if (fullctrl)
      {
        float movemult = bU() ? 0.125F : 1.0F;
        C = (this.A = n.A);
        B = (n.B * 0.5F);
        b(A, B);
        aP = (this.aN = A);
        par1 = n).be * 0.2F * sizerootratio * movemult;
        par2 = n).bf * 0.4F * sizerootratio * movemult;
        
        if (par2 <= 0.0F)
        {
          par2 *= 0.25F;
        }
        

      }
      else if ((strafe != 0.0F) || (fwd != 0.0F))
      {
        A = ls.g(A + ls.g(n.A - A) * sizeratio * 0.5F);
        B = (n.B * 0.5F);
        b(A, B);
        aP = (this.aN = A);
        
        if (fwd <= 0.0F)
        {
          fwd *= 0.5F;
        }
        par1 += strafe * 0.5F * sizerootratio;
        par2 += fwd * 0.5F * sizerootratio;
      }
      
      Y = (bU() ? 0.125F : 1.0F);
      
      if (!q.I)
      {
        i((float)a(tp.d).e());
        super.e(par1, par2);
      }
      
      aF = aG;
      double d0 = u - r;
      double d1 = w - t;
      float f4 = ls.a(d0 * d0 + d1 * d1) * 4.0F / getSizeMovementMultiplier();
      
      if (f4 > 1.0F)
      {
        f4 = 1.0F;
      }
      
      aG += (f4 - aG) * 0.4F;
      aH += aG;
    }
    else
    {
      Y = 0.5F;
      super.e(par1, par2);
    }
  }
  
  @SideOnly(Side.CLIENT)
  public void a(byte par1)
  {
    if (par1 == 8)
    {
      bt = true;
      bu = 0.0F;
      bv = 0.0F;
    }
    else
    {
      super.a(par1);
    }
  }
  
  @SideOnly(Side.CLIENT)
  public float cb()
  {
    return bT() ? (0.55F - (20.0F - ah.d(18)) * 0.02F) * 3.1415927F : cc() ? 1.5393804F : 0.62831855F;
  }
  




  public boolean c(ye par1ItemStack)
  {
    return !(yc.g[d] instanceof xx) ? false : par1ItemStack == null ? false : ((xx)yc.g[d]).j();
  }
  



  public int bv()
  {
    return 8;
  }
  



  public boolean cc()
  {
    return (ah.a(16) & 0x2) != 0;
  }
  



  public void l(boolean par1)
  {
    byte b0 = ah.a(16);
    
    if (par1)
    {
      ah.b(16, Byte.valueOf((byte)(b0 | 0x2)));
    }
    else
    {
      ah.b(16, Byte.valueOf((byte)(b0 & 0xFFFFFFFD)));
    }
  }
  



  public int cd()
  {
    return ah.a(20) & 0xF;
  }
  



  public void p(int par1)
  {
    ah.b(20, Byte.valueOf((byte)(par1 & 0xF)));
  }
  



  public sf b(nk par1EntityAgeable)
  {
    sf entitywolf = new sf(q);
    String s = h_();
    
    if ((s != null) && (s.trim().length() > 0))
    {
      entitywolf.b(s);
      entitywolf.j(true);
    }
    
    return entitywolf;
  }
  
  public void m(boolean par1)
  {
    if (par1)
    {
      ah.b(19, Byte.valueOf((byte)1));
    }
    else
    {
      ah.b(19, Byte.valueOf((byte)0));
    }
  }
  



  public boolean a(rp par1EntityAnimal)
  {
    if (par1EntityAnimal == this)
    {
      return false;
    }
    if (!bT())
    {
      return false;
    }
    if (!(par1EntityAnimal instanceof sf))
    {
      return false;
    }
    

    sf entitywolf = (sf)par1EntityAnimal;
    return entitywolf.bT();
  }
  

  public boolean ce()
  {
    return ah.a(19) == 1;
  }
  



  protected boolean t()
  {
    return (!bT()) && (ac > 2400);
  }
  
  public boolean a(of par1EntityLivingBase, of par2EntityLivingBase)
  {
    if ((!(par1EntityLivingBase instanceof tf)) && (!(par1EntityLivingBase instanceof tj)))
    {
      if ((par1EntityLivingBase instanceof sf))
      {
        sf entitywolf = (sf)par1EntityLivingBase;
        
        if ((entitywolf.bT()) && (entitywolf.bV() == par2EntityLivingBase))
        {
          return false;
        }
      }
      
      return (!(par1EntityLivingBase instanceof uf)) || (!(par2EntityLivingBase instanceof uf)) || (((uf)par2EntityLivingBase).a((uf)par1EntityLivingBase));
    }
    

    return false;
  }
  

  public nk a(nk par1EntityAgeable)
  {
    return b(par1EntityAgeable);
  }
}
