import cpw.mods.fml.common.FMLCommonHandler;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import gulliver.common.GulliverOMHelper;
import java.io.File;
import java.io.IOException;
import net.minecraft.server.MinecraftServer;
import net.minecraftforge.common.DimensionManager;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.EventBus;
import net.minecraftforge.event.world.WorldEvent.Load;
























@SideOnly(Side.CLIENT)
public class bkz
  extends MinecraftServer
{
  private final atv l;
  private final acd m;
  private final lp n;
  private blc o;
  private boolean p;
  private boolean q;
  private blh r;
  
  public bkz(atv par1Minecraft, String par2Str, String par3Str, acd par4WorldSettings)
  {
    super(new File(x, "saves"));
    n = new lc("Minecraft-Server", " [SERVER]", new File(x, "output-server.log").getAbsolutePath());
    j(par1Minecraft.H().a());
    k(par2Str);
    l(par3Str);
    b(par1Minecraft.p());
    c(par4WorldSettings.c());
    d(256);
    a(new bky(this));
    l = par1Minecraft;
    c = par1Minecraft.I();
    m = par4WorldSettings;
    
    try
    {
      o = new blc(this);
    }
    catch (IOException ioexception)
    {
      throw new Error();
    }
  }
  
  protected void a(String par1Str, String par2Str, long par3, acg par5WorldType, String par6Str)
  {
    a(par1Str);
    amc isavehandler = P().a(par1Str, true);
    
    js overWorld = O() ? new jj(this, isavehandler, par2Str, 0, a, an()) : GulliverOMHelper.getOptifineWorldServer(this, isavehandler, par2Str, 0, m, a, an());
    Integer[] arr$ = DimensionManager.getStaticDimensionIDs();int len$ = arr$.length; for (int i$ = 0; i$ < len$; i$++) { int dim = arr$[i$].intValue();
      
      js world = dim == 0 ? overWorld : new jl(this, isavehandler, par2Str, dim, m, overWorld, a, an());
      world.a(new jo(this, world));
      
      if (!K())
      {
        world.N().a(h());
      }
      
      MinecraftForge.EVENT_BUS.post(new WorldEvent.Load(world));
    }
    
    af().a(new js[] { overWorld });
    c(i());
    f();
  }
  


  protected boolean d()
    throws IOException
  {
    n.a("Starting integrated minecraft server version 1.6.4");
    d(false);
    e(true);
    f(true);
    g(true);
    h(true);
    n.a("Generating keypair");
    a(lg.b());
    if (!FMLCommonHandler.instance().handleServerAboutToStart(this)) return false;
    a(L(), M(), m.d(), m.h(), m.j());
    n(J() + " - " + b[0].N().k());
    return FMLCommonHandler.instance().handleServerStarting(this);
  }
  



  public void s()
  {
    boolean flag = p;
    p = o.f();
    
    if ((!flag) && (p))
    {
      n.a("Saving and pausing game...");
      af().g();
      a(false);
    }
    
    if (!p)
    {
      super.s();
    }
  }
  
  public boolean g()
  {
    return false;
  }
  
  public ace h()
  {
    return m.e();
  }
  



  public int i()
  {
    return l.u.Y;
  }
  



  public boolean j()
  {
    return m.f();
  }
  
  protected File q()
  {
    return l.x;
  }
  
  public boolean V()
  {
    return false;
  }
  



  public blc a()
  {
    return o;
  }
  



  protected void a(b par1CrashReport)
  {
    l.a(par1CrashReport);
  }
  



  public b b(b par1CrashReport)
  {
    par1CrashReport = super.b(par1CrashReport);
    par1CrashReport.g().a("Type", new bla(this));
    par1CrashReport.g().a("Is Modded", new blb(this));
    return par1CrashReport;
  }
  
  public void a(mv par1PlayerUsageSnooper)
  {
    super.a(par1PlayerUsageSnooper);
    par1PlayerUsageSnooper.a("snooper_partner", l.E().f());
  }
  



  public boolean T()
  {
    return atv.w().T();
  }
  



  public String a(ace par1EnumGameType, boolean par2)
  {
    try
    {
      String s = o.c();
      an().a("Started on " + s);
      q = true;
      r = new blh(ac(), s);
      r.start();
      af().a(par1EnumGameType);
      af().b(par2);
      return s;
    }
    catch (IOException ioexception) {}
    
    return null;
  }
  

  public lp an()
  {
    return n;
  }
  



  public void m()
  {
    super.m();
    
    if (r != null)
    {
      r.interrupt();
      r = null;
    }
  }
  



  public void p()
  {
    super.p();
    
    if (r != null)
    {
      r.interrupt();
      r = null;
    }
  }
  



  public boolean c()
  {
    return q;
  }
  



  public void a(ace par1EnumGameType)
  {
    af().a(par1EnumGameType);
  }
  



  public boolean ab()
  {
    return true;
  }
  
  public int k()
  {
    return 4;
  }
  
  public kd ag()
  {
    return a();
  }
}
