import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import org.lwjgl.opengl.GL11;










@SideOnly(Side.CLIENT)
public class bgq
  extends bgm
{
  private static final bjo a = new bjo("textures/particle/particles.png");
  

  public bgq() {}
  
  public void a(ul par1EntityFishHook, double par2, double par4, double par6, float par8, float par9)
  {
    GL11.glPushMatrix();
    GL11.glTranslatef((float)par2, (float)par4, (float)par6);
    GL11.glEnable(32826);
    float sizemult = par1EntityFishHook.getSizeMultiplier();
    GL11.glScalef(0.5F * sizemult, 0.5F * sizemult, 0.5F * sizemult);
    b(par1EntityFishHook);
    bfq tessellator = bfq.a;
    byte b0 = 1;
    byte b1 = 2;
    float f2 = (b0 * 8 + 0) / 128.0F;
    float f3 = (b0 * 8 + 8) / 128.0F;
    float f4 = (b1 * 8 + 0) / 128.0F;
    float f5 = (b1 * 8 + 8) / 128.0F;
    float f6 = 1.0F;
    float f7 = 0.5F;
    float f8 = 0.5F;
    GL11.glRotatef(180.0F - b.j, 0.0F, 1.0F, 0.0F);
    GL11.glRotatef(-b.k, 1.0F, 0.0F, 0.0F);
    tessellator.b();
    tessellator.b(0.0F, 1.0F, 0.0F);
    tessellator.a(0.0F - f7, 0.0F - f8, 0.0D, f2, f5);
    tessellator.a(f6 - f7, 0.0F - f8, 0.0D, f3, f5);
    tessellator.a(f6 - f7, 1.0F - f8, 0.0D, f3, f4);
    tessellator.a(0.0F - f7, 1.0F - f8, 0.0D, f2, f4);
    tessellator.a();
    GL11.glDisable(32826);
    GL11.glPopMatrix();
    
    if (b != null)
    {
      float f9 = b.k(par9);
      float f10 = ls.a(ls.c(f9) * 3.1415927F);
      double asize = b.getSizeMultiplier();
      atc vec3 = q.V().a(-0.5D * asize, 0.03D * asize, 0.8D * asize);
      vec3.a(-(b.D + (b.B - b.D) * par9) * 3.1415927F / 180.0F);
      vec3.b(-(b.C + (b.A - b.C) * par9) * 3.1415927F / 180.0F);
      vec3.b(f10 * 0.5F);
      vec3.a(-f10 * 0.7F);
      double d3 = b.r + (b.u - b.r) * par9 + c;
      double d4 = b.s + (b.v - b.s) * par9 + d;
      double d5 = b.t + (b.w - b.t) * par9 + e;
      double d6 = b == wh ? 0.0D : b.f();
      
      if ((b.l.aa > 0) || (b != wh))
      {
        float f11 = (b.aO + (b.aN - b.aO) * par9) * 3.1415927F / 180.0F;
        double d7 = ls.a(f11);
        double d8 = ls.b(f11);
        d3 = b.r + (b.u - b.r) * par9 - d8 * 0.35D * asize - d7 * 0.85D * asize;
        d4 = b.s + d6 + (b.v - b.s) * par9 - 0.45D * asize;
        d5 = b.t + (b.w - b.t) * par9 - d7 * 0.35D * asize + d8 * 0.85D * asize;
      }
      
      double d9 = r + (u - r) * par9;
      double d10 = s + (v - s) * par9 + 0.25D * sizemult;
      double d11 = t + (w - t) * par9;
      double d12 = (float)(d3 - d9);
      double d13 = (float)(d4 - d10);
      double d14 = (float)(d5 - d11);
      GL11.glDisable(3553);
      GL11.glDisable(2896);
      tessellator.b(3);
      tessellator.d(0);
      byte b2 = 16;
      
      for (int i = 0; i <= b2; i++)
      {
        float f12 = i / b2;
        tessellator.a(par2 + d12 * f12, par4 + d13 * (f12 * f12 + f12) * 0.5D + 0.25D * sizemult, par6 + d14 * f12);
      }
      
      tessellator.a();
      GL11.glEnable(2896);
      GL11.glEnable(3553);
    }
  }
  
  protected bjo a(ul par1EntityFishHook)
  {
    return a;
  }
  



  protected bjo a(nn par1Entity)
  {
    return a((ul)par1Entity);
  }
  






  public void a(nn par1Entity, double par2, double par4, double par6, float par8, float par9)
  {
    a((ul)par1Entity, par2, par4, par6, par8, par9);
  }
}
