import com.google.common.base.Charsets;
import cpw.mods.fml.common.network.FMLNetworkHandler;
import cpw.mods.fml.common.registry.GameRegistry;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import gulliver.EntityResizeablePlayerMP;
import gulliver.common.GulliverEnvoy;
import java.io.File;
import java.io.PrintStream;
import java.net.SocketAddress;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.logging.Logger;
import net.minecraft.server.MinecraftServer;












































public abstract class hn
{
  private static final SimpleDateFormat d = new SimpleDateFormat("yyyy-MM-dd 'at' HH:mm:ss z");
  

  private final MinecraftServer e;
  

  public final List a = new ArrayList();
  private final gn f = new gn(new File("banned-players.txt"));
  private final gn g = new gn(new File("banned-ips.txt"));
  

  private Set h = new HashSet();
  

  private Set i = new HashSet();
  

  private amq j;
  

  private boolean k;
  

  protected int b;
  

  protected int c;
  

  private ace l;
  

  private boolean m;
  
  private int n;
  

  public hn(MinecraftServer par1MinecraftServer)
  {
    e = par1MinecraftServer;
    f.a(false);
    g.a(false);
    b = 8;
  }
  
  public void a(cm par1INetworkManager, jv par2EntityPlayerMP)
  {
    by nbttagcompound = a(par2EntityPlayerMP);
    par2EntityPlayerMP.a(e.a(ar));
    c.a((js)q);
    String s = "local";
    
    if (par1INetworkManager.c() != null)
    {
      s = par1INetworkManager.c().toString();
    }
    
    e.an().a(par2EntityPlayerMP.c_() + "[" + s + "] logged in with entity id " + k + " at (" + u + ", " + v + ", " + w + ")");
    js worldserver = e.a(ar);
    
    if (!readSizeBaseFromFile)
    {
      par2EntityPlayerMP.setSizeBaseMultiplier(GulliverEnvoy.getNewBasePlayerSize());
      par2EntityPlayerMP.doResize(sizeBaseMultiplier, false);
      GulliverEnvoy.getLogger().info("Newly connecting with base size " + sizeBaseMultiplier);
    }
    else
    {
      par2EntityPlayerMP.doResize(par2EntityPlayerMP.getSizeMultiplier(), false);
      GulliverEnvoy.getLogger().info("Reconnecting with base size " + sizeBaseMultiplier + ", sizemult " + par2EntityPlayerMP.getSizeMultiplier());
    }
    
    par2EntityPlayerMP.refreshSizeDestMultiplier();
    t chunkcoordinates = worldserver.K();
    a(par2EntityPlayerMP, (jv)null, worldserver);
    ka netserverhandler = new ka(e, par1INetworkManager, par2EntityPlayerMP);
    netserverhandler.b(new ep(k, worldserver.N().u(), c.b(), worldserver.N().t(), t.i, r, worldserver.R(), l()));
    netserverhandler.b(new ea("MC|Brand", p().getServerModName().getBytes(Charsets.UTF_8)));
    netserverhandler.b(new fw(a, b, c));
    netserverhandler.b(new fa(bG));
    netserverhandler.b(new fk(bn.c));
    a((hp)worldserver.X(), par2EntityPlayerMP);
    b(par2EntityPlayerMP, worldserver);
    a(cv.b("multiplayer.player.joined", new Object[] { par2EntityPlayerMP.ay() }).a(a.o));
    netserverhandler.resizeTo(par2EntityPlayerMP.getSizeMultiplier());
    c(par2EntityPlayerMP);
    netserverhandler.a(u, v + 0.01D, w, A, B);
    e.ag().a(netserverhandler);
    netserverhandler.b(new fx(worldserver.I(), worldserver.J(), worldserver.O().b("doDaylightCycle")));
    
    if (e.S().length() > 0)
    {
      par2EntityPlayerMP.a(e.S(), e.U());
    }
    
    Iterator iterator = par2EntityPlayerMP.aL().iterator();
    
    while (iterator.hasNext())
    {
      nj potioneffect = (nj)iterator.next();
      netserverhandler.b(new gj(k, potioneffect));
    }
    
    par2EntityPlayerMP.d();
    
    FMLNetworkHandler.handlePlayerLogin(par2EntityPlayerMP, netserverhandler, par1INetworkManager);
    
    if ((nbttagcompound != null) && (nbttagcompound.b("Riding")))
    {
      nn entity = nt.a(nbttagcompound.l("Riding"), worldserver);
      
      if (entity != null)
      {
        p = true;
        worldserver.d(entity);
        par2EntityPlayerMP.a(entity);
        p = false;
      }
    }
  }
  
  protected void a(hp par1ServerScoreboard, jv par2EntityPlayerMP)
  {
    HashSet hashset = new HashSet();
    Iterator iterator = par1ServerScoreboard.g().iterator();
    
    while (iterator.hasNext())
    {
      atf scoreplayerteam = (atf)iterator.next();
      a.b(new fu(scoreplayerteam, 0));
    }
    
    for (int i = 0; i < 3; i++)
    {
      ate scoreobjective = par1ServerScoreboard.a(i);
      
      if ((scoreobjective != null) && (!hashset.contains(scoreobjective)))
      {
        List list = par1ServerScoreboard.d(scoreobjective);
        Iterator iterator1 = list.iterator();
        
        while (iterator1.hasNext())
        {
          ey packet = (ey)iterator1.next();
          a.b(packet);
        }
        
        hashset.add(scoreobjective);
      }
    }
  }
  



  public void a(js[] par1ArrayOfWorldServer)
  {
    j = par1ArrayOfWorldServer[0].M().e();
  }
  
  public void a(jv par1EntityPlayerMP, js par2WorldServer)
  {
    js worldserver1 = par1EntityPlayerMP.p();
    
    if (par2WorldServer != null)
    {
      par2WorldServer.s().c(par1EntityPlayerMP);
    }
    
    worldserver1.s().a(par1EntityPlayerMP);
    b.c((int)u >> 4, (int)w >> 4);
  }
  
  public int a()
  {
    return jp.a(o());
  }
  



  public by a(jv par1EntityPlayerMP)
  {
    by nbttagcompound = e.b[0].N().i();
    
    by nbttagcompound1;
    if ((par1EntityPlayerMP.c_().equals(e.J())) && (nbttagcompound != null))
    {
      par1EntityPlayerMP.f(nbttagcompound);
      by nbttagcompound1 = nbttagcompound;
      System.out.println("loading single player");
    }
    else
    {
      nbttagcompound1 = j.b(par1EntityPlayerMP);
    }
    
    return nbttagcompound1;
  }
  



  protected void b(jv par1EntityPlayerMP)
  {
    j.a(par1EntityPlayerMP);
  }
  



  public void c(jv par1EntityPlayerMP)
  {
    a(new fd(par1EntityPlayerMP.c_(), true, 1000));
    a.add(par1EntityPlayerMP);
    js worldserver = e.a(ar);
    worldserver.d(par1EntityPlayerMP);
    a(par1EntityPlayerMP, (js)null);
    
    for (int i = 0; i < a.size(); i++)
    {
      jv entityplayermp1 = (jv)a.get(i);
      a.b(new fd(entityplayermp1.c_(), true, i));
    }
  }
  



  public void d(jv par1EntityPlayerMP)
  {
    par1EntityPlayerMP.p().s().d(par1EntityPlayerMP);
  }
  



  public void e(jv par1EntityPlayerMP)
  {
    GameRegistry.onPlayerLogout(par1EntityPlayerMP);
    b(par1EntityPlayerMP);
    js worldserver = par1EntityPlayerMP.p();
    

    if ((o != null) && (!(o instanceof uf)))
    {
      worldserver.f(o);
      System.out.println("removing player mount");
    }
    
    worldserver.e(par1EntityPlayerMP);
    worldserver.s().c(par1EntityPlayerMP);
    a.remove(par1EntityPlayerMP);
    a(new fd(par1EntityPlayerMP.c_(), false, 9999));
  }
  



  public String a(SocketAddress par1SocketAddress, String par2Str)
  {
    if (f.a(par2Str))
    {
      gm banentry = (gm)f.c().get(par2Str);
      String s1 = "You are banned from this server!\nReason: " + banentry.f();
      
      if (banentry.d() != null)
      {
        s1 = s1 + "\nYour ban will be removed on " + d.format(banentry.d());
      }
      
      return s1;
    }
    if (!d(par2Str))
    {
      return "You are not white-listed on this server!";
    }
    

    String s2 = par1SocketAddress.toString();
    s2 = s2.substring(s2.indexOf("/") + 1);
    s2 = s2.substring(0, s2.indexOf(":"));
    
    if (g.a(s2))
    {
      gm banentry1 = (gm)g.c().get(s2);
      String s3 = "Your IP address is banned from this server!\nReason: " + banentry1.f();
      
      if (banentry1.d() != null)
      {
        s3 = s3 + "\nYour ban will be removed on " + d.format(banentry1.d());
      }
      
      return s3;
    }
    

    return a.size() >= b ? "The server is full!" : null;
  }
  





  public jv a(String par1Str)
  {
    ArrayList arraylist = new ArrayList();
    

    for (int i = 0; i < a.size(); i++)
    {
      jv entityplayermp = (jv)a.get(i);
      
      if (entityplayermp.c_().equalsIgnoreCase(par1Str))
      {
        arraylist.add(entityplayermp);
      }
    }
    
    Iterator iterator = arraylist.iterator();
    
    while (iterator.hasNext())
    {
      jv entityplayermp = (jv)iterator.next();
      a.c("You logged in from another location");
    }
    
    Object object;
    Object object;
    if (e.O())
    {
      object = new jk(e.a(0));
    }
    else
    {
      object = new jw(e.a(0));
    }
    
    return new EntityResizeablePlayerMP(e, e.a(0), par1Str, (jw)object);
  }
  





  public jv a(jv par1EntityPlayerMP, int par2, boolean par3)
  {
    abw world = e.a(par2);
    if (world == null)
    {
      par2 = 0;
    }
    else if (!t.e())
    {
      par2 = t.getRespawnDimension(par1EntityPlayerMP);
    }
    
    par1EntityPlayerMP.p().q().a(par1EntityPlayerMP);
    par1EntityPlayerMP.p().q().b(par1EntityPlayerMP);
    par1EntityPlayerMP.p().s().c(par1EntityPlayerMP);
    a.remove(par1EntityPlayerMP);
    e.a(ar).f(par1EntityPlayerMP);
    t chunkcoordinates = par1EntityPlayerMP.getBedLocation(par2);
    boolean flag1 = par1EntityPlayerMP.isSpawnForced(par2);
    ar = par2;
    Object object;
    Object object;
    if (e.O())
    {
      object = new jk(e.a(ar));
    }
    else
    {
      object = new jw(e.a(ar));
    }
    
    jv entityplayermp1 = new EntityResizeablePlayerMP(e, e.a(ar), par1EntityPlayerMP.c_(), (jw)object);
    a = a;
    entityplayermp1.a(par1EntityPlayerMP, par3);
    ar = par2;
    k = k;
    js worldserver = e.a(ar);
    
    if ((!par3) && (GulliverEnvoy.isKarmaModeEnabled()))
    {
      entityplayermp1.setSizeBaseMultiplier(GulliverEnvoy.getNewBasePlayerSize());
      GulliverEnvoy.getLogger().info("connecting with new base size " + sizeBaseMultiplier);
    }
    else
    {
      entityplayermp1.setSizeBaseMultiplier(sizeBaseMultiplier);
    }
    
    entityplayermp1.doResize(sizeBaseMultiplier, false);
    entityplayermp1.refreshSizeDestMultiplier();
    a(entityplayermp1, par1EntityPlayerMP, worldserver);
    

    if (chunkcoordinates != null)
    {
      t chunkcoordinates1 = uf.a(e.a(ar), chunkcoordinates, flag1);
      
      if (chunkcoordinates1 != null)
      {
        entityplayermp1.b(a + 0.5F, b + 0.1F, c + 0.5F, 0.0F, 0.0F);
        entityplayermp1.a(chunkcoordinates, flag1);
      }
      else
      {
        a.b(new ef(0, 0));
      }
    }
    
    b.c((int)u >> 4, (int)w >> 4);
    
    while (!worldserver.a(entityplayermp1, E).isEmpty())
    {
      entityplayermp1.b(u, v + 1.0D, w);
    }
    
    a.b(new fh(ar, (byte)q.r, q.N().u(), q.R(), c.b()));
    a.resizeTo(entityplayermp1.getSizeMultiplier());
    t chunkcoordinates1 = worldserver.K();
    a.a(u, v + 0.01D, w, A, B);
    a.b(new fw(a, b, c));
    a.b(new fr(bJ, bI, bH));
    b(entityplayermp1, worldserver);
    worldserver.s().a(entityplayermp1);
    worldserver.d(entityplayermp1);
    a.add(entityplayermp1);
    entityplayermp1.d();
    entityplayermp1.g(entityplayermp1.aN());
    GameRegistry.onPlayerRespawn(entityplayermp1);
    return entityplayermp1;
  }
  
  public void a(jv par1EntityPlayerMP, int par2)
  {
    transferPlayerToDimension(par1EntityPlayerMP, par2, e.a(par2).t());
  }
  
  public void transferPlayerToDimension(jv par1EntityPlayerMP, int par2, acj teleporter)
  {
    int j = ar;
    js worldserver = e.a(ar);
    ar = par2;
    js worldserver1 = e.a(ar);
    a.b(new fh(ar, (byte)q.r, worldserver1.N().u(), worldserver1.R(), c.b()));
    a.resizeTo(par1EntityPlayerMP.getSizeMultiplier());
    worldserver.f(par1EntityPlayerMP);
    M = false;
    transferEntityToWorld(par1EntityPlayerMP, j, worldserver, worldserver1, teleporter);
    a(par1EntityPlayerMP, worldserver);
    a.a(u, v + 0.01D, w, A, B);
    c.a(worldserver1);
    b(par1EntityPlayerMP, worldserver1);
    f(par1EntityPlayerMP);
    Iterator iterator = par1EntityPlayerMP.aL().iterator();
    
    while (iterator.hasNext())
    {
      nj potioneffect = (nj)iterator.next();
      a.b(new gj(k, potioneffect));
    }
    
    GameRegistry.onPlayerChangedDimension(par1EntityPlayerMP);
  }
  



  public void a(nn par1Entity, int par2, js par3WorldServer, js par4WorldServer)
  {
    transferEntityToWorld(par1Entity, par2, par3WorldServer, par4WorldServer, par4WorldServer.t());
  }
  
  public void transferEntityToWorld(nn par1Entity, int par2, js par3WorldServer, js par4WorldServer, acj teleporter)
  {
    aei pOld = t;
    aei pNew = t;
    double moveFactor = pOld.getMovementFactor() / pNew.getMovementFactor();
    double d0 = u * moveFactor;
    double d1 = w * moveFactor;
    double d3 = u;
    double d4 = v;
    double d5 = w;
    float f = A;
    C.a("moving");
    
    if (ar == 1)
    {
      t chunkcoordinates;
      t chunkcoordinates;
      if (par2 == 1)
      {
        chunkcoordinates = par4WorldServer.K();
      }
      else
      {
        chunkcoordinates = par4WorldServer.l();
      }
      
      d0 = a;
      v = b;
      d1 = c;
      par1Entity.b(d0, v + 0.01D, d1, 90.0F, 0.0F);
      
      if (par1Entity.T())
      {
        par3WorldServer.a(par1Entity, false);
      }
    }
    
    C.b();
    
    if (par2 != 1)
    {
      C.a("placing");
      d0 = ls.a((int)d0, -29999872, 29999872);
      d1 = ls.a((int)d1, -29999872, 29999872);
      
      if (par1Entity.T())
      {
        par4WorldServer.d(par1Entity);
        par1Entity.b(d0, v + 0.01D, d1, A, B);
        par4WorldServer.a(par1Entity, false);
        teleporter.a(par1Entity, d3, d4, d5, f);
      }
      
      C.b();
    }
    
    par1Entity.a(par4WorldServer);
  }
  



  public void b()
  {
    if (++n > 600)
    {
      n = 0;
    }
    
    if (n < a.size())
    {
      jv entityplayermp = (jv)a.get(n);
      a(new fd(entityplayermp.c_(), true, i));
    }
  }
  



  public void a(ey par1Packet)
  {
    for (int i = 0; i < a.size(); i++)
    {
      a.get(i)).a.b(par1Packet);
    }
  }
  



  public void a(ey par1Packet, int par2)
  {
    for (int j = 0; j < a.size(); j++)
    {
      jv entityplayermp = (jv)a.get(j);
      
      if (ar == par2)
      {
        a.b(par1Packet);
      }
    }
  }
  



  public String c()
  {
    String s = "";
    
    for (int i = 0; i < a.size(); i++)
    {
      if (i > 0)
      {
        s = s + ", ";
      }
      
      s = s + ((jv)a.get(i)).c_();
    }
    
    return s;
  }
  



  public String[] d()
  {
    String[] astring = new String[a.size()];
    
    for (int i = 0; i < a.size(); i++)
    {
      astring[i] = ((jv)a.get(i)).c_();
    }
    
    return astring;
  }
  
  public gn e()
  {
    return f;
  }
  
  public gn f()
  {
    return g;
  }
  



  public void b(String par1Str)
  {
    h.add(par1Str.toLowerCase());
  }
  



  public void c(String par1Str)
  {
    h.remove(par1Str.toLowerCase());
  }
  



  public boolean d(String par1Str)
  {
    par1Str = par1Str.trim().toLowerCase();
    return (!k) || (h.contains(par1Str)) || (i.contains(par1Str));
  }
  



  public boolean e(String par1Str)
  {
    return (h.contains(par1Str.trim().toLowerCase())) || ((e.K()) && (e.b[0].N().v()) && (e.J().equalsIgnoreCase(par1Str))) || (m);
  }
  
  public jv f(String par1Str)
  {
    Iterator iterator = a.iterator();
    
    jv entityplayermp;
    do
    {
      if (!iterator.hasNext())
      {
        return null;
      }
      
      entityplayermp = (jv)iterator.next();
    }
    while (!entityplayermp.c_().equalsIgnoreCase(par1Str));
    
    return entityplayermp;
  }
  



  public List a(t par1ChunkCoordinates, int par2, int par3, int par4, int par5, int par6, int par7, Map par8Map, String par9Str, String par10Str, abw par11World)
  {
    return findPlayersSized(par1ChunkCoordinates, par2, par3, par4, par5, par6, par7, par8Map, par9Str, par10Str, 0.0F, 0.0F, 0.0F, 0.0F, par11World);
  }
  



  public List findPlayersSized(t par1ChunkCoordinates, int par2, int par3, int par4, int par5, int par6, int par7, Map par8Map, String par9Str, String par10Str, float par11, float par12, float par13, float par14, abw par15World)
  {
    if (a.isEmpty())
    {
      return null;
    }
    

    Object object = new ArrayList();
    boolean flag = par4 < 0;
    boolean flag1 = (par9Str != null) && (par9Str.startsWith("!"));
    boolean flag2 = (par10Str != null) && (par10Str.startsWith("!"));
    int k1 = par2 * par2;
    int l1 = par3 * par3;
    par4 = ls.a(par4);
    
    if (flag1)
    {
      par9Str = par9Str.substring(1);
    }
    
    if (flag2)
    {
      par10Str = par10Str.substring(1);
    }
    
    for (int i2 = 0; i2 < a.size(); i2++)
    {
      jv entityplayermp = (jv)a.get(i2);
      
      if (((par15World == null) || (q == par15World)) && ((par9Str == null) || (flag1 != par9Str.equalsIgnoreCase(entityplayermp.an()))))
      {
        if (par10Str != null)
        {
          atl team = entityplayermp.bo();
          String s2 = team == null ? "" : team.b();
          
          if (flag2 == par10Str.equalsIgnoreCase(s2)) {}




        }
        else if ((par1ChunkCoordinates != null) && ((par2 > 0) || (par3 > 0)))
        {
          float f = par1ChunkCoordinates.e(entityplayermp.b());
          
          if (((par2 > 0) && (f < k1)) || ((par3 > 0) && (f > l1))) {}




        }
        else if ((a(entityplayermp, par8Map)) && ((par5 == ace.a.a()) || (par5 == c.b().a())) && ((par6 <= 0) || (bH >= par6)) && (bH <= par7) && ((par11 <= 0.0F) || (entityplayermp.getSizeMultiplier() >= par11)) && ((par12 <= 0.0F) || (entityplayermp.getSizeMultiplier() <= par12)) && ((par13 <= 0.0F) || (sizeBaseMultiplier >= par13)) && ((par14 <= 0.0F) || (sizeBaseMultiplier <= par14)))
        {
          ((List)object).add(entityplayermp);
        }
      }
    }
    
    if (par1ChunkCoordinates != null)
    {
      Collections.sort((List)object, new hm(par1ChunkCoordinates));
    }
    
    if (flag)
    {
      Collections.reverse((List)object);
    }
    
    if (par4 > 0)
    {
      object = ((List)object).subList(0, Math.min(par4, ((List)object).size()));
    }
    
    return (List)object;
  }
  

  private boolean a(uf par1EntityPlayer, Map par2Map)
  {
    if ((par2Map != null) && (par2Map.size() != 0))
    {
      Iterator iterator = par2Map.entrySet().iterator();
      
      Map.Entry entry;
      boolean flag;
      int i;
      do
      {
        if (!iterator.hasNext())
        {
          return true;
        }
        
        entry = (Map.Entry)iterator.next();
        String s = (String)entry.getKey();
        flag = false;
        
        if ((s.endsWith("_min")) && (s.length() > 4))
        {
          flag = true;
          s = s.substring(0, s.length() - 4);
        }
        
        atj scoreboard = par1EntityPlayer.bM();
        ate scoreobjective = scoreboard.b(s);
        
        if (scoreobjective == null)
        {
          return false;
        }
        
        atg score = par1EntityPlayer.bM().a(par1EntityPlayer.an(), scoreobjective);
        i = score.c();
        
        if ((i < ((Integer)entry.getValue()).intValue()) && (flag))
        {
          return false;
        }
        
      } while ((i <= ((Integer)entry.getValue()).intValue()) || (flag));
      
      return false;
    }
    

    return true;
  }
  




  public void a(double par1, double par3, double par5, double par7, int par9, ey par10Packet)
  {
    a((uf)null, par1, par3, par5, par7, par9, par10Packet);
  }
  




  public void a(uf par1EntityPlayer, double par2, double par4, double par6, double par8, int par10, ey par11Packet)
  {
    for (int j = 0; j < a.size(); j++)
    {
      jv entityplayermp = (jv)a.get(j);
      
      if ((entityplayermp != par1EntityPlayer) && (ar == par10))
      {
        double d4 = par2 - u;
        double d5 = par4 - v;
        double d6 = par6 - w;
        
        if (d4 * d4 + d5 * d5 + d6 * d6 < par8 * par8)
        {
          a.b(par11Packet);
        }
      }
    }
  }
  



  public void g()
  {
    for (int i = 0; i < a.size(); i++)
    {
      b((jv)a.get(i));
    }
  }
  



  public void g(String par1Str)
  {
    i.add(par1Str);
  }
  



  public void h(String par1Str)
  {
    i.remove(par1Str);
  }
  



  public Set h()
  {
    return i;
  }
  
  public Set i()
  {
    return h;
  }
  



  public void j() {}
  



  public void b(jv par1EntityPlayerMP, js par2WorldServer)
  {
    a.b(new fx(par2WorldServer.I(), par2WorldServer.J(), par2WorldServer.O().b("doDaylightCycle")));
    
    if (par2WorldServer.Q())
    {
      a.b(new ef(1, 0));
    }
  }
  



  public void f(jv par1EntityPlayerMP)
  {
    par1EntityPlayerMP.a(bo);
    par1EntityPlayerMP.m();
    a.b(new fk(bn.c));
  }
  



  public int k()
  {
    return a.size();
  }
  



  public int l()
  {
    return b;
  }
  



  public String[] m()
  {
    return e.b[0].M().e().f();
  }
  
  public boolean n()
  {
    return k;
  }
  
  public void a(boolean par1)
  {
    k = par1;
  }
  
  public List i(String par1Str)
  {
    ArrayList arraylist = new ArrayList();
    Iterator iterator = a.iterator();
    
    while (iterator.hasNext())
    {
      jv entityplayermp = (jv)iterator.next();
      
      if (entityplayermp.q().equals(par1Str))
      {
        arraylist.add(entityplayermp);
      }
    }
    
    return arraylist;
  }
  



  public int o()
  {
    return c;
  }
  
  public MinecraftServer p()
  {
    return e;
  }
  



  public by q()
  {
    return null;
  }
  
  @SideOnly(Side.CLIENT)
  public void a(ace par1EnumGameType)
  {
    l = par1EnumGameType;
  }
  
  private void a(jv par1EntityPlayerMP, jv par2EntityPlayerMP, abw par3World)
  {
    if (par2EntityPlayerMP != null)
    {
      c.a(c.b());
    }
    else if (l != null)
    {
      c.a(l);
    }
    
    c.b(par3World.N().r());
  }
  




  @SideOnly(Side.CLIENT)
  public void b(boolean par1)
  {
    m = par1;
  }
  



  public void r()
  {
    while (!a.isEmpty())
    {
      a.get(0)).a.c("Server closed");
    }
  }
  
  public void a(cv par1ChatMessageComponent, boolean par2)
  {
    e.a(par1ChatMessageComponent);
    a(new dm(par1ChatMessageComponent, par2));
  }
  



  public void a(cv par1ChatMessageComponent)
  {
    a(par1ChatMessageComponent, true);
  }
}
