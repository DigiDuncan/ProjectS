import java.util.Random;













public class ts
  extends og
  implements th
{
  public float h;
  public float i;
  public float j;
  public boolean isSlimy;
  private int bn;
  
  public ts(abw par1World)
  {
    super(par1World);
    int i = 1 << ab.nextInt(3);
    N = 0.0F;
    bn = (ab.nextInt(20) + 10);
    a(i);
    isSlimy = true;
  }
  
  protected void a()
  {
    super.a();
    ah.a(16, new Byte((byte)1));
  }
  
  public void a(int par1)
  {
    ah.b(16, new Byte((byte)par1));
    a(0.6F * par1, 0.6F * par1);
    b(u, v, w);
    a(tp.a).a(par1 * par1);
    g(aT());
    b = par1;
  }
  



  public boolean isSticky()
  {
    return isSlimy ? false : super.isSticky();
  }
  



  public int bR()
  {
    return ah.a(16);
  }
  



  public void b(by par1NBTTagCompound)
  {
    super.b(par1NBTTagCompound);
    par1NBTTagCompound.a("Size", bR() - 1);
  }
  



  public void a(by par1NBTTagCompound)
  {
    super.a(par1NBTTagCompound);
    a(par1NBTTagCompound.e("Size") + 1);
  }
  



  protected String bJ()
  {
    return "slime";
  }
  



  protected String bP()
  {
    return "mob.slime." + (ls.d(bR() * getSizeMultiplier()) > 1 ? "big" : "small");
  }
  



  public void l_()
  {
    if ((!q.I) && (q.r == 0) && (bR() > 0))
    {
      M = true;
    }
    
    i += (h - i) * 0.5F;
    this.j = i;
    boolean flag = F;
    super.l_();
    

    if ((F) && (!flag))
    {
      float var2 = bR() * getSizeMultiplier();
      
      for (int j = 0; j < (int)var2 * 8; j++)
      {
        float f = ab.nextFloat() * 3.1415927F * 2.0F;
        float f1 = ab.nextFloat() * 0.5F + 0.5F;
        float f2 = ls.a(f) * var2 * 0.5F * f1;
        float f3 = ls.b(f) * var2 * 0.5F * f1;
        q.a(bJ(), u + f2, E.b, w + f3, 0.0D, 0.0D, 0.0D);
      }
      
      if (bQ())
      {
        a(bP(), ba(), ((ab.nextFloat() - ab.nextFloat()) * 0.2F + 1.0F) / 0.8F);
      }
      
      h = -0.5F;
    }
    else if ((!F) && (flag))
    {
      h = 1.0F;
    }
    
    bM();
    
    if (q.I)
    {
      float var2 = bR();
      a(0.6F * var2, 0.6F * var2);
    }
  }
  
  protected void bl()
  {
    u();
    uf entityplayer = q.b(this, 16.0D);
    
    if (entityplayer != null)
    {
      a(entityplayer, 10.0F, 20.0F);
    }
    
    if ((F) && (bn-- <= 0))
    {
      bn = bL();
      
      if (entityplayer != null)
      {
        bn /= 3;
      }
      
      bd = true;
      
      if (bS())
      {
        a(bP(), ba(), ((ab.nextFloat() - ab.nextFloat()) * 0.2F + 1.0F) * 0.8F);
      }
      
      be = ((1.0F - ab.nextFloat() * 2.0F) * getSizeMultiplierRoot());
      bf = (1 * bR() * getSizeMultiplierRoot());
    }
    else
    {
      bd = false;
      
      if (F)
      {
        be = (this.bf = 0.0F);
      }
    }
  }
  
  protected void bM()
  {
    h *= 0.6F;
  }
  



  protected int bL()
  {
    return ab.nextInt(20) + 10;
  }
  
  protected ts bK()
  {
    return new ts(q);
  }
  



  public void x()
  {
    int i = bR();
    
    if ((!q.I) && (i > 1) && (aN() <= 0.0F))
    {
      float sizemult = getSizeMultiplier();
      int j = 2 + ab.nextInt(3);
      
      for (int k = 0; k < j; k++)
      {
        float f = (k % 2 - 0.5F) * i * sizemult / 4.0F;
        float f1 = (k / 2 - 0.5F) * i * sizemult / 4.0F;
        ts entityslime = bK();
        entityslime.setSizeBaseMultiplier(sizemult);
        entityslime.doResize(sizemult, false);
        entityslime.a(i / 2);
        entityslime.b(u + f, v + 0.5D * getSizeMultiplierRoot(), w + f1, ab.nextFloat() * 360.0F, 0.0F);
        q.d(entityslime);
      }
    }
    
    super.x();
  }
  



  public void b_(uf par1EntityPlayer)
  {
    if ((bN()) || (bR() * getSizeMultiplier() > par1EntityPlayer.getSizeMultiplier()))
    {
      double var2 = (O + O) * (O + O);
      if ((o(par1EntityPlayer)) && (e(par1EntityPlayer) < var2) && (par1EntityPlayer.a(nb.a(this), bO())))
      {
        a("mob.attack", 1.0F, (ab.nextFloat() - ab.nextFloat()) * 0.2F + 1.0F);
      }
    }
  }
  



  protected boolean bN()
  {
    return bR() > 1;
  }
  



  protected int bO()
  {
    return bR();
  }
  



  protected String aO()
  {
    return "mob.slime." + (ls.d(bR() * getSizeMultiplier()) > 1 ? "big" : "small");
  }
  



  protected String aP()
  {
    return "mob.slime." + (ls.d(bR() * getSizeMultiplier()) > 1 ? "big" : "small");
  }
  



  protected int s()
  {
    return bR() == 1 ? aOcv : 0;
  }
  



  public boolean bs()
  {
    adr chunk = q.d(ls.c(u), ls.c(w));
    
    if (q.N().u().handleSlimeSpawnReduction(ab, q))
    {
      return false;
    }
    

    if ((bR() == 1) || (q.r > 0))
    {
      acq biomegenbase = q.a(ls.c(u), ls.c(w));
      
      if ((biomegenbase == acq.h) && (v > 50.0D) && (v < 70.0D) && (ab.nextFloat() < 0.5F) && (ab.nextFloat() < q.x()) && (q.n(ls.c(u), ls.c(v), ls.c(w)) <= ab.nextInt(8)))
      {
        return super.bs();
      }
      
      if ((ab.nextInt(10) == 0) && (chunk.a(987234911L).nextInt(10) == 0) && (v < 40.0D))
      {
        return super.bs();
      }
    }
    
    return false;
  }
  




  protected float ba()
  {
    return 0.4F * bR() * getSizeMultiplierRoot();
  }
  




  public int bp()
  {
    return 0;
  }
  



  protected boolean bS()
  {
    return bR() > 0;
  }
  



  protected boolean bQ()
  {
    return bR() * getSizeMultiplier() > 2.0F;
  }
  



  public double Y()
  {
    return P * (0.3D + bR() * 0.1D);
  }
}
