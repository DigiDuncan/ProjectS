import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.Calendar;
import java.util.List;
import java.util.Random;
import java.util.UUID;
import net.minecraftforge.common.ForgeDummyContainer;
import net.minecraftforge.event.Event.Result;
import net.minecraftforge.event.ForgeEventFactory;
import net.minecraftforge.event.entity.living.ZombieEvent.SummonAidEvent;






























public class tw
  extends tm
{
  protected static final or bp = new oy("zombie.spawnReinforcements", 0.0D, 0.0D, 1.0D).a("Spawn Reinforcements Chance");
  private static final UUID bq = UUID.fromString("B9766B59-9566-4402-BC1F-2EE2A276D836");
  private static final ot br = new ot(bq, "Baby speed boost", 0.5D, 1);
  

  private int bs;
  


  public tw(abw par1World)
  {
    super(par1World);
    k().b(true);
    c.a(0, new pp(this));
    c.a(1, new pj(this));
    c.a(2, new qa(this, uf.class, 1.0D, false));
    c.a(3, new qa(this, ub.class, 1.0D, true));
    c.a(4, new qd(this, 1.0D));
    c.a(5, new qc(this, 1.0D, false));
    c.a(6, new qm(this, 1.0D));
    c.a(7, new px(this, uf.class, 8.0F));
    c.a(7, new ql(this));
    d.a(1, new qx(this, true));
    d.a(2, new qy(this, uf.class, 0, true));
    d.a(2, new qy(this, ub.class, 0, false));
  }
  
  protected void az()
  {
    super.az();
    a(tp.b).a(40.0D);
    a(tp.d).a(0.23000000417232513D);
    a(tp.e).a(3.0D);
    aX().b(bp).a(ab.nextDouble() * ForgeDummyContainer.zombieSummonBaseChance);
  }
  
  protected void a()
  {
    super.a();
    v().a(12, Byte.valueOf((byte)0));
    v().a(13, Byte.valueOf((byte)0));
    v().a(14, Byte.valueOf((byte)0));
  }
  



  public int aQ()
  {
    int i = super.aQ() + 2;
    
    if (i > 20)
    {
      i = 20;
    }
    
    return i;
  }
  



  protected boolean bf()
  {
    return true;
  }
  



  public boolean g_()
  {
    return v().a(12) == 1;
  }
  



  public void a(boolean par1)
  {
    v().b(12, Byte.valueOf((byte)(par1 ? 1 : 0)));
    
    if ((q != null) && (!q.I))
    {
      os attributeinstance = a(tp.d);
      attributeinstance.b(br);
      
      if (par1)
      {
        attributeinstance.a(br);
      }
    }
  }
  



  public boolean bT()
  {
    return v().a(13) == 1;
  }
  



  public void i(boolean par1)
  {
    v().b(13, Byte.valueOf((byte)(par1 ? 1 : 0)));
  }
  




  public void c()
  {
    if ((q.v()) && (!q.I) && (!g_()))
    {
      float f = d(1.0F);
      
      if ((f > 0.5F) && (ab.nextFloat() * 30.0F < (f - 0.4F) * 2.0F) && (q.l(ls.c(u), ls.c(v), ls.c(w))))
      {
        boolean flag = true;
        ye itemstack = n(4);
        
        if (itemstack != null)
        {
          if (itemstack.g())
          {
            itemstack.b(itemstack.j() + ab.nextInt(2));
            
            if (itemstack.j() >= itemstack.l())
            {
              a(itemstack);
              c(4, (ye)null);
            }
          }
          
          flag = false;
        }
        
        if (flag)
        {
          d(8);
        }
      }
    }
    
    super.c();
  }
  



  public boolean a(nb par1DamageSource, float par2)
  {
    if (!super.a(par1DamageSource, par2))
    {
      return false;
    }
    

    of entitylivingbase = m();
    
    if ((entitylivingbase == null) && ((bN() instanceof of)))
    {
      entitylivingbase = (of)bN();
    }
    
    if ((entitylivingbase == null) && ((par1DamageSource.i() instanceof of)))
    {
      entitylivingbase = (of)par1DamageSource.i();
    }
    
    int i = ls.c(u);
    int j = ls.c(v);
    int k = ls.c(w);
    
    ZombieEvent.SummonAidEvent summonAid = ForgeEventFactory.fireZombieSummonAid(this, q, i, j, k, entitylivingbase, a(bp).e());
    
    if (summonAid.getResult() == Event.Result.DENY)
    {
      return true;
    }
    if ((summonAid.getResult() == Event.Result.ALLOW) || ((entitylivingbase != null) && (q.r >= 3) && (ab.nextFloat() < a(bp).e()))) {
      tw entityzombie;
      tw entityzombie;
      if ((customSummonedAid != null) && (summonAid.getResult() == Event.Result.ALLOW))
      {
        entityzombie = customSummonedAid;
      }
      else
      {
        entityzombie = new tw(q);
      }
      
      for (int l = 0; l < 50; l++)
      {
        int i1 = i + ls.a(ab, 7, 40) * ls.a(ab, -1, 1);
        int j1 = j + ls.a(ab, 7, 40) * ls.a(ab, -1, 1);
        int k1 = k + ls.a(ab, 7, 40) * ls.a(ab, -1, 1);
        
        if ((q.w(i1, j1 - 1, k1)) && (q.n(i1, j1, k1) < 10))
        {
          entityzombie.b(i1, j1, k1);
          
          if ((q.b(E)) && (q.a(entityzombie, E).isEmpty()) && (!q.d(E)))
          {
            q.d(entityzombie);
            if (entitylivingbase != null) entityzombie.d(entitylivingbase);
            entityzombie.a((oi)null);
            a(bp).a(new ot("Zombie reinforcement caller charge", -0.05000000074505806D, 0));
            entityzombie.a(bp).a(new ot("Zombie reinforcement callee charge", -0.05000000074505806D, 0));
            break;
          }
        }
      }
    }
    
    return true;
  }
  




  public void l_()
  {
    if ((!q.I) && (bV()))
    {
      int i = bX();
      bs -= i;
      
      if (bs <= 0)
      {
        bW();
      }
    }
    
    super.l_();
  }
  





  public double X()
  {
    float sizemult = getSizeMultiplier();
    
    if ((o != null) && ((o instanceof of)))
    {

      if (((of)o).getSaddled())
      {


        return N - (float)o.Y() / o.P * sizemult + 0.24F * o.getSizeMultiplier() + 0.01F * sizemult * sizemult / o.getSizeMultiplier();
      }
      

      return N - (float)o.Y() / o.P * sizemult + 0.21F * o.getSizeMultiplier() + 0.01F * sizemult * sizemult / o.getSizeMultiplier();
    }
    



    return N - 0.62F * getSizeMultiplier() + 0.12F;
  }
  

  public boolean m(nn par1Entity)
  {
    boolean flag = super.m(par1Entity);
    

    if ((flag) && (aZ() == null) && (af()) && (ab.nextFloat() < q.r * 0.3F) && (!isTinierThan(par1Entity)))
    {
      par1Entity.d(2 * q.r);
    }
    
    return flag;
  }
  



  protected String r()
  {
    return "mob.zombie.say";
  }
  



  protected String aO()
  {
    return "mob.zombie.hurt";
  }
  



  protected String aP()
  {
    return "mob.zombie.death";
  }
  



  protected void a(int par1, int par2, int par3, int par4)
  {
    a("mob.zombie.step", 0.15F, 1.0F);
  }
  



  protected int s()
  {
    return bocv;
  }
  



  public oj aY()
  {
    return oj.b;
  }
  
  protected void l(int par1)
  {
    switch (ab.nextInt(3))
    {
    case 0: 
      b(qcv, 1);
      break;
    case 1: 
      b(bMcv, 1);
      break;
    case 2: 
      b(bNcv, 1);
    }
    
  }
  


  protected void bw()
  {
    super.bw();
    
    if (ab.nextFloat() < (q.r == 3 ? 0.05F : 0.01F))
    {
      int i = ab.nextInt(3);
      
      if (i == 0)
      {
        c(0, new ye(yc.s));
      }
      else
      {
        c(0, new ye(yc.h));
      }
    }
  }
  



  public void b(by par1NBTTagCompound)
  {
    super.b(par1NBTTagCompound);
    
    if (g_())
    {
      par1NBTTagCompound.a("IsBaby", true);
    }
    
    if (bT())
    {
      par1NBTTagCompound.a("IsVillager", true);
    }
    
    par1NBTTagCompound.a("ConversionTime", bV() ? bs : -1);
  }
  



  public void a(by par1NBTTagCompound)
  {
    super.a(par1NBTTagCompound);
    
    if (par1NBTTagCompound.n("IsBaby"))
    {
      a(true);
    }
    
    if (par1NBTTagCompound.n("IsVillager"))
    {
      i(true);
    }
    
    if ((par1NBTTagCompound.b("ConversionTime")) && (par1NBTTagCompound.e("ConversionTime") > -1))
    {
      a(par1NBTTagCompound.e("ConversionTime"));
    }
  }
  



  public void a(of par1EntityLivingBase)
  {
    super.a(par1EntityLivingBase);
    
    if ((q.r >= 2) && ((par1EntityLivingBase instanceof ub)))
    {
      if ((q.r == 2) && (ab.nextBoolean()))
      {
        return;
      }
      
      tw entityzombie = new tw(q);
      entityzombie.setSizeBaseMultiplier(par1EntityLivingBase.getSizeMultiplier());
      entityzombie.doResize(par1EntityLivingBase.getSizeMultiplier(), false);
      entityzombie.j(par1EntityLivingBase);
      q.e(par1EntityLivingBase);
      entityzombie.a((oi)null);
      entityzombie.i(true);
      
      if (par1EntityLivingBase.g_())
      {
        entityzombie.a(true);
      }
      
      q.d(entityzombie);
      q.a((uf)null, 1016, (int)u, (int)v, (int)w, 0);
    }
  }
  
  public oi a(oi par1EntityLivingData)
  {
    Object par1EntityLivingData1 = super.a(par1EntityLivingData);
    float f = q.b(u, v, w);
    h(ab.nextFloat() < 0.55F * f);
    
    if (par1EntityLivingData1 == null)
    {
      par1EntityLivingData1 = new ty(this, q.s.nextFloat() < ForgeDummyContainer.zombieBabyChance, q.s.nextFloat() < 0.05F, (tx)null);
    }
    
    if ((par1EntityLivingData1 instanceof ty))
    {
      ty entityzombiegroupdata = (ty)par1EntityLivingData1;
      
      if (b)
      {
        i(true);
      }
      
      if (a)
      {
        a(true);
      }
    }
    
    bw();
    bx();
    
    if (n(4) == null)
    {
      Calendar calendar = q.W();
      
      if ((calendar.get(2) + 1 == 10) && (calendar.get(5) == 31) && (ab.nextFloat() < 0.25F))
      {
        c(4, new ye(ab.nextFloat() < 0.1F ? aqz.bk : aqz.bf));
        e[4] = 0.0F;
      }
    }
    
    a(tp.c).a(new ot("Random spawn bonus", ab.nextDouble() * 0.05000000074505806D, 0));
    a(tp.b).a(new ot("Random zombie-spawn bonus", ab.nextDouble() * 1.5D, 2));
    
    if (ab.nextFloat() < f * 0.05F)
    {
      a(bp).a(new ot("Leader zombie bonus", ab.nextDouble() * 0.25D + 0.5D, 0));
      a(tp.a).a(new ot("Leader zombie bonus", ab.nextDouble() * 3.0D + 1.0D, 2));
    }
    
    return (oi)par1EntityLivingData1;
  }
  



  public boolean a(uf par1EntityPlayer)
  {
    ye itemstack = par1EntityPlayer.by();
    
    if ((itemstack != null) && (itemstack.b() == yc.av) && (itemstack.k() == 0) && (bT()) && (a(ni.t)))
    {
      if (!bG.d)
      {
        b -= 1;
      }
      
      if (b <= 0)
      {
        bn.a(bn.c, (ye)null);
      }
      
      if (!q.I)
      {
        a(ab.nextInt(2401) + 3600);
      }
      
      return true;
    }
    

    return false;
  }
  





  protected void a(int par1)
  {
    bs = par1;
    v().b(14, Byte.valueOf((byte)1));
    k(tH);
    c(new nj(gH, par1, Math.min(q.r - 1, 0)));
    q.a(this, (byte)16);
  }
  
  @SideOnly(Side.CLIENT)
  public void a(byte par1)
  {
    if (par1 == 16)
    {
      q.a(u + 0.5D, v + 0.5D, w + 0.5D, "mob.zombie.remedy", 1.0F + ab.nextFloat(), ab.nextFloat() * 0.7F + 0.3F, false);
    }
    else
    {
      super.a(par1);
    }
  }
  



  protected boolean t()
  {
    return !bV();
  }
  



  public boolean bV()
  {
    return v().a(14) == 1;
  }
  



  protected void bW()
  {
    ub entityvillager = new ub(q);
    entityvillager.setSizeBaseMultiplier(getSizeMultiplier());
    entityvillager.doResize(getSizeMultiplier(), false);
    entityvillager.j(this);
    entityvillager.a((oi)null);
    entityvillager.bX();
    
    if (g_())
    {
      entityvillager.c(41536);
    }
    
    q.e(this);
    q.d(entityvillager);
    entityvillager.c(new nj(kH, 200, 0));
    q.a((uf)null, 1017, (int)u, (int)v, (int)w, 0);
  }
  



  protected int bX()
  {
    int i = 1;
    
    if (ab.nextFloat() < 0.01F)
    {
      int j = 0;
      
      for (int k = (int)u - 4; (k < (int)u + 4) && (j < 14); k++)
      {
        for (int l = (int)v - 4; (l < (int)v + 4) && (j < 14); l++)
        {
          for (int i1 = (int)w - 4; (i1 < (int)w + 4) && (j < 14); i1++)
          {
            int j1 = q.a(k, l, i1);
            
            if ((j1 == bucF) || (j1 == XcF))
            {
              if (ab.nextFloat() < 0.3F)
              {
                i++;
              }
              
              j++;
            }
          }
        }
      }
    }
    
    return i;
  }
}
