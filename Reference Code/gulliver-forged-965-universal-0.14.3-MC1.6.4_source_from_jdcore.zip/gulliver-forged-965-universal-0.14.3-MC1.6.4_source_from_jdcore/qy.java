import java.util.Collections;
import java.util.List;
import java.util.Random;











public class qy
  extends re
{
  private final Class a;
  private final int b;
  private final ra e;
  private final nw f;
  private of g;
  
  public qy(on par1EntityCreature, Class par2Class, int par3, boolean par4)
  {
    this(par1EntityCreature, par2Class, par3, par4, false);
  }
  
  public qy(on par1EntityCreature, Class par2Class, int par3, boolean par4, boolean par5)
  {
    this(par1EntityCreature, par2Class, par3, par4, par5, (nw)null);
  }
  
  public qy(on par1EntityCreature, Class par2Class, int par3, boolean par4, boolean par5, nw par6IEntitySelector)
  {
    super(par1EntityCreature, par4, par5);
    a = par2Class;
    b = par3;
    e = new ra(par1EntityCreature);
    minTargetSize = par1EntityCreature.getMinTargetSize();
    maxTargetSize = par1EntityCreature.getMaxTargetSize();
    a(1);
    f = new qz(this, par6IEntitySelector);
  }
  



  public boolean a()
  {
    if ((b > 0) && (c.aD().nextInt(b) != 0))
    {
      return false;
    }
    

    double d0 = f() * c.getRangeMultiplier();
    List list = c.q.a(a, c.E.b(d0, 4.0D * c.getSizeMultiplierRoot(), d0), f);
    Collections.sort(list, e);
    
    if (list.isEmpty())
    {
      return false;
    }
    

    g = ((of)list.get(0));
    return true;
  }
  





  public void c()
  {
    c.d(g);
    super.c();
  }
}
