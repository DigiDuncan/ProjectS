A revival of the old Gulliver mod, which was made by UncleMion.

This mod allows any entity to be resized, either with potions, commands, or the mod's configuration file.