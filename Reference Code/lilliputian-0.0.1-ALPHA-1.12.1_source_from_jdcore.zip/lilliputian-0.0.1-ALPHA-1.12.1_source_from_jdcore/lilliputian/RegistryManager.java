package lilliputian;

import lilliputian.compat.RusticCompat;
import lilliputian.potions.PotionLilliputian;
import net.minecraft.block.Block;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.init.Items;
import net.minecraft.init.PotionTypes;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionType;
import net.minecraft.potion.PotionUtils;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.common.brewing.BrewingRecipeRegistry;
import net.minecraftforge.event.RegistryEvent.Register;
import net.minecraftforge.fml.common.Loader;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.registry.GameRegistry.ObjectHolder;
import net.minecraftforge.registries.IForgeRegistry;



@Mod.EventBusSubscriber(modid="lilliputian")
@GameRegistry.ObjectHolder("lilliputian")
public class RegistryManager
{
  public RegistryManager() {}
  
  @SubscribeEvent
  public static void registerBlocks(RegistryEvent.Register<Block> event) {}
  
  @SubscribeEvent
  public static void registerItemBlocks(RegistryEvent.Register<Item> event) {}
  
  @SubscribeEvent
  public static void registerItems(RegistryEvent.Register<Item> event) {}
  
  @SubscribeEvent
  public static void registerPotions(RegistryEvent.Register<Potion> event)
  {
    event.getRegistry().register(PotionLilliputian.SHRINKING_POTION);
    event.getRegistry().register(PotionLilliputian.GROWING_POTION);
  }
  
  @SubscribeEvent
  public static void registerPotionTypes(RegistryEvent.Register<PotionType> event) {
    event.getRegistry().register(PotionLilliputian.SHRINKING);
    event.getRegistry().register(PotionLilliputian.LONG_SHRINKING);
    event.getRegistry().register(PotionLilliputian.STRONG_SHRINKING);
    event.getRegistry().register(PotionLilliputian.GROWING);
    event.getRegistry().register(PotionLilliputian.LONG_GROWING);
    event.getRegistry().register(PotionLilliputian.STRONG_GROWING);
  }
  
  @SubscribeEvent
  public static void registerRecipes(RegistryEvent.Register<IRecipe> event) {
    BrewingRecipeRegistry.addRecipe(
      PotionUtils.func_185188_a(new ItemStack(Items.field_151068_bn), PotionTypes.field_185233_e), new ItemStack(Items.field_151009_A), 
      
      PotionUtils.func_185188_a(new ItemStack(Items.field_151068_bn), PotionLilliputian.SHRINKING));
    BrewingRecipeRegistry.addRecipe(
      PotionUtils.func_185188_a(new ItemStack(Items.field_151068_bn), PotionLilliputian.SHRINKING), new ItemStack(Items.field_151137_ax), 
      
      PotionUtils.func_185188_a(new ItemStack(Items.field_151068_bn), PotionLilliputian.LONG_SHRINKING));
    BrewingRecipeRegistry.addRecipe(
      PotionUtils.func_185188_a(new ItemStack(Items.field_151068_bn), PotionLilliputian.SHRINKING), new ItemStack(Items.field_151114_aO), 
      
      PotionUtils.func_185188_a(new ItemStack(Items.field_151068_bn), PotionLilliputian.STRONG_SHRINKING));
    
    BrewingRecipeRegistry.addRecipe(
      PotionUtils.func_185188_a(new ItemStack(Items.field_151068_bn), PotionTypes.field_185233_e), new ItemStack(Items.field_151105_aU), 
      
      PotionUtils.func_185188_a(new ItemStack(Items.field_151068_bn), PotionLilliputian.GROWING));
    BrewingRecipeRegistry.addRecipe(
      PotionUtils.func_185188_a(new ItemStack(Items.field_151068_bn), PotionLilliputian.GROWING), new ItemStack(Items.field_151137_ax), 
      
      PotionUtils.func_185188_a(new ItemStack(Items.field_151068_bn), PotionLilliputian.LONG_GROWING));
    BrewingRecipeRegistry.addRecipe(
      PotionUtils.func_185188_a(new ItemStack(Items.field_151068_bn), PotionLilliputian.GROWING), new ItemStack(Items.field_151114_aO), 
      
      PotionUtils.func_185188_a(new ItemStack(Items.field_151068_bn), PotionLilliputian.STRONG_GROWING));
    
    BrewingRecipeRegistry.addRecipe(
      PotionUtils.func_185188_a(new ItemStack(Items.field_185155_bH), PotionTypes.field_185233_e), new ItemStack(Items.field_151009_A), 
      
      PotionUtils.func_185188_a(new ItemStack(Items.field_185155_bH), PotionLilliputian.SHRINKING));
    BrewingRecipeRegistry.addRecipe(
      PotionUtils.func_185188_a(new ItemStack(Items.field_185155_bH), PotionLilliputian.SHRINKING), new ItemStack(Items.field_151137_ax), 
      
      PotionUtils.func_185188_a(new ItemStack(Items.field_185155_bH), PotionLilliputian.LONG_SHRINKING));
    BrewingRecipeRegistry.addRecipe(
      PotionUtils.func_185188_a(new ItemStack(Items.field_185155_bH), PotionLilliputian.SHRINKING), new ItemStack(Items.field_151114_aO), 
      
      PotionUtils.func_185188_a(new ItemStack(Items.field_185155_bH), PotionLilliputian.STRONG_SHRINKING));
    
    BrewingRecipeRegistry.addRecipe(
      PotionUtils.func_185188_a(new ItemStack(Items.field_185155_bH), PotionTypes.field_185233_e), new ItemStack(Items.field_151105_aU), 
      
      PotionUtils.func_185188_a(new ItemStack(Items.field_185155_bH), PotionLilliputian.GROWING));
    BrewingRecipeRegistry.addRecipe(
      PotionUtils.func_185188_a(new ItemStack(Items.field_185155_bH), PotionLilliputian.GROWING), new ItemStack(Items.field_151137_ax), 
      
      PotionUtils.func_185188_a(new ItemStack(Items.field_185155_bH), PotionLilliputian.LONG_GROWING));
    BrewingRecipeRegistry.addRecipe(
      PotionUtils.func_185188_a(new ItemStack(Items.field_185155_bH), PotionLilliputian.GROWING), new ItemStack(Items.field_151114_aO), 
      
      PotionUtils.func_185188_a(new ItemStack(Items.field_185155_bH), PotionLilliputian.STRONG_GROWING));
    
    BrewingRecipeRegistry.addRecipe(
      PotionUtils.func_185188_a(new ItemStack(Items.field_185156_bI), PotionTypes.field_185233_e), new ItemStack(Items.field_151009_A), 
      
      PotionUtils.func_185188_a(new ItemStack(Items.field_185156_bI), PotionLilliputian.SHRINKING));
    BrewingRecipeRegistry.addRecipe(
      PotionUtils.func_185188_a(new ItemStack(Items.field_185156_bI), PotionLilliputian.SHRINKING), new ItemStack(Items.field_151137_ax), 
      
      PotionUtils.func_185188_a(new ItemStack(Items.field_185156_bI), PotionLilliputian.LONG_SHRINKING));
    BrewingRecipeRegistry.addRecipe(
      PotionUtils.func_185188_a(new ItemStack(Items.field_185156_bI), PotionLilliputian.SHRINKING), new ItemStack(Items.field_151114_aO), 
      PotionUtils.func_185188_a(new ItemStack(Items.field_185156_bI), PotionLilliputian.STRONG_SHRINKING));
    

    BrewingRecipeRegistry.addRecipe(
      PotionUtils.func_185188_a(new ItemStack(Items.field_185156_bI), PotionTypes.field_185233_e), new ItemStack(Items.field_151105_aU), 
      
      PotionUtils.func_185188_a(new ItemStack(Items.field_185156_bI), PotionLilliputian.GROWING));
    BrewingRecipeRegistry.addRecipe(
      PotionUtils.func_185188_a(new ItemStack(Items.field_185156_bI), PotionLilliputian.GROWING), new ItemStack(Items.field_151137_ax), 
      
      PotionUtils.func_185188_a(new ItemStack(Items.field_185156_bI), PotionLilliputian.LONG_GROWING));
    BrewingRecipeRegistry.addRecipe(
      PotionUtils.func_185188_a(new ItemStack(Items.field_185156_bI), PotionLilliputian.GROWING), new ItemStack(Items.field_151114_aO), 
      
      PotionUtils.func_185188_a(new ItemStack(Items.field_185156_bI), PotionLilliputian.STRONG_GROWING));
    
    BrewingRecipeRegistry.addRecipe(
      PotionUtils.func_185188_a(new ItemStack(Items.field_151068_bn), PotionLilliputian.SHRINKING), new ItemStack(Items.field_151016_H), 
      
      PotionUtils.func_185188_a(new ItemStack(Items.field_185155_bH), PotionLilliputian.SHRINKING));
    BrewingRecipeRegistry.addRecipe(
      PotionUtils.func_185188_a(new ItemStack(Items.field_151068_bn), PotionLilliputian.LONG_SHRINKING), new ItemStack(Items.field_151016_H), 
      
      PotionUtils.func_185188_a(new ItemStack(Items.field_185155_bH), PotionLilliputian.LONG_SHRINKING));
    BrewingRecipeRegistry.addRecipe(
      PotionUtils.func_185188_a(new ItemStack(Items.field_151068_bn), PotionLilliputian.STRONG_SHRINKING), new ItemStack(Items.field_151016_H), 
      PotionUtils.func_185188_a(new ItemStack(Items.field_185155_bH), PotionLilliputian.STRONG_SHRINKING));
    

    BrewingRecipeRegistry.addRecipe(
      PotionUtils.func_185188_a(new ItemStack(Items.field_151068_bn), PotionLilliputian.GROWING), new ItemStack(Items.field_151016_H), 
      
      PotionUtils.func_185188_a(new ItemStack(Items.field_185155_bH), PotionLilliputian.GROWING));
    BrewingRecipeRegistry.addRecipe(
      PotionUtils.func_185188_a(new ItemStack(Items.field_151068_bn), PotionLilliputian.LONG_GROWING), new ItemStack(Items.field_151016_H), 
      
      PotionUtils.func_185188_a(new ItemStack(Items.field_185155_bH), PotionLilliputian.LONG_GROWING));
    BrewingRecipeRegistry.addRecipe(
      PotionUtils.func_185188_a(new ItemStack(Items.field_151068_bn), PotionLilliputian.STRONG_GROWING), new ItemStack(Items.field_151016_H), 
      
      PotionUtils.func_185188_a(new ItemStack(Items.field_185155_bH), PotionLilliputian.STRONG_GROWING));
    
    BrewingRecipeRegistry.addRecipe(
      PotionUtils.func_185188_a(new ItemStack(Items.field_185155_bH), PotionLilliputian.SHRINKING), new ItemStack(Items.field_185157_bK), 
      
      PotionUtils.func_185188_a(new ItemStack(Items.field_185156_bI), PotionLilliputian.SHRINKING));
    BrewingRecipeRegistry.addRecipe(
      PotionUtils.func_185188_a(new ItemStack(Items.field_185155_bH), PotionLilliputian.LONG_SHRINKING), new ItemStack(Items.field_185157_bK), 
      
      PotionUtils.func_185188_a(new ItemStack(Items.field_185156_bI), PotionLilliputian.LONG_SHRINKING));
    BrewingRecipeRegistry.addRecipe(
      PotionUtils.func_185188_a(new ItemStack(Items.field_185155_bH), PotionLilliputian.STRONG_SHRINKING), new ItemStack(Items.field_185157_bK), 
      
      PotionUtils.func_185188_a(new ItemStack(Items.field_185156_bI), PotionLilliputian.STRONG_SHRINKING));
    

    BrewingRecipeRegistry.addRecipe(
      PotionUtils.func_185188_a(new ItemStack(Items.field_185155_bH), PotionLilliputian.GROWING), new ItemStack(Items.field_185157_bK), 
      
      PotionUtils.func_185188_a(new ItemStack(Items.field_185156_bI), PotionLilliputian.GROWING));
    BrewingRecipeRegistry.addRecipe(
      PotionUtils.func_185188_a(new ItemStack(Items.field_185155_bH), PotionLilliputian.LONG_GROWING), new ItemStack(Items.field_185157_bK), 
      
      PotionUtils.func_185188_a(new ItemStack(Items.field_185156_bI), PotionLilliputian.LONG_GROWING));
    BrewingRecipeRegistry.addRecipe(
      PotionUtils.func_185188_a(new ItemStack(Items.field_185155_bH), PotionLilliputian.STRONG_GROWING), new ItemStack(Items.field_185157_bK), 
      
      PotionUtils.func_185188_a(new ItemStack(Items.field_185156_bI), PotionLilliputian.STRONG_GROWING));
    if (Loader.isModLoaded("rustic")) {
      RusticCompat.initElixirs();
    }
  }
  

  @SubscribeEvent
  public static void setupModels(ModelRegistryEvent event) {}
  
  private static void registerItemBlock(IForgeRegistry<Item> registry, Block block)
  {
    registry.register(new ItemBlock(block).setRegistryName(block.getRegistryName()));
  }
  
  private static void registerBlockModel(Block block) {
    ModelLoader.setCustomModelResourceLocation(Item.func_150898_a(block), 0, new ModelResourceLocation(block
      .getRegistryName().toString(), "inventory"));
  }
  
  private static void registerItemModel(Item item) {
    ModelLoader.setCustomModelResourceLocation(item, 0, new ModelResourceLocation(item
      .getRegistryName().toString(), "inventory"));
  }
}
