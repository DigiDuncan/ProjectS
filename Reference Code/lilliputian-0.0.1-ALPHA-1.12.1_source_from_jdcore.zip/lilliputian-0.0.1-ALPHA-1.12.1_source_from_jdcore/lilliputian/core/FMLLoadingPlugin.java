package lilliputian.core;

import java.util.Map;
import net.minecraftforge.fml.relauncher.IFMLLoadingPlugin;
import net.minecraftforge.fml.relauncher.IFMLLoadingPlugin.SortingIndex;
import net.minecraftforge.fml.relauncher.IFMLLoadingPlugin.TransformerExclusions;

@IFMLLoadingPlugin.TransformerExclusions({"lilliputian.core"})
@net.minecraftforge.fml.relauncher.IFMLLoadingPlugin.MCVersion("1.12.1")
@IFMLLoadingPlugin.SortingIndex(32767)
public class FMLLoadingPlugin implements IFMLLoadingPlugin
{
  public static boolean runtimeDeobfEnabled = false;
  
  public FMLLoadingPlugin() {}
  
  public String[] getASMTransformerClass() { return new String[] { ClassTransformer.class.getName() }; }
  

  public String getModContainerClass()
  {
    return LilliputianCore.class.getName();
  }
  
  public String getSetupClass()
  {
    return null;
  }
  
  public void injectData(Map<String, Object> data)
  {
    runtimeDeobfEnabled = ((Boolean)data.get("runtimeDeobfuscationEnabled")).booleanValue();
  }
  
  public String getAccessTransformerClass()
  {
    return null;
  }
}
