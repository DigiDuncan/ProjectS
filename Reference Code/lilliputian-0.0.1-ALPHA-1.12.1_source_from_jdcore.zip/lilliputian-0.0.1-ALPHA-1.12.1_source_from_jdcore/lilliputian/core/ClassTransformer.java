package lilliputian.core;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.LdcInsnNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;

public class ClassTransformer implements net.minecraft.launchwrapper.IClassTransformer
{
  public ClassTransformer() {}
  
  public byte[] transform(String name, String transformedName, byte[] basicClass)
  {
    if (transformedName.equals("net.minecraft.client.renderer.EntityRenderer"))
      return patchEntityRendererASM(name, basicClass, !name.equals(transformedName));
    if (transformedName.equals("net.minecraft.client.renderer.entity.Render"))
      return patchAbstractRenderASM(name, basicClass, !name.equals(transformedName));
    if (transformedName.equals("net.minecraft.entity.player.EntityPlayer"))
      return patchEntityPlayerASM(name, basicClass, !name.equals(transformedName));
    if (transformedName.equals("net.minecraft.entity.Entity"))
      return patchEntityASM(name, basicClass, !name.equals(transformedName));
    if (transformedName.equals("net.minecraft.entity.EntityLivingBase"))
      return patchEntityLivingBaseASM(name, basicClass, !name.equals(transformedName));
    if (transformedName.equals("net.minecraft.client.multiplayer.PlayerControllerMP"))
      return patchPlayerControllerMPASM(name, basicClass, !name.equals(transformedName));
    if (transformedName.equals("net.minecraft.server.management.PlayerInteractionManager"))
      return patchPlayerInteractionManagerASM(name, basicClass, !name.equals(transformedName));
    if (transformedName.equals("net.minecraft.block.BlockCactus"))
      return patchBlockCactusASM(name, basicClass, !name.equals(transformedName));
    if ((transformedName.contains("Entity")) && (!transformedName.contains("minecraftforge")))
      return patchGenericEntityASM(name, basicClass, !name.equals(transformedName));
    if (transformedName.equals("net.minecraft.client.gui.inventory.GuiInventory")) {
      return patchInventoryRenderASM(name, basicClass, !name.equals(transformedName));
    }
    return basicClass;
  }
  
  @net.minecraftforge.fml.relauncher.SideOnly(net.minecraftforge.fml.relauncher.Side.CLIENT)
  public byte[] patchEntityRendererASM(String name, byte[] bytes, boolean obfuscated) {
    String setupCameraTransform = "";
    String renderHand = "";
    String renderWorldPass = "";
    String renderCloudsCheck = "";
    String applyBobbing = "";
    String orientCamera = "";
    String updateRenderer = "";
    String getMouseOver = "";
    
    String extendedReach = "";
    
    String entityName = "";
    
    if (obfuscated) {
      setupCameraTransform = "func_78479_a";
      renderHand = "func_78476_b";
      renderWorldPass = "func_175068_a";
      renderCloudsCheck = "func_180437_a";
      applyBobbing = "func_78475_f";
      orientCamera = "func_78467_g";
      updateRenderer = "func_78464_a";
      getMouseOver = "func_78473_a";
      
      extendedReach = "func_78749_i";
      
      entityName = "Lnet/minecraft/entity/Entity;";
    } else {
      setupCameraTransform = "setupCameraTransform";
      renderHand = "renderHand";
      renderWorldPass = "renderWorldPass";
      renderCloudsCheck = "renderCloudsCheck";
      applyBobbing = "applyBobbing";
      orientCamera = "orientCamera";
      updateRenderer = "updateRenderer";
      getMouseOver = "getMouseOver";
      
      extendedReach = "extendedReach";
      
      entityName = "Lnet/minecraft/entity/Entity;";
    }
    
    ClassNode classNode = new ClassNode();
    ClassReader classReader = new ClassReader(bytes);
    classReader.accept(classNode, 0);
    
    java.util.List<MethodNode> methods = methods;
    
    for (MethodNode m : methods) {
      if (name.equals(setupCameraTransform)) {
        System.out.println("Found method " + name + "." + name + "" + desc);
        InsnList code = instructions;
        MethodInsnNode method = new MethodInsnNode(184, "lilliputian/util/EntitySizeUtil", "getCameraNearPlane", "()F", false);
        
        for (int i = 0; i < code.size(); i++) {
          if ((code.get(i) instanceof LdcInsnNode)) {
            LdcInsnNode lin = (LdcInsnNode)code.get(i);
            if (((cst instanceof Float)) && (((Float)cst).floatValue() == 0.05F)) {
              code.set(lin, method);
            }
          }
        }
      }
      else if (name.equals(renderHand)) {
        System.out.println("Found method " + name + "." + name + "" + desc);
        InsnList code = instructions;
        MethodInsnNode method = new MethodInsnNode(184, "lilliputian/util/EntitySizeUtil", "getCameraNearPlane", "()F", false);
        
        for (int i = 0; i < code.size(); i++) {
          if ((code.get(i) instanceof LdcInsnNode)) {
            LdcInsnNode lin = (LdcInsnNode)code.get(i);
            if (((cst instanceof Float)) && (((Float)cst).floatValue() == 0.05F)) {
              code.set(lin, method);
            }
          }
        }
      }
      else if (name.equals(renderWorldPass)) {
        System.out.println("Found method " + name + "." + name + "" + desc);
        InsnList code = instructions;
        MethodInsnNode method = new MethodInsnNode(184, "lilliputian/util/EntitySizeUtil", "getCameraNearPlane", "()F", false);
        
        for (int i = 0; i < code.size(); i++) {
          if ((code.get(i) instanceof LdcInsnNode)) {
            LdcInsnNode lin = (LdcInsnNode)code.get(i);
            if (((cst instanceof Float)) && (((Float)cst).floatValue() == 0.05F)) {
              code.set(lin, method);
            }
            
          }
        }
      }
      else if (name.equals(renderCloudsCheck)) {
        System.out.println("Found method " + name + "." + name + "" + desc);
        InsnList code = instructions;
        MethodInsnNode method = new MethodInsnNode(184, "lilliputian/util/EntitySizeUtil", "getCameraNearPlane", "()F", false);
        
        for (int i = 0; i < code.size(); i++) {
          if ((code.get(i) instanceof LdcInsnNode)) {
            LdcInsnNode lin = (LdcInsnNode)code.get(i);
            if (((cst instanceof Float)) && (((Float)cst).floatValue() == 0.05F)) {
              code.set(lin, method);
            }
            
          }
        }
      }
      else if (name.equals(applyBobbing)) {
        System.out.println("Found method " + name + "." + name + "" + desc);
        InsnList code = instructions;
        MethodInsnNode method = new MethodInsnNode(184, "lilliputian/util/EntitySizeUtil", "getViewEntityScale", "()F", false);
        
        MethodInsnNode method2 = new MethodInsnNode(184, "lilliputian/util/EntitySizeUtil", "getViewEntityScale", "()F", false);
        
        MethodInsnNode method3 = new MethodInsnNode(184, "lilliputian/util/EntitySizeUtil", "getViewEntityScaleRoot", "()F", false);
        

        code.insert(code.get(73), method);
        code.insert(code.get(74), new org.objectweb.asm.tree.InsnNode(106));
        code.insert(code.get(67), method2);
        code.insert(code.get(68), new org.objectweb.asm.tree.InsnNode(106));
        
        code.insert(code.get(29), method3);
        code.insert(code.get(30), new org.objectweb.asm.tree.InsnNode(110));
      } else if (name.equals(orientCamera)) {
        System.out.println("Found method " + name + "." + name + "" + desc);
        InsnList code = instructions;
        MethodInsnNode method = new MethodInsnNode(184, "lilliputian/util/EntitySizeUtil", "getViewEntityScale", "()F", false);
        
        for (int i = 0; i < code.size(); i++) {
          if ((code.get(i) instanceof LdcInsnNode)) {
            LdcInsnNode lin = (LdcInsnNode)code.get(i);
            if (((cst instanceof Float)) && (((Float)cst).floatValue() == 4.0F)) {
              code.insert(code.get(i), method);
              code.insert(code.get(i + 1), new org.objectweb.asm.tree.InsnNode(106));
            }
            
          }
        }
      }
      else if (name.equals(updateRenderer)) {
        System.out.println("Found method " + name + "." + name + "" + desc);
        InsnList code = instructions;
        MethodInsnNode method = new MethodInsnNode(184, "lilliputian/util/EntitySizeUtil", "getViewEntityScale", "()F", false);
        

        code.insert(code.get(27), method);
        code.insert(code.get(28), new org.objectweb.asm.tree.InsnNode(106));
      } else if (name.equals(getMouseOver)) {
        System.out.println("Found method " + name + "." + name + "" + desc);
        InsnList code = instructions;
        MethodInsnNode method = new MethodInsnNode(184, "lilliputian/util/EntitySizeUtil", "getMaxReach", "()D", false);
        
        MethodInsnNode method2 = new MethodInsnNode(184, "lilliputian/util/EntitySizeUtil", "getExtendedReach", "()D", false);
        
        boolean notFirst = false;
        for (int i = 0; i < code.size(); i++) {
          if ((code.get(i) instanceof LdcInsnNode)) {
            LdcInsnNode lin = (LdcInsnNode)code.get(i);
            if (((cst instanceof Double)) && (((Double)cst).doubleValue() == 3.0D)) {
              if (notFirst) {
                code.set(lin, method);
              } else {
                notFirst = true;
              }
            } else if (((cst instanceof Double)) && (((Double)cst).doubleValue() == 6.0D)) {
              code.set(lin, method2);
            }
          }
        }
      }
    }
    




    ClassWriter writer = new ClassWriter(classReader, 1);
    classNode.accept(writer);
    
    return writer.toByteArray();
  }
  
  @net.minecraftforge.fml.relauncher.SideOnly(net.minecraftforge.fml.relauncher.Side.CLIENT)
  public byte[] patchAbstractRenderASM(String name, byte[] bytes, boolean obfuscated) {
    String renderShadow = "";
    
    String shadowSize = "";
    
    String entityName = "";
    
    if (obfuscated) {
      renderShadow = "func_76975_c";
      
      shadowSize = "field_76989_e";
      
      entityName = "Lnet/minecraft/entity/Entity;";
    } else {
      renderShadow = "renderShadow";
      
      shadowSize = "shadowSize";
      
      entityName = "Lnet/minecraft/entity/Entity;";
    }
    
    ClassNode classNode = new ClassNode();
    ClassReader classReader = new ClassReader(bytes);
    classReader.accept(classNode, 0);
    
    java.util.List<MethodNode> methods = methods;
    
    for (MethodNode m : methods) {
      if (name.equals(renderShadow)) {
        System.out.println("Found method " + name + "." + name + "" + desc);
        InsnList code = instructions;
        MethodInsnNode method = new MethodInsnNode(184, "lilliputian/util/EntitySizeUtil", "getEntityScale", "(" + entityName + ")F", false);
        





        for (int i = 0; i < code.size(); i++) {
          if ((code.get(i) instanceof org.objectweb.asm.tree.FieldInsnNode)) {
            org.objectweb.asm.tree.FieldInsnNode fin = (org.objectweb.asm.tree.FieldInsnNode)code.get(i);
            if ((fin.getOpcode() == 180) && (name.equals(shadowSize)) && (desc.equals("F"))) {
              code.insert(code.get(i), new org.objectweb.asm.tree.VarInsnNode(25, 1));
              code.insert(code.get(i + 1), method);
              code.insert(code.get(i + 2), new org.objectweb.asm.tree.InsnNode(106));
            }
          }
        }
      }
    }
    



    ClassWriter writer = new ClassWriter(1);
    classNode.accept(writer);
    
    return writer.toByteArray();
  }
  
  public byte[] patchEntityPlayerASM(String name, byte[] bytes, boolean obfuscated) {
    String getEyeHeight = "";
    String updateSize = "";
    String getYOffset = "";
    
    String entityName = "";
    
    if (obfuscated) {
      getEyeHeight = "func_70047_e";
      updateSize = "func_184808_cD";
      getYOffset = "func_70033_W";
      
      entityName = "Lnet/minecraft/entity/Entity;";
    } else {
      getEyeHeight = "getEyeHeight";
      updateSize = "updateSize";
      getYOffset = "getYOffset";
      
      entityName = "Lnet/minecraft/entity/Entity;";
    }
    
    ClassNode classNode = new ClassNode();
    ClassReader classReader = new ClassReader(bytes);
    classReader.accept(classNode, 0);
    
    java.util.List<MethodNode> methods = methods;
    
    for (MethodNode m : methods) {
      if (name.equals(getEyeHeight)) {
        System.out.println("Found method " + name + "." + name + "" + desc);
        InsnList code = instructions;
        MethodInsnNode method = new MethodInsnNode(184, "lilliputian/util/EntitySizeUtil", "getEntityScale", "(" + entityName + ")F", false);
        

        code.insertBefore(code.get(53), new org.objectweb.asm.tree.VarInsnNode(25, 0));
        code.insertBefore(code.get(54), method);
        code.insertBefore(code.get(55), new org.objectweb.asm.tree.InsnNode(106));
      } else if (name.equals(updateSize)) {
        System.out.println("Found method " + name + "." + name + "" + desc);
        InsnList code = instructions;
        MethodInsnNode method = new MethodInsnNode(184, "lilliputian/util/EntitySizeUtil", "getEntityScale", "(" + entityName + ")F", false);
        
        MethodInsnNode method2 = new MethodInsnNode(184, "lilliputian/util/EntitySizeUtil", "getEntityScale", "(" + entityName + ")F", false);
        

        code.insert(code.get(58), new org.objectweb.asm.tree.VarInsnNode(25, 0));
        code.insert(code.get(59), method);
        code.insert(code.get(60), new org.objectweb.asm.tree.VarInsnNode(23, 1));
        code.insert(code.get(61), new org.objectweb.asm.tree.InsnNode(106));
        code.insert(code.get(62), new org.objectweb.asm.tree.VarInsnNode(56, 1));
        
        code.insert(code.get(63), new org.objectweb.asm.tree.VarInsnNode(25, 0));
        code.insert(code.get(64), method2);
        code.insert(code.get(65), new org.objectweb.asm.tree.VarInsnNode(23, 2));
        code.insert(code.get(66), new org.objectweb.asm.tree.InsnNode(106));
        code.insert(code.get(67), new org.objectweb.asm.tree.VarInsnNode(56, 2));
      } else if (name.equals(getYOffset)) {
        System.out.println("Found method " + name + "." + name + "" + desc);
        InsnList code = instructions;
        MethodInsnNode method = new MethodInsnNode(184, "lilliputian/util/EntitySizeUtil", "getEntityYOffset", "(D" + entityName + ")D", false);
        

        for (int i = code.size() - 1; i > 0; i--) {
          if (code.get(i).getOpcode() == 175) {
            code.insertBefore(code.get(i), new org.objectweb.asm.tree.VarInsnNode(25, 0));
            code.insertBefore(code.get(i + 1), method);
          }
        }
      }
    }
    
    ClassWriter writer = new ClassWriter(1);
    classNode.accept(writer);
    
    return writer.toByteArray();
  }
  
  public byte[] patchEntityASM(String name, byte[] bytes, boolean obfuscated) {
    String isEntityInsideOpaqueBlock = "";
    String getMountedYOffset = "";
    
    String entityName = "";
    
    if (obfuscated) {
      isEntityInsideOpaqueBlock = "func_70094_T";
      getMountedYOffset = "func_70042_X";
      
      entityName = "Lnet/minecraft/entity/Entity;";
    } else {
      isEntityInsideOpaqueBlock = "isEntityInsideOpaqueBlock";
      getMountedYOffset = "getMountedYOffset";
      
      entityName = "Lnet/minecraft/entity/Entity;";
    }
    
    ClassNode classNode = new ClassNode();
    ClassReader classReader = new ClassReader(bytes);
    classReader.accept(classNode, 0);
    
    java.util.List<MethodNode> methods = methods;
    
    for (MethodNode m : methods) {
      if (name.equals(isEntityInsideOpaqueBlock)) {
        System.out.println("Found method " + name + "." + name + "" + desc);
        InsnList code = instructions;
        MethodInsnNode method = new MethodInsnNode(184, "lilliputian/util/EntitySizeUtil", "getEntityScale", "(" + entityName + ")F", false);
        

        code.insert(code.get(36), new org.objectweb.asm.tree.VarInsnNode(25, 0));
        code.insert(code.get(37), method);
        code.insert(code.get(38), new org.objectweb.asm.tree.InsnNode(106));
      }
    }
    
    ClassWriter writer = new ClassWriter(1);
    classNode.accept(writer);
    
    return writer.toByteArray();
  }
  
  public byte[] patchEntityLivingBaseASM(String name, byte[] bytes, boolean obfuscated) {
    String isOnLadder = "";
    
    String entityName = "";
    
    if (obfuscated) {
      isOnLadder = "func_70617_f_";
      
      entityName = "Lnet/minecraft/entity/Entity;";
    } else {
      isOnLadder = "isOnLadder";
      
      entityName = "Lnet/minecraft/entity/Entity;";
    }
    
    ClassNode classNode = new ClassNode();
    ClassReader classReader = new ClassReader(bytes);
    classReader.accept(classNode, 0);
    
    java.util.List<MethodNode> methods = methods;
    
    for (MethodNode m : methods) {
      if (name.equals(isOnLadder)) {
        System.out.println("Found method " + name + "." + name + "" + desc);
        InsnList code = instructions;
        MethodInsnNode method = new MethodInsnNode(184, "lilliputian/util/EntitySizeUtil", "isOnLadder", "(" + entityName + ")Z", false);
        

        code.insertBefore(code.get(67), new org.objectweb.asm.tree.VarInsnNode(25, 0));
        code.insertBefore(code.get(68), method);
        code.insertBefore(code.get(69), new org.objectweb.asm.tree.InsnNode(128));
      }
    }
    
    ClassWriter writer = new ClassWriter(1);
    classNode.accept(writer);
    
    return writer.toByteArray();
  }
  
  @net.minecraftforge.fml.relauncher.SideOnly(net.minecraftforge.fml.relauncher.Side.CLIENT)
  public byte[] patchPlayerControllerMPASM(String name, byte[] bytes, boolean obfuscated) {
    String getBlockReachDistance = "";
    
    String mc = "";
    String player = "";
    
    String entityName = "";
    String minecraftName = "";
    String playerName = "";
    
    if (obfuscated) {
      getBlockReachDistance = "func_78757_d";
      
      mc = "field_78776_a";
      player = "field_71439_g";
      
      entityName = "Lnet/minecraft/entity/Entity;";
      minecraftName = "Lnet/minecraft/client/Minecraft;";
      playerName = "Lnet/minecraft/client/entity/EntityPlayerSP;";
    } else {
      getBlockReachDistance = "getBlockReachDistance";
      
      mc = "mc";
      player = "player";
      
      entityName = "Lnet/minecraft/entity/Entity;";
      minecraftName = "Lnet/minecraft/client/Minecraft;";
      playerName = "Lnet/minecraft/client/entity/EntityPlayerSP;";
    }
    
    ClassNode classNode = new ClassNode();
    ClassReader classReader = new ClassReader(bytes);
    classReader.accept(classNode, 0);
    
    java.util.List<MethodNode> methods = methods;
    
    for (MethodNode m : methods) {
      if (name.equals(getBlockReachDistance)) {
        System.out.println("Found method " + name + "." + name + "" + desc);
        InsnList code = instructions;
        MethodInsnNode method = new MethodInsnNode(184, "lilliputian/util/EntitySizeUtil", "getEntityScaleRoot", "(" + entityName + ")F", false);
        





        code.insertBefore(code.get(13), new org.objectweb.asm.tree.VarInsnNode(25, 0));
        code.insertBefore(code.get(14), new org.objectweb.asm.tree.FieldInsnNode(180, "net/minecraft/client/multiplayer/PlayerControllerMP", mc, minecraftName));
        code.insertBefore(code.get(15), new org.objectweb.asm.tree.FieldInsnNode(180, "net/minecraft/client/Minecraft", player, playerName));
        code.insertBefore(code.get(16), method);
        code.insertBefore(code.get(17), new org.objectweb.asm.tree.InsnNode(106));
      }
    }
    
    ClassWriter writer = new ClassWriter(1);
    classNode.accept(writer);
    
    return writer.toByteArray();
  }
  
  public byte[] patchPlayerInteractionManagerASM(String name, byte[] bytes, boolean obfuscated) {
    String getBlockReachDistance = "";
    
    String player = "";
    
    String entityName = "";
    String playerName = "";
    
    if (obfuscated) {
      getBlockReachDistance = "getBlockReachDistance";
      
      player = "field_73090_b";
      
      entityName = "Lnet/minecraft/entity/Entity;";
      playerName = "Lnet/minecraft/entity/player/EntityPlayerMP;";
    } else {
      getBlockReachDistance = "getBlockReachDistance";
      
      player = "player";
      
      entityName = "Lnet/minecraft/entity/Entity;";
      playerName = "Lnet/minecraft/entity/player/EntityPlayerMP;";
    }
    
    ClassNode classNode = new ClassNode();
    ClassReader classReader = new ClassReader(bytes);
    classReader.accept(classNode, 0);
    
    java.util.List<MethodNode> methods = methods;
    
    for (MethodNode m : methods) {
      if (name.equals(getBlockReachDistance)) {
        System.out.println("Found method " + name + "." + name + "" + desc);
        InsnList code = instructions;
        MethodInsnNode method = new MethodInsnNode(184, "lilliputian/util/EntitySizeUtil", "getEntityScaleRootDouble", "(" + entityName + ")D", false);
        





        code.insertBefore(code.get(4), new org.objectweb.asm.tree.VarInsnNode(25, 0));
        code.insertBefore(code.get(5), new org.objectweb.asm.tree.FieldInsnNode(180, "net/minecraft/server/management/PlayerInteractionManager", player, playerName));
        code.insertBefore(code.get(6), method);
        code.insertBefore(code.get(7), new org.objectweb.asm.tree.InsnNode(107));
      }
    }
    
    ClassWriter writer = new ClassWriter(1);
    classNode.accept(writer);
    
    return writer.toByteArray();
  }
  
  public byte[] patchGenericEntityASM(String name, byte[] bytes, boolean obfuscated) {
    String getEyeHeight = "";
    String getMountedYOffset = "";
    String getYOffset = "";
    
    String height = "";
    
    String entityName = "";
    
    if (obfuscated) {
      getEyeHeight = "func_70047_e";
      getMountedYOffset = "func_70042_X";
      getYOffset = "func_70033_W";
      
      height = "field_70131_O";
      
      entityName = "Lnet/minecraft/entity/Entity;";
    } else {
      getEyeHeight = "getEyeHeight";
      getMountedYOffset = "getMountedYOffset";
      getYOffset = "getYOffset";
      
      height = "height";
      
      entityName = "Lnet/minecraft/entity/Entity;";
    }
    
    ClassNode classNode = new ClassNode();
    ClassReader classReader = new ClassReader(bytes);
    classReader.accept(classNode, 0);
    
    java.util.List<MethodNode> methods = methods;
    
    for (MethodNode m : methods) {
      if (name.equals(getEyeHeight)) {
        System.out.println("Found method " + name + "." + name + "" + desc);
        InsnList code = instructions;
        MethodInsnNode method = new MethodInsnNode(184, "lilliputian/util/EntitySizeUtil", "getEntityScale", "(" + entityName + ")F", false);
        
        boolean referencesHeight = false;
        for (int i = 0; i < code.size(); i++) {
          if ((code.get(i) instanceof org.objectweb.asm.tree.FieldInsnNode)) {
            org.objectweb.asm.tree.FieldInsnNode fin = (org.objectweb.asm.tree.FieldInsnNode)code.get(i);
            if ((fin.getOpcode() == 180) && (desc.equals("F")) && (name.equals(height))) {
              referencesHeight = true;
              break;
            }
          }
        }
        if (!referencesHeight) {
          for (int i = code.size() - 1; i >= 0; i--) {
            if (code.get(i).getOpcode() == 174) {
              code.insertBefore(code.get(i), new org.objectweb.asm.tree.VarInsnNode(25, 0));
              code.insertBefore(code.get(i + 1), method);
              code.insertBefore(code.get(i + 2), new org.objectweb.asm.tree.InsnNode(106));
            }
          }
        }
      } else if (name.equals(getYOffset)) {
        System.out.println("Found method " + name + "." + name + "" + desc);
        InsnList code = instructions;
        MethodInsnNode method = new MethodInsnNode(184, "lilliputian/util/EntitySizeUtil", "getEntityYOffset", "(D" + entityName + ")D", false);
        

        for (int i = code.size() - 1; i > 0; i--) {
          if (code.get(i).getOpcode() == 175) {
            code.insertBefore(code.get(i), new org.objectweb.asm.tree.VarInsnNode(25, 0));
            code.insertBefore(code.get(i + 1), method);
          }
        }
      }
    }
    
    ClassWriter writer = new ClassWriter(1);
    classNode.accept(writer);
    
    return writer.toByteArray();
  }
  
  public byte[] patchBlockCactusASM(String name, byte[] bytes, boolean obfuscated) {
    String onEntityCollidedWithBlock = "";
    
    String entityName = "";
    
    if (obfuscated) {
      onEntityCollidedWithBlock = "func_180634_a";
      
      entityName = "Lnet/minecraft/entity/Entity;";
    } else {
      onEntityCollidedWithBlock = "onEntityCollidedWithBlock";
      
      entityName = "Lnet/minecraft/entity/Entity;";
    }
    
    ClassNode classNode = new ClassNode();
    ClassReader classReader = new ClassReader(bytes);
    classReader.accept(classNode, 0);
    
    java.util.List<MethodNode> methods = methods;
    
    for (MethodNode m : methods) {
      if (name.equals(onEntityCollidedWithBlock)) {
        System.out.println("Found method " + name + "." + name + "" + desc);
        InsnList code = instructions;
        MethodInsnNode method = new MethodInsnNode(184, "lilliputian/util/EntitySizeUtil", "attemptCactusDamage", "(" + entityName + ")V", false);
        





        code.remove(code.get(6));
        code.set(code.get(5), method);
        code.remove(code.get(4));
        code.remove(code.get(3));
      }
    }
    
    ClassWriter writer = new ClassWriter(1);
    classNode.accept(writer);
    
    return writer.toByteArray();
  }
  
  @net.minecraftforge.fml.relauncher.SideOnly(net.minecraftforge.fml.relauncher.Side.CLIENT)
  public byte[] patchInventoryRenderASM(String name, byte[] bytes, boolean obfuscated) {
    ClassNode classNode = new ClassNode();
    ClassReader classReader = new ClassReader(bytes);
    classReader.accept(classNode, 0);
    
    java.util.List<MethodNode> methods = methods;
    for (MethodNode m : methods) {
      if ((name.equals("drawEntityOnScreen")) || (name.equals("func_147046_a"))) {
        org.objectweb.asm.tree.VarInsnNode iload0 = new org.objectweb.asm.tree.VarInsnNode(21, 0);
        org.objectweb.asm.tree.VarInsnNode iload1 = new org.objectweb.asm.tree.VarInsnNode(21, 1);
        org.objectweb.asm.tree.VarInsnNode iload2 = new org.objectweb.asm.tree.VarInsnNode(21, 2);
        MethodInsnNode method = new MethodInsnNode(184, "lilliputian/util/EntitySizeUtil", "doRenderEntity", "(Lnet/minecraft/entity/Entity;IIIFFZ)V", false);
        
        System.out.println("Found method " + name + "." + name + "" + desc);
        InsnList code = instructions;
        code.set(code.get(162), iload0);
        code.set(code.get(163), iload1);
        code.set(code.get(164), iload2);
        code.set(code.get(168), method);
      }
    }
    
    ClassWriter writer = new ClassWriter(1);
    classNode.accept(writer);
    
    return writer.toByteArray();
  }
}
