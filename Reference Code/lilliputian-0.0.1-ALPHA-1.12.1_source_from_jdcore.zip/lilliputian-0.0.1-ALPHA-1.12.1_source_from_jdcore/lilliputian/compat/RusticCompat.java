package lilliputian.compat;

import java.util.List;
import lilliputian.potions.PotionLilliputian;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionEffect;
import rustic.common.crafting.Recipes;

public class RusticCompat
{
  public RusticCompat() {}
  
  public static void initElixirs()
  {
    Recipes.condenserRecipes.add(new rustic.common.crafting.BasicCondenserRecipe(new PotionEffect(PotionLilliputian.SHRINKING_POTION, 3600, 0), new ItemStack(net.minecraft.init.Blocks.field_150338_P), new ItemStack(Items.field_151009_A)));
    Recipes.condenserRecipes.add(new rustic.common.crafting.AdvancedCondenserRecipe(new PotionEffect(PotionLilliputian.SHRINKING_POTION, 9600, 0), new ItemStack(rustic.common.blocks.crops.Herbs.HORSETAIL), new ItemStack[] { new ItemStack(net.minecraft.init.Blocks.field_150338_P), new ItemStack(Items.field_151009_A) }));
    Recipes.condenserRecipes.add(new rustic.common.crafting.AdvancedCondenserRecipe(new PotionEffect(PotionLilliputian.SHRINKING_POTION, 1800, 1), new ItemStack(rustic.common.blocks.crops.Herbs.MARSH_MALLOW), new ItemStack[] { new ItemStack(net.minecraft.init.Blocks.field_150338_P), new ItemStack(Items.field_151009_A) }));
    
    Recipes.condenserRecipes.add(new rustic.common.crafting.BasicCondenserRecipe(new PotionEffect(PotionLilliputian.GROWING_POTION, 3600, 0), new ItemStack(net.minecraft.init.Blocks.field_150337_Q), new ItemStack(Items.field_151105_aU)));
    Recipes.condenserRecipes.add(new rustic.common.crafting.AdvancedCondenserRecipe(new PotionEffect(PotionLilliputian.GROWING_POTION, 9600, 0), new ItemStack(rustic.common.blocks.crops.Herbs.HORSETAIL), new ItemStack[] { new ItemStack(net.minecraft.init.Blocks.field_150337_Q), new ItemStack(Items.field_151105_aU) }));
    Recipes.condenserRecipes.add(new rustic.common.crafting.AdvancedCondenserRecipe(new PotionEffect(PotionLilliputian.GROWING_POTION, 1800, 1), new ItemStack(rustic.common.blocks.crops.Herbs.MARSH_MALLOW), new ItemStack[] { new ItemStack(net.minecraft.init.Blocks.field_150337_Q), new ItemStack(Items.field_151105_aU) }));
  }
}
