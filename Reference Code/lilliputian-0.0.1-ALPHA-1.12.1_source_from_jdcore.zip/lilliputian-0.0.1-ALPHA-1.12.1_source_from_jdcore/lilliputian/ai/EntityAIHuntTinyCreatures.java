package lilliputian.ai;

import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.player.EntityPlayer;

public class EntityAIHuntTinyCreatures extends EntityAINearestAttackableTarget
{
  public EntityAIHuntTinyCreatures(EntityCreature creature)
  {
    super(creature, EntityLivingBase.class, false);
  }
  
  public boolean func_75250_a()
  {
    if ((super.func_75250_a()) && 
      (field_75309_a != null)) {
      return (field_75309_a.field_70130_N < field_75299_d.field_70130_N) && (lilliputian.util.EntitySizeUtil.getEntityScale(field_75309_a) <= 0.33333F) && (((field_75309_a instanceof EntityPlayer)) || ((field_75309_a instanceof EntityCreature)));
    }
    
    return false;
  }
}
