package lilliputian;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.common.config.Configuration;
import net.minecraftforge.fml.common.registry.EntityEntry;
import net.minecraftforge.fml.common.registry.ForgeRegistries;
import net.minecraftforge.registries.IForgeRegistry;




public class Config
{
  private static final String CATEGORY_GENERAL = "all.general";
  private static final List<String> PROPERTY_ORDER_GENERAL = new ArrayList();
  
  private static List<String> resizingBlacklistStrings;
  public static final List<Class> RESIZING_BLACKLIST = new ArrayList();
  private static List<String> entityBaseSizeStrings;
  public static final Map<Class, BaseSizeRange> ENTITY_BASESIZES = new HashMap();
  public static BaseSizeRange PLAYER_BASESIZE;
  
  public Config() {}
  
  /* Error */
  public static void readConfig()
  {
    // Byte code:
    //   0: getstatic 41	lilliputian/Lilliputian:config	Lnet/minecraftforge/common/config/Configuration;
    //   3: astore_0
    //   4: aload_0
    //   5: invokevirtual 46	net/minecraftforge/common/config/Configuration:load	()V
    //   8: aload_0
    //   9: invokestatic 50	lilliputian/Config:initGeneralConfig	(Lnet/minecraftforge/common/config/Configuration;)V
    //   12: aload_0
    //   13: invokevirtual 54	net/minecraftforge/common/config/Configuration:hasChanged	()Z
    //   16: ifeq +39 -> 55
    //   19: aload_0
    //   20: invokevirtual 57	net/minecraftforge/common/config/Configuration:save	()V
    //   23: goto +32 -> 55
    //   26: astore_1
    //   27: aload_0
    //   28: invokevirtual 54	net/minecraftforge/common/config/Configuration:hasChanged	()Z
    //   31: ifeq +24 -> 55
    //   34: aload_0
    //   35: invokevirtual 57	net/minecraftforge/common/config/Configuration:save	()V
    //   38: goto +17 -> 55
    //   41: astore_2
    //   42: aload_0
    //   43: invokevirtual 54	net/minecraftforge/common/config/Configuration:hasChanged	()Z
    //   46: ifeq +7 -> 53
    //   49: aload_0
    //   50: invokevirtual 57	net/minecraftforge/common/config/Configuration:save	()V
    //   53: aload_2
    //   54: athrow
    //   55: return
    // Line number table:
    //   Java source line #31	-> byte code offset #0
    //   Java source line #33	-> byte code offset #4
    //   Java source line #34	-> byte code offset #8
    //   Java source line #38	-> byte code offset #12
    //   Java source line #39	-> byte code offset #19
    //   Java source line #35	-> byte code offset #26
    //   Java source line #38	-> byte code offset #27
    //   Java source line #39	-> byte code offset #34
    //   Java source line #38	-> byte code offset #41
    //   Java source line #39	-> byte code offset #49
    //   Java source line #42	-> byte code offset #55
    // Local variable table:
    //   start	length	slot	name	signature
    //   3	47	0	cfg	Configuration
    //   26	1	1	localException	Exception
    //   41	13	2	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   4	12	26	java/lang/Exception
    //   4	12	41	finally
  }
  
  private static void initGeneralConfig(Configuration cfg)
  {
    cfg.addCustomCategoryComment("all.general", "General Options");
    
    resizingBlacklistStrings = Arrays.asList(cfg.getStringList("Entity Resizing Blacklist", "all.general", new String[] { "minecraft:giant", "minecraft:elder_guardian", "minecraft:shulker" }, "Entities on this list will not be resizeable. If you load a world with previously resized entities after blacklisting them, they will return to normal size."));
    entityBaseSizeStrings = Arrays.asList(cfg.getStringList("Entity Base Sizes", "all.general", new String[0], "The entries of this list will be parsed and used to determine the base size of newly spawned mobs. You can give a single value per entity, or give an entity a range from which a random base size will be selected.\nformat: <entity name>|<basesize> OR <entity name>|<min>-<max>"));
    String playerBaseSizeRangeString = cfg.getString("Player Base Size", "all.general", "1", "This string will be used to determine the base size of players when they spawn in a world. You can give a single value, or a range from which a random base size will be selected.\nformat: <basesize> OR <min>-<max>");
    PLAYER_BASESIZE = new BaseSizeRange(playerBaseSizeRangeString, null);
    
    PROPERTY_ORDER_GENERAL.add("Entity Resizing Blacklist");
    PROPERTY_ORDER_GENERAL.add("Player Base Size");
    PROPERTY_ORDER_GENERAL.add("Entity Base Sizes");
    
    cfg.setCategoryPropertyOrder("all.general", PROPERTY_ORDER_GENERAL);
  }
  
  public static void postInit() {
    for (String entityName : resizingBlacklistStrings) {
      ResourceLocation key = new ResourceLocation(entityName);
      if (ForgeRegistries.ENTITIES.containsKey(key)) {
        EntityEntry e = (EntityEntry)ForgeRegistries.ENTITIES.getValue(key);
        RESIZING_BLACKLIST.add(e.getEntityClass());
      }
    }
    
    for (String listEntry : entityBaseSizeStrings) {
      int separator = listEntry.indexOf("|");
      if (separator >= 1)
      {

        ResourceLocation key = new ResourceLocation(listEntry.substring(0, separator));
        if (ForgeRegistries.ENTITIES.containsKey(key)) {
          EntityEntry e = (EntityEntry)ForgeRegistries.ENTITIES.getValue(key);
          ENTITY_BASESIZES.put(e.getEntityClass(), new BaseSizeRange(listEntry.substring(separator + 1), null));
        }
      }
    }
  }
  
  public static class BaseSizeRange {
    float min;
    float max;
    
    private BaseSizeRange(String configEntry) { int separator = configEntry.indexOf("-");
      if (separator > 0) {
        String minString = configEntry.substring(0, separator);
        String maxString = configEntry.substring(separator + 1);
        
        min = Math.max(Float.parseFloat(minString), 0.125F);
        max = Math.min(Float.parseFloat(maxString), 8.0F);
      } else {
        min = (this.max = MathHelper.func_76131_a(Float.parseFloat(configEntry), 0.125F, 8.0F));
      }
    }
    
    private BaseSizeRange(float min, float max) {
      this.min = Math.max(min, 0.125F);
      this.max = Math.min(max, 8.0F);
    }
    
    public float randomBaseSize(Random rand) {
      if (min == max) {
        return min;
      }
      return rand.nextFloat() * (max - min) + min;
    }
  }
}
