package lilliputian.handlers;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import lilliputian.Config;
import lilliputian.Config.BaseSizeRange;
import lilliputian.ai.EntityAIHuntTinyCreatures;
import lilliputian.ai.EntityAINewOcelotFear;
import lilliputian.capabilities.DefaultSizeCapability;
import lilliputian.capabilities.ISizeCapability;
import lilliputian.capabilities.SizeProvider;
import lilliputian.network.MessageSizeChange;
import lilliputian.network.PacketHandler;
import lilliputian.potions.PotionLilliputian;
import lilliputian.util.EntitySizeUtil;
import net.minecraft.block.Block;
import net.minecraft.block.BlockDoublePlant;
import net.minecraft.block.BlockDoublePlant.EnumBlockHalf;
import net.minecraft.block.BlockDoublePlant.EnumPlantType;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.entity.ai.EntityAITasks;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.ai.attributes.IAttributeInstance;
import net.minecraft.entity.passive.EntityOcelot;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayer.SleepResult;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.NonNullList;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.Tuple;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.world.World;
import net.minecraftforge.client.event.PlayerSPPushOutOfBlocksEvent;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraftforge.event.entity.EntityMountEvent;
import net.minecraftforge.event.entity.PlaySoundAtEntityEvent;
import net.minecraftforge.event.entity.living.LivingEvent.LivingJumpEvent;
import net.minecraftforge.event.entity.living.LivingEvent.LivingUpdateEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerEvent.BreakSpeed;
import net.minecraftforge.event.entity.player.PlayerEvent.Clone;
import net.minecraftforge.event.entity.player.PlayerInteractEvent.EntityInteract;
import net.minecraftforge.event.entity.player.PlayerSleepInBedEvent;
import net.minecraftforge.event.world.WorldEvent.Unload;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import net.minecraftforge.fml.relauncher.ReflectionHelper;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;











@Mod.EventBusSubscriber(modid="lilliputian")
public class EntitySizeHandler
{
  public EntitySizeHandler() {}
  
  private static final Map<Entity, Tuple<Float, Float>> entitySizeCache = new HashMap();
  private static final List<EntityPlayer> initializedPlayers = new ArrayList();
  
  private static final Map<Entity, Integer> shrinkingAmps = new HashMap();
  private static final Map<Entity, Integer> growingAmps = new HashMap();
  
  public static final float defaultWidth = 0.6F;
  public static final float defaultHeight = 1.8F;
  
  public static final AttributeModifier SPEED_MODIFIER = new AttributeModifier(
    UUID.fromString("1E7E2380-2E87-45B6-A90C-869563A27FA3"), "size_speed_mod", 0.0D, 1);
  public static final AttributeModifier ATTACK_SPEED_MODIFIER = new AttributeModifier(
    UUID.fromString("174DEEAF-A876-4666-BFEB-709960E09021"), "size_attack_speed_mod", 0.0D, 1);
  
  @SubscribeEvent
  public static void onAddCapabilites(AttachCapabilitiesEvent event) {
    if (((event.getObject() instanceof EntityPlayer)) || ((event.getObject() instanceof EntityLivingBase))) {
      for (Class entityClass : Config.RESIZING_BLACKLIST) {
        if (entityClass == event.getObject().getClass()) {
          return;
        }
      }
      EntityLivingBase entity = (EntityLivingBase)event.getObject();
      if ((entity.func_184222_aU()) && (!entity.hasCapability(SizeProvider.sizeCapability, null))) {
        float baseSize = 1.0F;
        if (Config.ENTITY_BASESIZES.containsKey(entity.getClass())) {
          baseSize = ((Config.BaseSizeRange)Config.ENTITY_BASESIZES.get(entity.getClass())).randomBaseSize(entity.func_70681_au());
        }
        if ((entity instanceof EntityPlayer)) {
          baseSize = Config.PLAYER_BASESIZE.randomBaseSize(entity.func_70681_au());
        }
        ISizeCapability cap = new DefaultSizeCapability(baseSize);
        event.addCapability(new ResourceLocation("lilliputian", "size"), new SizeProvider(cap));
      }
    }
  }
  
  @SubscribeEvent
  public static void onLivingUpdate(LivingEvent.LivingUpdateEvent event) {
    if (event.getEntityLiving() != null) {
      EntityLivingBase entity = event.getEntityLiving();
      if (entity.hasCapability(SizeProvider.sizeCapability, null)) {
        ISizeCapability size = (ISizeCapability)entity.getCapability(SizeProvider.sizeCapability, null);
        
        if (!field_70170_p.field_72995_K) {
          if ((((entity instanceof EntityPlayer)) && (!initializedPlayers.contains(entity))) || ((!(entity instanceof EntityPlayer)) && 
            (!entitySizeCache.containsKey(entity)))) {
            PacketHandler.INSTANCE.sendToAll(new MessageSizeChange(size.getBaseSize(), size.getScale(), entity
              .func_145782_y(), false));
          } else if (field_70173_aa % 40 == 0) {
            PacketHandler.INSTANCE.sendToAll(new MessageSizeChange(size
              .getBaseSize(), size.getScale(), entity.func_145782_y()));
          }
          updateSizePotionEffects(entity, size);
        }
        
        if ((size.getMorphTime() > 0) && (size.getMaxMorphTime() > 0)) {
          if (size.getActualScaleNoClamp() != size.getScale()) {
            int t = size.getMorphTime();
            size.incrementMorphTime();
            int m = size.getMaxMorphTime();
            float d = (size.getScale() - size.getActualScale()) / t;
            
            size.setActualScale(size.getActualScale() + d / 1.0F);
          }
        } else if (size.getActualScaleNoClamp() != size.getScale()) {
          size.setActualScale(size.getScale());
        }
        
        if (!(entity instanceof EntityPlayer)) {
          if (!entitySizeCache.containsKey(entity)) {
            entitySizeCache.put(entity, new Tuple(Float.valueOf(field_70130_N), Float.valueOf(field_70131_O)));
          }
          Tuple<Float, Float> dims = (Tuple)entitySizeCache.get(entity);
          float width = ((Float)dims.func_76341_a()).floatValue() * size.getActualSize();
          float height = ((Float)dims.func_76340_b()).floatValue() * size.getActualSize();
          setEntitySize(entity, width, height);
        } else {
          if (!initializedPlayers.contains(entity)) {
            initializedPlayers.add((EntityPlayer)entity);
          }
          if (entity.func_184187_bx() != null) {
            setEntitySize(entity, 0.6F * size.getActualSize(), 1.8F * size.getActualSize());
            
            Entity mount = entity.func_184187_bx();
            if (EntitySizeUtil.getEntityScale(mount) < size.getActualSize()) {
              entity.func_184210_p();
            }
          }
        }
        
        if (entity.func_110148_a(SharedMonsterAttributes.field_111263_d) != null)
        {
          IAttributeInstance speedAttribute = entity.func_110148_a(SharedMonsterAttributes.field_111263_d);
          double speedMod = Math.pow(size.getActualSize(), 0.25D) - 1.0D;
          speedAttribute.func_188479_b(SPEED_MODIFIER.func_111167_a());
          speedAttribute.func_111121_a(new AttributeModifier(SPEED_MODIFIER.func_111167_a(), SPEED_MODIFIER.func_111166_b(), speedMod, SPEED_MODIFIER
            .func_111169_c()).func_111168_a(false));
        }
        if (entity.func_110148_a(SharedMonsterAttributes.field_188790_f) != null) {
          IAttributeInstance speedAttribute = entity.func_110148_a(SharedMonsterAttributes.field_188790_f);
          double speedMod = Math.pow(size.getActualSize(), -0.25D) - 1.0D;
          speedAttribute.func_188479_b(ATTACK_SPEED_MODIFIER.func_111167_a());
          speedAttribute.func_111121_a(new AttributeModifier(ATTACK_SPEED_MODIFIER
            .func_111167_a(), ATTACK_SPEED_MODIFIER.func_111166_b(), speedMod, ATTACK_SPEED_MODIFIER
            .func_111169_c()).func_111168_a(false));
        }
        
        if ((entity instanceof EntityPlayer)) {
          float actualSize = size.getActualSize();
          field_70138_W = (actualSize > 1.0F ? actualSize * 0.6F : actualSize < 0.6F ? actualSize : 0.6F);
        }
        
        if ((entity.func_184613_cA()) && (field_70125_A > 45.0F) && (field_70125_A < 10.0F) && 
          (size.getActualSize() <= 0.33333F)) {
          field_70181_x += 0.10000000149011612D;
        }
        
        if ((!field_70170_p.field_72995_K) && ((size.getActualSize() <= 0.33333F) || 
          (size.getActualSize() >= 3.0F)) && 
          ((entity.func_184193_aE() instanceof NonNullList))) {
          NonNullList<ItemStack> armorInv = (NonNullList)entity.func_184193_aE();
          for (int i = 0; i < armorInv.size(); i++) {
            if (!((ItemStack)armorInv.get(i)).func_190926_b()) {
              entity.func_70099_a(((ItemStack)armorInv.get(i)).func_77946_l(), field_70131_O * 0.125F + field_70131_O * 0.25F);
              
              armorInv.set(i, ItemStack.field_190927_a);
            }
          }
        }
        

        if (size.getActualSize() <= 0.33333F) {
          AxisAlignedBB aabb = entity.func_174813_aQ();
          if (aabb != null) {
            int minX = MathHelper.func_76128_c(field_72340_a);
            int maxX = MathHelper.func_76143_f(field_72336_d);
            int minY = MathHelper.func_76128_c(field_72338_b);
            int maxY = MathHelper.func_76143_f(field_72337_e);
            int minZ = MathHelper.func_76128_c(field_72339_c);
            int maxZ = MathHelper.func_76143_f(field_72334_f);
            
            for (int x = minX; x < maxX; x++) {
              for (int y = minY; (y < maxY) && (y >= 0) && (y < 256); y++) {
                for (int z = minZ; z < maxZ; z++) {
                  BlockPos pos = new BlockPos(x, y, z);
                  IBlockState state = field_70170_p.func_180495_p(pos);
                  if (state.func_177230_c() == Blocks.field_150398_cm)
                    if (state.func_177229_b(BlockDoublePlant.field_176493_a) != BlockDoublePlant.EnumPlantType.ROSE) {
                      if ((state.func_177229_b(BlockDoublePlant.field_176492_b) == BlockDoublePlant.EnumBlockHalf.UPPER) && (y > 0))
                      {

                        if ((field_70170_p.func_180495_p(pos.func_177977_b()).func_177230_c() != Blocks.field_150398_cm) || 
                          (field_70170_p.func_180495_p(pos.func_177977_b()).func_177229_b(BlockDoublePlant.field_176493_a) != BlockDoublePlant.EnumPlantType.ROSE)) {} }
                    } else {
                      entity.func_70097_a(new DamageSource("rose"), 1.0F);
                      break;
                    }
                }
              }
            }
          }
        }
      }
    }
  }
  
  @SubscribeEvent
  public static void playerJoinWorld(EntityJoinWorldEvent event) {
    if ((getEntityfield_70170_p != null) && (!getEntityfield_70170_p.field_72995_K) && 
      (event.getEntity().hasCapability(SizeProvider.sizeCapability, null))) {
      ISizeCapability size = (ISizeCapability)event.getEntity().getCapability(SizeProvider.sizeCapability, null);
      PacketHandler.INSTANCE.sendToAll(new MessageSizeChange(size
        .getBaseSize(), size.getScale(), event.getEntity().func_145782_y(), false));
    }
  }
  
  @SubscribeEvent
  public static void ocelotInit(EntityJoinWorldEvent event) {
    if ((event.getEntity() instanceof EntityOcelot)) {
      EntityOcelot ocelot = (EntityOcelot)event.getEntity();
      Field avoidAiField = ReflectionHelper.findField(EntityOcelot.class, new String[] { "avoidEntity", "field_175545_bm" });
      
      try
      {
        field_70714_bg.func_85156_a((EntityAIBase)avoidAiField.get(ocelot));
      } catch (IllegalArgumentException e) {
        e.printStackTrace();
      } catch (IllegalAccessException e) {
        e.printStackTrace();
      }
      
      field_70714_bg.func_75776_a(4, new EntityAINewOcelotFear(ocelot, EntityPlayer.class, 16.0F, 0.8D, 1.33D));
      field_70715_bh.func_75776_a(2, new EntityAIHuntTinyCreatures(ocelot));
    }
  }
  
  @SubscribeEvent
  public static void worldUnload(WorldEvent.Unload event) {
    Iterator<Entity> eIter = entitySizeCache.keySet().iterator();
    while (eIter.hasNext()) {
      Entity e = (Entity)eIter.next();
      if ((e == null) || (field_70170_p.equals(event.getWorld()))) {
        eIter.remove();
      }
    }
    
    Iterator<EntityPlayer> pIter = initializedPlayers.iterator();
    while (pIter.hasNext()) {
      EntityPlayer p = (EntityPlayer)pIter.next();
      if ((p == null) || (field_70170_p.equals(event.getWorld()))) {
        pIter.remove();
      }
    }
    
    Iterator<Entity> sIter = shrinkingAmps.keySet().iterator();
    while (sIter.hasNext()) {
      Entity e = (Entity)sIter.next();
      if ((e == null) || (field_70170_p.equals(event.getWorld()))) {
        sIter.remove();
      }
    }
    Iterator<Entity> gIter = growingAmps.keySet().iterator();
    while (gIter.hasNext()) {
      Entity e = (Entity)gIter.next();
      if ((e == null) || (field_70170_p.equals(event.getWorld()))) {
        gIter.remove();
      }
    }
  }
  
  @SubscribeEvent
  public static void playerClone(PlayerEvent.Clone event) {
    if ((event.isWasDeath()) && (event.getOriginal().hasCapability(SizeProvider.sizeCapability, null)) && 
      (event.getEntityPlayer().hasCapability(SizeProvider.sizeCapability, null))) {
      ISizeCapability originalSize = (ISizeCapability)event.getOriginal().getCapability(SizeProvider.sizeCapability, null);
      ISizeCapability size = (ISizeCapability)event.getEntityPlayer().getCapability(SizeProvider.sizeCapability, null);
      
      size.setBaseSize(originalSize.getBaseSize());
      initializedPlayers.remove(event.getOriginal());
      initializedPlayers.remove(event.getEntityPlayer());
    }
  }
  
  @SubscribeEvent
  public static void onEntityJump(LivingEvent.LivingJumpEvent event) {
    if ((!event.getEntityLiving().func_70093_af()) && (EntitySizeUtil.getEntityScale(event.getEntityLiving()) > 1.0F)) {
      EntityLivingBase tmp26_23 = event.getEntityLiving();
      2623field_70181_x = (2623field_70181_x * MathHelper.func_76129_c(Math.max(EntitySizeUtil.getEntityScale(event.getEntityLiving()), 1.0F)));
      getEntityLivingfield_70133_I = true;
    }
  }
  
  @SubscribeEvent
  public static void breakSpeed(PlayerEvent.BreakSpeed event) {
    event.setNewSpeed(event
      .getNewSpeed() * MathHelper.func_76129_c(EntitySizeUtil.getEntityScale(event.getEntityPlayer())));
  }
  
  @SubscribeEvent
  @SideOnly(Side.CLIENT)
  public static void pushOutOfBlock(PlayerSPPushOutOfBlocksEvent event) {
    if (EntitySizeUtil.getEntityScale(event.getEntityPlayer()) < 1.0F) {
      event.setCanceled(true);
      EntityPlayer player = event.getEntityPlayer();
      AxisAlignedBB axisalignedbb = event.getEntityBoundingBox();
      
      pushPlayerSPOutOfBlocks(player, field_70165_t - field_70130_N * 0.35D, field_72338_b + Math.max(0.125D, 0.5D * EntitySizeUtil.getEntityScaleDoubleMin1(player)), field_70161_v + field_70130_N * 0.35D);
      pushPlayerSPOutOfBlocks(player, field_70165_t - field_70130_N * 0.35D, field_72338_b + Math.max(0.125D, 0.5D * EntitySizeUtil.getEntityScaleDoubleMin1(player)), field_70161_v - field_70130_N * 0.35D);
      pushPlayerSPOutOfBlocks(player, field_70165_t + field_70130_N * 0.35D, field_72338_b + Math.max(0.125D, 0.5D * EntitySizeUtil.getEntityScaleDoubleMin1(player)), field_70161_v - field_70130_N * 0.35D);
      pushPlayerSPOutOfBlocks(player, field_70165_t + field_70130_N * 0.35D, field_72338_b + Math.max(0.125D, 0.5D * EntitySizeUtil.getEntityScaleDoubleMin1(player)), field_70161_v + field_70130_N * 0.35D);
    }
  }
  






  @SubscribeEvent
  public static void trySleep(PlayerSleepInBedEvent event)
  {
    if ((event.getEntityPlayer() != null) && 
      (EntitySizeUtil.getEntityScale(event.getEntityPlayer()) > 1.25F)) {
      event.setResult(EntityPlayer.SleepResult.OTHER_PROBLEM);
      event.getEntityPlayer().func_146105_b(new TextComponentTranslation("tile.bed.tooBig", new Object[0]), true);
    }
  }
  
  @SubscribeEvent
  public static void onEntityHurt(LivingHurtEvent event)
  {
    EntityLivingBase entity = event.getEntityLiving();
    float size = EntitySizeUtil.getEntityScale(entity);
    
    if (event.getSource() == DamageSource.field_76379_h) {
      event.setAmount(event.getAmount() * Math.min(MathHelper.func_76129_c(size), size));
    } else {
      event.setAmount(event.getAmount() / MathHelper.func_76129_c(size));
    }
    
    if (event.getSource().func_76364_f() != null) {
      float attackerSize = EntitySizeUtil.getEntityScale(event.getSource().func_76364_f());
      
      event.setAmount(event.getAmount() * MathHelper.func_76129_c(size));
    }
  }
  
  @SubscribeEvent
  public static void entityInteract(PlayerInteractEvent.EntityInteract event) {
    if ((event.getTarget() != null) && 
      (EntitySizeUtil.getEntityScale(event.getEntityPlayer()) <= 0.33333F)) {
      EntityPlayer player = event.getEntityPlayer();
      Entity target = event.getTarget();
      
      if ((target.func_184222_aU()) && (!player.func_184586_b(event.getHand()).func_190926_b()) && 
        (player.func_184586_b(event.getHand()).func_77973_b() == Items.field_151007_F) && 
        (player.func_184220_m(target))) {
        event.setCancellationResult(EnumActionResult.SUCCESS);
      }
    }
  }
  
  @SubscribeEvent
  public static void entityMount(EntityMountEvent event)
  {
    if ((event.getEntityMounting() != null) && (event.getEntityBeingMounted() != null) && (event.isMounting())) {
      Entity entityMounting = event.getEntityMounting();
      float mountingSize = EntitySizeUtil.getEntityScale(entityMounting);
      Entity entityMounted = event.getEntityBeingMounted();
      float mountedSize = EntitySizeUtil.getEntityScale(entityMounted);
      
      if (mountingSize > mountedSize) {
        event.setCanceled(true);
      }
    }
  }
  
  @SubscribeEvent
  public static void playSoundAtEntity(PlaySoundAtEntityEvent event) {
    if ((event.getEntity() != null) && (event.getEntity().hasCapability(SizeProvider.sizeCapability, null))) {
      Entity entity = event.getEntity();
      float entitySize = EntitySizeUtil.getEntityScale(entity);
      
      event.setVolume(event.getVolume() * MathHelper.func_76129_c(entitySize));
      event.setPitch(event.getPitch() * entitySize);
    }
  }
  
  private static void setEntitySize(Entity entity, float width, float height) {
    if ((width != field_70130_N) || (height != field_70131_O)) {
      float f = field_70130_N;
      float f1 = field_70131_O;
      field_70130_N = width;
      field_70131_O = height;
      
      if (field_70130_N < f) {
        AxisAlignedBB axisalignedbb = entity.func_174813_aQ();
        if (!field_70170_p.field_72995_K) {
          field_70163_u += (f1 - field_70131_O) / 2.0F;
        }
        double d0 = width / 2.0D;
        entity.func_174826_a(new AxisAlignedBB(field_70165_t - d0, field_70163_u, field_70161_v - d0, field_70165_t + d0, field_70163_u + field_70131_O, field_70161_v + d0));
        
        return;
      }
      
      AxisAlignedBB axisalignedbb = entity.func_174813_aQ();
      



      double d0 = width / 2.0D;
      entity.func_174826_a(new AxisAlignedBB(field_70165_t - d0, field_70163_u, field_70161_v - d0, field_70165_t + d0, field_70163_u + field_70131_O, field_70161_v + d0));
    }
  }
  


  private static void updateSizePotionEffects(EntityLivingBase entity, ISizeCapability size)
  {
    int prevShrinkingAmp = entity.func_70660_b(PotionLilliputian.SHRINKING_POTION) != null ? entity.func_70660_b(PotionLilliputian.SHRINKING_POTION).func_76458_c() : shrinkingAmps.containsKey(entity) ? ((Integer)shrinkingAmps.get(entity)).intValue() : -1;
    

    int prevGrowingAmp = entity.func_70660_b(PotionLilliputian.GROWING_POTION) != null ? entity.func_70660_b(PotionLilliputian.GROWING_POTION).func_76458_c() : growingAmps.containsKey(entity) ? ((Integer)growingAmps.get(entity)).intValue() : -1;
    
    int shrinkingAmp = entity.func_70660_b(PotionLilliputian.SHRINKING_POTION) != null ? entity.func_70660_b(PotionLilliputian.SHRINKING_POTION).func_76458_c() : -1;
    
    int growingAmp = entity.func_70660_b(PotionLilliputian.GROWING_POTION) != null ? entity.func_70660_b(PotionLilliputian.GROWING_POTION).func_76458_c() : -1;
    
    if ((shrinkingAmp > -1) && (growingAmp > -1) && ((prevShrinkingAmp != shrinkingAmp) || (prevGrowingAmp != growingAmp)))
    {
      if (shrinkingAmp == growingAmp) {
        entity.func_184589_d(PotionLilliputian.GROWING_POTION);
        entity.func_184589_d(PotionLilliputian.SHRINKING_POTION);
      } else if (shrinkingAmp > growingAmp) {
        entity.func_184589_d(PotionLilliputian.GROWING_POTION);
        PotionEffect shrinking = entity.func_70660_b(PotionLilliputian.SHRINKING_POTION);
        int duration = shrinking.func_76459_b();
        boolean ambient = shrinking.func_82720_e();
        boolean particles = shrinking.func_188418_e();
        entity.func_184589_d(PotionLilliputian.SHRINKING_POTION);
        entity.func_70690_d(new PotionEffect(PotionLilliputian.SHRINKING_POTION, duration, shrinkingAmp + 1 - (growingAmp + 1) - 1, ambient, particles));
      }
      else if (shrinkingAmp < growingAmp) {
        entity.func_184589_d(PotionLilliputian.SHRINKING_POTION);
        PotionEffect growing = entity.func_70660_b(PotionLilliputian.GROWING_POTION);
        int duration = growing.func_76459_b();
        boolean ambient = growing.func_82720_e();
        boolean particles = growing.func_188418_e();
        entity.func_184589_d(PotionLilliputian.GROWING_POTION);
        entity.func_70690_d(new PotionEffect(PotionLilliputian.GROWING_POTION, duration, growingAmp + 1 - (shrinkingAmp + 1) - 1, ambient, particles));
      }
    }
    

    shrinkingAmp = entity.func_70660_b(PotionLilliputian.SHRINKING_POTION) != null ? entity.func_70660_b(PotionLilliputian.SHRINKING_POTION).func_76458_c() : -1;
    
    growingAmp = entity.func_70660_b(PotionLilliputian.GROWING_POTION) != null ? entity.func_70660_b(PotionLilliputian.GROWING_POTION).func_76458_c() : -1;
    
    if ((prevShrinkingAmp != shrinkingAmp) || (prevGrowingAmp != growingAmp)) {
      float potionScaling = 1.0F;
      float prevPotionScaling = 1.0F;
      if (shrinkingAmp > -1) {
        potionScaling /= Math.max((shrinkingAmp + 1) * 2, 0.125F / size.getBaseSize());
      }
      if (growingAmp > -1) {
        potionScaling *= Math.min((growingAmp + 1) * 2, 8.0F / size.getBaseSize());
      }
      if (prevShrinkingAmp > -1) {
        prevPotionScaling /= Math.max((prevShrinkingAmp + 1) * 2, 0.125F / size.getBaseSize());
      }
      if (prevGrowingAmp > -1) {
        prevPotionScaling *= Math.min((prevGrowingAmp + 1) * 2, 8.0F / size.getBaseSize());
      }
      

      size.setScale(size.getScale() * (potionScaling / prevPotionScaling));
      PacketHandler.INSTANCE
        .sendToAll(new MessageSizeChange(size.getBaseSize(), size.getScale(), entity.func_145782_y()));
    }
    
    if (field_70128_L) {
      shrinkingAmps.put(entity, Integer.valueOf(-1));
      growingAmps.put(entity, Integer.valueOf(-1));
    } else {
      shrinkingAmps.put(entity, Integer.valueOf(shrinkingAmp));
      growingAmps.put(entity, Integer.valueOf(growingAmp));
    }
  }
  
  private static void pushPlayerSPOutOfBlocks(EntityPlayer player, double x, double y, double z) {
    if (field_70145_X) {
      return;
    }
    BlockPos blockpos = new BlockPos(x, y, z);
    double d0 = x - blockpos.func_177958_n();
    double d1 = z - blockpos.func_177952_p();
    
    int entHeight = Math.max((int)Math.ceil(field_70131_O), 1);
    
    boolean inTranslucentBlock = !isHeadspaceFree(field_70170_p, blockpos, entHeight);
    
    if (inTranslucentBlock) {
      int i = -1;
      double d2 = 9999.0D;
      
      if ((isHeadspaceFree(field_70170_p, blockpos.func_177976_e(), entHeight)) && (d0 < d2)) {
        d2 = d0;
        i = 0;
      }
      
      if ((isHeadspaceFree(field_70170_p, blockpos.func_177974_f(), entHeight)) && (1.0D - d0 < d2)) {
        d2 = 1.0D - d0;
        i = 1;
      }
      
      if ((isHeadspaceFree(field_70170_p, blockpos.func_177978_c(), entHeight)) && (d1 < d2)) {
        d2 = d1;
        i = 4;
      }
      
      if ((isHeadspaceFree(field_70170_p, blockpos.func_177968_d(), entHeight)) && (1.0D - d1 < d2)) {
        d2 = 1.0D - d1;
        i = 5;
      }
      
      float f = 0.1F;
      
      if (i == 0) {
        field_70159_w = -0.10000000149011612D;
      }
      
      if (i == 1) {
        field_70159_w = 0.10000000149011612D;
      }
      
      if (i == 4) {
        field_70179_y = -0.10000000149011612D;
      }
      
      if (i == 5) {
        field_70179_y = 0.10000000149011612D;
      }
    }
  }
  
  private static boolean isHeadspaceFree(World world, BlockPos pos, int height)
  {
    for (int y = 0; y < height; y++) {
      if (!isOpenBlockSpace(world, pos.func_177982_a(0, y, 0))) {
        return false;
      }
    }
    return true;
  }
  
  private static boolean isOpenBlockSpace(World world, BlockPos pos) {
    IBlockState iblockstate = world.func_180495_p(pos);
    return !iblockstate.func_177230_c().isNormalCube(iblockstate, world, pos);
  }
}
