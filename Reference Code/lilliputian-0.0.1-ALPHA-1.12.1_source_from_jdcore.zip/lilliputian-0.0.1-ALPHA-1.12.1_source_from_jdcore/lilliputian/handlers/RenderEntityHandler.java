package lilliputian.handlers;

import java.util.ArrayList;
import lilliputian.util.EntitySizeUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.EntityLivingBase;
import net.minecraftforge.client.event.EntityViewRenderEvent.CameraSetup;
import net.minecraftforge.client.event.GuiScreenEvent.DrawScreenEvent.Post;
import net.minecraftforge.client.event.RenderLivingEvent.Pre;
import net.minecraftforge.client.event.RenderLivingEvent.Specials.Post;
import net.minecraftforge.client.event.RenderLivingEvent.Specials.Pre;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
@net.minecraftforge.fml.common.Mod.EventBusSubscriber(value={Side.CLIENT}, modid="lilliputian")
public class RenderEntityHandler
{
  public RenderEntityHandler() {}
  
  public static ArrayList<Multiplier> cache = new ArrayList();
  
  @SubscribeEvent
  public static void renderEntityPre(RenderLivingEvent.Pre event) {
    float scale = EntitySizeUtil.getEntityScale(event.getEntity());
    
    GlStateManager.func_179094_E();
    
    GlStateManager.func_179152_a(scale, scale, scale);
    GlStateManager.func_179137_b(event.getX() / scale - event.getX(), event.getY() / scale - event.getY(), event.getZ() / scale - event.getZ());
    if (event.getEntity().func_70093_af()) {
      GlStateManager.func_179109_b(0.0F, 0.125F / scale, 0.0F);
      GlStateManager.func_179109_b(0.0F, -0.125F, 0.0F);
    }
  }
  

  @SubscribeEvent
  public static void renderEntityPost(net.minecraftforge.client.event.RenderLivingEvent.Post event) {}
  
  @SubscribeEvent
  public static void renderEntityNamePre(RenderLivingEvent.Specials.Pre event)
  {
    float scale = EntitySizeUtil.getEntityScale(event.getEntity());
    
    GlStateManager.func_179094_E();
    
    boolean flag = event.getEntity().func_70093_af();
    float vanillaOffset = getEntityfield_70131_O + 0.5F - (flag ? 0.25F : 0.0F);
    
    GlStateManager.func_179109_b(0.0F, -vanillaOffset, 0.0F);
    
    float adjustedOffset = getEntityfield_70131_O / scale + 0.5F - (flag ? 0.25F : 0.0F);
    
    GlStateManager.func_179109_b(0.0F, adjustedOffset, 0.0F);
  }
  

  @SubscribeEvent
  public static void renderEntityNamePost(RenderLivingEvent.Specials.Post event) {}
  
  @SubscribeEvent
  public static void setupCamera(EntityViewRenderEvent.CameraSetup event)
  {
    float scale = EntitySizeUtil.getEntityScale(event.getEntity());
    
    if (((!(event.getEntity() instanceof EntityLivingBase)) || 
      (!((EntityLivingBase)event.getEntity()).func_70608_bn())) && 
      (func_71410_xfield_71474_y.field_74320_O == 0)) {
      GlStateManager.func_179109_b(0.0F, 0.0F, -0.05F);
      GlStateManager.func_179109_b(0.0F, 0.0F, scale * 0.05F);
    }
  }
  
  @SideOnly(Side.CLIENT)
  @SubscribeEvent
  public static void renderGui(GuiScreenEvent.DrawScreenEvent.Post event) {
    
    for (Multiplier m : cache) {
      int mouseX = event.getMouseX();
      int mouseY = event.getMouseY();
      
      if (((event.getGui() instanceof net.minecraft.client.gui.inventory.GuiInventory)) && (x - mouseX <= 12) && (mouseX - x <= 12) && (y - mouseY >= 0) && (y - mouseY <= 56)) {
        event.getGui().func_146279_a(string, mouseX, mouseY);
      } else if (((event.getGui() instanceof net.minecraft.client.gui.inventory.GuiContainerCreative)) && (x - mouseX <= 9) && (mouseX - x <= 9) && (y - mouseY >= 0) && (y - mouseY <= 38)) {
        event.getGui().func_146279_a(string, mouseX, mouseY);
      }
    }
    cache.clear();
  }
  
  @SideOnly(Side.CLIENT)
  public static void registerMultiplier(int x, int y, String string) {
    cache.add(new Multiplier(x, y, string));
  }
  
  private static class Multiplier {
    public int x;
    public int y;
    public String string;
    
    public Multiplier(int x, int y, String string) {
      this.x = x;
      this.y = y;
      this.string = string;
    }
  }
}
