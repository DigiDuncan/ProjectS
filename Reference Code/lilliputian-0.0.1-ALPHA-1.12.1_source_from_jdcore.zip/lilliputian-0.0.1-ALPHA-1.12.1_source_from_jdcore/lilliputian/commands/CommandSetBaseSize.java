package lilliputian.commands;

import java.util.Collections;
import java.util.List;
import javax.annotation.Nullable;
import lilliputian.capabilities.ISizeCapability;
import lilliputian.capabilities.SizeProvider;
import lilliputian.network.MessageSizeChange;
import lilliputian.network.PacketHandler;
import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.command.WrongUsageException;
import net.minecraft.entity.Entity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;

public class CommandSetBaseSize extends CommandBase
{
  public CommandSetBaseSize() {}
  
  public String func_71517_b()
  {
    return "setbasesize";
  }
  
  public int func_82362_a()
  {
    return 2;
  }
  
  public String func_71518_a(ICommandSender sender)
  {
    return "lilliputian.commands.setbasesize.usage";
  }
  
  public void func_184881_a(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException
  {
    if ((args.length < 1) || (args.length > 2)) {
      throw new WrongUsageException(func_71518_a(sender), new Object[0]);
    }
    int i = 0;
    Entity entity;
    Entity entity;
    if (args.length == 1) {
      entity = func_71521_c(sender);
    } else {
      entity = func_184885_b(server, sender, args[i]);
      i = 1;
    }
    
    if (entity.hasCapability(SizeProvider.sizeCapability, null)) {
      ISizeCapability cap = (ISizeCapability)entity.getCapability(SizeProvider.sizeCapability, null);
      
      if (args.length != i + 1) {
        throw new WrongUsageException(func_71518_a(sender), new Object[0]);
      }
      
      float newBaseSize = (float)func_175756_a(args[i], 0.125D, 8.0D);
      if (!field_70170_p.field_72995_K) {
        cap.setBaseSize(newBaseSize);
        PacketHandler.INSTANCE.sendToAll(new MessageSizeChange(cap.getBaseSize(), cap.getScale(), entity.func_145782_y()));
      }
    }
  }
  



  public List<String> func_184883_a(MinecraftServer server, ICommandSender sender, String[] args, @Nullable BlockPos targetPos)
  {
    return args.length != 1 ? Collections.emptyList() : func_71530_a(args, server.func_71213_z());
  }
  
  public boolean func_82358_a(String[] args, int index)
  {
    return index == 0;
  }
}
