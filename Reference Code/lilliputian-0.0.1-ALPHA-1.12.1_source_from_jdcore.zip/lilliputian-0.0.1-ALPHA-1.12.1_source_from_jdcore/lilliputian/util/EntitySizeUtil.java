package lilliputian.util;

import lilliputian.capabilities.ISizeCapability;
import lilliputian.capabilities.SizeProvider;
import lilliputian.handlers.RenderEntityHandler;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.util.DamageSource;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class EntitySizeUtil
{
  public static final float HARD_MIN = 0.125F;
  public static final float HARD_MAX = 8.0F;
  public static final float TINY_THRESHOLD = 0.33333F;
  public static final float HUGE_THRESHOLD = 3.0F;
  
  public EntitySizeUtil() {}
  
  public static float getEntityScale(Entity entity)
  {
    if (entity.hasCapability(SizeProvider.sizeCapability, null)) {
      ISizeCapability size = (ISizeCapability)entity.getCapability(SizeProvider.sizeCapability, null);
      
      return size.getActualSize();
    }
    return 1.0F;
  }
  
  public static float getEntityScaleRoot(Entity entity) {
    return MathHelper.func_76129_c(getEntityScale(entity));
  }
  
  public static double getEntityScaleDouble(Entity entity) {
    return getEntityScale(entity);
  }
  
  public static double getEntityScaleRootDouble(Entity entity) {
    return MathHelper.func_76133_a(getEntityScale(entity));
  }
  
  public static double getEntityScaleDoubleMin1(Entity entity) {
    return Math.min(getEntityScale(entity), 1.0D);
  }
  
  public static double getEntityScaleDoubleMax1(Entity entity) {
    return Math.max(getEntityScale(entity), 1.0D);
  }
  
  public static double getInverse(double d) {
    return 1.0D / d;
  }
  
  public static double getEntityYOffset(double origOffset, Entity entity) {
    double scale = getEntityScaleDouble(entity);
    double riddenScale = entity.func_184187_bx() != null ? getEntityScale(entity.func_184187_bx()) : 1.0D;
    

    double d = 0.23125D * riddenScale - origOffset;
    return origOffset + (1.0D / scale - 1.0D) * (d * (field_70131_O / 2.0F)) + (riddenScale - 1.0D) * 0.225D * scale;
  }
  
  @SideOnly(Side.CLIENT)
  public static float getCameraNearPlane() {
    return 0.05F * Math.min(getEntityScale(Minecraft.func_71410_x().func_175606_aa()), 1.0F);
  }
  
  @SideOnly(Side.CLIENT)
  public static float getViewEntityScale() {
    return getEntityScale(Minecraft.func_71410_x().func_175606_aa());
  }
  
  @SideOnly(Side.CLIENT)
  public static float getViewEntityScaleRoot() {
    return MathHelper.func_76129_c(getEntityScale(Minecraft.func_71410_x().func_175606_aa()));
  }
  
  @SideOnly(Side.CLIENT)
  public static double getViewEntityScaleRootDouble() {
    return MathHelper.func_76133_a(getEntityScale(Minecraft.func_71410_x().func_175606_aa()));
  }
  
  @SideOnly(Side.CLIENT)
  public static double getMaxReach() {
    return 3.0D * MathHelper.func_76133_a(getEntityScale(Minecraft.func_71410_x().func_175606_aa()));
  }
  
  @SideOnly(Side.CLIENT)
  public static double getExtendedReach() {
    return 6.0D * MathHelper.func_76133_a(getEntityScale(Minecraft.func_71410_x().func_175606_aa()));
  }
  
  public static void attemptCactusDamage(Entity entity) {
    if ((getEntityScale(entity) > 0.33333F) && (getEntityScale(entity) < 3.0F)) {
      entity.func_70097_a(DamageSource.field_76367_g, 1.0F);
    }
  }
  
  @SideOnly(Side.CLIENT)
  public static void doRenderEntity(Entity entityIn, int x, int y, int z, float yaw, float partialTicks, boolean p_188391_10_) {
    RenderManager rendermanager = Minecraft.func_71410_x().func_175598_ae();
    float scale = 1.0F / getEntityScale(entityIn);
    GlStateManager.func_179152_a(scale, scale, scale);
    rendermanager.func_188391_a(entityIn, 0.0D, 0.0D, 0.0D, yaw, partialTicks, p_188391_10_);
    RenderEntityHandler.registerMultiplier(x, y, "x" + getEntityScale(entityIn));
  }
  
  public static boolean isOnLadder(Entity entity) {
    if (((entity instanceof EntityPlayer)) && (getEntityScale(entity) <= 0.33333F) && (field_70123_F)) {
      EntityPlayer player = (EntityPlayer)entity;
      return (player.func_184614_ca().func_77973_b() == Items.field_151123_aH) && (player.func_184592_cb().func_77973_b() == Items.field_151123_aH);
    }
    return false;
  }
}
