package lilliputian.capabilities;

import net.minecraft.nbt.NBTBase;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.EnumFacing;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.Capability.IStorage;

public class SizeCapabilityStorage implements Capability.IStorage<ISizeCapability>
{
  public static final SizeCapabilityStorage storage = new SizeCapabilityStorage();
  
  public SizeCapabilityStorage() {}
  
  public NBTBase writeNBT(Capability<ISizeCapability> capability, ISizeCapability instance, EnumFacing side) { NBTTagCompound tag = new NBTTagCompound();
    tag.func_74776_a("scale", instance.getScale());
    tag.func_74776_a("base_size", instance.getBaseSize());
    return tag;
  }
  

  public void readNBT(Capability<ISizeCapability> capability, ISizeCapability instance, EnumFacing side, NBTBase nbt)
  {
    if ((nbt instanceof NBTTagCompound)) {
      NBTTagCompound tag = (NBTTagCompound)nbt;
      if (tag.func_150297_b("scale", 5)) {
        instance.setScale(tag.func_74760_g("scale"));
        instance.setActualScale(tag.func_74760_g("scale"));
      }
      if (tag.func_150297_b("base_size", 5)) {
        instance.setBaseSize(tag.func_74760_g("base_size"));
      }
    }
  }
}
