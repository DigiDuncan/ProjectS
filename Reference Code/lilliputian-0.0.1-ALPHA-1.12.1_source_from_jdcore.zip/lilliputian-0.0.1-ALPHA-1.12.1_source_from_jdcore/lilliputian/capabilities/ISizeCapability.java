package lilliputian.capabilities;

import net.minecraft.nbt.NBTTagCompound;

public abstract interface ISizeCapability
{
  public abstract float getBaseSize();
  
  public abstract float getScale();
  
  public abstract void setBaseSize(float paramFloat);
  
  public abstract void setScale(float paramFloat);
  
  public abstract void setScaleNoMorph(float paramFloat);
  
  public abstract float getActualSize();
  
  public abstract float getActualScale();
  
  public abstract float getActualScaleNoClamp();
  
  public abstract void setActualScale(float paramFloat);
  
  public abstract float getPrevScale();
  
  public abstract int getMorphTime();
  
  public abstract int getMaxMorphTime();
  
  public abstract void setMorphing();
  
  public abstract void incrementMorphTime();
  
  public abstract NBTTagCompound saveNBT();
  
  public abstract void loadNBT(NBTTagCompound paramNBTTagCompound);
}
