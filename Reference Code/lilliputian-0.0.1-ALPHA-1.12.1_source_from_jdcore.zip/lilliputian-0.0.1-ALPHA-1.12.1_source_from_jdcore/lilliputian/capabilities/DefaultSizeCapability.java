package lilliputian.capabilities;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.math.MathHelper;


public class DefaultSizeCapability
  implements ISizeCapability
{
  private float baseSize = 1.0F;
  private float scale = 1.0F;
  private float actualScale = 1.0F;
  private float prevScale = 1.0F;
  
  private int morphTime = 0;
  

  public DefaultSizeCapability() {}
  
  public DefaultSizeCapability(float baseSize)
  {
    this.baseSize = baseSize;
  }
  
  public float getBaseSize()
  {
    return baseSize;
  }
  
  public float getScale()
  {
    return scale;
  }
  
  public void setBaseSize(float baseSize)
  {
    if (this.baseSize != baseSize) {
      this.baseSize = MathHelper.func_76131_a(baseSize, 0.125F, 8.0F);
    }
  }
  
  public void setScale(float scale)
  {
    if (this.scale != scale)
    {
      prevScale = this.scale;
      
      this.scale = scale;
      setMorphing();
    }
  }
  
  public void setScaleNoMorph(float scale)
  {
    if (this.scale != scale)
    {
      prevScale = this.scale;
      
      this.scale = scale;
      actualScale = this.scale;
    }
  }
  
  public float getActualSize()
  {
    return getActualScale() * baseSize;
  }
  

  public float getActualScale()
  {
    return MathHelper.func_76131_a(actualScale, 0.125F / baseSize, 8.0F / baseSize);
  }
  
  public float getActualScaleNoClamp()
  {
    return actualScale;
  }
  
  public void setActualScale(float actualScale)
  {
    this.actualScale = actualScale;
  }
  
  public float getPrevScale()
  {
    return prevScale;
  }
  
  public int getMorphTime()
  {
    return morphTime;
  }
  
  public int getMaxMorphTime()
  {
    return 20;
  }
  
  public void setMorphing()
  {
    morphTime = getMaxMorphTime();
  }
  
  public void incrementMorphTime()
  {
    if (morphTime > 0) {
      morphTime -= 1;
    }
    if (morphTime < 0) {
      morphTime = 0;
    }
  }
  
  public NBTTagCompound saveNBT()
  {
    return (NBTTagCompound)SizeCapabilityStorage.storage.writeNBT(SizeProvider.sizeCapability, this, null);
  }
  
  public void loadNBT(NBTTagCompound compound)
  {
    SizeCapabilityStorage.storage.readNBT(SizeProvider.sizeCapability, this, null, compound);
  }
}
