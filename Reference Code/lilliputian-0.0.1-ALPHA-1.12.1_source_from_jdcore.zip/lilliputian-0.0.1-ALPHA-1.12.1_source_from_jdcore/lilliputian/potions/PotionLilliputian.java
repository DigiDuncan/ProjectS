package lilliputian.potions;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.potion.PotionType;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class PotionLilliputian extends Potion
{
  public static ResourceLocation POTION_ICONS = new ResourceLocation("lilliputian", "textures/gui/potion_icons.png");
  
  public PotionLilliputian(boolean isBadEffect, int color, String name) {
    super(isBadEffect, color);
    func_76390_b("effect." + name);
    if (!isBadEffect) {
      func_188413_j();
    }
  }
  
  public PotionLilliputian setIconIndex(int x, int y) {
    super.func_76399_b(x, y);
    return this;
  }
  
  @SideOnly(Side.CLIENT)
  public int func_76392_e()
  {
    Minecraft.func_71410_x().func_110434_K().func_110577_a(POTION_ICONS);
    return super.func_76392_e();
  }
  
  public static final Potion SHRINKING_POTION = (Potion)new PotionLilliputian(false, 12779775, "shrinking").setIconIndex(0, 0).setRegistryName(new ResourceLocation("lilliputian", "shrinking"));
  public static final Potion GROWING_POTION = (Potion)new PotionLilliputian(false, 65415, "growing").setIconIndex(1, 0).setRegistryName(new ResourceLocation("lilliputian", "growing"));
  
  public static final PotionType SHRINKING = (PotionType)new PotionType("shrinking", new PotionEffect[] { new PotionEffect(SHRINKING_POTION, 3600, 0) }).setRegistryName(new ResourceLocation("lilliputian", "shrinking"));
  public static final PotionType LONG_SHRINKING = (PotionType)new PotionType("shrinking", new PotionEffect[] { new PotionEffect(SHRINKING_POTION, 9600, 0) }).setRegistryName(new ResourceLocation("lilliputian", "long_shrinking"));
  public static final PotionType STRONG_SHRINKING = (PotionType)new PotionType("shrinking", new PotionEffect[] { new PotionEffect(SHRINKING_POTION, 1800, 1) }).setRegistryName(new ResourceLocation("lilliputian", "strong_shrinking"));
  
  public static final PotionType GROWING = (PotionType)new PotionType("growing", new PotionEffect[] { new PotionEffect(GROWING_POTION, 3600, 0) }).setRegistryName(new ResourceLocation("lilliputian", "growing"));
  public static final PotionType LONG_GROWING = (PotionType)new PotionType("growing", new PotionEffect[] { new PotionEffect(GROWING_POTION, 9600, 0) }).setRegistryName(new ResourceLocation("lilliputian", "long_growing"));
  public static final PotionType STRONG_GROWING = (PotionType)new PotionType("growing", new PotionEffect[] { new PotionEffect(GROWING_POTION, 1800, 1) }).setRegistryName(new ResourceLocation("lilliputian", "strong_growing"));
}
