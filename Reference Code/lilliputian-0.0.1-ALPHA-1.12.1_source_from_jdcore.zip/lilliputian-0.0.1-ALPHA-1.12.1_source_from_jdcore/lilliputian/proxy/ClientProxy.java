package lilliputian.proxy;

import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

public class ClientProxy extends CommonProxy
{
  public ClientProxy() {}
  
  public void preInit(FMLPreInitializationEvent event)
  {
    super.preInit(event);
  }
  

  public void init(net.minecraftforge.fml.common.event.FMLInitializationEvent event)
  {
    super.init(event);
  }
  

  public void postInit(net.minecraftforge.fml.common.event.FMLPostInitializationEvent event)
  {
    super.postInit(event);
  }
}
