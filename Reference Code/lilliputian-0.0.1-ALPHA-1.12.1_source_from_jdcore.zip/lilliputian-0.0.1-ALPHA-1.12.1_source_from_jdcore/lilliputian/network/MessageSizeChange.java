package lilliputian.network;

import io.netty.buffer.ByteBuf;
import lilliputian.capabilities.ISizeCapability;
import lilliputian.capabilities.SizeProvider;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.entity.Entity;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;



public class MessageSizeChange
  implements IMessage
{
  public float baseSize = 1.0F;
  public float scale = 1.0F;
  public int entityID = 0;
  public boolean morph = true;
  

  public MessageSizeChange() {}
  
  public MessageSizeChange(float baseSize, float scale, int id)
  {
    this.baseSize = baseSize;
    this.scale = scale;
    entityID = id;
    morph = true;
  }
  
  public MessageSizeChange(float baseSize, float scale, int id, boolean morph) {
    this.baseSize = baseSize;
    this.scale = scale;
    entityID = id;
    this.morph = morph;
  }
  
  public void fromBytes(ByteBuf buf)
  {
    baseSize = buf.readFloat();
    scale = buf.readFloat();
    entityID = buf.readInt();
    morph = buf.readBoolean();
  }
  
  public void toBytes(ByteBuf buf)
  {
    buf.writeFloat(baseSize);
    buf.writeFloat(scale);
    buf.writeInt(entityID);
    buf.writeBoolean(morph);
  }
  
  public static class MessageHolder implements IMessageHandler<MessageSizeChange, IMessage> {
    public MessageHolder() {}
    
    public IMessage onMessage(MessageSizeChange message, MessageContext ctx) {
      if ((func_71410_xfield_71441_e != null) && (func_71410_xfield_71439_g != null))
      {

        Entity entity = func_71410_xfield_71441_e.func_73045_a(entityID);
        
        if ((entity != null) && (entity.hasCapability(SizeProvider.sizeCapability, null))) {
          ISizeCapability size = (ISizeCapability)entity.getCapability(SizeProvider.sizeCapability, null);
          
          if (size.getBaseSize() != baseSize) {
            size.setBaseSize(baseSize);
          }
          if (size.getScale() != scale) {
            if (morph) {
              size.setScale(scale);
            } else {
              size.setScaleNoMorph(scale);
            }
          }
        }
      }
      return null;
    }
  }
}
