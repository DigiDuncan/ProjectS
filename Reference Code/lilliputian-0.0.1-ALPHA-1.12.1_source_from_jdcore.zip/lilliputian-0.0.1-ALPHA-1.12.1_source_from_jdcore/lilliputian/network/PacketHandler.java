package lilliputian.network;

import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;

public class PacketHandler
{
  public PacketHandler() {}
  
  public static SimpleNetworkWrapper INSTANCE = NetworkRegistry.INSTANCE.newSimpleChannel("lilliputian");
  
  private static int id = 0;
  
  public static void registerMessages() {
    INSTANCE.registerMessage(MessageSizeChange.MessageHolder.class, MessageSizeChange.class, id++, net.minecraftforge.fml.relauncher.Side.CLIENT);
  }
}
